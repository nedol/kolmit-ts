import{s as Y,n as I}from"../chunks/BFS4dl8i.js";import{S as U,i as G,d as O,a as Q,b as t,k as g,y,c as n,e as K,w as o,g as b,h as a,j as k}from"../chunks/B2NxKjp4.js";const X=!1,et=Object.freeze(Object.defineProperty({__proto__:null,prerender:X},Symbol.toStringTag,{value:"Module"}));function Z(V){let l,_,P='<meta charset="UTF-8"/> <meta name="viewport" content="width=device-width, initial-scale=1.0"/> <title>Домашняя страница Kolmit</title> <link rel="stylesheet" href="styles.css"/>',E,e,p,z="<h1>Добро пожаловать в Kolmit</h1> <p>Ваше приложение для изучения иностранных языков</p>",j,x,w='<ul class="svelte-19uk3xr"><li class="svelte-19uk3xr"><a href="#" class="svelte-19uk3xr">Главная</a></li> <li class="svelte-19uk3xr"><a href="#" class="svelte-19uk3xr">О нас</a></li> <li class="svelte-19uk3xr"><a href="#" class="svelte-19uk3xr">Учебные материалы</a></li> <li class="svelte-19uk3xr"><a href="#" class="svelte-19uk3xr">Контакты</a></li></ul>',H,m,q=`<section class="svelte-19uk3xr"><h2>О нас</h2> <p id="about-text">Мы - команда разработчиков, увлеченных изучением иностранных языков. Наше приложение
					Kolmit создано для того, чтобы помочь вам в этом нелегком деле.</p></section> <section class="svelte-19uk3xr"><h2>Учебные материалы</h2> <p id="materials-text">У нас есть обширная библиотека учебных материалов на различных языках. Вы можете начать
					изучение прямо сейчас!</p></section>`,M,h,A="<p>© 2024 Kolmit. Все права защищены.</p>",N,r,i,B="Русский",u,W="English",d,D="Nederlands",c,F="Español",v,R="Français",S,f,J=`// JavaScript для изменения контента при выборе языка\r
			const languageSelect = document.getElementById('language-select');\r
			const aboutText = document.getElementById('about-text');\r
			const materialsText = document.getElementById('materials-text');\r
\r
			languageSelect.addEventListener('change', function () {\r
				const selectedLanguage = languageSelect.value;\r
\r
				if (selectedLanguage === 'ru') {\r
					aboutText.textContent =\r
						'Мы - команда разработчиков, увлеченных изучением иностранных языков. Наше приложение Kolmit создано для того, чтобы помочь вам в этом нелегком деле.';\r
					materialsText.textContent =\r
						'У нас есть обширная библиотека учебных материалов на различных языках. Вы можете начать изучение прямо сейчас!';\r
				} else if (selectedLanguage === 'en') {\r
					aboutText.textContent =\r
						'We are a team of developers passionate about learning foreign languages. Our Kolmit app is designed to help you in this challenging endeavor.';\r
					materialsText.textContent =\r
						'We have an extensive library of educational materials in various languages. You can start learning right now!';\r
				} else if (selectedLanguage === 'nl') {\r
					aboutText.textContent =\r
						'Wij zijn een team van ontwikkelaars die gepassioneerd zijn over het leren van vreemde talen. Onze Kolmit-app is ontworpen om je te helpen bij deze uitdagende onderneming.';\r
					materialsText.textContent =\r
						'We hebben een uitgebreide bibliotheek met educatief materiaal in verschillende talen. Je kunt nu beginnen met leren!';\r
				} else if (selectedLanguage === 'es') {\r
					aboutText.textContent =\r
						'Somos un equipo de desarrolladores apasionados por aprender idiomas extranjeros. Nuestra aplicación Kolmit está diseñada para ayudarte en este desafiante proceso.';\r
					materialsText.textContent =\r
						'Tenemos una amplia biblioteca de materiales educativos en varios idiomas. ¡Puedes comenzar a aprender ahora mismo!';\r
				} else if (selectedLanguage === 'fr') {\r
					aboutText.textContent =\r
						"Nous sommes une équipe de développeurs passionnés par l'apprentissage des langues étrangères. Notre application Kolmit est conçue pour vous aider dans cette entreprise exigeante.";\r
					materialsText.textContent =\r
						'Nous avons une vaste bibliothèque de matériel éducatif dans diverses langues. Vous pouvez commencer à apprendre dès maintenant !';\r
				}\r
			});`;return{c(){l=a("html"),_=a("head"),_.innerHTML=P,E=k(),e=a("body"),p=a("header"),p.innerHTML=z,j=k(),x=a("nav"),x.innerHTML=w,H=k(),m=a("main"),m.innerHTML=q,M=k(),h=a("footer"),h.innerHTML=A,N=k(),r=a("select"),i=a("option"),i.textContent=B,u=a("option"),u.textContent=W,d=a("option"),d.textContent=D,c=a("option"),c.textContent=F,v=a("option"),v.textContent=R,S=k(),f=a("script"),f.textContent=J,this.h()},l(L){l=n(L,"HTML",{lang:!0});var C=K(l);_=n(C,"HEAD",{"data-svelte-h":!0}),o(_)!=="svelte-xut2jm"&&(_.innerHTML=P),E=b(C),e=n(C,"BODY",{});var s=K(e);p=n(s,"HEADER",{class:!0,"data-svelte-h":!0}),o(p)!=="svelte-10gip9a"&&(p.innerHTML=z),j=b(s),x=n(s,"NAV",{class:!0,"data-svelte-h":!0}),o(x)!=="svelte-ny1ykt"&&(x.innerHTML=w),H=b(s),m=n(s,"MAIN",{class:!0,"data-svelte-h":!0}),o(m)!=="svelte-k20qj1"&&(m.innerHTML=q),M=b(s),h=n(s,"FOOTER",{class:!0,"data-svelte-h":!0}),o(h)!=="svelte-3e0agz"&&(h.innerHTML=A),N=b(s),r=n(s,"SELECT",{id:!0,class:!0});var T=K(r);i=n(T,"OPTION",{"data-svelte-h":!0}),o(i)!=="svelte-kb8mvn"&&(i.textContent=B),u=n(T,"OPTION",{"data-svelte-h":!0}),o(u)!=="svelte-1bjraht"&&(u.textContent=W),d=n(T,"OPTION",{"data-svelte-h":!0}),o(d)!=="svelte-hi7116"&&(d.textContent=D),c=n(T,"OPTION",{"data-svelte-h":!0}),o(c)!=="svelte-128r36l"&&(c.textContent=F),v=n(T,"OPTION",{"data-svelte-h":!0}),o(v)!=="svelte-r9p3ar"&&(v.textContent=R),T.forEach(O),S=b(s),f=n(s,"SCRIPT",{"data-svelte-h":!0}),o(f)!=="svelte-lqsuaj"&&(f.textContent=J),s.forEach(O),C.forEach(O),this.h()},h(){g(p,"class","svelte-19uk3xr"),g(x,"class","svelte-19uk3xr"),g(m,"class","svelte-19uk3xr"),g(h,"class","svelte-19uk3xr"),i.__value="ru",y(i,i.__value),u.__value="en",y(u,u.__value),d.__value="nl",y(d,d.__value),c.__value="es",y(c,c.__value),v.__value="fr",y(v,v.__value),g(r,"id","language-select"),g(r,"class","svelte-19uk3xr"),g(l,"lang","ru")},m(L,C){Q(L,l,C),t(l,_),t(l,E),t(l,e),t(e,p),t(e,j),t(e,x),t(e,H),t(e,m),t(e,M),t(e,h),t(e,N),t(e,r),t(r,i),t(r,u),t(r,d),t(r,c),t(r,v),t(e,S),t(e,f)},p:I,i:I,o:I,d(L){L&&O(l)}}}class nt extends U{constructor(l){super(),G(this,l,null,Z,Y,{})}}export{nt as component,et as universal};
//# sourceMappingURL=7.CRZVl2iG.js.map
