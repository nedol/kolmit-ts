import { w as writable } from './index2-Iz8xeDhy.js';

let operatorst = writable();
let editable = writable(false);
let view = writable("group");
let nlang = writable("en");
let langs = writable("en");
let llang = writable("en");
let posterst = writable();
let msg = writable();
let signal = writable();
let dicts = writable();
let users = writable({});
let call_but_status = writable("inactive");
let ice_conf = writable();
let rtcPool_st = writable({});
let lesson = writable({ visible: true, data: "" });
let click_call_func = writable();
let dc = writable();
let dc_state = writable("close");
let sql_st = writable();
let muted = writable(true);
let showBottomAppBar = writable(true);
let OnCheckQU = writable();

export { OnCheckQU as O, signal as a, lesson as b, showBottomAppBar as c, dicts as d, editable as e, call_but_status as f, click_call_func as g, dc_state as h, ice_conf as i, llang as j, dc as k, langs as l, msg as m, muted as n, operatorst as o, posterst as p, nlang as q, rtcPool_st as r, sql_st as s, users as u, view as v };
//# sourceMappingURL=stores-9atq2JWj.js.map
