const prerender = false;

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  prerender: prerender
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CJiuDl_Z.js')).default;
const universal_id = "src/routes/site/+page.js";
const imports = ["_app/immutable/nodes/7.CRZVl2iG.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js"];
const stylesheets = ["_app/immutable/assets/7.YDbPBxg_.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=7-ByV8a7M5.js.map
