import { T as Translate } from './db-LknqzByu.js';
import 'lodash';
import 'md5';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

async function POST({ url, fetch, cookies, request }) {
  let { question } = await request.json();
  let resp = await Translate(
    question.text,
    question.from_lang,
    question.to_lang
  );
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}

export { POST };
//# sourceMappingURL=_server-CUphjZHb.js.map
