import md5 from 'md5';
import { d as dict } from './dict-DqfG9VE-.js';
import { C as CreatePool_neon, G as GetGroup } from './db-LknqzByu.js';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

const prerender = false;
const ssr = false;

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  prerender: prerender,
  ssr: ssr
});

let ice_conf = {
  stun: [
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun2.l.google.com:19302" },
    { urls: "stun:stun3.l.google.com:19302" },
    { urls: "stun:stun4.l.google.com:19302" }
  ],
  turn: [
    {
      urls: "turn:relay1.expressturn.com:3478?transport=tcp",
      username: "ef0ZUU5G66E1O9IV3Z",
      credential: "jE9btE3On6i5nLz0"
    },
    {
      urls: "turn:kolmit-server.onrender.com:3000?transport=udp",
      username: "username",
      credential: "password"
    },
    {
      urls: "turn:kolmit-server.onrender.com:3000?transport=tcp",
      username: "username",
      credential: "password"
    }
  ],
  lifetimeDuration: "86400s"
};
let kolmit;
async function load({ fetch, cookies, route, url }) {
  let res;
  let abonent = url.searchParams.get("abonent");
  let lang = url.searchParams.get("lang");
  let name = url.searchParams.get("name");
  let operator = url.searchParams.get("operator");
  let psw = url.searchParams.get("psw");
  let lvl = url.searchParams.get("lvl") ? url.searchParams.get("lvl") : "";
  new Promise((resolve, reject) => {
    console.log(url.hostname);
    CreatePool_neon();
  }).catch((error) => console.error("Ошибка:", error));
  const host = url.origin;
  let resp = {
    dict,
    ice_conf
  };
  try {
    if (lvl) {
      res = cookies.get(`${lvl}.kolmit.operator.${abonent}`);
      if (!res) {
      }
    } else {
      if (!res) {
        res = cookies.get(`kolmit.operator.${abonent}`);
      }
      if (!res) {
        res = cookies.get("kolmit.operator:" + abonent);
        if (res) {
          cookies.set("kolmit.operator." + abonent, res, {
            path: "/",
            maxAge: 60 * 60 * 24 * 400
          });
          cookies.delete("kolmit.operator:" + abonent, {
            path: "/"
          });
        }
      }
    }
    if (psw) {
      kolmit = { operator, psw: md5(psw), name, lang };
    } else {
      if (res) {
        kolmit = JSON.parse(res);
      } else {
        resp.check = false;
        resp.operator = "";
        resp.abonent = abonent;
        resp.operators = "{}";
        resp.dict = dict;
        return resp;
      }
    }
  } catch (ex) {
    console.log();
  }
  let params = {
    operator: kolmit.operator,
    abonent,
    psw: kolmit.psw
  };
  let { group, oper } = await GetGroup(params);
  return {
    check: true,
    host,
    // url: decodeURIComponent(url.toString()),
    lvl,
    cookies: res,
    operator: oper,
    abonent,
    dict,
    group,
    ice_conf
  };
}

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-5vTtzJze.js')).default;
const universal_id = "src/routes/+page.js";
const server_id = "src/routes/+page.server.ts";
const imports = ["_app/immutable/nodes/3.kD-QQMzP.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js","_app/immutable/chunks/CnDslQqG.js","_app/immutable/chunks/C-TImyHC.js","_app/immutable/chunks/CjtaZ3kr.js","_app/immutable/chunks/DtRdbcpU.js"];
const stylesheets = ["_app/immutable/assets/3.BwqpBcPK.css","_app/immutable/assets/index.CI7HwAql.css"];
const fonts = ["_app/immutable/assets/icofont.CegLT4Ez.woff2","_app/immutable/assets/icofont.CRj9mKsw.woff"];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=3-C0Vme7Cj.js.map
