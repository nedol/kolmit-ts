import { dirname } from 'path';
import { fileURLToPath } from 'url';
import 'iso-google-locales';
import { T as Translate } from './db-LknqzByu.js';
import { C as Client } from './index-7vFat6VW.js';
import { config } from 'dotenv';
import { HfInference } from '@huggingface/inference';
import 'lodash';
import 'md5';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

const __filename = fileURLToPath(import.meta.url);
dirname(__filename);
config();
const HF_TOKEN = process.env.HF_TOKEN_2;
const inference = new HfInference(HF_TOKEN);
async function POST({ url, fetch: fetch2, cookies, request }) {
  const formData = await request.formData();
  const fileContent = formData.get("file");
  const from_lang = formData.get("from_lang");
  const to_lang = formData.get("to_lang");
  const buffer = await fileContent.arrayBuffer();
  const nodeBuffer = Buffer.from(buffer);
  const blob = new Blob([nodeBuffer]);
  const arrayBuffer = await blob.arrayBuffer();
  await URL.createObjectURL(blob);
  let resp;
  if (from_lang == "_en") {
    resp = await stt_en(arrayBuffer, from_lang);
    if (resp) {
      resp = {
        [from_lang]: resp.text,
        [to_lang]: await Translate(resp.text, from_lang, to_lang)
      };
    }
  } else if (from_lang == "nl") {
    const result = await stt_karim_space(blob);
    //!
    if (result) {
      resp = {
        [from_lang]: result
        // [to_lang]: await Translate(result, from_lang, to_lang),
      };
    }
  } else {
    const result = await stt_whisper(arrayBuffer);
    if (result) {
      resp = {
        [from_lang]: result,
        [to_lang]: await Translate(result, from_lang, to_lang)
      };
    }
  }
  console.log(resp);
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
async function stt_whisper(blob, from_lang, to_lang) {
  const response = await fetch(
    "https://api-inference.huggingface.co/models/openai/whisper-large-v3",
    // "https://api-inference.huggingface.co/models/openai/whisper-small",
    {
      headers: {
        Authorization: "Bearer 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",
        "Content-Type": "application/json"
      },
      method: "POST",
      body: blob
    }
  );
  const result = await response.json();
  return result.text;
}
async function stt_karim_space(arrayBuffer, from_lang, to_lang) {
  const client = await Client.connect("MelikaNLP/Persian_Automatic_Speech_Recognition-asr");
  const result = await client.predict("/g_rec", {
    audio_File: arrayBuffer,
    language: "nl-BE"
  });
  if (!result.data[0].includes("Exception:"))
    return result.data[0].replace("Text:", "").trim();
}
async function stt_en(arrayBuffer, from_lang) {
  try {
    return await inference.automaticSpeechRecognition({
      data: arrayBuffer,
      model: "openai/whisper-large-v3",
      language: from_lang
    });
  } catch (ex) {
    console.log(ex);
  }
}

export { POST };
//# sourceMappingURL=_server-B1YbvtEs.js.map
