const DEV = false;

export { DEV as D };
//# sourceMappingURL=false-B2gHlHjM.js.map
