const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-HdPICp3h.js')).default;
const imports = ["_app/immutable/nodes/2.Db32UqnW.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js"];
const stylesheets = ["_app/immutable/assets/2.lWokVH0X.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-wrRxY3Nd.js.map
