import { s as subscribe, a as set_store_value, i as is_promise, b as noop, c as compute_rest_props, n as null_to_empty } from './utils-DaVwj2Zu.js';
import { c as create_ssr_component, v as validate_component, e as escape, b as each, s as setContext, o as onDestroy, a as add_attribute, d as get_current_component, f as spread, h as escape_attribute_value, i as escape_object, g as getContext, m as missing_component } from './ssr2-CjWPy-sK.js';
import { a as TopAppBar, R as Row, S as Section, b as Title, T as Translate, A as Accordion, h as Panel, H as Header$1, g as Content, f as Card, e as CommonLabel, c as Item, n as Image, d as Supporting, I as IconButton, j as Menu, L as List, k as Item$1, l as Text, i as Checkbox, C as CommonIcon, P as Paper } from './Checkbox-DH6qE2ah.js';
import { q as nlang, l as langs, d as dicts, v as view, b as lesson, j as llang, h as dc_state, f as call_but_status } from './stores-9atq2JWj.js';
import ISO6391 from 'iso-google-locales';
import './client-QR49yHlf.js';
import { _ as __extends, a as __assign, M as MDCFoundation, T as Textfield, B as Button, f as forwardEventsBuilder, c as classMap, e as exclude, g as globals, p as prefixFilter, S as SmuiElement, R as Ripple } from './Textfield-CFaEN1yp.js';
import pkg from 'lodash';
import { mdiAccountMultiple, mdiTextBoxOutline, mdiFileWordBoxOutline } from '@mdi/js';
import './index2-Iz8xeDhy.js';
import './exports-DVe6os7E.js';

/**!
 * Sortable 1.15.6
 * @author	RubaXa   <trash@rubaxa.org>
 * @author	owenm    <owen23355@gmail.com>
 * @license MIT
 */
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }
    keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};
    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }
  return target;
}
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }
  return _typeof(obj);
}
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;
  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }
  return target;
}
function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;
  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }
  return target;
}

var version = "1.15.6";

function userAgent(pattern) {
  if (typeof window !== 'undefined' && window.navigator) {
    return !! /*@__PURE__*/navigator.userAgent.match(pattern);
  }
}
var IE11OrLess = userAgent(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i);
var Edge = userAgent(/Edge/i);
var FireFox = userAgent(/firefox/i);
var Safari = userAgent(/safari/i) && !userAgent(/chrome/i) && !userAgent(/android/i);
var IOS = userAgent(/iP(ad|od|hone)/i);
var ChromeForAndroid = userAgent(/chrome/i) && userAgent(/android/i);

var captureMode = {
  capture: false,
  passive: false
};
function on(el, event, fn) {
  el.addEventListener(event, fn, !IE11OrLess && captureMode);
}
function off(el, event, fn) {
  el.removeEventListener(event, fn, !IE11OrLess && captureMode);
}
function matches( /**HTMLElement*/el, /**String*/selector) {
  if (!selector) return;
  selector[0] === '>' && (selector = selector.substring(1));
  if (el) {
    try {
      if (el.matches) {
        return el.matches(selector);
      } else if (el.msMatchesSelector) {
        return el.msMatchesSelector(selector);
      } else if (el.webkitMatchesSelector) {
        return el.webkitMatchesSelector(selector);
      }
    } catch (_) {
      return false;
    }
  }
  return false;
}
function getParentOrHost(el) {
  return el.host && el !== document && el.host.nodeType ? el.host : el.parentNode;
}
function closest( /**HTMLElement*/el, /**String*/selector, /**HTMLElement*/ctx, includeCTX) {
  if (el) {
    ctx = ctx || document;
    do {
      if (selector != null && (selector[0] === '>' ? el.parentNode === ctx && matches(el, selector) : matches(el, selector)) || includeCTX && el === ctx) {
        return el;
      }
      if (el === ctx) break;
      /* jshint boss:true */
    } while (el = getParentOrHost(el));
  }
  return null;
}
var R_SPACE = /\s+/g;
function toggleClass(el, name, state) {
  if (el && name) {
    if (el.classList) {
      el.classList[state ? 'add' : 'remove'](name);
    } else {
      var className = (' ' + el.className + ' ').replace(R_SPACE, ' ').replace(' ' + name + ' ', ' ');
      el.className = (className + (state ? ' ' + name : '')).replace(R_SPACE, ' ');
    }
  }
}
function css$7(el, prop, val) {
  var style = el && el.style;
  if (style) {
    if (val === void 0) {
      if (document.defaultView && document.defaultView.getComputedStyle) {
        val = document.defaultView.getComputedStyle(el, '');
      } else if (el.currentStyle) {
        val = el.currentStyle;
      }
      return prop === void 0 ? val : val[prop];
    } else {
      if (!(prop in style) && prop.indexOf('webkit') === -1) {
        prop = '-webkit-' + prop;
      }
      style[prop] = val + (typeof val === 'string' ? '' : 'px');
    }
  }
}
function matrix(el, selfOnly) {
  var appliedTransforms = '';
  if (typeof el === 'string') {
    appliedTransforms = el;
  } else {
    do {
      var transform = css$7(el, 'transform');
      if (transform && transform !== 'none') {
        appliedTransforms = transform + ' ' + appliedTransforms;
      }
      /* jshint boss:true */
    } while (!selfOnly && (el = el.parentNode));
  }
  var matrixFn = window.DOMMatrix || window.WebKitCSSMatrix || window.CSSMatrix || window.MSCSSMatrix;
  /*jshint -W056 */
  return matrixFn && new matrixFn(appliedTransforms);
}
function find(ctx, tagName, iterator) {
  if (ctx) {
    var list = ctx.getElementsByTagName(tagName),
      i = 0,
      n = list.length;
    if (iterator) {
      for (; i < n; i++) {
        iterator(list[i], i);
      }
    }
    return list;
  }
  return [];
}
function getWindowScrollingElement() {
  var scrollingElement = document.scrollingElement;
  if (scrollingElement) {
    return scrollingElement;
  } else {
    return document.documentElement;
  }
}

/**
 * Returns the "bounding client rect" of given element
 * @param  {HTMLElement} el                       The element whose boundingClientRect is wanted
 * @param  {[Boolean]} relativeToContainingBlock  Whether the rect should be relative to the containing block of (including) the container
 * @param  {[Boolean]} relativeToNonStaticParent  Whether the rect should be relative to the relative parent of (including) the contaienr
 * @param  {[Boolean]} undoScale                  Whether the container's scale() should be undone
 * @param  {[HTMLElement]} container              The parent the element will be placed in
 * @return {Object}                               The boundingClientRect of el, with specified adjustments
 */
function getRect(el, relativeToContainingBlock, relativeToNonStaticParent, undoScale, container) {
  if (!el.getBoundingClientRect && el !== window) return;
  var elRect, top, left, bottom, right, height, width;
  if (el !== window && el.parentNode && el !== getWindowScrollingElement()) {
    elRect = el.getBoundingClientRect();
    top = elRect.top;
    left = elRect.left;
    bottom = elRect.bottom;
    right = elRect.right;
    height = elRect.height;
    width = elRect.width;
  } else {
    top = 0;
    left = 0;
    bottom = window.innerHeight;
    right = window.innerWidth;
    height = window.innerHeight;
    width = window.innerWidth;
  }
  if ((relativeToContainingBlock || relativeToNonStaticParent) && el !== window) {
    // Adjust for translate()
    container = container || el.parentNode;

    // solves #1123 (see: https://stackoverflow.com/a/37953806/6088312)
    // Not needed on <= IE11
    if (!IE11OrLess) {
      do {
        if (container && container.getBoundingClientRect && (css$7(container, 'transform') !== 'none' || relativeToNonStaticParent && css$7(container, 'position') !== 'static')) {
          var containerRect = container.getBoundingClientRect();

          // Set relative to edges of padding box of container
          top -= containerRect.top + parseInt(css$7(container, 'border-top-width'));
          left -= containerRect.left + parseInt(css$7(container, 'border-left-width'));
          bottom = top + elRect.height;
          right = left + elRect.width;
          break;
        }
        /* jshint boss:true */
      } while (container = container.parentNode);
    }
  }
  if (undoScale && el !== window) {
    // Adjust for scale()
    var elMatrix = matrix(container || el),
      scaleX = elMatrix && elMatrix.a,
      scaleY = elMatrix && elMatrix.d;
    if (elMatrix) {
      top /= scaleY;
      left /= scaleX;
      width /= scaleX;
      height /= scaleY;
      bottom = top + height;
      right = left + width;
    }
  }
  return {
    top: top,
    left: left,
    bottom: bottom,
    right: right,
    width: width,
    height: height
  };
}

/**
 * Checks if a side of an element is scrolled past a side of its parents
 * @param  {HTMLElement}  el           The element who's side being scrolled out of view is in question
 * @param  {String}       elSide       Side of the element in question ('top', 'left', 'right', 'bottom')
 * @param  {String}       parentSide   Side of the parent in question ('top', 'left', 'right', 'bottom')
 * @return {HTMLElement}               The parent scroll element that the el's side is scrolled past, or null if there is no such element
 */
function isScrolledPast(el, elSide, parentSide) {
  var parent = getParentAutoScrollElement(el, true),
    elSideVal = getRect(el)[elSide];

  /* jshint boss:true */
  while (parent) {
    var parentSideVal = getRect(parent)[parentSide],
      visible = void 0;
    {
      visible = elSideVal >= parentSideVal;
    }
    if (!visible) return parent;
    if (parent === getWindowScrollingElement()) break;
    parent = getParentAutoScrollElement(parent, false);
  }
  return false;
}

/**
 * Gets nth child of el, ignoring hidden children, sortable's elements (does not ignore clone if it's visible)
 * and non-draggable elements
 * @param  {HTMLElement} el       The parent element
 * @param  {Number} childNum      The index of the child
 * @param  {Object} options       Parent Sortable's options
 * @return {HTMLElement}          The child at index childNum, or null if not found
 */
function getChild(el, childNum, options, includeDragEl) {
  var currentChild = 0,
    i = 0,
    children = el.children;
  while (i < children.length) {
    if (children[i].style.display !== 'none' && children[i] !== Sortable.ghost && (includeDragEl || children[i] !== Sortable.dragged) && closest(children[i], options.draggable, el, false)) {
      if (currentChild === childNum) {
        return children[i];
      }
      currentChild++;
    }
    i++;
  }
  return null;
}

/**
 * Gets the last child in the el, ignoring ghostEl or invisible elements (clones)
 * @param  {HTMLElement} el       Parent element
 * @param  {selector} selector    Any other elements that should be ignored
 * @return {HTMLElement}          The last child, ignoring ghostEl
 */
function lastChild(el, selector) {
  var last = el.lastElementChild;
  while (last && (last === Sortable.ghost || css$7(last, 'display') === 'none' || selector && !matches(last, selector))) {
    last = last.previousElementSibling;
  }
  return last || null;
}

/**
 * Returns the index of an element within its parent for a selected set of
 * elements
 * @param  {HTMLElement} el
 * @param  {selector} selector
 * @return {number}
 */
function index(el, selector) {
  var index = 0;
  if (!el || !el.parentNode) {
    return -1;
  }

  /* jshint boss:true */
  while (el = el.previousElementSibling) {
    if (el.nodeName.toUpperCase() !== 'TEMPLATE' && el !== Sortable.clone && (!selector || matches(el, selector))) {
      index++;
    }
  }
  return index;
}

/**
 * Returns the scroll offset of the given element, added with all the scroll offsets of parent elements.
 * The value is returned in real pixels.
 * @param  {HTMLElement} el
 * @return {Array}             Offsets in the format of [left, top]
 */
function getRelativeScrollOffset(el) {
  var offsetLeft = 0,
    offsetTop = 0,
    winScroller = getWindowScrollingElement();
  if (el) {
    do {
      var elMatrix = matrix(el),
        scaleX = elMatrix.a,
        scaleY = elMatrix.d;
      offsetLeft += el.scrollLeft * scaleX;
      offsetTop += el.scrollTop * scaleY;
    } while (el !== winScroller && (el = el.parentNode));
  }
  return [offsetLeft, offsetTop];
}

/**
 * Returns the index of the object within the given array
 * @param  {Array} arr   Array that may or may not hold the object
 * @param  {Object} obj  An object that has a key-value pair unique to and identical to a key-value pair in the object you want to find
 * @return {Number}      The index of the object in the array, or -1
 */
function indexOfObject(arr, obj) {
  for (var i in arr) {
    if (!arr.hasOwnProperty(i)) continue;
    for (var key in obj) {
      if (obj.hasOwnProperty(key) && obj[key] === arr[i][key]) return Number(i);
    }
  }
  return -1;
}
function getParentAutoScrollElement(el, includeSelf) {
  // skip to window
  if (!el || !el.getBoundingClientRect) return getWindowScrollingElement();
  var elem = el;
  var gotSelf = false;
  do {
    // we don't need to get elem css if it isn't even overflowing in the first place (performance)
    if (elem.clientWidth < elem.scrollWidth || elem.clientHeight < elem.scrollHeight) {
      var elemCSS = css$7(elem);
      if (elem.clientWidth < elem.scrollWidth && (elemCSS.overflowX == 'auto' || elemCSS.overflowX == 'scroll') || elem.clientHeight < elem.scrollHeight && (elemCSS.overflowY == 'auto' || elemCSS.overflowY == 'scroll')) {
        if (!elem.getBoundingClientRect || elem === document.body) return getWindowScrollingElement();
        if (gotSelf || includeSelf) return elem;
        gotSelf = true;
      }
    }
    /* jshint boss:true */
  } while (elem = elem.parentNode);
  return getWindowScrollingElement();
}
function extend(dst, src) {
  if (dst && src) {
    for (var key in src) {
      if (src.hasOwnProperty(key)) {
        dst[key] = src[key];
      }
    }
  }
  return dst;
}
function isRectEqual(rect1, rect2) {
  return Math.round(rect1.top) === Math.round(rect2.top) && Math.round(rect1.left) === Math.round(rect2.left) && Math.round(rect1.height) === Math.round(rect2.height) && Math.round(rect1.width) === Math.round(rect2.width);
}
var _throttleTimeout;
function throttle(callback, ms) {
  return function () {
    if (!_throttleTimeout) {
      var args = arguments,
        _this = this;
      if (args.length === 1) {
        callback.call(_this, args[0]);
      } else {
        callback.apply(_this, args);
      }
      _throttleTimeout = setTimeout(function () {
        _throttleTimeout = void 0;
      }, ms);
    }
  };
}
function cancelThrottle() {
  clearTimeout(_throttleTimeout);
  _throttleTimeout = void 0;
}
function scrollBy(el, x, y) {
  el.scrollLeft += x;
  el.scrollTop += y;
}
function clone(el) {
  var Polymer = window.Polymer;
  var $ = window.jQuery || window.Zepto;
  if (Polymer && Polymer.dom) {
    return Polymer.dom(el).cloneNode(true);
  } else if ($) {
    return $(el).clone(true)[0];
  } else {
    return el.cloneNode(true);
  }
}
function getChildContainingRectFromElement(container, options, ghostEl) {
  var rect = {};
  Array.from(container.children).forEach(function (child) {
    var _rect$left, _rect$top, _rect$right, _rect$bottom;
    if (!closest(child, options.draggable, container, false) || child.animated || child === ghostEl) return;
    var childRect = getRect(child);
    rect.left = Math.min((_rect$left = rect.left) !== null && _rect$left !== void 0 ? _rect$left : Infinity, childRect.left);
    rect.top = Math.min((_rect$top = rect.top) !== null && _rect$top !== void 0 ? _rect$top : Infinity, childRect.top);
    rect.right = Math.max((_rect$right = rect.right) !== null && _rect$right !== void 0 ? _rect$right : -Infinity, childRect.right);
    rect.bottom = Math.max((_rect$bottom = rect.bottom) !== null && _rect$bottom !== void 0 ? _rect$bottom : -Infinity, childRect.bottom);
  });
  rect.width = rect.right - rect.left;
  rect.height = rect.bottom - rect.top;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}
var expando = 'Sortable' + new Date().getTime();

function AnimationStateManager() {
  var animationStates = [],
    animationCallbackId;
  return {
    captureAnimationState: function captureAnimationState() {
      animationStates = [];
      if (!this.options.animation) return;
      var children = [].slice.call(this.el.children);
      children.forEach(function (child) {
        if (css$7(child, 'display') === 'none' || child === Sortable.ghost) return;
        animationStates.push({
          target: child,
          rect: getRect(child)
        });
        var fromRect = _objectSpread2({}, animationStates[animationStates.length - 1].rect);

        // If animating: compensate for current animation
        if (child.thisAnimationDuration) {
          var childMatrix = matrix(child, true);
          if (childMatrix) {
            fromRect.top -= childMatrix.f;
            fromRect.left -= childMatrix.e;
          }
        }
        child.fromRect = fromRect;
      });
    },
    addAnimationState: function addAnimationState(state) {
      animationStates.push(state);
    },
    removeAnimationState: function removeAnimationState(target) {
      animationStates.splice(indexOfObject(animationStates, {
        target: target
      }), 1);
    },
    animateAll: function animateAll(callback) {
      var _this = this;
      if (!this.options.animation) {
        clearTimeout(animationCallbackId);
        if (typeof callback === 'function') callback();
        return;
      }
      var animating = false,
        animationTime = 0;
      animationStates.forEach(function (state) {
        var time = 0,
          target = state.target,
          fromRect = target.fromRect,
          toRect = getRect(target),
          prevFromRect = target.prevFromRect,
          prevToRect = target.prevToRect,
          animatingRect = state.rect,
          targetMatrix = matrix(target, true);
        if (targetMatrix) {
          // Compensate for current animation
          toRect.top -= targetMatrix.f;
          toRect.left -= targetMatrix.e;
        }
        target.toRect = toRect;
        if (target.thisAnimationDuration) {
          // Could also check if animatingRect is between fromRect and toRect
          if (isRectEqual(prevFromRect, toRect) && !isRectEqual(fromRect, toRect) &&
          // Make sure animatingRect is on line between toRect & fromRect
          (animatingRect.top - toRect.top) / (animatingRect.left - toRect.left) === (fromRect.top - toRect.top) / (fromRect.left - toRect.left)) {
            // If returning to same place as started from animation and on same axis
            time = calculateRealTime(animatingRect, prevFromRect, prevToRect, _this.options);
          }
        }

        // if fromRect != toRect: animate
        if (!isRectEqual(toRect, fromRect)) {
          target.prevFromRect = fromRect;
          target.prevToRect = toRect;
          if (!time) {
            time = _this.options.animation;
          }
          _this.animate(target, animatingRect, toRect, time);
        }
        if (time) {
          animating = true;
          animationTime = Math.max(animationTime, time);
          clearTimeout(target.animationResetTimer);
          target.animationResetTimer = setTimeout(function () {
            target.animationTime = 0;
            target.prevFromRect = null;
            target.fromRect = null;
            target.prevToRect = null;
            target.thisAnimationDuration = null;
          }, time);
          target.thisAnimationDuration = time;
        }
      });
      clearTimeout(animationCallbackId);
      if (!animating) {
        if (typeof callback === 'function') callback();
      } else {
        animationCallbackId = setTimeout(function () {
          if (typeof callback === 'function') callback();
        }, animationTime);
      }
      animationStates = [];
    },
    animate: function animate(target, currentRect, toRect, duration) {
      if (duration) {
        css$7(target, 'transition', '');
        css$7(target, 'transform', '');
        var elMatrix = matrix(this.el),
          scaleX = elMatrix && elMatrix.a,
          scaleY = elMatrix && elMatrix.d,
          translateX = (currentRect.left - toRect.left) / (scaleX || 1),
          translateY = (currentRect.top - toRect.top) / (scaleY || 1);
        target.animatingX = !!translateX;
        target.animatingY = !!translateY;
        css$7(target, 'transform', 'translate3d(' + translateX + 'px,' + translateY + 'px,0)');
        this.forRepaintDummy = repaint(target); // repaint

        css$7(target, 'transition', 'transform ' + duration + 'ms' + (this.options.easing ? ' ' + this.options.easing : ''));
        css$7(target, 'transform', 'translate3d(0,0,0)');
        typeof target.animated === 'number' && clearTimeout(target.animated);
        target.animated = setTimeout(function () {
          css$7(target, 'transition', '');
          css$7(target, 'transform', '');
          target.animated = false;
          target.animatingX = false;
          target.animatingY = false;
        }, duration);
      }
    }
  };
}
function repaint(target) {
  return target.offsetWidth;
}
function calculateRealTime(animatingRect, fromRect, toRect, options) {
  return Math.sqrt(Math.pow(fromRect.top - animatingRect.top, 2) + Math.pow(fromRect.left - animatingRect.left, 2)) / Math.sqrt(Math.pow(fromRect.top - toRect.top, 2) + Math.pow(fromRect.left - toRect.left, 2)) * options.animation;
}

var plugins = [];
var defaults = {
  initializeByDefault: true
};
var PluginManager = {
  mount: function mount(plugin) {
    // Set default static properties
    for (var option in defaults) {
      if (defaults.hasOwnProperty(option) && !(option in plugin)) {
        plugin[option] = defaults[option];
      }
    }
    plugins.forEach(function (p) {
      if (p.pluginName === plugin.pluginName) {
        throw "Sortable: Cannot mount plugin ".concat(plugin.pluginName, " more than once");
      }
    });
    plugins.push(plugin);
  },
  pluginEvent: function pluginEvent(eventName, sortable, evt) {
    var _this = this;
    this.eventCanceled = false;
    evt.cancel = function () {
      _this.eventCanceled = true;
    };
    var eventNameGlobal = eventName + 'Global';
    plugins.forEach(function (plugin) {
      if (!sortable[plugin.pluginName]) return;
      // Fire global events if it exists in this sortable
      if (sortable[plugin.pluginName][eventNameGlobal]) {
        sortable[plugin.pluginName][eventNameGlobal](_objectSpread2({
          sortable: sortable
        }, evt));
      }

      // Only fire plugin event if plugin is enabled in this sortable,
      // and plugin has event defined
      if (sortable.options[plugin.pluginName] && sortable[plugin.pluginName][eventName]) {
        sortable[plugin.pluginName][eventName](_objectSpread2({
          sortable: sortable
        }, evt));
      }
    });
  },
  initializePlugins: function initializePlugins(sortable, el, defaults, options) {
    plugins.forEach(function (plugin) {
      var pluginName = plugin.pluginName;
      if (!sortable.options[pluginName] && !plugin.initializeByDefault) return;
      var initialized = new plugin(sortable, el, sortable.options);
      initialized.sortable = sortable;
      initialized.options = sortable.options;
      sortable[pluginName] = initialized;

      // Add default options from plugin
      _extends(defaults, initialized.defaults);
    });
    for (var option in sortable.options) {
      if (!sortable.options.hasOwnProperty(option)) continue;
      var modified = this.modifyOption(sortable, option, sortable.options[option]);
      if (typeof modified !== 'undefined') {
        sortable.options[option] = modified;
      }
    }
  },
  getEventProperties: function getEventProperties(name, sortable) {
    var eventProperties = {};
    plugins.forEach(function (plugin) {
      if (typeof plugin.eventProperties !== 'function') return;
      _extends(eventProperties, plugin.eventProperties.call(sortable[plugin.pluginName], name));
    });
    return eventProperties;
  },
  modifyOption: function modifyOption(sortable, name, value) {
    var modifiedValue;
    plugins.forEach(function (plugin) {
      // Plugin must exist on the Sortable
      if (!sortable[plugin.pluginName]) return;

      // If static option listener exists for this option, call in the context of the Sortable's instance of this plugin
      if (plugin.optionListeners && typeof plugin.optionListeners[name] === 'function') {
        modifiedValue = plugin.optionListeners[name].call(sortable[plugin.pluginName], value);
      }
    });
    return modifiedValue;
  }
};

function dispatchEvent(_ref) {
  var sortable = _ref.sortable,
    rootEl = _ref.rootEl,
    name = _ref.name,
    targetEl = _ref.targetEl,
    cloneEl = _ref.cloneEl,
    toEl = _ref.toEl,
    fromEl = _ref.fromEl,
    oldIndex = _ref.oldIndex,
    newIndex = _ref.newIndex,
    oldDraggableIndex = _ref.oldDraggableIndex,
    newDraggableIndex = _ref.newDraggableIndex,
    originalEvent = _ref.originalEvent,
    putSortable = _ref.putSortable,
    extraEventProperties = _ref.extraEventProperties;
  sortable = sortable || rootEl && rootEl[expando];
  if (!sortable) return;
  var evt,
    options = sortable.options,
    onName = 'on' + name.charAt(0).toUpperCase() + name.substr(1);
  // Support for new CustomEvent feature
  if (window.CustomEvent && !IE11OrLess && !Edge) {
    evt = new CustomEvent(name, {
      bubbles: true,
      cancelable: true
    });
  } else {
    evt = document.createEvent('Event');
    evt.initEvent(name, true, true);
  }
  evt.to = toEl || rootEl;
  evt.from = fromEl || rootEl;
  evt.item = targetEl || rootEl;
  evt.clone = cloneEl;
  evt.oldIndex = oldIndex;
  evt.newIndex = newIndex;
  evt.oldDraggableIndex = oldDraggableIndex;
  evt.newDraggableIndex = newDraggableIndex;
  evt.originalEvent = originalEvent;
  evt.pullMode = putSortable ? putSortable.lastPutMode : undefined;
  var allEventProperties = _objectSpread2(_objectSpread2({}, extraEventProperties), PluginManager.getEventProperties(name, sortable));
  for (var option in allEventProperties) {
    evt[option] = allEventProperties[option];
  }
  if (rootEl) {
    rootEl.dispatchEvent(evt);
  }
  if (options[onName]) {
    options[onName].call(sortable, evt);
  }
}

var _excluded = ["evt"];
var pluginEvent = function pluginEvent(eventName, sortable) {
  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
    originalEvent = _ref.evt,
    data = _objectWithoutProperties(_ref, _excluded);
  PluginManager.pluginEvent.bind(Sortable)(eventName, sortable, _objectSpread2({
    dragEl: dragEl,
    parentEl: parentEl,
    ghostEl: ghostEl,
    rootEl: rootEl,
    nextEl: nextEl,
    lastDownEl: lastDownEl,
    cloneEl: cloneEl,
    cloneHidden: cloneHidden,
    dragStarted: moved,
    putSortable: putSortable,
    activeSortable: Sortable.active,
    originalEvent: originalEvent,
    oldIndex: oldIndex,
    oldDraggableIndex: oldDraggableIndex,
    newIndex: newIndex,
    newDraggableIndex: newDraggableIndex,
    hideGhostForTarget: _hideGhostForTarget,
    unhideGhostForTarget: _unhideGhostForTarget,
    cloneNowHidden: function cloneNowHidden() {
      cloneHidden = true;
    },
    cloneNowShown: function cloneNowShown() {
      cloneHidden = false;
    },
    dispatchSortableEvent: function dispatchSortableEvent(name) {
      _dispatchEvent({
        sortable: sortable,
        name: name,
        originalEvent: originalEvent
      });
    }
  }, data));
};
function _dispatchEvent(info) {
  dispatchEvent(_objectSpread2({
    putSortable: putSortable,
    cloneEl: cloneEl,
    targetEl: dragEl,
    rootEl: rootEl,
    oldIndex: oldIndex,
    oldDraggableIndex: oldDraggableIndex,
    newIndex: newIndex,
    newDraggableIndex: newDraggableIndex
  }, info));
}
var dragEl,
  parentEl,
  ghostEl,
  rootEl,
  nextEl,
  lastDownEl,
  cloneEl,
  cloneHidden,
  oldIndex,
  newIndex,
  oldDraggableIndex,
  newDraggableIndex,
  activeGroup,
  putSortable,
  awaitingDragStarted = false,
  ignoreNextClick = false,
  sortables = [],
  tapEvt,
  touchEvt,
  lastDx,
  lastDy,
  tapDistanceLeft,
  tapDistanceTop,
  moved,
  lastTarget,
  lastDirection,
  pastFirstInvertThresh = false,
  isCircumstantialInvert = false,
  targetMoveDistance,
  // For positioning ghost absolutely
  ghostRelativeParent,
  ghostRelativeParentInitialScroll = [],
  // (left, top)

  _silent = false,
  savedInputChecked = [];

/** @const */
var documentExists = typeof document !== 'undefined',
  PositionGhostAbsolutely = IOS,
  CSSFloatProperty = Edge || IE11OrLess ? 'cssFloat' : 'float',
  // This will not pass for IE9, because IE9 DnD only works on anchors
  supportDraggable = documentExists && !ChromeForAndroid && !IOS && 'draggable' in document.createElement('div'),
  supportCssPointerEvents = function () {
    if (!documentExists) return;
    // false when <= IE11
    if (IE11OrLess) {
      return false;
    }
    var el = document.createElement('x');
    el.style.cssText = 'pointer-events:auto';
    return el.style.pointerEvents === 'auto';
  }(),
  _detectDirection = function _detectDirection(el, options) {
    var elCSS = css$7(el),
      elWidth = parseInt(elCSS.width) - parseInt(elCSS.paddingLeft) - parseInt(elCSS.paddingRight) - parseInt(elCSS.borderLeftWidth) - parseInt(elCSS.borderRightWidth),
      child1 = getChild(el, 0, options),
      child2 = getChild(el, 1, options),
      firstChildCSS = child1 && css$7(child1),
      secondChildCSS = child2 && css$7(child2),
      firstChildWidth = firstChildCSS && parseInt(firstChildCSS.marginLeft) + parseInt(firstChildCSS.marginRight) + getRect(child1).width,
      secondChildWidth = secondChildCSS && parseInt(secondChildCSS.marginLeft) + parseInt(secondChildCSS.marginRight) + getRect(child2).width;
    if (elCSS.display === 'flex') {
      return elCSS.flexDirection === 'column' || elCSS.flexDirection === 'column-reverse' ? 'vertical' : 'horizontal';
    }
    if (elCSS.display === 'grid') {
      return elCSS.gridTemplateColumns.split(' ').length <= 1 ? 'vertical' : 'horizontal';
    }
    if (child1 && firstChildCSS["float"] && firstChildCSS["float"] !== 'none') {
      var touchingSideChild2 = firstChildCSS["float"] === 'left' ? 'left' : 'right';
      return child2 && (secondChildCSS.clear === 'both' || secondChildCSS.clear === touchingSideChild2) ? 'vertical' : 'horizontal';
    }
    return child1 && (firstChildCSS.display === 'block' || firstChildCSS.display === 'flex' || firstChildCSS.display === 'table' || firstChildCSS.display === 'grid' || firstChildWidth >= elWidth && elCSS[CSSFloatProperty] === 'none' || child2 && elCSS[CSSFloatProperty] === 'none' && firstChildWidth + secondChildWidth > elWidth) ? 'vertical' : 'horizontal';
  },
  _dragElInRowColumn = function _dragElInRowColumn(dragRect, targetRect, vertical) {
    var dragElS1Opp = vertical ? dragRect.left : dragRect.top,
      dragElS2Opp = vertical ? dragRect.right : dragRect.bottom,
      dragElOppLength = vertical ? dragRect.width : dragRect.height,
      targetS1Opp = vertical ? targetRect.left : targetRect.top,
      targetS2Opp = vertical ? targetRect.right : targetRect.bottom,
      targetOppLength = vertical ? targetRect.width : targetRect.height;
    return dragElS1Opp === targetS1Opp || dragElS2Opp === targetS2Opp || dragElS1Opp + dragElOppLength / 2 === targetS1Opp + targetOppLength / 2;
  },
  /**
   * Detects first nearest empty sortable to X and Y position using emptyInsertThreshold.
   * @param  {Number} x      X position
   * @param  {Number} y      Y position
   * @return {HTMLElement}   Element of the first found nearest Sortable
   */
  _detectNearestEmptySortable = function _detectNearestEmptySortable(x, y) {
    var ret;
    sortables.some(function (sortable) {
      var threshold = sortable[expando].options.emptyInsertThreshold;
      if (!threshold || lastChild(sortable)) return;
      var rect = getRect(sortable),
        insideHorizontally = x >= rect.left - threshold && x <= rect.right + threshold,
        insideVertically = y >= rect.top - threshold && y <= rect.bottom + threshold;
      if (insideHorizontally && insideVertically) {
        return ret = sortable;
      }
    });
    return ret;
  },
  _prepareGroup = function _prepareGroup(options) {
    function toFn(value, pull) {
      return function (to, from, dragEl, evt) {
        var sameGroup = to.options.group.name && from.options.group.name && to.options.group.name === from.options.group.name;
        if (value == null && (pull || sameGroup)) {
          // Default pull value
          // Default pull and put value if same group
          return true;
        } else if (value == null || value === false) {
          return false;
        } else if (pull && value === 'clone') {
          return value;
        } else if (typeof value === 'function') {
          return toFn(value(to, from, dragEl, evt), pull)(to, from, dragEl, evt);
        } else {
          var otherGroup = (pull ? to : from).options.group.name;
          return value === true || typeof value === 'string' && value === otherGroup || value.join && value.indexOf(otherGroup) > -1;
        }
      };
    }
    var group = {};
    var originalGroup = options.group;
    if (!originalGroup || _typeof(originalGroup) != 'object') {
      originalGroup = {
        name: originalGroup
      };
    }
    group.name = originalGroup.name;
    group.checkPull = toFn(originalGroup.pull, true);
    group.checkPut = toFn(originalGroup.put);
    group.revertClone = originalGroup.revertClone;
    options.group = group;
  },
  _hideGhostForTarget = function _hideGhostForTarget() {
    if (!supportCssPointerEvents && ghostEl) {
      css$7(ghostEl, 'display', 'none');
    }
  },
  _unhideGhostForTarget = function _unhideGhostForTarget() {
    if (!supportCssPointerEvents && ghostEl) {
      css$7(ghostEl, 'display', '');
    }
  };

// #1184 fix - Prevent click event on fallback if dragged but item not changed position
if (documentExists && !ChromeForAndroid) {
  document.addEventListener('click', function (evt) {
    if (ignoreNextClick) {
      evt.preventDefault();
      evt.stopPropagation && evt.stopPropagation();
      evt.stopImmediatePropagation && evt.stopImmediatePropagation();
      ignoreNextClick = false;
      return false;
    }
  }, true);
}
var nearestEmptyInsertDetectEvent = function nearestEmptyInsertDetectEvent(evt) {
  if (dragEl) {
    evt = evt.touches ? evt.touches[0] : evt;
    var nearest = _detectNearestEmptySortable(evt.clientX, evt.clientY);
    if (nearest) {
      // Create imitation event
      var event = {};
      for (var i in evt) {
        if (evt.hasOwnProperty(i)) {
          event[i] = evt[i];
        }
      }
      event.target = event.rootEl = nearest;
      event.preventDefault = void 0;
      event.stopPropagation = void 0;
      nearest[expando]._onDragOver(event);
    }
  }
};
var _checkOutsideTargetEl = function _checkOutsideTargetEl(evt) {
  if (dragEl) {
    dragEl.parentNode[expando]._isOutsideThisEl(evt.target);
  }
};

/**
 * @class  Sortable
 * @param  {HTMLElement}  el
 * @param  {Object}       [options]
 */
function Sortable(el, options) {
  if (!(el && el.nodeType && el.nodeType === 1)) {
    throw "Sortable: `el` must be an HTMLElement, not ".concat({}.toString.call(el));
  }
  this.el = el; // root element
  this.options = options = _extends({}, options);

  // Export instance
  el[expando] = this;
  var defaults = {
    group: null,
    sort: true,
    disabled: false,
    store: null,
    handle: null,
    draggable: /^[uo]l$/i.test(el.nodeName) ? '>li' : '>*',
    swapThreshold: 1,
    // percentage; 0 <= x <= 1
    invertSwap: false,
    // invert always
    invertedSwapThreshold: null,
    // will be set to same as swapThreshold if default
    removeCloneOnHide: true,
    direction: function direction() {
      return _detectDirection(el, this.options);
    },
    ghostClass: 'sortable-ghost',
    chosenClass: 'sortable-chosen',
    dragClass: 'sortable-drag',
    ignore: 'a, img',
    filter: null,
    preventOnFilter: true,
    animation: 0,
    easing: null,
    setData: function setData(dataTransfer, dragEl) {
      dataTransfer.setData('Text', dragEl.textContent);
    },
    dropBubble: false,
    dragoverBubble: false,
    dataIdAttr: 'data-id',
    delay: 0,
    delayOnTouchOnly: false,
    touchStartThreshold: (Number.parseInt ? Number : window).parseInt(window.devicePixelRatio, 10) || 1,
    forceFallback: false,
    fallbackClass: 'sortable-fallback',
    fallbackOnBody: false,
    fallbackTolerance: 0,
    fallbackOffset: {
      x: 0,
      y: 0
    },
    // Disabled on Safari: #1571; Enabled on Safari IOS: #2244
    supportPointer: Sortable.supportPointer !== false && 'PointerEvent' in window && (!Safari || IOS),
    emptyInsertThreshold: 5
  };
  PluginManager.initializePlugins(this, el, defaults);

  // Set default options
  for (var name in defaults) {
    !(name in options) && (options[name] = defaults[name]);
  }
  _prepareGroup(options);

  // Bind all private methods
  for (var fn in this) {
    if (fn.charAt(0) === '_' && typeof this[fn] === 'function') {
      this[fn] = this[fn].bind(this);
    }
  }

  // Setup drag mode
  this.nativeDraggable = options.forceFallback ? false : supportDraggable;
  if (this.nativeDraggable) {
    // Touch start threshold cannot be greater than the native dragstart threshold
    this.options.touchStartThreshold = 1;
  }

  // Bind events
  if (options.supportPointer) {
    on(el, 'pointerdown', this._onTapStart);
  } else {
    on(el, 'mousedown', this._onTapStart);
    on(el, 'touchstart', this._onTapStart);
  }
  if (this.nativeDraggable) {
    on(el, 'dragover', this);
    on(el, 'dragenter', this);
  }
  sortables.push(this.el);

  // Restore sorting
  options.store && options.store.get && this.sort(options.store.get(this) || []);

  // Add animation state manager
  _extends(this, AnimationStateManager());
}
Sortable.prototype = /** @lends Sortable.prototype */{
  constructor: Sortable,
  _isOutsideThisEl: function _isOutsideThisEl(target) {
    if (!this.el.contains(target) && target !== this.el) {
      lastTarget = null;
    }
  },
  _getDirection: function _getDirection(evt, target) {
    return typeof this.options.direction === 'function' ? this.options.direction.call(this, evt, target, dragEl) : this.options.direction;
  },
  _onTapStart: function _onTapStart( /** Event|TouchEvent */evt) {
    if (!evt.cancelable) return;
    var _this = this,
      el = this.el,
      options = this.options,
      preventOnFilter = options.preventOnFilter,
      type = evt.type,
      touch = evt.touches && evt.touches[0] || evt.pointerType && evt.pointerType === 'touch' && evt,
      target = (touch || evt).target,
      originalTarget = evt.target.shadowRoot && (evt.path && evt.path[0] || evt.composedPath && evt.composedPath()[0]) || target,
      filter = options.filter;
    _saveInputCheckedState(el);

    // Don't trigger start event when an element is been dragged, otherwise the evt.oldindex always wrong when set option.group.
    if (dragEl) {
      return;
    }
    if (/mousedown|pointerdown/.test(type) && evt.button !== 0 || options.disabled) {
      return; // only left button and enabled
    }

    // cancel dnd if original target is content editable
    if (originalTarget.isContentEditable) {
      return;
    }

    // Safari ignores further event handling after mousedown
    if (!this.nativeDraggable && Safari && target && target.tagName.toUpperCase() === 'SELECT') {
      return;
    }
    target = closest(target, options.draggable, el, false);
    if (target && target.animated) {
      return;
    }
    if (lastDownEl === target) {
      // Ignoring duplicate `down`
      return;
    }

    // Get the index of the dragged element within its parent
    oldIndex = index(target);
    oldDraggableIndex = index(target, options.draggable);

    // Check filter
    if (typeof filter === 'function') {
      if (filter.call(this, evt, target, this)) {
        _dispatchEvent({
          sortable: _this,
          rootEl: originalTarget,
          name: 'filter',
          targetEl: target,
          toEl: el,
          fromEl: el
        });
        pluginEvent('filter', _this, {
          evt: evt
        });
        preventOnFilter && evt.preventDefault();
        return; // cancel dnd
      }
    } else if (filter) {
      filter = filter.split(',').some(function (criteria) {
        criteria = closest(originalTarget, criteria.trim(), el, false);
        if (criteria) {
          _dispatchEvent({
            sortable: _this,
            rootEl: criteria,
            name: 'filter',
            targetEl: target,
            fromEl: el,
            toEl: el
          });
          pluginEvent('filter', _this, {
            evt: evt
          });
          return true;
        }
      });
      if (filter) {
        preventOnFilter && evt.preventDefault();
        return; // cancel dnd
      }
    }
    if (options.handle && !closest(originalTarget, options.handle, el, false)) {
      return;
    }

    // Prepare `dragstart`
    this._prepareDragStart(evt, touch, target);
  },
  _prepareDragStart: function _prepareDragStart( /** Event */evt, /** Touch */touch, /** HTMLElement */target) {
    var _this = this,
      el = _this.el,
      options = _this.options,
      ownerDocument = el.ownerDocument,
      dragStartFn;
    if (target && !dragEl && target.parentNode === el) {
      var dragRect = getRect(target);
      rootEl = el;
      dragEl = target;
      parentEl = dragEl.parentNode;
      nextEl = dragEl.nextSibling;
      lastDownEl = target;
      activeGroup = options.group;
      Sortable.dragged = dragEl;
      tapEvt = {
        target: dragEl,
        clientX: (touch || evt).clientX,
        clientY: (touch || evt).clientY
      };
      tapDistanceLeft = tapEvt.clientX - dragRect.left;
      tapDistanceTop = tapEvt.clientY - dragRect.top;
      this._lastX = (touch || evt).clientX;
      this._lastY = (touch || evt).clientY;
      dragEl.style['will-change'] = 'all';
      dragStartFn = function dragStartFn() {
        pluginEvent('delayEnded', _this, {
          evt: evt
        });
        if (Sortable.eventCanceled) {
          _this._onDrop();
          return;
        }
        // Delayed drag has been triggered
        // we can re-enable the events: touchmove/mousemove
        _this._disableDelayedDragEvents();
        if (!FireFox && _this.nativeDraggable) {
          dragEl.draggable = true;
        }

        // Bind the events: dragstart/dragend
        _this._triggerDragStart(evt, touch);

        // Drag start event
        _dispatchEvent({
          sortable: _this,
          name: 'choose',
          originalEvent: evt
        });

        // Chosen item
        toggleClass(dragEl, options.chosenClass, true);
      };

      // Disable "draggable"
      options.ignore.split(',').forEach(function (criteria) {
        find(dragEl, criteria.trim(), _disableDraggable);
      });
      on(ownerDocument, 'dragover', nearestEmptyInsertDetectEvent);
      on(ownerDocument, 'mousemove', nearestEmptyInsertDetectEvent);
      on(ownerDocument, 'touchmove', nearestEmptyInsertDetectEvent);
      if (options.supportPointer) {
        on(ownerDocument, 'pointerup', _this._onDrop);
        // Native D&D triggers pointercancel
        !this.nativeDraggable && on(ownerDocument, 'pointercancel', _this._onDrop);
      } else {
        on(ownerDocument, 'mouseup', _this._onDrop);
        on(ownerDocument, 'touchend', _this._onDrop);
        on(ownerDocument, 'touchcancel', _this._onDrop);
      }

      // Make dragEl draggable (must be before delay for FireFox)
      if (FireFox && this.nativeDraggable) {
        this.options.touchStartThreshold = 4;
        dragEl.draggable = true;
      }
      pluginEvent('delayStart', this, {
        evt: evt
      });

      // Delay is impossible for native DnD in Edge or IE
      if (options.delay && (!options.delayOnTouchOnly || touch) && (!this.nativeDraggable || !(Edge || IE11OrLess))) {
        if (Sortable.eventCanceled) {
          this._onDrop();
          return;
        }
        // If the user moves the pointer or let go the click or touch
        // before the delay has been reached:
        // disable the delayed drag
        if (options.supportPointer) {
          on(ownerDocument, 'pointerup', _this._disableDelayedDrag);
          on(ownerDocument, 'pointercancel', _this._disableDelayedDrag);
        } else {
          on(ownerDocument, 'mouseup', _this._disableDelayedDrag);
          on(ownerDocument, 'touchend', _this._disableDelayedDrag);
          on(ownerDocument, 'touchcancel', _this._disableDelayedDrag);
        }
        on(ownerDocument, 'mousemove', _this._delayedDragTouchMoveHandler);
        on(ownerDocument, 'touchmove', _this._delayedDragTouchMoveHandler);
        options.supportPointer && on(ownerDocument, 'pointermove', _this._delayedDragTouchMoveHandler);
        _this._dragStartTimer = setTimeout(dragStartFn, options.delay);
      } else {
        dragStartFn();
      }
    }
  },
  _delayedDragTouchMoveHandler: function _delayedDragTouchMoveHandler( /** TouchEvent|PointerEvent **/e) {
    var touch = e.touches ? e.touches[0] : e;
    if (Math.max(Math.abs(touch.clientX - this._lastX), Math.abs(touch.clientY - this._lastY)) >= Math.floor(this.options.touchStartThreshold / (this.nativeDraggable && window.devicePixelRatio || 1))) {
      this._disableDelayedDrag();
    }
  },
  _disableDelayedDrag: function _disableDelayedDrag() {
    dragEl && _disableDraggable(dragEl);
    clearTimeout(this._dragStartTimer);
    this._disableDelayedDragEvents();
  },
  _disableDelayedDragEvents: function _disableDelayedDragEvents() {
    var ownerDocument = this.el.ownerDocument;
    off(ownerDocument, 'mouseup', this._disableDelayedDrag);
    off(ownerDocument, 'touchend', this._disableDelayedDrag);
    off(ownerDocument, 'touchcancel', this._disableDelayedDrag);
    off(ownerDocument, 'pointerup', this._disableDelayedDrag);
    off(ownerDocument, 'pointercancel', this._disableDelayedDrag);
    off(ownerDocument, 'mousemove', this._delayedDragTouchMoveHandler);
    off(ownerDocument, 'touchmove', this._delayedDragTouchMoveHandler);
    off(ownerDocument, 'pointermove', this._delayedDragTouchMoveHandler);
  },
  _triggerDragStart: function _triggerDragStart( /** Event */evt, /** Touch */touch) {
    touch = touch || evt.pointerType == 'touch' && evt;
    if (!this.nativeDraggable || touch) {
      if (this.options.supportPointer) {
        on(document, 'pointermove', this._onTouchMove);
      } else if (touch) {
        on(document, 'touchmove', this._onTouchMove);
      } else {
        on(document, 'mousemove', this._onTouchMove);
      }
    } else {
      on(dragEl, 'dragend', this);
      on(rootEl, 'dragstart', this._onDragStart);
    }
    try {
      if (document.selection) {
        _nextTick(function () {
          document.selection.empty();
        });
      } else {
        window.getSelection().removeAllRanges();
      }
    } catch (err) {}
  },
  _dragStarted: function _dragStarted(fallback, evt) {
    awaitingDragStarted = false;
    if (rootEl && dragEl) {
      pluginEvent('dragStarted', this, {
        evt: evt
      });
      if (this.nativeDraggable) {
        on(document, 'dragover', _checkOutsideTargetEl);
      }
      var options = this.options;

      // Apply effect
      !fallback && toggleClass(dragEl, options.dragClass, false);
      toggleClass(dragEl, options.ghostClass, true);
      Sortable.active = this;
      fallback && this._appendGhost();

      // Drag start event
      _dispatchEvent({
        sortable: this,
        name: 'start',
        originalEvent: evt
      });
    } else {
      this._nulling();
    }
  },
  _emulateDragOver: function _emulateDragOver() {
    if (touchEvt) {
      this._lastX = touchEvt.clientX;
      this._lastY = touchEvt.clientY;
      _hideGhostForTarget();
      var target = document.elementFromPoint(touchEvt.clientX, touchEvt.clientY);
      var parent = target;
      while (target && target.shadowRoot) {
        target = target.shadowRoot.elementFromPoint(touchEvt.clientX, touchEvt.clientY);
        if (target === parent) break;
        parent = target;
      }
      dragEl.parentNode[expando]._isOutsideThisEl(target);
      if (parent) {
        do {
          if (parent[expando]) {
            var inserted = void 0;
            inserted = parent[expando]._onDragOver({
              clientX: touchEvt.clientX,
              clientY: touchEvt.clientY,
              target: target,
              rootEl: parent
            });
            if (inserted && !this.options.dragoverBubble) {
              break;
            }
          }
          target = parent; // store last element
        }
        /* jshint boss:true */ while (parent = getParentOrHost(parent));
      }
      _unhideGhostForTarget();
    }
  },
  _onTouchMove: function _onTouchMove( /**TouchEvent*/evt) {
    if (tapEvt) {
      var options = this.options,
        fallbackTolerance = options.fallbackTolerance,
        fallbackOffset = options.fallbackOffset,
        touch = evt.touches ? evt.touches[0] : evt,
        ghostMatrix = ghostEl && matrix(ghostEl, true),
        scaleX = ghostEl && ghostMatrix && ghostMatrix.a,
        scaleY = ghostEl && ghostMatrix && ghostMatrix.d,
        relativeScrollOffset = PositionGhostAbsolutely && ghostRelativeParent && getRelativeScrollOffset(ghostRelativeParent),
        dx = (touch.clientX - tapEvt.clientX + fallbackOffset.x) / (scaleX || 1) + (relativeScrollOffset ? relativeScrollOffset[0] - ghostRelativeParentInitialScroll[0] : 0) / (scaleX || 1),
        dy = (touch.clientY - tapEvt.clientY + fallbackOffset.y) / (scaleY || 1) + (relativeScrollOffset ? relativeScrollOffset[1] - ghostRelativeParentInitialScroll[1] : 0) / (scaleY || 1);

      // only set the status to dragging, when we are actually dragging
      if (!Sortable.active && !awaitingDragStarted) {
        if (fallbackTolerance && Math.max(Math.abs(touch.clientX - this._lastX), Math.abs(touch.clientY - this._lastY)) < fallbackTolerance) {
          return;
        }
        this._onDragStart(evt, true);
      }
      if (ghostEl) {
        if (ghostMatrix) {
          ghostMatrix.e += dx - (lastDx || 0);
          ghostMatrix.f += dy - (lastDy || 0);
        } else {
          ghostMatrix = {
            a: 1,
            b: 0,
            c: 0,
            d: 1,
            e: dx,
            f: dy
          };
        }
        var cssMatrix = "matrix(".concat(ghostMatrix.a, ",").concat(ghostMatrix.b, ",").concat(ghostMatrix.c, ",").concat(ghostMatrix.d, ",").concat(ghostMatrix.e, ",").concat(ghostMatrix.f, ")");
        css$7(ghostEl, 'webkitTransform', cssMatrix);
        css$7(ghostEl, 'mozTransform', cssMatrix);
        css$7(ghostEl, 'msTransform', cssMatrix);
        css$7(ghostEl, 'transform', cssMatrix);
        lastDx = dx;
        lastDy = dy;
        touchEvt = touch;
      }
      evt.cancelable && evt.preventDefault();
    }
  },
  _appendGhost: function _appendGhost() {
    // Bug if using scale(): https://stackoverflow.com/questions/2637058
    // Not being adjusted for
    if (!ghostEl) {
      var container = this.options.fallbackOnBody ? document.body : rootEl,
        rect = getRect(dragEl, true, PositionGhostAbsolutely, true, container),
        options = this.options;

      // Position absolutely
      if (PositionGhostAbsolutely) {
        // Get relatively positioned parent
        ghostRelativeParent = container;
        while (css$7(ghostRelativeParent, 'position') === 'static' && css$7(ghostRelativeParent, 'transform') === 'none' && ghostRelativeParent !== document) {
          ghostRelativeParent = ghostRelativeParent.parentNode;
        }
        if (ghostRelativeParent !== document.body && ghostRelativeParent !== document.documentElement) {
          if (ghostRelativeParent === document) ghostRelativeParent = getWindowScrollingElement();
          rect.top += ghostRelativeParent.scrollTop;
          rect.left += ghostRelativeParent.scrollLeft;
        } else {
          ghostRelativeParent = getWindowScrollingElement();
        }
        ghostRelativeParentInitialScroll = getRelativeScrollOffset(ghostRelativeParent);
      }
      ghostEl = dragEl.cloneNode(true);
      toggleClass(ghostEl, options.ghostClass, false);
      toggleClass(ghostEl, options.fallbackClass, true);
      toggleClass(ghostEl, options.dragClass, true);
      css$7(ghostEl, 'transition', '');
      css$7(ghostEl, 'transform', '');
      css$7(ghostEl, 'box-sizing', 'border-box');
      css$7(ghostEl, 'margin', 0);
      css$7(ghostEl, 'top', rect.top);
      css$7(ghostEl, 'left', rect.left);
      css$7(ghostEl, 'width', rect.width);
      css$7(ghostEl, 'height', rect.height);
      css$7(ghostEl, 'opacity', '0.8');
      css$7(ghostEl, 'position', PositionGhostAbsolutely ? 'absolute' : 'fixed');
      css$7(ghostEl, 'zIndex', '100000');
      css$7(ghostEl, 'pointerEvents', 'none');
      Sortable.ghost = ghostEl;
      container.appendChild(ghostEl);

      // Set transform-origin
      css$7(ghostEl, 'transform-origin', tapDistanceLeft / parseInt(ghostEl.style.width) * 100 + '% ' + tapDistanceTop / parseInt(ghostEl.style.height) * 100 + '%');
    }
  },
  _onDragStart: function _onDragStart( /**Event*/evt, /**boolean*/fallback) {
    var _this = this;
    var dataTransfer = evt.dataTransfer;
    var options = _this.options;
    pluginEvent('dragStart', this, {
      evt: evt
    });
    if (Sortable.eventCanceled) {
      this._onDrop();
      return;
    }
    pluginEvent('setupClone', this);
    if (!Sortable.eventCanceled) {
      cloneEl = clone(dragEl);
      cloneEl.removeAttribute("id");
      cloneEl.draggable = false;
      cloneEl.style['will-change'] = '';
      this._hideClone();
      toggleClass(cloneEl, this.options.chosenClass, false);
      Sortable.clone = cloneEl;
    }

    // #1143: IFrame support workaround
    _this.cloneId = _nextTick(function () {
      pluginEvent('clone', _this);
      if (Sortable.eventCanceled) return;
      if (!_this.options.removeCloneOnHide) {
        rootEl.insertBefore(cloneEl, dragEl);
      }
      _this._hideClone();
      _dispatchEvent({
        sortable: _this,
        name: 'clone'
      });
    });
    !fallback && toggleClass(dragEl, options.dragClass, true);

    // Set proper drop events
    if (fallback) {
      ignoreNextClick = true;
      _this._loopId = setInterval(_this._emulateDragOver, 50);
    } else {
      // Undo what was set in _prepareDragStart before drag started
      off(document, 'mouseup', _this._onDrop);
      off(document, 'touchend', _this._onDrop);
      off(document, 'touchcancel', _this._onDrop);
      if (dataTransfer) {
        dataTransfer.effectAllowed = 'move';
        options.setData && options.setData.call(_this, dataTransfer, dragEl);
      }
      on(document, 'drop', _this);

      // #1276 fix:
      css$7(dragEl, 'transform', 'translateZ(0)');
    }
    awaitingDragStarted = true;
    _this._dragStartId = _nextTick(_this._dragStarted.bind(_this, fallback, evt));
    on(document, 'selectstart', _this);
    moved = true;
    window.getSelection().removeAllRanges();
    if (Safari) {
      css$7(document.body, 'user-select', 'none');
    }
  },
  // Returns true - if no further action is needed (either inserted or another condition)
  _onDragOver: function _onDragOver( /**Event*/evt) {
    var el = this.el,
      target = evt.target,
      dragRect,
      targetRect,
      revert,
      options = this.options,
      group = options.group,
      activeSortable = Sortable.active,
      isOwner = activeGroup === group,
      canSort = options.sort,
      fromSortable = putSortable || activeSortable,
      vertical,
      _this = this,
      completedFired = false;
    if (_silent) return;
    function dragOverEvent(name, extra) {
      pluginEvent(name, _this, _objectSpread2({
        evt: evt,
        isOwner: isOwner,
        axis: vertical ? 'vertical' : 'horizontal',
        revert: revert,
        dragRect: dragRect,
        targetRect: targetRect,
        canSort: canSort,
        fromSortable: fromSortable,
        target: target,
        completed: completed,
        onMove: function onMove(target, after) {
          return _onMove(rootEl, el, dragEl, dragRect, target, getRect(target), evt, after);
        },
        changed: changed
      }, extra));
    }

    // Capture animation state
    function capture() {
      dragOverEvent('dragOverAnimationCapture');
      _this.captureAnimationState();
      if (_this !== fromSortable) {
        fromSortable.captureAnimationState();
      }
    }

    // Return invocation when dragEl is inserted (or completed)
    function completed(insertion) {
      dragOverEvent('dragOverCompleted', {
        insertion: insertion
      });
      if (insertion) {
        // Clones must be hidden before folding animation to capture dragRectAbsolute properly
        if (isOwner) {
          activeSortable._hideClone();
        } else {
          activeSortable._showClone(_this);
        }
        if (_this !== fromSortable) {
          // Set ghost class to new sortable's ghost class
          toggleClass(dragEl, putSortable ? putSortable.options.ghostClass : activeSortable.options.ghostClass, false);
          toggleClass(dragEl, options.ghostClass, true);
        }
        if (putSortable !== _this && _this !== Sortable.active) {
          putSortable = _this;
        } else if (_this === Sortable.active && putSortable) {
          putSortable = null;
        }

        // Animation
        if (fromSortable === _this) {
          _this._ignoreWhileAnimating = target;
        }
        _this.animateAll(function () {
          dragOverEvent('dragOverAnimationComplete');
          _this._ignoreWhileAnimating = null;
        });
        if (_this !== fromSortable) {
          fromSortable.animateAll();
          fromSortable._ignoreWhileAnimating = null;
        }
      }

      // Null lastTarget if it is not inside a previously swapped element
      if (target === dragEl && !dragEl.animated || target === el && !target.animated) {
        lastTarget = null;
      }

      // no bubbling and not fallback
      if (!options.dragoverBubble && !evt.rootEl && target !== document) {
        dragEl.parentNode[expando]._isOutsideThisEl(evt.target);

        // Do not detect for empty insert if already inserted
        !insertion && nearestEmptyInsertDetectEvent(evt);
      }
      !options.dragoverBubble && evt.stopPropagation && evt.stopPropagation();
      return completedFired = true;
    }

    // Call when dragEl has been inserted
    function changed() {
      newIndex = index(dragEl);
      newDraggableIndex = index(dragEl, options.draggable);
      _dispatchEvent({
        sortable: _this,
        name: 'change',
        toEl: el,
        newIndex: newIndex,
        newDraggableIndex: newDraggableIndex,
        originalEvent: evt
      });
    }
    if (evt.preventDefault !== void 0) {
      evt.cancelable && evt.preventDefault();
    }
    target = closest(target, options.draggable, el, true);
    dragOverEvent('dragOver');
    if (Sortable.eventCanceled) return completedFired;
    if (dragEl.contains(evt.target) || target.animated && target.animatingX && target.animatingY || _this._ignoreWhileAnimating === target) {
      return completed(false);
    }
    ignoreNextClick = false;
    if (activeSortable && !options.disabled && (isOwner ? canSort || (revert = parentEl !== rootEl) // Reverting item into the original list
    : putSortable === this || (this.lastPutMode = activeGroup.checkPull(this, activeSortable, dragEl, evt)) && group.checkPut(this, activeSortable, dragEl, evt))) {
      vertical = this._getDirection(evt, target) === 'vertical';
      dragRect = getRect(dragEl);
      dragOverEvent('dragOverValid');
      if (Sortable.eventCanceled) return completedFired;
      if (revert) {
        parentEl = rootEl; // actualization
        capture();
        this._hideClone();
        dragOverEvent('revert');
        if (!Sortable.eventCanceled) {
          if (nextEl) {
            rootEl.insertBefore(dragEl, nextEl);
          } else {
            rootEl.appendChild(dragEl);
          }
        }
        return completed(true);
      }
      var elLastChild = lastChild(el, options.draggable);
      if (!elLastChild || _ghostIsLast(evt, vertical, this) && !elLastChild.animated) {
        // Insert to end of list

        // If already at end of list: Do not insert
        if (elLastChild === dragEl) {
          return completed(false);
        }

        // if there is a last element, it is the target
        if (elLastChild && el === evt.target) {
          target = elLastChild;
        }
        if (target) {
          targetRect = getRect(target);
        }
        if (_onMove(rootEl, el, dragEl, dragRect, target, targetRect, evt, !!target) !== false) {
          capture();
          if (elLastChild && elLastChild.nextSibling) {
            // the last draggable element is not the last node
            el.insertBefore(dragEl, elLastChild.nextSibling);
          } else {
            el.appendChild(dragEl);
          }
          parentEl = el; // actualization

          changed();
          return completed(true);
        }
      } else if (elLastChild && _ghostIsFirst(evt, vertical, this)) {
        // Insert to start of list
        var firstChild = getChild(el, 0, options, true);
        if (firstChild === dragEl) {
          return completed(false);
        }
        target = firstChild;
        targetRect = getRect(target);
        if (_onMove(rootEl, el, dragEl, dragRect, target, targetRect, evt, false) !== false) {
          capture();
          el.insertBefore(dragEl, firstChild);
          parentEl = el; // actualization

          changed();
          return completed(true);
        }
      } else if (target.parentNode === el) {
        targetRect = getRect(target);
        var direction = 0,
          targetBeforeFirstSwap,
          differentLevel = dragEl.parentNode !== el,
          differentRowCol = !_dragElInRowColumn(dragEl.animated && dragEl.toRect || dragRect, target.animated && target.toRect || targetRect, vertical),
          side1 = vertical ? 'top' : 'left',
          scrolledPastTop = isScrolledPast(target, 'top', 'top') || isScrolledPast(dragEl, 'top', 'top'),
          scrollBefore = scrolledPastTop ? scrolledPastTop.scrollTop : void 0;
        if (lastTarget !== target) {
          targetBeforeFirstSwap = targetRect[side1];
          pastFirstInvertThresh = false;
          isCircumstantialInvert = !differentRowCol && options.invertSwap || differentLevel;
        }
        direction = _getSwapDirection(evt, target, targetRect, vertical, differentRowCol ? 1 : options.swapThreshold, options.invertedSwapThreshold == null ? options.swapThreshold : options.invertedSwapThreshold, isCircumstantialInvert, lastTarget === target);
        var sibling;
        if (direction !== 0) {
          // Check if target is beside dragEl in respective direction (ignoring hidden elements)
          var dragIndex = index(dragEl);
          do {
            dragIndex -= direction;
            sibling = parentEl.children[dragIndex];
          } while (sibling && (css$7(sibling, 'display') === 'none' || sibling === ghostEl));
        }
        // If dragEl is already beside target: Do not insert
        if (direction === 0 || sibling === target) {
          return completed(false);
        }
        lastTarget = target;
        lastDirection = direction;
        var nextSibling = target.nextElementSibling,
          after = false;
        after = direction === 1;
        var moveVector = _onMove(rootEl, el, dragEl, dragRect, target, targetRect, evt, after);
        if (moveVector !== false) {
          if (moveVector === 1 || moveVector === -1) {
            after = moveVector === 1;
          }
          _silent = true;
          setTimeout(_unsilent, 30);
          capture();
          if (after && !nextSibling) {
            el.appendChild(dragEl);
          } else {
            target.parentNode.insertBefore(dragEl, after ? nextSibling : target);
          }

          // Undo chrome's scroll adjustment (has no effect on other browsers)
          if (scrolledPastTop) {
            scrollBy(scrolledPastTop, 0, scrollBefore - scrolledPastTop.scrollTop);
          }
          parentEl = dragEl.parentNode; // actualization

          // must be done before animation
          if (targetBeforeFirstSwap !== undefined && !isCircumstantialInvert) {
            targetMoveDistance = Math.abs(targetBeforeFirstSwap - getRect(target)[side1]);
          }
          changed();
          return completed(true);
        }
      }
      if (el.contains(dragEl)) {
        return completed(false);
      }
    }
    return false;
  },
  _ignoreWhileAnimating: null,
  _offMoveEvents: function _offMoveEvents() {
    off(document, 'mousemove', this._onTouchMove);
    off(document, 'touchmove', this._onTouchMove);
    off(document, 'pointermove', this._onTouchMove);
    off(document, 'dragover', nearestEmptyInsertDetectEvent);
    off(document, 'mousemove', nearestEmptyInsertDetectEvent);
    off(document, 'touchmove', nearestEmptyInsertDetectEvent);
  },
  _offUpEvents: function _offUpEvents() {
    var ownerDocument = this.el.ownerDocument;
    off(ownerDocument, 'mouseup', this._onDrop);
    off(ownerDocument, 'touchend', this._onDrop);
    off(ownerDocument, 'pointerup', this._onDrop);
    off(ownerDocument, 'pointercancel', this._onDrop);
    off(ownerDocument, 'touchcancel', this._onDrop);
    off(document, 'selectstart', this);
  },
  _onDrop: function _onDrop( /**Event*/evt) {
    var el = this.el,
      options = this.options;

    // Get the index of the dragged element within its parent
    newIndex = index(dragEl);
    newDraggableIndex = index(dragEl, options.draggable);
    pluginEvent('drop', this, {
      evt: evt
    });
    parentEl = dragEl && dragEl.parentNode;

    // Get again after plugin event
    newIndex = index(dragEl);
    newDraggableIndex = index(dragEl, options.draggable);
    if (Sortable.eventCanceled) {
      this._nulling();
      return;
    }
    awaitingDragStarted = false;
    isCircumstantialInvert = false;
    pastFirstInvertThresh = false;
    clearInterval(this._loopId);
    clearTimeout(this._dragStartTimer);
    _cancelNextTick(this.cloneId);
    _cancelNextTick(this._dragStartId);

    // Unbind events
    if (this.nativeDraggable) {
      off(document, 'drop', this);
      off(el, 'dragstart', this._onDragStart);
    }
    this._offMoveEvents();
    this._offUpEvents();
    if (Safari) {
      css$7(document.body, 'user-select', '');
    }
    css$7(dragEl, 'transform', '');
    if (evt) {
      if (moved) {
        evt.cancelable && evt.preventDefault();
        !options.dropBubble && evt.stopPropagation();
      }
      ghostEl && ghostEl.parentNode && ghostEl.parentNode.removeChild(ghostEl);
      if (rootEl === parentEl || putSortable && putSortable.lastPutMode !== 'clone') {
        // Remove clone(s)
        cloneEl && cloneEl.parentNode && cloneEl.parentNode.removeChild(cloneEl);
      }
      if (dragEl) {
        if (this.nativeDraggable) {
          off(dragEl, 'dragend', this);
        }
        _disableDraggable(dragEl);
        dragEl.style['will-change'] = '';

        // Remove classes
        // ghostClass is added in dragStarted
        if (moved && !awaitingDragStarted) {
          toggleClass(dragEl, putSortable ? putSortable.options.ghostClass : this.options.ghostClass, false);
        }
        toggleClass(dragEl, this.options.chosenClass, false);

        // Drag stop event
        _dispatchEvent({
          sortable: this,
          name: 'unchoose',
          toEl: parentEl,
          newIndex: null,
          newDraggableIndex: null,
          originalEvent: evt
        });
        if (rootEl !== parentEl) {
          if (newIndex >= 0) {
            // Add event
            _dispatchEvent({
              rootEl: parentEl,
              name: 'add',
              toEl: parentEl,
              fromEl: rootEl,
              originalEvent: evt
            });

            // Remove event
            _dispatchEvent({
              sortable: this,
              name: 'remove',
              toEl: parentEl,
              originalEvent: evt
            });

            // drag from one list and drop into another
            _dispatchEvent({
              rootEl: parentEl,
              name: 'sort',
              toEl: parentEl,
              fromEl: rootEl,
              originalEvent: evt
            });
            _dispatchEvent({
              sortable: this,
              name: 'sort',
              toEl: parentEl,
              originalEvent: evt
            });
          }
          putSortable && putSortable.save();
        } else {
          if (newIndex !== oldIndex) {
            if (newIndex >= 0) {
              // drag & drop within the same list
              _dispatchEvent({
                sortable: this,
                name: 'update',
                toEl: parentEl,
                originalEvent: evt
              });
              _dispatchEvent({
                sortable: this,
                name: 'sort',
                toEl: parentEl,
                originalEvent: evt
              });
            }
          }
        }
        if (Sortable.active) {
          /* jshint eqnull:true */
          if (newIndex == null || newIndex === -1) {
            newIndex = oldIndex;
            newDraggableIndex = oldDraggableIndex;
          }
          _dispatchEvent({
            sortable: this,
            name: 'end',
            toEl: parentEl,
            originalEvent: evt
          });

          // Save sorting
          this.save();
        }
      }
    }
    this._nulling();
  },
  _nulling: function _nulling() {
    pluginEvent('nulling', this);
    rootEl = dragEl = parentEl = ghostEl = nextEl = cloneEl = lastDownEl = cloneHidden = tapEvt = touchEvt = moved = newIndex = newDraggableIndex = oldIndex = oldDraggableIndex = lastTarget = lastDirection = putSortable = activeGroup = Sortable.dragged = Sortable.ghost = Sortable.clone = Sortable.active = null;
    savedInputChecked.forEach(function (el) {
      el.checked = true;
    });
    savedInputChecked.length = lastDx = lastDy = 0;
  },
  handleEvent: function handleEvent( /**Event*/evt) {
    switch (evt.type) {
      case 'drop':
      case 'dragend':
        this._onDrop(evt);
        break;
      case 'dragenter':
      case 'dragover':
        if (dragEl) {
          this._onDragOver(evt);
          _globalDragOver(evt);
        }
        break;
      case 'selectstart':
        evt.preventDefault();
        break;
    }
  },
  /**
   * Serializes the item into an array of string.
   * @returns {String[]}
   */
  toArray: function toArray() {
    var order = [],
      el,
      children = this.el.children,
      i = 0,
      n = children.length,
      options = this.options;
    for (; i < n; i++) {
      el = children[i];
      if (closest(el, options.draggable, this.el, false)) {
        order.push(el.getAttribute(options.dataIdAttr) || _generateId(el));
      }
    }
    return order;
  },
  /**
   * Sorts the elements according to the array.
   * @param  {String[]}  order  order of the items
   */
  sort: function sort(order, useAnimation) {
    var items = {},
      rootEl = this.el;
    this.toArray().forEach(function (id, i) {
      var el = rootEl.children[i];
      if (closest(el, this.options.draggable, rootEl, false)) {
        items[id] = el;
      }
    }, this);
    useAnimation && this.captureAnimationState();
    order.forEach(function (id) {
      if (items[id]) {
        rootEl.removeChild(items[id]);
        rootEl.appendChild(items[id]);
      }
    });
    useAnimation && this.animateAll();
  },
  /**
   * Save the current sorting
   */
  save: function save() {
    var store = this.options.store;
    store && store.set && store.set(this);
  },
  /**
   * For each element in the set, get the first element that matches the selector by testing the element itself and traversing up through its ancestors in the DOM tree.
   * @param   {HTMLElement}  el
   * @param   {String}       [selector]  default: `options.draggable`
   * @returns {HTMLElement|null}
   */
  closest: function closest$1(el, selector) {
    return closest(el, selector || this.options.draggable, this.el, false);
  },
  /**
   * Set/get option
   * @param   {string} name
   * @param   {*}      [value]
   * @returns {*}
   */
  option: function option(name, value) {
    var options = this.options;
    if (value === void 0) {
      return options[name];
    } else {
      var modifiedValue = PluginManager.modifyOption(this, name, value);
      if (typeof modifiedValue !== 'undefined') {
        options[name] = modifiedValue;
      } else {
        options[name] = value;
      }
      if (name === 'group') {
        _prepareGroup(options);
      }
    }
  },
  /**
   * Destroy
   */
  destroy: function destroy() {
    pluginEvent('destroy', this);
    var el = this.el;
    el[expando] = null;
    off(el, 'mousedown', this._onTapStart);
    off(el, 'touchstart', this._onTapStart);
    off(el, 'pointerdown', this._onTapStart);
    if (this.nativeDraggable) {
      off(el, 'dragover', this);
      off(el, 'dragenter', this);
    }
    // Remove draggable attributes
    Array.prototype.forEach.call(el.querySelectorAll('[draggable]'), function (el) {
      el.removeAttribute('draggable');
    });
    this._onDrop();
    this._disableDelayedDragEvents();
    sortables.splice(sortables.indexOf(this.el), 1);
    this.el = el = null;
  },
  _hideClone: function _hideClone() {
    if (!cloneHidden) {
      pluginEvent('hideClone', this);
      if (Sortable.eventCanceled) return;
      css$7(cloneEl, 'display', 'none');
      if (this.options.removeCloneOnHide && cloneEl.parentNode) {
        cloneEl.parentNode.removeChild(cloneEl);
      }
      cloneHidden = true;
    }
  },
  _showClone: function _showClone(putSortable) {
    if (putSortable.lastPutMode !== 'clone') {
      this._hideClone();
      return;
    }
    if (cloneHidden) {
      pluginEvent('showClone', this);
      if (Sortable.eventCanceled) return;

      // show clone at dragEl or original position
      if (dragEl.parentNode == rootEl && !this.options.group.revertClone) {
        rootEl.insertBefore(cloneEl, dragEl);
      } else if (nextEl) {
        rootEl.insertBefore(cloneEl, nextEl);
      } else {
        rootEl.appendChild(cloneEl);
      }
      if (this.options.group.revertClone) {
        this.animate(dragEl, cloneEl);
      }
      css$7(cloneEl, 'display', '');
      cloneHidden = false;
    }
  }
};
function _globalDragOver( /**Event*/evt) {
  if (evt.dataTransfer) {
    evt.dataTransfer.dropEffect = 'move';
  }
  evt.cancelable && evt.preventDefault();
}
function _onMove(fromEl, toEl, dragEl, dragRect, targetEl, targetRect, originalEvent, willInsertAfter) {
  var evt,
    sortable = fromEl[expando],
    onMoveFn = sortable.options.onMove,
    retVal;
  // Support for new CustomEvent feature
  if (window.CustomEvent && !IE11OrLess && !Edge) {
    evt = new CustomEvent('move', {
      bubbles: true,
      cancelable: true
    });
  } else {
    evt = document.createEvent('Event');
    evt.initEvent('move', true, true);
  }
  evt.to = toEl;
  evt.from = fromEl;
  evt.dragged = dragEl;
  evt.draggedRect = dragRect;
  evt.related = targetEl || toEl;
  evt.relatedRect = targetRect || getRect(toEl);
  evt.willInsertAfter = willInsertAfter;
  evt.originalEvent = originalEvent;
  fromEl.dispatchEvent(evt);
  if (onMoveFn) {
    retVal = onMoveFn.call(sortable, evt, originalEvent);
  }
  return retVal;
}
function _disableDraggable(el) {
  el.draggable = false;
}
function _unsilent() {
  _silent = false;
}
function _ghostIsFirst(evt, vertical, sortable) {
  var firstElRect = getRect(getChild(sortable.el, 0, sortable.options, true));
  var childContainingRect = getChildContainingRectFromElement(sortable.el, sortable.options, ghostEl);
  var spacer = 10;
  return vertical ? evt.clientX < childContainingRect.left - spacer || evt.clientY < firstElRect.top && evt.clientX < firstElRect.right : evt.clientY < childContainingRect.top - spacer || evt.clientY < firstElRect.bottom && evt.clientX < firstElRect.left;
}
function _ghostIsLast(evt, vertical, sortable) {
  var lastElRect = getRect(lastChild(sortable.el, sortable.options.draggable));
  var childContainingRect = getChildContainingRectFromElement(sortable.el, sortable.options, ghostEl);
  var spacer = 10;
  return vertical ? evt.clientX > childContainingRect.right + spacer || evt.clientY > lastElRect.bottom && evt.clientX > lastElRect.left : evt.clientY > childContainingRect.bottom + spacer || evt.clientX > lastElRect.right && evt.clientY > lastElRect.top;
}
function _getSwapDirection(evt, target, targetRect, vertical, swapThreshold, invertedSwapThreshold, invertSwap, isLastTarget) {
  var mouseOnAxis = vertical ? evt.clientY : evt.clientX,
    targetLength = vertical ? targetRect.height : targetRect.width,
    targetS1 = vertical ? targetRect.top : targetRect.left,
    targetS2 = vertical ? targetRect.bottom : targetRect.right,
    invert = false;
  if (!invertSwap) {
    // Never invert or create dragEl shadow when target movemenet causes mouse to move past the end of regular swapThreshold
    if (isLastTarget && targetMoveDistance < targetLength * swapThreshold) {
      // multiplied only by swapThreshold because mouse will already be inside target by (1 - threshold) * targetLength / 2
      // check if past first invert threshold on side opposite of lastDirection
      if (!pastFirstInvertThresh && (lastDirection === 1 ? mouseOnAxis > targetS1 + targetLength * invertedSwapThreshold / 2 : mouseOnAxis < targetS2 - targetLength * invertedSwapThreshold / 2)) {
        // past first invert threshold, do not restrict inverted threshold to dragEl shadow
        pastFirstInvertThresh = true;
      }
      if (!pastFirstInvertThresh) {
        // dragEl shadow (target move distance shadow)
        if (lastDirection === 1 ? mouseOnAxis < targetS1 + targetMoveDistance // over dragEl shadow
        : mouseOnAxis > targetS2 - targetMoveDistance) {
          return -lastDirection;
        }
      } else {
        invert = true;
      }
    } else {
      // Regular
      if (mouseOnAxis > targetS1 + targetLength * (1 - swapThreshold) / 2 && mouseOnAxis < targetS2 - targetLength * (1 - swapThreshold) / 2) {
        return _getInsertDirection(target);
      }
    }
  }
  invert = invert || invertSwap;
  if (invert) {
    // Invert of regular
    if (mouseOnAxis < targetS1 + targetLength * invertedSwapThreshold / 2 || mouseOnAxis > targetS2 - targetLength * invertedSwapThreshold / 2) {
      return mouseOnAxis > targetS1 + targetLength / 2 ? 1 : -1;
    }
  }
  return 0;
}

/**
 * Gets the direction dragEl must be swapped relative to target in order to make it
 * seem that dragEl has been "inserted" into that element's position
 * @param  {HTMLElement} target       The target whose position dragEl is being inserted at
 * @return {Number}                   Direction dragEl must be swapped
 */
function _getInsertDirection(target) {
  if (index(dragEl) < index(target)) {
    return 1;
  } else {
    return -1;
  }
}

/**
 * Generate id
 * @param   {HTMLElement} el
 * @returns {String}
 * @private
 */
function _generateId(el) {
  var str = el.tagName + el.className + el.src + el.href + el.textContent,
    i = str.length,
    sum = 0;
  while (i--) {
    sum += str.charCodeAt(i);
  }
  return sum.toString(36);
}
function _saveInputCheckedState(root) {
  savedInputChecked.length = 0;
  var inputs = root.getElementsByTagName('input');
  var idx = inputs.length;
  while (idx--) {
    var el = inputs[idx];
    el.checked && savedInputChecked.push(el);
  }
}
function _nextTick(fn) {
  return setTimeout(fn, 0);
}
function _cancelNextTick(id) {
  return clearTimeout(id);
}

// Fixed #973:
if (documentExists) {
  on(document, 'touchmove', function (evt) {
    if ((Sortable.active || awaitingDragStarted) && evt.cancelable) {
      evt.preventDefault();
    }
  });
}

// Export utils
Sortable.utils = {
  on: on,
  off: off,
  css: css$7,
  find: find,
  is: function is(el, selector) {
    return !!closest(el, selector, el, false);
  },
  extend: extend,
  throttle: throttle,
  closest: closest,
  toggleClass: toggleClass,
  clone: clone,
  index: index,
  nextTick: _nextTick,
  cancelNextTick: _cancelNextTick,
  detectDirection: _detectDirection,
  getChild: getChild,
  expando: expando
};

/**
 * Get the Sortable instance of an element
 * @param  {HTMLElement} element The element
 * @return {Sortable|undefined}         The instance of Sortable
 */
Sortable.get = function (element) {
  return element[expando];
};

/**
 * Mount a plugin to Sortable
 * @param  {...SortablePlugin|SortablePlugin[]} plugins       Plugins being mounted
 */
Sortable.mount = function () {
  for (var _len = arguments.length, plugins = new Array(_len), _key = 0; _key < _len; _key++) {
    plugins[_key] = arguments[_key];
  }
  if (plugins[0].constructor === Array) plugins = plugins[0];
  plugins.forEach(function (plugin) {
    if (!plugin.prototype || !plugin.prototype.constructor) {
      throw "Sortable: Mounted plugin must be a constructor function, not ".concat({}.toString.call(plugin));
    }
    if (plugin.utils) Sortable.utils = _objectSpread2(_objectSpread2({}, Sortable.utils), plugin.utils);
    PluginManager.mount(plugin);
  });
};

/**
 * Create sortable instance
 * @param {HTMLElement}  el
 * @param {Object}      [options]
 */
Sortable.create = function (el, options) {
  return new Sortable(el, options);
};

// Export
Sortable.version = version;

var autoScrolls = [],
  scrollEl,
  scrollRootEl,
  scrolling = false,
  lastAutoScrollX,
  lastAutoScrollY,
  touchEvt$1,
  pointerElemChangedInterval;
function AutoScrollPlugin() {
  function AutoScroll() {
    this.defaults = {
      scroll: true,
      forceAutoScrollFallback: false,
      scrollSensitivity: 30,
      scrollSpeed: 10,
      bubbleScroll: true
    };

    // Bind all private methods
    for (var fn in this) {
      if (fn.charAt(0) === '_' && typeof this[fn] === 'function') {
        this[fn] = this[fn].bind(this);
      }
    }
  }
  AutoScroll.prototype = {
    dragStarted: function dragStarted(_ref) {
      var originalEvent = _ref.originalEvent;
      if (this.sortable.nativeDraggable) {
        on(document, 'dragover', this._handleAutoScroll);
      } else {
        if (this.options.supportPointer) {
          on(document, 'pointermove', this._handleFallbackAutoScroll);
        } else if (originalEvent.touches) {
          on(document, 'touchmove', this._handleFallbackAutoScroll);
        } else {
          on(document, 'mousemove', this._handleFallbackAutoScroll);
        }
      }
    },
    dragOverCompleted: function dragOverCompleted(_ref2) {
      var originalEvent = _ref2.originalEvent;
      // For when bubbling is canceled and using fallback (fallback 'touchmove' always reached)
      if (!this.options.dragOverBubble && !originalEvent.rootEl) {
        this._handleAutoScroll(originalEvent);
      }
    },
    drop: function drop() {
      if (this.sortable.nativeDraggable) {
        off(document, 'dragover', this._handleAutoScroll);
      } else {
        off(document, 'pointermove', this._handleFallbackAutoScroll);
        off(document, 'touchmove', this._handleFallbackAutoScroll);
        off(document, 'mousemove', this._handleFallbackAutoScroll);
      }
      clearPointerElemChangedInterval();
      clearAutoScrolls();
      cancelThrottle();
    },
    nulling: function nulling() {
      touchEvt$1 = scrollRootEl = scrollEl = scrolling = pointerElemChangedInterval = lastAutoScrollX = lastAutoScrollY = null;
      autoScrolls.length = 0;
    },
    _handleFallbackAutoScroll: function _handleFallbackAutoScroll(evt) {
      this._handleAutoScroll(evt, true);
    },
    _handleAutoScroll: function _handleAutoScroll(evt, fallback) {
      var _this = this;
      var x = (evt.touches ? evt.touches[0] : evt).clientX,
        y = (evt.touches ? evt.touches[0] : evt).clientY,
        elem = document.elementFromPoint(x, y);
      touchEvt$1 = evt;

      // IE does not seem to have native autoscroll,
      // Edge's autoscroll seems too conditional,
      // MACOS Safari does not have autoscroll,
      // Firefox and Chrome are good
      if (fallback || this.options.forceAutoScrollFallback || Edge || IE11OrLess || Safari) {
        autoScroll(evt, this.options, elem, fallback);

        // Listener for pointer element change
        var ogElemScroller = getParentAutoScrollElement(elem, true);
        if (scrolling && (!pointerElemChangedInterval || x !== lastAutoScrollX || y !== lastAutoScrollY)) {
          pointerElemChangedInterval && clearPointerElemChangedInterval();
          // Detect for pointer elem change, emulating native DnD behaviour
          pointerElemChangedInterval = setInterval(function () {
            var newElem = getParentAutoScrollElement(document.elementFromPoint(x, y), true);
            if (newElem !== ogElemScroller) {
              ogElemScroller = newElem;
              clearAutoScrolls();
            }
            autoScroll(evt, _this.options, newElem, fallback);
          }, 10);
          lastAutoScrollX = x;
          lastAutoScrollY = y;
        }
      } else {
        // if DnD is enabled (and browser has good autoscrolling), first autoscroll will already scroll, so get parent autoscroll of first autoscroll
        if (!this.options.bubbleScroll || getParentAutoScrollElement(elem, true) === getWindowScrollingElement()) {
          clearAutoScrolls();
          return;
        }
        autoScroll(evt, this.options, getParentAutoScrollElement(elem, false), false);
      }
    }
  };
  return _extends(AutoScroll, {
    pluginName: 'scroll',
    initializeByDefault: true
  });
}
function clearAutoScrolls() {
  autoScrolls.forEach(function (autoScroll) {
    clearInterval(autoScroll.pid);
  });
  autoScrolls = [];
}
function clearPointerElemChangedInterval() {
  clearInterval(pointerElemChangedInterval);
}
var autoScroll = throttle(function (evt, options, rootEl, isFallback) {
  // Bug: https://bugzilla.mozilla.org/show_bug.cgi?id=505521
  if (!options.scroll) return;
  var x = (evt.touches ? evt.touches[0] : evt).clientX,
    y = (evt.touches ? evt.touches[0] : evt).clientY,
    sens = options.scrollSensitivity,
    speed = options.scrollSpeed,
    winScroller = getWindowScrollingElement();
  var scrollThisInstance = false,
    scrollCustomFn;

  // New scroll root, set scrollEl
  if (scrollRootEl !== rootEl) {
    scrollRootEl = rootEl;
    clearAutoScrolls();
    scrollEl = options.scroll;
    scrollCustomFn = options.scrollFn;
    if (scrollEl === true) {
      scrollEl = getParentAutoScrollElement(rootEl, true);
    }
  }
  var layersOut = 0;
  var currentParent = scrollEl;
  do {
    var el = currentParent,
      rect = getRect(el),
      top = rect.top,
      bottom = rect.bottom,
      left = rect.left,
      right = rect.right,
      width = rect.width,
      height = rect.height,
      canScrollX = void 0,
      canScrollY = void 0,
      scrollWidth = el.scrollWidth,
      scrollHeight = el.scrollHeight,
      elCSS = css$7(el),
      scrollPosX = el.scrollLeft,
      scrollPosY = el.scrollTop;
    if (el === winScroller) {
      canScrollX = width < scrollWidth && (elCSS.overflowX === 'auto' || elCSS.overflowX === 'scroll' || elCSS.overflowX === 'visible');
      canScrollY = height < scrollHeight && (elCSS.overflowY === 'auto' || elCSS.overflowY === 'scroll' || elCSS.overflowY === 'visible');
    } else {
      canScrollX = width < scrollWidth && (elCSS.overflowX === 'auto' || elCSS.overflowX === 'scroll');
      canScrollY = height < scrollHeight && (elCSS.overflowY === 'auto' || elCSS.overflowY === 'scroll');
    }
    var vx = canScrollX && (Math.abs(right - x) <= sens && scrollPosX + width < scrollWidth) - (Math.abs(left - x) <= sens && !!scrollPosX);
    var vy = canScrollY && (Math.abs(bottom - y) <= sens && scrollPosY + height < scrollHeight) - (Math.abs(top - y) <= sens && !!scrollPosY);
    if (!autoScrolls[layersOut]) {
      for (var i = 0; i <= layersOut; i++) {
        if (!autoScrolls[i]) {
          autoScrolls[i] = {};
        }
      }
    }
    if (autoScrolls[layersOut].vx != vx || autoScrolls[layersOut].vy != vy || autoScrolls[layersOut].el !== el) {
      autoScrolls[layersOut].el = el;
      autoScrolls[layersOut].vx = vx;
      autoScrolls[layersOut].vy = vy;
      clearInterval(autoScrolls[layersOut].pid);
      if (vx != 0 || vy != 0) {
        scrollThisInstance = true;
        /* jshint loopfunc:true */
        autoScrolls[layersOut].pid = setInterval(function () {
          // emulate drag over during autoscroll (fallback), emulating native DnD behaviour
          if (isFallback && this.layer === 0) {
            Sortable.active._onTouchMove(touchEvt$1); // To move ghost if it is positioned absolutely
          }
          var scrollOffsetY = autoScrolls[this.layer].vy ? autoScrolls[this.layer].vy * speed : 0;
          var scrollOffsetX = autoScrolls[this.layer].vx ? autoScrolls[this.layer].vx * speed : 0;
          if (typeof scrollCustomFn === 'function') {
            if (scrollCustomFn.call(Sortable.dragged.parentNode[expando], scrollOffsetX, scrollOffsetY, evt, touchEvt$1, autoScrolls[this.layer].el) !== 'continue') {
              return;
            }
          }
          scrollBy(autoScrolls[this.layer].el, scrollOffsetX, scrollOffsetY);
        }.bind({
          layer: layersOut
        }), 24);
      }
    }
    layersOut++;
  } while (options.bubbleScroll && currentParent !== winScroller && (currentParent = getParentAutoScrollElement(currentParent, false)));
  scrolling = scrollThisInstance; // in case another function catches scrolling as false in between when it is not
}, 30);

var drop = function drop(_ref) {
  var originalEvent = _ref.originalEvent,
    putSortable = _ref.putSortable,
    dragEl = _ref.dragEl,
    activeSortable = _ref.activeSortable,
    dispatchSortableEvent = _ref.dispatchSortableEvent,
    hideGhostForTarget = _ref.hideGhostForTarget,
    unhideGhostForTarget = _ref.unhideGhostForTarget;
  if (!originalEvent) return;
  var toSortable = putSortable || activeSortable;
  hideGhostForTarget();
  var touch = originalEvent.changedTouches && originalEvent.changedTouches.length ? originalEvent.changedTouches[0] : originalEvent;
  var target = document.elementFromPoint(touch.clientX, touch.clientY);
  unhideGhostForTarget();
  if (toSortable && !toSortable.el.contains(target)) {
    dispatchSortableEvent('spill');
    this.onSpill({
      dragEl: dragEl,
      putSortable: putSortable
    });
  }
};
function Revert() {}
Revert.prototype = {
  startIndex: null,
  dragStart: function dragStart(_ref2) {
    var oldDraggableIndex = _ref2.oldDraggableIndex;
    this.startIndex = oldDraggableIndex;
  },
  onSpill: function onSpill(_ref3) {
    var dragEl = _ref3.dragEl,
      putSortable = _ref3.putSortable;
    this.sortable.captureAnimationState();
    if (putSortable) {
      putSortable.captureAnimationState();
    }
    var nextSibling = getChild(this.sortable.el, this.startIndex, this.options);
    if (nextSibling) {
      this.sortable.el.insertBefore(dragEl, nextSibling);
    } else {
      this.sortable.el.appendChild(dragEl);
    }
    this.sortable.animateAll();
    if (putSortable) {
      putSortable.animateAll();
    }
  },
  drop: drop
};
_extends(Revert, {
  pluginName: 'revertOnSpill'
});
function Remove() {}
Remove.prototype = {
  onSpill: function onSpill(_ref4) {
    var dragEl = _ref4.dragEl,
      putSortable = _ref4.putSortable;
    var parentSortable = putSortable || this.sortable;
    parentSortable.captureAnimationState();
    dragEl.parentNode && dragEl.parentNode.removeChild(dragEl);
    parentSortable.animateAll();
  },
  drop: drop
};
_extends(Remove, {
  pluginName: 'removeOnSpill'
});

Sortable.mount(new AutoScrollPlugin());
Sortable.mount(Remove, Revert);

/**
 * @license
 * Copyright 2018 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
var cssClasses = {
    ACTIVE: 'mdc-tab-indicator--active',
    FADE: 'mdc-tab-indicator--fade',
    NO_TRANSITION: 'mdc-tab-indicator--no-transition',
};
var strings = {
    CONTENT_SELECTOR: '.mdc-tab-indicator__content',
};

/**
 * @license
 * Copyright 2018 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
var MDCTabIndicatorFoundation = /** @class */ (function (_super) {
    __extends(MDCTabIndicatorFoundation, _super);
    function MDCTabIndicatorFoundation(adapter) {
        return _super.call(this, __assign(__assign({}, MDCTabIndicatorFoundation.defaultAdapter), adapter)) || this;
    }
    Object.defineProperty(MDCTabIndicatorFoundation, "cssClasses", {
        get: function () {
            return cssClasses;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(MDCTabIndicatorFoundation, "strings", {
        get: function () {
            return strings;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(MDCTabIndicatorFoundation, "defaultAdapter", {
        get: function () {
            // tslint:disable:object-literal-sort-keys Methods should be in the same order as the adapter interface.
            return {
                addClass: function () { return undefined; },
                removeClass: function () { return undefined; },
                computeContentClientRect: function () {
                    return ({ top: 0, right: 0, bottom: 0, left: 0, width: 0, height: 0 });
                },
                setContentStyleProperty: function () { return undefined; },
            };
            // tslint:enable:object-literal-sort-keys
        },
        enumerable: false,
        configurable: true
    });
    MDCTabIndicatorFoundation.prototype.computeContentClientRect = function () {
        return this.adapter.computeContentClientRect();
    };
    return MDCTabIndicatorFoundation;
}(MDCFoundation));

/**
 * @license
 * Copyright 2018 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/* istanbul ignore next: subclass is not a branch statement */
var MDCFadingTabIndicatorFoundation = /** @class */ (function (_super) {
    __extends(MDCFadingTabIndicatorFoundation, _super);
    function MDCFadingTabIndicatorFoundation() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    MDCFadingTabIndicatorFoundation.prototype.activate = function () {
        this.adapter.addClass(MDCTabIndicatorFoundation.cssClasses.ACTIVE);
    };
    MDCFadingTabIndicatorFoundation.prototype.deactivate = function () {
        this.adapter.removeClass(MDCTabIndicatorFoundation.cssClasses.ACTIVE);
    };
    return MDCFadingTabIndicatorFoundation;
}(MDCTabIndicatorFoundation));

/**
 * @license
 * Copyright 2018 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/* istanbul ignore next: subclass is not a branch statement */
var MDCSlidingTabIndicatorFoundation = /** @class */ (function (_super) {
    __extends(MDCSlidingTabIndicatorFoundation, _super);
    function MDCSlidingTabIndicatorFoundation() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    MDCSlidingTabIndicatorFoundation.prototype.activate = function (previousIndicatorClientRect) {
        // Early exit if no indicator is present to handle cases where an indicator
        // may be activated without a prior indicator state
        if (!previousIndicatorClientRect) {
            this.adapter.addClass(MDCTabIndicatorFoundation.cssClasses.ACTIVE);
            return;
        }
        // This animation uses the FLIP approach. You can read more about it at the link below:
        // https://aerotwist.com/blog/flip-your-animations/
        // Calculate the dimensions based on the dimensions of the previous indicator
        var currentClientRect = this.computeContentClientRect();
        var widthDelta = previousIndicatorClientRect.width / currentClientRect.width;
        var xPosition = previousIndicatorClientRect.left - currentClientRect.left;
        this.adapter.addClass(MDCTabIndicatorFoundation.cssClasses.NO_TRANSITION);
        this.adapter.setContentStyleProperty('transform', "translateX(" + xPosition + "px) scaleX(" + widthDelta + ")");
        // Force repaint before updating classes and transform to ensure the transform properly takes effect
        this.computeContentClientRect();
        this.adapter.removeClass(MDCTabIndicatorFoundation.cssClasses.NO_TRANSITION);
        this.adapter.addClass(MDCTabIndicatorFoundation.cssClasses.ACTIVE);
        this.adapter.setContentStyleProperty('transform', '');
    };
    MDCSlidingTabIndicatorFoundation.prototype.deactivate = function () {
        this.adapter.removeClass(MDCTabIndicatorFoundation.cssClasses.ACTIVE);
    };
    return MDCSlidingTabIndicatorFoundation;
}(MDCTabIndicatorFoundation));

const Actions = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["use", "class", "fullBleed", "getElement"]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { fullBleed = false } = $$props;
  let element;
  setContext("SMUI:button:context", "card:action");
  setContext("SMUI:icon-button:context", "card:action");
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.fullBleed === void 0 && $$bindings.fullBleed && fullBleed !== void 0) $$bindings.fullBleed(fullBleed);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  return `<div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "mdc-card__actions": true,
          "mdc-card__actions--full-bleed": fullBleed
        }))
      },
      escape_object($$restProps)
    ],
    {}
  )}${add_attribute("this", element, 0)}>${slots.default ? slots.default({}) : ``} </div>`;
});
const css$6 = {
  code: "header.svelte-ql5em8{position:absolute;display:flex;justify-content:space-between;top:0;width:100%}.top-app-bar-container.svelte-ql5em8{border:1px solid\r\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));margin:0 18px 18px 0;background-color:var(--mdc-theme-background, #fff);overflow:auto;display:inline-block}.lang_span.svelte-ql5em8{font-size:smaller;bottom:-15px;position:relative}.lang_list.svelte-ql5em8{position:absolute;top:50px;height:75vh;overflow:auto;justify-content:center;align-items:center;background-color:darkturquoise}",
  map: `{"version":3,"file":"Header.svelte","sources":["Header.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, setContext } from \\"svelte\\";\\nimport TopAppBar, { Row, Title, Section } from \\"@smui/top-app-bar\\";\\nimport { dicts, langs, view, lesson } from \\"$lib/js/stores\\";\\nimport google_langs_list from \\"$lib/dict/google_lang_list.json\\";\\nimport ISO6391 from \\"iso-google-locales\\";\\nimport { Translate } from \\"../translate/Transloc\\";\\nlet topAppBar;\\nlet abonent;\\nlet lang_menu = false;\\nonMount(async () => {\\n  let params = new URL(document.location).searchParams;\\n  abonent = params.get(\\"abonent\\");\\n});\\nfunction OnSetLang(ev) {\\n  let lang = ev.currentTarget.outerText;\\n  let code = ISO6391.getCode(lang);\\n  if (code !== \\"English\\") {\\n    $langs = code;\\n  }\\n  lang_menu = false;\\n  fetch(\`/?func=set_lang&abonent=\${abonent}&admin==\${abonent}&lang=\${$langs}\`).then(() => console.log()).catch((error) => {\\n    console.log(error);\\n  });\\n}\\n<\/script>\\r\\n\\r\\n<!-- {#if $dicts && $langs && $dicts['CLASS'][$langs]} -->\\r\\n<header>\\r\\n  <div class=\\"top-app-bar-container flexor\\">\\r\\n    <TopAppBar bind:this={topAppBar} variant=\\"fixed\\" dense>\\r\\n      <Row>\\r\\n        <div class=\\"sec_items\\">\\r\\n          {#if $view !== 'login'}\\r\\n            <Section>\\r\\n              {#await Translate('GROUP', 'en', $langs) then data}\\r\\n                <Title\\r\\n                  on:click={() => {\\r\\n                    $view = 'group';\\r\\n                  }}>{data}</Title\\r\\n                >\\r\\n              {/await}\\r\\n              {#await Translate('LESSON', 'en', $langs) then data}\\r\\n                <Title\\r\\n                  on:click={async () => {\\r\\n                    console.log();\\r\\n                    $lesson.data = { quiz: '' };\\r\\n                    $view = 'lesson';\\r\\n                  }}>{data}</Title\\r\\n                >\\r\\n              {/await}\\r\\n              <!-- <IconButton class=\\"material-icons\\" aria-label=\\"Bookmark this page\\">bookmark</IconButton> -->\\r\\n            </Section>\\r\\n          {/if}\\r\\n        </div>\\r\\n\\r\\n        <Section align=\\"end\\">\\r\\n          <span\\r\\n            class=\\"lang_span\\"\\r\\n            on:click={() => {\\r\\n              lang_menu = !lang_menu;\\r\\n            }}\\r\\n            >{(() => {\\r\\n              return ISO6391.getNativeName($langs);\\r\\n            })()}</span\\r\\n          >\\r\\n          {#if lang_menu}\\r\\n            <div class=\\"lang_list\\">\\r\\n              {#each google_langs_list as lang}\\r\\n                <div\\r\\n                  style=\\"color:black; margin:10px;font-size:smaller\\"\\r\\n                  on:click={OnSetLang}\\r\\n                >\\r\\n                  {lang}\\r\\n                </div>\\r\\n              {/each}\\r\\n            </div>\\r\\n          {/if}\\r\\n        </Section>\\r\\n      </Row>\\r\\n    </TopAppBar>\\r\\n    <div class=\\"flexor-content\\"></div>\\r\\n  </div>\\r\\n</header>\\r\\n\\r\\n<!-- {/if} -->\\r\\n\\r\\n<style>\\r\\n  header {\\r\\n    position: absolute;\\r\\n    display: flex;\\r\\n    justify-content: space-between;\\r\\n    top: 0;\\r\\n    width: 100%;\\r\\n  }\\r\\n  .top-app-bar-container {\\r\\n    /* max-width: 480px; */\\r\\n    /* width: 100%; */\\r\\n    /* height: 100vh; */\\r\\n    border: 1px solid\\r\\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));\\r\\n    margin: 0 18px 18px 0;\\r\\n    background-color: var(--mdc-theme-background, #fff);\\r\\n\\r\\n    overflow: auto;\\r\\n    display: inline-block;\\r\\n  }\\r\\n\\r\\n  .lang_span {\\r\\n    font-size: smaller;\\r\\n    bottom: -15px;\\r\\n    position: relative;\\r\\n  }\\r\\n\\r\\n  .lang_list {\\r\\n    position: absolute;\\r\\n    top: 50px;\\r\\n    height: 75vh;\\r\\n    overflow: auto;\\r\\n    justify-content: center; /* Выравниваем содержимое по центру вертикально */\\r\\n    align-items: center; /* Выравниваем содержимое по центру горизонтально */\\r\\n    background-color: darkturquoise;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAuFE,oBAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,GAAG,CAAE,CAAC,CACN,KAAK,CAAE,IACT,CACA,oCAAuB,CAIrB,MAAM,CAAE,GAAG,CAAC,KAAK;AACrB,MAAM,IAAI,mCAAmC,CAAC,mBAAmB,CAAC,CAC9D,MAAM,CAAE,CAAC,CAAC,IAAI,CAAC,IAAI,CAAC,CAAC,CACrB,gBAAgB,CAAE,IAAI,sBAAsB,CAAC,KAAK,CAAC,CAEnD,QAAQ,CAAE,IAAI,CACd,OAAO,CAAE,YACX,CAEA,wBAAW,CACT,SAAS,CAAE,OAAO,CAClB,MAAM,CAAE,KAAK,CACb,QAAQ,CAAE,QACZ,CAEA,wBAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CACT,MAAM,CAAE,IAAI,CACZ,QAAQ,CAAE,IAAI,CACd,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,gBAAgB,CAAE,aACpB"}`
};
const Header = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $view, $$unsubscribe_view;
  let $$unsubscribe_lesson;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => value);
  let topAppBar;
  $$result.css.add(css$6);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = ` <header class="svelte-ql5em8"><div class="top-app-bar-container flexor svelte-ql5em8">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      {
        variant: "fixed",
        dense: true,
        this: topAppBar
      },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `<div class="sec_items">${$view !== "login" ? `${validate_component(Section, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return `${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data) {
                      return ` ${validate_component(Title, "Title").$$render($$result, {}, {}, {
                        default: () => {
                          return `${escape(data)}`;
                        }
                      })} `;
                    }(__value);
                  }(Translate("GROUP", "en", $langs))} ${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data) {
                      return ` ${validate_component(Title, "Title").$$render($$result, {}, {}, {
                        default: () => {
                          return `${escape(data)}`;
                        }
                      })} `;
                    }(__value);
                  }(Translate("LESSON", "en", $langs))} `;
                }
              })}` : ``}</div> ${validate_component(Section, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<span class="lang_span svelte-ql5em8">${escape((() => {
                    return ISO6391.getNativeName($langs);
                  })())}</span> ${``}`;
                }
              })}`;
            }
          })}`;
        }
      }
    )} <div class="flexor-content"></div></div></header> `;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_view();
  $$unsubscribe_lesson();
  return $$rendered;
});
const css$5 = {
  code: "@media screen and (min-width: 768px){}@media screen and (max-width: 767px){}form.svelte-1oy5700{display:flex;flex-direction:column;align-items:center;max-width:400px;margin:0 auto;padding:20px;border:1px solid #ccc;border-radius:5px;background-color:#fff}",
  map: `{"version":3,"file":"Login.svelte","sources":["Login.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount } from \\"svelte\\";\\nimport { applyAction, deserialize } from \\"$app/forms\\";\\nimport Button from \\"@smui/button\\";\\nimport Textfield from \\"@smui/textfield\\";\\nimport { dicts } from \\"../../../lib/js/stores.js\\";\\nimport { langs } from \\"$lib/js/stores.js\\";\\nexport let email, abonent;\\nlet width, height, value;\\nlet formData = {\\n  func: \\"\\",\\n  name: \\"\\",\\n  email: \\"\\",\\n  psw: \\"\\",\\n  confirmPassword: \\"\\",\\n  picture: \\"\\",\\n  lang: $langs\\n};\\nif (!formData.picture) {\\n  formData.picture = \\"/assets/operator.svg\\";\\n}\\nlet psw;\\nlet confirmPassword;\\nlet passwordMatch = true;\\nonMount(async () => {\\n  let url = new URL(window.location.href);\\n  abonent = url.searchParams.get(\\"abonent\\");\\n});\\nasync function handleSubmit() {\\n  let par = formData;\\n  par.email = par.email.trim();\\n  passwordMatch = par.confirmPassword === par.psw;\\n  if (!passwordMatch)\\n    return;\\n  par.func = \\"operator\\";\\n  par.lang = $langs;\\n  const headers = {\\n    \\"Content-Type\\": \\"application/json\\"\\n    // Authorization: \`Bearer \${token}\`\\n  };\\n  let res = await fetch(\`./admin/login\`, {\\n    method: \\"POST\\",\\n    // mode: 'no-cors',\\n    body: JSON.stringify({ par }),\\n    headers\\n  }).then((response) => response.json()).then((data) => {\\n    location.href = location.origin + location.pathname + \\"?abonent=\\" + data.resp.operator;\\n  }).catch((error) => {\\n    console.log(error);\\n    return [];\\n  });\\n}\\n<\/script>\\r\\n\\r\\n<!-- {@debug $dicts} -->\\r\\n\\r\\n<form on:submit|preventDefault={handleSubmit}>\\r\\n  <div class=\\"columns margins\\">\\r\\n    <div>\\r\\n      <Textfield\\r\\n        bind:value={formData.email}\\r\\n        label=\\"{$dicts['Email',$langs]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"text\\"\\r\\n        name=\\"name\\"\\r\\n        bind:value={formData.name}\\r\\n        label=\\"{$dicts['Имя'][$langs]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"password\\"\\r\\n        name=\\"psw\\"\\r\\n        bind:value={formData.psw}\\r\\n        label=\\"{$dicts['Пароль'][$langs]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"password\\"\\r\\n        name=\\"confirmPassword\\"\\r\\n        bind:value={formData.confirmPassword}\\r\\n        label=\\"{$dicts['Повторить пароль'][$langs]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Button class=\\"upload-button\\">{$dicts['Sign In'][$langs]}</Button>\\r\\n    </div>\\r\\n  </div>\\r\\n</form>\\r\\n\\r\\n{#if !passwordMatch}\\r\\n  <p style=\\"color: red;\\">{$dicts['Пароли не совпадают'][$langs]}</p>\\r\\n{/if}\\r\\n\\r\\n<style>\\r\\n  /* Стили для мобильных устройств */\\r\\n\\r\\n  /* Стили для более крупных экранов */\\r\\n  @media screen and (min-width: 768px) {\\r\\n    /* Ваши стили для более крупных экранов здесь */\\r\\n    button {\\r\\n      padding: 6px 10px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n\\r\\n    input {\\r\\n      padding: 8px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n  }\\r\\n  /* Стили для мобильных устройств */\\r\\n  @media screen and (max-width: 767px) {\\r\\n    button {\\r\\n      padding: 6px 10px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n\\r\\n    input {\\r\\n      padding: 8px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n  }\\r\\n\\r\\n  /* CSS стили для формы регистрации */\\r\\n  form {\\r\\n    display: flex;\\r\\n    flex-direction: column;\\r\\n    align-items: center;\\r\\n    max-width: 400px;\\r\\n    margin: 0 auto;\\r\\n    padding: 20px;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 5px;\\r\\n    background-color: #fff;\\r\\n  }\\r\\n\\r\\n  img {\\r\\n    display: block;\\r\\n    margin-left: auto;\\r\\n    margin-right: auto;\\r\\n  }\\r\\n\\r\\n  label {\\r\\n    font-weight: bold;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  input[type='email'],\\r\\n  input[type='text'],\\r\\n  input[type='psw'] {\\r\\n    width: 100%;\\r\\n    padding: 10px;\\r\\n    margin: 5px 0;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 5px;\\r\\n  }\\r\\n\\r\\n  input[type='file'] {\\r\\n    display: none;\\r\\n  }\\r\\n\\r\\n  .container {\\r\\n    text-align: center;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  #oper_pic {\\r\\n    max-width: 100px;\\r\\n    max-height: 100px;\\r\\n    border-radius: 50%;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  .upload-button {\\r\\n    background-color: #0078d4;\\r\\n    color: #fff;\\r\\n    border: none;\\r\\n    padding: 10px 20px;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA6GE,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAWrC,CAEA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAUrC,CAGA,mBAAK,CACH,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,KAAK,CAChB,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,gBAAgB,CAAE,IACpB"}`
};
const Login = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $dicts, $$unsubscribe_dicts;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  let { email, abonent } = $$props;
  let formData = {
    name: "",
    email: "",
    psw: "",
    confirmPassword: "",
    picture: ""
  };
  if (!formData.picture) {
    formData.picture = "/assets/operator.svg";
  }
  if ($$props.email === void 0 && $$bindings.email && email !== void 0) $$bindings.email(email);
  if ($$props.abonent === void 0 && $$bindings.abonent && abonent !== void 0) $$bindings.abonent(abonent);
  $$result.css.add(css$5);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = ` <form class="svelte-1oy5700"><div class="columns margins"><div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        label: $dicts[$langs] + ":",
        required: true,
        value: formData.email
      },
      {
        value: ($$value) => {
          formData.email = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "text",
        name: "name",
        label: $dicts["Имя"][$langs] + ":",
        required: true,
        value: formData.name
      },
      {
        value: ($$value) => {
          formData.name = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "password",
        name: "psw",
        label: $dicts["Пароль"][$langs] + ":",
        required: true,
        value: formData.psw
      },
      {
        value: ($$value) => {
          formData.psw = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "password",
        name: "confirmPassword",
        label: $dicts["Повторить пароль"][$langs] + ":",
        required: true,
        value: formData.confirmPassword
      },
      {
        value: ($$value) => {
          formData.confirmPassword = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Button, "Button").$$render($$result, { class: "upload-button" }, {}, {
      default: () => {
        return `${escape($dicts["Sign In"][$langs])}`;
      }
    })}</div></div></form> ${``}`;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_dicts();
  return $$rendered;
});
const css$4 = {
  code: ".flexy-dad.svelte-x9i0f{display:flex;flex-wrap:wrap}.flexy-boy.svelte-x9i0f{display:flex;justify-content:center;align-items:center;width:100px;height:100px;margin:0 30px 30px 0}.card-container.svelte-x9i0f{display:inline-flex;align-items:center;min-height:200px;width:70%;overflow-x:auto;background-color:var(--mdc-theme-background, #f8f8f8);border:1px solid\r\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));padding:20px;margin-right:20px;margin-bottom:20px}.save.svelte-x9i0f{width:100px}.deps_div.svelte-x9i0f{overflow-y:scroll;margin-left:0px;margin-top:20px}.svelte-x9i0f::-webkit-scrollbar{display:none}.add_user.svelte-x9i0f{position:relative}",
  map: `{"version":3,"file":"GroupEditor.svelte","sources":["GroupEditor.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, setContext, getContext } from \\"svelte\\";\\nimport Accordion, { Panel, Header, Content } from \\"@smui-extra/accordion\\";\\nimport pkg from \\"lodash\\";\\nconst { remove } = pkg;\\nimport \\"$lib/css/Elevation.scss\\";\\nimport Textfield from \\"@smui/textfield\\";\\nimport ImageList, { Item, ImageAspectContainer, Image, Supporting } from \\"@smui/image-list\\";\\nimport Card, { PrimaryAction, Actions, ActionButtons, ActionIcons } from \\"@smui/card\\";\\nimport Button, { Label } from \\"@smui/button\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nexport let data;\\nlet groups = data.groups;\\nconst abonent = data.abonent;\\nlet card_display = \\"\\";\\nlet clicked = 0;\\nlet name = \\"\\", operator = \\"\\", email = \\"\\", picture = \\"\\";\\nimport { llang, langs, dicts } from \\"$lib/js/stores.js\\";\\nimport { Translate } from \\"../../../routes/translate/Transloc.ts\\";\\nlet user_lang = \\"en\\";\\nconst headers = {\\n  \\"Content-Type\\": \\"application/json\\"\\n  // Authorization: \`Bearer \${token}\`\\n};\\nfunction OnClickUser(user) {\\n  name = user.operator.name;\\n  operator = user.operator.operator;\\n  email = user.operator.email;\\n  picture = user.operator.picture ? user.operator.picture : \\"/assets/operator.svg\\";\\n  user_lang = user.operator.lang;\\n}\\nonMount(async () => {\\n});\\nlet edited_display = false;\\nlet display = \\"none\\";\\nfunction saveClassData() {\\n}\\nasync function OnSaveUser(class_name) {\\n  card_display = \\"\\";\\n  const par = {\\n    func: \\"add_user\\",\\n    role: \\"operator\\",\\n    class_name,\\n    name,\\n    email: email.trim(),\\n    operator,\\n    abonent,\\n    lang: user_lang\\n  };\\n  const prom = fetch(\`/admin/group\`, {\\n    method: \\"POST\\",\\n    // mode: 'no-cors',\\n    body: JSON.stringify(par),\\n    headers\\n  });\\n  let resp = await (await prom).json();\\n  if (resp.resp.length > 0) {\\n    data.operators.push({\\n      role: \\"operator\\",\\n      class: class_name,\\n      operator,\\n      name\\n    });\\n    data = data;\\n  }\\n}\\nfunction OnDeleteUser(operator2) {\\n  const par = {\\n    func: \\"del_user\\",\\n    name,\\n    operator: operator2,\\n    abonent\\n  };\\n  fetch(\`/admin/group\`, {\\n    method: \\"POST\\",\\n    // mode: 'no-cors',\\n    body: JSON.stringify(par),\\n    headers\\n  }).then((response) => response.json()).then((resp) => {\\n    card_display = \\"\\";\\n    remove(data.operators, (obj) => {\\n      return obj.operator === operator2;\\n    });\\n    console.log(resp);\\n  }).catch((error) => {\\n    console.log(error);\\n    return [];\\n  });\\n}\\nfunction OnAddClass() {\\n  groups.push({ name: \\"New Class\\" });\\n  groups = groups;\\n}\\nfunction OnAddUser(ev) {\\n  name = \\"\\";\\n  operator = \\"\\";\\n  picture = \\"\\";\\n  email = \\"\\";\\n  user_lang = \\"\\";\\n}\\nfunction OnClose() {\\n  card_display = \\"\\";\\n}\\n<\/script>\\r\\n\\r\\n<div style=\\"margin-top:50px\\">\\r\\n  {#each groups as item}\\r\\n    <div class=\\"accordion-container\\">\\r\\n      <Accordion multiple>\\r\\n        <Panel class=\\"panel\\">\\r\\n          <Header><b>{item.name}</b></Header>\\r\\n          <Content>\\r\\n            {#if card_display === item.name}\\r\\n              <div class=\\"card-container\\">\\r\\n                <!-- {#if name} -->\\r\\n                <Card style=\\"width:100%\\">\\r\\n                  <div style=\\"display:inline-flex\\">\\r\\n                    <div style=\\"display:block;\\">\\r\\n                      <Content>\\r\\n                        {#await Translate('Language', 'en', $langs) then data}\\r\\n                          <Textfield\\r\\n                            class=\\"shaped-filled\\"\\r\\n                            variant=\\"filled\\"\\r\\n                            bind:value={user_lang}\\r\\n                            label={data}\\r\\n                          ></Textfield>\\r\\n                        {/await}\\r\\n                      </Content>\\r\\n                      <Content>\\r\\n                        {#await Translate('Name', 'en', $langs) then data}\\r\\n                          <Textfield\\r\\n                            class=\\"shaped-filled\\"\\r\\n                            variant=\\"filled\\"\\r\\n                            bind:value={name}\\r\\n                            label={data}\\r\\n                          ></Textfield>\\r\\n                        {/await}\\r\\n                      </Content>\\r\\n                      <Content>\\r\\n                        <Textfield\\r\\n                          class=\\"shaped-filled\\"\\r\\n                          variant=\\"filled\\"\\r\\n                          bind:value={email}\\r\\n                          label=\\"E-mail\\"\\r\\n                        ></Textfield>\\r\\n                      </Content>\\r\\n                    </div>\\r\\n                    {#if picture}\\r\\n                      <Image\\r\\n                        style=\\"\\r\\n                    display: block;\\r\\n                    flex:1;\\r\\n                    margin-left: auto;\\r\\n                    margin-right: auto;\\r\\n                    max-height: 100px;\\r\\n                    max-width:max-content\\r\\n                  \\"\\r\\n                        src={picture}\\r\\n                      />\\r\\n                    {/if}\\r\\n                  </div>\\r\\n\\r\\n                  <Actions>\\r\\n                    <Button on:click={() => OnSaveUser(item.name)}>\\r\\n                      <Label>{data.dict[0]['Save and Close'][$langs]}</Label>\\r\\n                    </Button>\\r\\n                    <Button on:click={() => OnDeleteUser(operator)}>\\r\\n                      <Label>{data.dict[0]['Remove'][$langs]}</Label>\\r\\n                    </Button>\\r\\n                    <Button on:click={() => (card_display = 'false')}>\\r\\n                      <Label>{data.dict[0]['Close'][$langs]}</Label>\\r\\n                    </Button>\\r\\n                  </Actions>\\r\\n                </Card>\\r\\n              </div>\\r\\n            {:else}\\r\\n              <Button variant=\\"outlined\\" class=\\"save\\" on:click={saveClassData}>\\r\\n                {#await Translate('Save', 'en', $langs) then data}\\r\\n                  <Label>{data}</Label>\\r\\n                {/await}\\r\\n              </Button>\\r\\n\\r\\n              <div class=\\"deps_div\\">\\r\\n                <div class=\\"flexy-dad\\">\\r\\n                  {#each data.operators as operator, i}\\r\\n                    {#if operator.group === item.name}\\r\\n                      <div\\r\\n                        class=\\"mdc-elevation--z{i + 1} flexy-boy\\"\\r\\n                        on:click={(ev) => {\\r\\n                          (card_display = item.name), OnClickUser({ operator });\\r\\n                        }}\\r\\n                      >\\r\\n                        <Item style=\\"text-align: center;\\">\\r\\n                          {#if operator.picture}\\r\\n                            <!-- {@debug operator} -->\\r\\n                            <Image\\r\\n                              src={operator.picture}\\r\\n                              style=\\"max-height:50px; max-width:max-content\\"\\r\\n                              alt=\\"Image {i + 1}\\"\\r\\n                            />\\r\\n                          {:else}\\r\\n                            <Image\\r\\n                              src=\\"/assets/operator.svg\\"\\r\\n                              style=\\"width:50px\\"\\r\\n                              alt=\\"Image {i + 1}\\"\\r\\n                            />\\r\\n                          {/if}\\r\\n                          <Supporting>\\r\\n                            <Label>{operator.name}</Label>\\r\\n                          </Supporting>\\r\\n                        </Item>\\r\\n                      </div>\\r\\n                    {/if}\\r\\n                  {/each}\\r\\n                </div>\\r\\n\\r\\n                <div class=\\"add_user\\">\\r\\n                  <Button\\r\\n                    on:click={(ev) => {\\r\\n                      card_display = item.name;\\r\\n                      OnAddUser(ev);\\r\\n                    }}\\r\\n                    variant=\\"outlined\\"\\r\\n                  >\\r\\n                    {#await Translate('добавить пользователя', 'ru', $langs) then data}\\r\\n                      <Label>{data}</Label>\\r\\n                    {/await}\\r\\n                  </Button>\\r\\n                </div>\\r\\n                <!-- <div class=\\"empty\\" style=\\"height:100px\\" /> -->\\r\\n              </div>\\r\\n            {/if}\\r\\n          </Content>\\r\\n        </Panel>\\r\\n      </Accordion>\\r\\n    </div>\\r\\n  {/each}\\r\\n</div>\\r\\n\\r\\n<div class=\\"add_class\\">\\r\\n  <Button class=\\"material-icons\\" variant=\\"outlined\\" on:click={OnAddClass}>\\r\\n    {#await Translate('добавить группу', 'ru', $langs) then data}\\r\\n      <Label>{data}</Label>\\r\\n    {/await}</Button\\r\\n  >\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n  .accordion-container {\\r\\n  }\\r\\n  .flexy-dad {\\r\\n    display: flex;\\r\\n    flex-wrap: wrap;\\r\\n  }\\r\\n\\r\\n  .flexy-boy {\\r\\n    display: flex;\\r\\n    justify-content: center;\\r\\n    align-items: center;\\r\\n    width: 100px;\\r\\n    height: 100px;\\r\\n    margin: 0 30px 30px 0;\\r\\n  }\\r\\n  .card-container {\\r\\n    display: inline-flex;\\r\\n    align-items: center;\\r\\n\\r\\n    min-height: 200px;\\r\\n    width: 70%;\\r\\n    /* max-width: 100%; */\\r\\n    overflow-x: auto;\\r\\n    background-color: var(--mdc-theme-background, #f8f8f8);\\r\\n    border: 1px solid\\r\\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));\\r\\n    padding: 20px;\\r\\n    margin-right: 20px;\\r\\n    margin-bottom: 20px;\\r\\n  }\\r\\n\\r\\n  .save {\\r\\n    width: 100px;\\r\\n  }\\r\\n  .deps_div {\\r\\n    overflow-y: scroll;\\r\\n    margin-left: 0px;\\r\\n    margin-top: 20px;\\r\\n  }\\r\\n  ::-webkit-scrollbar {\\r\\n    display: none;\\r\\n  }\\r\\n  .add_user {\\r\\n    position: relative;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAyPE,uBAAW,CACT,OAAO,CAAE,IAAI,CACb,SAAS,CAAE,IACb,CAEA,uBAAW,CACT,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,KAAK,CACb,MAAM,CAAE,CAAC,CAAC,IAAI,CAAC,IAAI,CAAC,CACtB,CACA,4BAAgB,CACd,OAAO,CAAE,WAAW,CACpB,WAAW,CAAE,MAAM,CAEnB,UAAU,CAAE,KAAK,CACjB,KAAK,CAAE,GAAG,CAEV,UAAU,CAAE,IAAI,CAChB,gBAAgB,CAAE,IAAI,sBAAsB,CAAC,QAAQ,CAAC,CACtD,MAAM,CAAE,GAAG,CAAC,KAAK;AACrB,MAAM,IAAI,mCAAmC,CAAC,mBAAmB,CAAC,CAC9D,OAAO,CAAE,IAAI,CACb,YAAY,CAAE,IAAI,CAClB,aAAa,CAAE,IACjB,CAEA,kBAAM,CACJ,KAAK,CAAE,KACT,CACA,sBAAU,CACR,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,GAAG,CAChB,UAAU,CAAE,IACd,cACA,mBAAoB,CAClB,OAAO,CAAE,IACX,CACA,sBAAU,CACR,QAAQ,CAAE,QACZ"}`
};
const GroupEditor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  const { remove } = pkg;
  let { data } = $$props;
  let groups = data.groups;
  data.abonent;
  let card_display = "";
  let name = "", email = "";
  let user_lang = "en";
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$4);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `<div style="margin-top:50px" class="svelte-x9i0f">${each(groups, (item) => {
      return `<div class="accordion-container svelte-x9i0f">${validate_component(Accordion, "Accordion").$$render($$result, { multiple: true }, {}, {
        default: () => {
          return `${validate_component(Panel, "Panel").$$render($$result, { class: "panel" }, {}, {
            default: () => {
              return `${validate_component(Header$1, "Header").$$render($$result, {}, {}, {
                default: () => {
                  return `<b class="svelte-x9i0f">${escape(item.name)}</b>`;
                }
              })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                default: () => {
                  return `${card_display === item.name ? `<div class="card-container svelte-x9i0f"> ${validate_component(Card, "Card").$$render($$result, { style: "width:100%" }, {}, {
                    default: () => {
                      return `<div style="display:inline-flex" class="svelte-x9i0f"><div style="display:block;" class="svelte-x9i0f">${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${validate_component(Textfield, "Textfield").$$render(
                                $$result,
                                {
                                  class: "shaped-filled",
                                  variant: "filled",
                                  label: data2,
                                  value: user_lang
                                },
                                {
                                  value: ($$value) => {
                                    user_lang = $$value;
                                    $$settled = false;
                                  }
                                },
                                {}
                              )} `;
                            }(__value);
                          }(Translate("Language", "en", $langs))} `;
                        }
                      })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${validate_component(Textfield, "Textfield").$$render(
                                $$result,
                                {
                                  class: "shaped-filled",
                                  variant: "filled",
                                  label: data2,
                                  value: name
                                },
                                {
                                  value: ($$value) => {
                                    name = $$value;
                                    $$settled = false;
                                  }
                                },
                                {}
                              )} `;
                            }(__value);
                          }(Translate("Name", "en", $langs))} `;
                        }
                      })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `${validate_component(Textfield, "Textfield").$$render(
                            $$result,
                            {
                              class: "shaped-filled",
                              variant: "filled",
                              label: "E-mail",
                              value: email
                            },
                            {
                              value: ($$value) => {
                                email = $$value;
                                $$settled = false;
                              }
                            },
                            {}
                          )} `;
                        }
                      })}</div> ${``}</div> ${validate_component(Actions, "Actions").$$render($$result, {}, {}, {
                        default: () => {
                          return `${validate_component(Button, "Button").$$render($$result, {}, {}, {
                            default: () => {
                              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                                default: () => {
                                  return `${escape(data.dict[0]["Save and Close"][$langs])}`;
                                }
                              })} `;
                            }
                          })} ${validate_component(Button, "Button").$$render($$result, {}, {}, {
                            default: () => {
                              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                                default: () => {
                                  return `${escape(data.dict[0]["Remove"][$langs])}`;
                                }
                              })} `;
                            }
                          })} ${validate_component(Button, "Button").$$render($$result, {}, {}, {
                            default: () => {
                              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                                default: () => {
                                  return `${escape(data.dict[0]["Close"][$langs])}`;
                                }
                              })} `;
                            }
                          })} `;
                        }
                      })} `;
                    }
                  })} </div>` : `${validate_component(Button, "Button").$$render($$result, { variant: "outlined", class: "save" }, {}, {
                    default: () => {
                      return `${function(__value) {
                        if (is_promise(__value)) {
                          __value.then(null, noop);
                          return ``;
                        }
                        return function(data2) {
                          return ` ${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                            default: () => {
                              return `${escape(data2)}`;
                            }
                          })} `;
                        }(__value);
                      }(Translate("Save", "en", $langs))} `;
                    }
                  })} <div class="deps_div svelte-x9i0f"><div class="flexy-dad svelte-x9i0f">${each(data.operators, (operator, i) => {
                    return `${operator.group === item.name ? `<div class="${"mdc-elevation--z" + escape(i + 1, true) + " flexy-boy svelte-x9i0f"}">${validate_component(Item, "Item").$$render($$result, { style: "text-align: center;" }, {}, {
                      default: () => {
                        return `${operator.picture ? ` ${validate_component(Image, "Image").$$render(
                          $$result,
                          {
                            src: operator.picture,
                            style: "max-height:50px; max-width:max-content",
                            alt: "Image " + (i + 1)
                          },
                          {},
                          {}
                        )}` : `${validate_component(Image, "Image").$$render(
                          $$result,
                          {
                            src: "/assets/operator.svg",
                            style: "width:50px",
                            alt: "Image " + (i + 1)
                          },
                          {},
                          {}
                        )}`} ${validate_component(Supporting, "Supporting").$$render($$result, {}, {}, {
                          default: () => {
                            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                              default: () => {
                                return `${escape(operator.name)}`;
                              }
                            })} `;
                          }
                        })} `;
                      }
                    })} </div>` : ``}`;
                  })}</div> <div class="add_user svelte-x9i0f">${validate_component(Button, "Button").$$render($$result, { variant: "outlined" }, {}, {
                    default: () => {
                      return `${function(__value) {
                        if (is_promise(__value)) {
                          __value.then(null, noop);
                          return ``;
                        }
                        return function(data2) {
                          return ` ${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                            default: () => {
                              return `${escape(data2)}`;
                            }
                          })} `;
                        }(__value);
                      }(Translate("добавить пользователя", "ru", $langs))} `;
                    }
                  })}</div>  </div>`} `;
                }
              })} `;
            }
          })} `;
        }
      })} </div>`;
    })}</div> <div class="add_class svelte-x9i0f">${validate_component(Button, "Button").$$render(
      $$result,
      {
        class: "material-icons",
        variant: "outlined"
      },
      {},
      {
        default: () => {
          return `${function(__value) {
            if (is_promise(__value)) {
              __value.then(null, noop);
              return ``;
            }
            return function(data2) {
              return ` ${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                default: () => {
                  return `${escape(data2)}`;
                }
              })} `;
            }(__value);
          }(Translate("добавить группу", "ru", $langs))}`;
        }
      }
    )} </div>`;
  } while (!$$settled);
  $$unsubscribe_langs();
  return $$rendered;
});
const SortableList = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let list;
  let { class: className } = $$props;
  let { multiDragClass = null } = $$props;
  let { swapClass = null } = $$props;
  let { group = void 0 } = $$props;
  let { sort = true } = $$props;
  let { disabled = false } = $$props;
  let { store = void 0 } = $$props;
  let { handle = void 0 } = $$props;
  let { swapThreshold = 1 } = $$props;
  let { invertSwap = false } = $$props;
  let { invertedSwapThreshold = void 0 } = $$props;
  let { removeCloneOnHide = true } = $$props;
  let { ghostClass = "sortable-ghost" } = $$props;
  let { chosenClass = "sortable-chosen" } = $$props;
  let { dragClass = "sortable-drag" } = $$props;
  let { ignore = "a; img" } = $$props;
  let { filter = void 0 } = $$props;
  let { preventOnFilter = true } = $$props;
  let { animation = 0 } = $$props;
  let { easing = void 0 } = $$props;
  let { dataIdAttr = "data-id" } = $$props;
  let { delay = 0 } = $$props;
  let { delayOnTouchOnly = false } = $$props;
  let { forceFallback = false } = $$props;
  let { fallbackClass = "sortable-fallback" } = $$props;
  let { fallbackOnBody = false } = $$props;
  let { fallbackTolerance = 0 } = $$props;
  let { fallbackOffset = { x: 0, y: 0 } } = $$props;
  let { emptyInsertThreshold = 5 } = $$props;
  let { direction = void 0 } = $$props;
  let { touchStartThreshold = void 0 } = $$props;
  let { setData = void 0 } = $$props;
  let { draggable = null } = $$props;
  let { onChoose = void 0 } = $$props;
  let { onUnchoose = void 0 } = $$props;
  let { onStart = void 0 } = $$props;
  let { onEnd = void 0 } = $$props;
  let { onAdd = void 0 } = $$props;
  let { onUpdate = void 0 } = $$props;
  let { onRemove = void 0 } = $$props;
  let { onFilter = void 0 } = $$props;
  let { onSort = void 0 } = $$props;
  let { onClone = void 0 } = $$props;
  let { onMove = void 0 } = $$props;
  let { onChange = void 0 } = $$props;
  onDestroy(() => {
  });
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.multiDragClass === void 0 && $$bindings.multiDragClass && multiDragClass !== void 0) $$bindings.multiDragClass(multiDragClass);
  if ($$props.swapClass === void 0 && $$bindings.swapClass && swapClass !== void 0) $$bindings.swapClass(swapClass);
  if ($$props.group === void 0 && $$bindings.group && group !== void 0) $$bindings.group(group);
  if ($$props.sort === void 0 && $$bindings.sort && sort !== void 0) $$bindings.sort(sort);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0) $$bindings.disabled(disabled);
  if ($$props.store === void 0 && $$bindings.store && store !== void 0) $$bindings.store(store);
  if ($$props.handle === void 0 && $$bindings.handle && handle !== void 0) $$bindings.handle(handle);
  if ($$props.swapThreshold === void 0 && $$bindings.swapThreshold && swapThreshold !== void 0) $$bindings.swapThreshold(swapThreshold);
  if ($$props.invertSwap === void 0 && $$bindings.invertSwap && invertSwap !== void 0) $$bindings.invertSwap(invertSwap);
  if ($$props.invertedSwapThreshold === void 0 && $$bindings.invertedSwapThreshold && invertedSwapThreshold !== void 0) $$bindings.invertedSwapThreshold(invertedSwapThreshold);
  if ($$props.removeCloneOnHide === void 0 && $$bindings.removeCloneOnHide && removeCloneOnHide !== void 0) $$bindings.removeCloneOnHide(removeCloneOnHide);
  if ($$props.ghostClass === void 0 && $$bindings.ghostClass && ghostClass !== void 0) $$bindings.ghostClass(ghostClass);
  if ($$props.chosenClass === void 0 && $$bindings.chosenClass && chosenClass !== void 0) $$bindings.chosenClass(chosenClass);
  if ($$props.dragClass === void 0 && $$bindings.dragClass && dragClass !== void 0) $$bindings.dragClass(dragClass);
  if ($$props.ignore === void 0 && $$bindings.ignore && ignore !== void 0) $$bindings.ignore(ignore);
  if ($$props.filter === void 0 && $$bindings.filter && filter !== void 0) $$bindings.filter(filter);
  if ($$props.preventOnFilter === void 0 && $$bindings.preventOnFilter && preventOnFilter !== void 0) $$bindings.preventOnFilter(preventOnFilter);
  if ($$props.animation === void 0 && $$bindings.animation && animation !== void 0) $$bindings.animation(animation);
  if ($$props.easing === void 0 && $$bindings.easing && easing !== void 0) $$bindings.easing(easing);
  if ($$props.dataIdAttr === void 0 && $$bindings.dataIdAttr && dataIdAttr !== void 0) $$bindings.dataIdAttr(dataIdAttr);
  if ($$props.delay === void 0 && $$bindings.delay && delay !== void 0) $$bindings.delay(delay);
  if ($$props.delayOnTouchOnly === void 0 && $$bindings.delayOnTouchOnly && delayOnTouchOnly !== void 0) $$bindings.delayOnTouchOnly(delayOnTouchOnly);
  if ($$props.forceFallback === void 0 && $$bindings.forceFallback && forceFallback !== void 0) $$bindings.forceFallback(forceFallback);
  if ($$props.fallbackClass === void 0 && $$bindings.fallbackClass && fallbackClass !== void 0) $$bindings.fallbackClass(fallbackClass);
  if ($$props.fallbackOnBody === void 0 && $$bindings.fallbackOnBody && fallbackOnBody !== void 0) $$bindings.fallbackOnBody(fallbackOnBody);
  if ($$props.fallbackTolerance === void 0 && $$bindings.fallbackTolerance && fallbackTolerance !== void 0) $$bindings.fallbackTolerance(fallbackTolerance);
  if ($$props.fallbackOffset === void 0 && $$bindings.fallbackOffset && fallbackOffset !== void 0) $$bindings.fallbackOffset(fallbackOffset);
  if ($$props.emptyInsertThreshold === void 0 && $$bindings.emptyInsertThreshold && emptyInsertThreshold !== void 0) $$bindings.emptyInsertThreshold(emptyInsertThreshold);
  if ($$props.direction === void 0 && $$bindings.direction && direction !== void 0) $$bindings.direction(direction);
  if ($$props.touchStartThreshold === void 0 && $$bindings.touchStartThreshold && touchStartThreshold !== void 0) $$bindings.touchStartThreshold(touchStartThreshold);
  if ($$props.setData === void 0 && $$bindings.setData && setData !== void 0) $$bindings.setData(setData);
  if ($$props.draggable === void 0 && $$bindings.draggable && draggable !== void 0) $$bindings.draggable(draggable);
  if ($$props.onChoose === void 0 && $$bindings.onChoose && onChoose !== void 0) $$bindings.onChoose(onChoose);
  if ($$props.onUnchoose === void 0 && $$bindings.onUnchoose && onUnchoose !== void 0) $$bindings.onUnchoose(onUnchoose);
  if ($$props.onStart === void 0 && $$bindings.onStart && onStart !== void 0) $$bindings.onStart(onStart);
  if ($$props.onEnd === void 0 && $$bindings.onEnd && onEnd !== void 0) $$bindings.onEnd(onEnd);
  if ($$props.onAdd === void 0 && $$bindings.onAdd && onAdd !== void 0) $$bindings.onAdd(onAdd);
  if ($$props.onUpdate === void 0 && $$bindings.onUpdate && onUpdate !== void 0) $$bindings.onUpdate(onUpdate);
  if ($$props.onRemove === void 0 && $$bindings.onRemove && onRemove !== void 0) $$bindings.onRemove(onRemove);
  if ($$props.onFilter === void 0 && $$bindings.onFilter && onFilter !== void 0) $$bindings.onFilter(onFilter);
  if ($$props.onSort === void 0 && $$bindings.onSort && onSort !== void 0) $$bindings.onSort(onSort);
  if ($$props.onClone === void 0 && $$bindings.onClone && onClone !== void 0) $$bindings.onClone(onClone);
  if ($$props.onMove === void 0 && $$bindings.onMove && onMove !== void 0) $$bindings.onMove(onMove);
  if ($$props.onChange === void 0 && $$bindings.onChange && onChange !== void 0) $$bindings.onChange(onChange);
  return ` <div${add_attribute("class", className, 0)}${add_attribute("this", list, 0)}>${slots.default ? slots.default({}) : ``}</div>`;
});
const TabIndicator = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, [
    "use",
    "class",
    "active",
    "type",
    "transition",
    "content$use",
    "content$class",
    "activate",
    "deactivate",
    "computeContentClientRect",
    "getElement"
  ]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { active = false } = $$props;
  let { type = "underline" } = $$props;
  let { transition = "slide" } = $$props;
  let { content$use = [] } = $$props;
  let { content$class = "" } = $$props;
  let element;
  let instance;
  let content;
  let internalClasses = {};
  let contentStyles = {};
  let changeSets = [];
  let oldTransition = transition;
  function getInstance() {
    const Foundation = {
      fade: MDCFadingTabIndicatorFoundation,
      slide: MDCSlidingTabIndicatorFoundation
    }[transition] || MDCSlidingTabIndicatorFoundation;
    return new Foundation({
      addClass: (...props) => doChange(() => addClass(...props)),
      removeClass: (...props) => doChange(() => removeClass(...props)),
      computeContentClientRect,
      setContentStyleProperty: (...props) => doChange(() => addContentStyle(...props))
    });
  }
  function doChange(fn) {
    if (changeSets.length) {
      changeSets[changeSets.length - 1].push(fn);
    } else {
      fn();
    }
  }
  function addClass(className2) {
    if (!internalClasses[className2]) {
      internalClasses[className2] = true;
    }
  }
  function removeClass(className2) {
    if (!(className2 in internalClasses) || internalClasses[className2]) {
      internalClasses[className2] = false;
    }
  }
  function addContentStyle(name, value) {
    if (contentStyles[name] != value) {
      if (value === "" || value == null) {
        delete contentStyles[name];
        contentStyles = contentStyles;
      } else {
        contentStyles[name] = value;
      }
    }
  }
  function activate(previousIndicatorClientRect) {
    active = true;
    instance.activate(previousIndicatorClientRect);
  }
  function deactivate() {
    active = false;
    instance.deactivate();
  }
  function computeContentClientRect() {
    changeSets.push([]);
    changeSets = changeSets;
    return content.getBoundingClientRect();
  }
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0) $$bindings.active(active);
  if ($$props.type === void 0 && $$bindings.type && type !== void 0) $$bindings.type(type);
  if ($$props.transition === void 0 && $$bindings.transition && transition !== void 0) $$bindings.transition(transition);
  if ($$props.content$use === void 0 && $$bindings.content$use && content$use !== void 0) $$bindings.content$use(content$use);
  if ($$props.content$class === void 0 && $$bindings.content$class && content$class !== void 0) $$bindings.content$class(content$class);
  if ($$props.activate === void 0 && $$bindings.activate && activate !== void 0) $$bindings.activate(activate);
  if ($$props.deactivate === void 0 && $$bindings.deactivate && deactivate !== void 0) $$bindings.deactivate(deactivate);
  if ($$props.computeContentClientRect === void 0 && $$bindings.computeContentClientRect && computeContentClientRect !== void 0) $$bindings.computeContentClientRect(computeContentClientRect);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  {
    if (oldTransition !== transition) {
      oldTransition = transition;
      instance && instance.destroy();
      internalClasses = {};
      contentStyles = {};
      instance = getInstance();
      instance.init();
    }
  }
  {
    if (changeSets.length) {
      requestAnimationFrame(() => {
        var _a;
        const changeSet = (_a = changeSets.shift()) !== null && _a !== void 0 ? _a : [];
        changeSets = changeSets;
        for (const fn of changeSet) {
          fn();
        }
      });
    }
  }
  return `<span${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "mdc-tab-indicator": true,
          "mdc-tab-indicator--active": active,
          "mdc-tab-indicator--fade": transition === "fade",
          ...internalClasses
        }))
      },
      escape_object(exclude($$restProps, ["content$"]))
    ],
    {}
  )}${add_attribute("this", element, 0)}><span${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [content$class]: true,
          "mdc-tab-indicator__content": true,
          "mdc-tab-indicator__content--underline": type === "underline",
          "mdc-tab-indicator__content--icon": type === "icon"
        }))
      },
      {
        style: escape_attribute_value(Object.entries(contentStyles).map(([name, value]) => `${name}: ${value};`).join(" "))
      },
      {
        "aria-hidden": escape_attribute_value(type === "icon" ? "true" : void 0)
      },
      escape_object(prefixFilter($$restProps, "content$"))
    ],
    {}
  )}${add_attribute("this", content, 0)}>${slots.default ? slots.default({}) : ``}</span> </span>`;
});
const { Object: Object_1$1 } = globals;
const Tab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, [
    "use",
    "class",
    "style",
    "tab",
    "ripple",
    "stacked",
    "minWidth",
    "indicatorSpanOnlyContent",
    "href",
    "content$use",
    "content$class",
    "component",
    "tag",
    "activate",
    "deactivate",
    "focus",
    "getElement"
  ]);
  const forwardEvents = forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { style = "" } = $$props;
  let { tab: tabId } = $$props;
  let { ripple = true } = $$props;
  let { stacked = false } = $$props;
  let { minWidth = false } = $$props;
  let { indicatorSpanOnlyContent = false } = $$props;
  let { href = void 0 } = $$props;
  let { content$use = [] } = $$props;
  let { content$class = "" } = $$props;
  let element;
  let instance;
  let content;
  let tabIndicator;
  let internalClasses = {};
  let internalStyles = {};
  let internalAttrs = {};
  let focusOnActivate = getContext("SMUI:tab:focusOnActivate");
  let active = tabId === getContext("SMUI:tab:initialActive");
  let forceAccessible = false;
  let { component = SmuiElement } = $$props;
  let { tag = component === SmuiElement ? href == null ? "button" : "a" : void 0 } = $$props;
  setContext("SMUI:label:context", "tab");
  setContext("SMUI:icon:context", "tab");
  if (!tabId) {
    throw new Error("The tab property is required! It should be passed down from the TabBar to the Tab.");
  }
  function addClass(className2) {
    if (!internalClasses[className2]) {
      internalClasses[className2] = true;
    }
  }
  function removeClass(className2) {
    if (!(className2 in internalClasses) || internalClasses[className2]) {
      internalClasses[className2] = false;
    }
  }
  function addStyle(name, value) {
    if (internalStyles[name] != value) {
      if (value === "" || value == null) {
        delete internalStyles[name];
        internalStyles = internalStyles;
      } else {
        internalStyles[name] = value;
      }
    }
  }
  function activate(previousIndicatorClientRect, skipFocus) {
    active = true;
    if (skipFocus) {
      instance.setFocusOnActivate(false);
    }
    instance.activate(previousIndicatorClientRect);
    if (skipFocus) {
      instance.setFocusOnActivate(focusOnActivate);
    }
  }
  function deactivate() {
    active = false;
    instance.deactivate();
  }
  function focus() {
    getElement().focus();
  }
  function getElement() {
    return element.getElement();
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.style === void 0 && $$bindings.style && style !== void 0) $$bindings.style(style);
  if ($$props.tab === void 0 && $$bindings.tab && tabId !== void 0) $$bindings.tab(tabId);
  if ($$props.ripple === void 0 && $$bindings.ripple && ripple !== void 0) $$bindings.ripple(ripple);
  if ($$props.stacked === void 0 && $$bindings.stacked && stacked !== void 0) $$bindings.stacked(stacked);
  if ($$props.minWidth === void 0 && $$bindings.minWidth && minWidth !== void 0) $$bindings.minWidth(minWidth);
  if ($$props.indicatorSpanOnlyContent === void 0 && $$bindings.indicatorSpanOnlyContent && indicatorSpanOnlyContent !== void 0) $$bindings.indicatorSpanOnlyContent(indicatorSpanOnlyContent);
  if ($$props.href === void 0 && $$bindings.href && href !== void 0) $$bindings.href(href);
  if ($$props.content$use === void 0 && $$bindings.content$use && content$use !== void 0) $$bindings.content$use(content$use);
  if ($$props.content$class === void 0 && $$bindings.content$class && content$class !== void 0) $$bindings.content$class(content$class);
  if ($$props.component === void 0 && $$bindings.component && component !== void 0) $$bindings.component(component);
  if ($$props.tag === void 0 && $$bindings.tag && tag !== void 0) $$bindings.tag(tag);
  if ($$props.activate === void 0 && $$bindings.activate && activate !== void 0) $$bindings.activate(activate);
  if ($$props.deactivate === void 0 && $$bindings.deactivate && deactivate !== void 0) $$bindings.deactivate(deactivate);
  if ($$props.focus === void 0 && $$bindings.focus && focus !== void 0) $$bindings.focus(focus);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `${validate_component(component || missing_component, "svelte:component").$$render(
      $$result,
      Object_1$1.assign(
        {},
        { tag },
        {
          use: [
            [
              Ripple,
              {
                ripple,
                unbounded: false,
                addClass,
                removeClass,
                addStyle
              }
            ],
            forwardEvents,
            ...use
          ]
        },
        {
          class: classMap({
            [className]: true,
            "mdc-tab": true,
            "mdc-tab--active": active,
            "mdc-tab--stacked": stacked,
            "mdc-tab--min-width": minWidth,
            ...internalClasses
          })
        },
        {
          style: Object.entries(internalStyles).map(([name, value]) => `${name}: ${value};`).concat([style]).join(" ")
        },
        { role: "tab" },
        {
          "aria-selected": active ? "true" : "false"
        },
        {
          tabindex: active || forceAccessible ? "0" : "-1"
        },
        { href },
        internalAttrs,
        exclude($$restProps, ["content$", "tabIndicator$"]),
        { this: element }
      ),
      {
        this: ($$value) => {
          element = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `<span${spread(
            [
              {
                class: escape_attribute_value(classMap({
                  [content$class]: true,
                  "mdc-tab__content": true
                }))
              },
              escape_object(prefixFilter($$restProps, "content$"))
            ],
            {}
          )}${add_attribute("this", content, 0)}>${slots.default ? slots.default({}) : ``} ${indicatorSpanOnlyContent ? `${validate_component(TabIndicator, "TabIndicator").$$render(
            $$result,
            Object_1$1.assign({}, { active }, prefixFilter($$restProps, "tabIndicator$"), { this: tabIndicator }),
            {
              this: ($$value) => {
                tabIndicator = $$value;
                $$settled = false;
              }
            },
            {
              default: () => {
                return `${slots["tab-indicator"] ? slots["tab-indicator"]({}) : ``}`;
              }
            }
          )}` : ``}</span> ${!indicatorSpanOnlyContent ? `${validate_component(TabIndicator, "TabIndicator").$$render(
            $$result,
            Object_1$1.assign({}, { active }, prefixFilter($$restProps, "tabIndicator$"), { this: tabIndicator }),
            {
              this: ($$value) => {
                tabIndicator = $$value;
                $$settled = false;
              }
            },
            {
              default: () => {
                return `${slots["tab-indicator"] ? slots["tab-indicator"]({}) : ``}`;
              }
            }
          )}` : ``} <span class="mdc-tab__ripple"></span>`;
        }
      }
    )}`;
  } while (!$$settled);
  return $$rendered;
});
const TabScroller = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, [
    "use",
    "class",
    "align",
    "scrollArea$use",
    "scrollArea$class",
    "scrollContent$use",
    "scrollContent$class",
    "getScrollPosition",
    "getScrollContentWidth",
    "incrementScroll",
    "scrollTo",
    "getElement"
  ]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { align = void 0 } = $$props;
  let { scrollArea$use = [] } = $$props;
  let { scrollArea$class = "" } = $$props;
  let { scrollContent$use = [] } = $$props;
  let { scrollContent$class = "" } = $$props;
  let element;
  let instance;
  let scrollArea;
  let scrollContent;
  let internalClasses = {};
  let scrollAreaClasses = {};
  let scrollAreaStyles = {};
  let scrollContentStyles = {};
  function getScrollPosition() {
    return instance.getScrollPosition();
  }
  function getScrollContentWidth() {
    return scrollContent.offsetWidth;
  }
  function incrementScroll(scrollXIncrement) {
    instance.incrementScroll(scrollXIncrement);
  }
  function scrollTo(scrollX) {
    instance.scrollTo(scrollX);
  }
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.align === void 0 && $$bindings.align && align !== void 0) $$bindings.align(align);
  if ($$props.scrollArea$use === void 0 && $$bindings.scrollArea$use && scrollArea$use !== void 0) $$bindings.scrollArea$use(scrollArea$use);
  if ($$props.scrollArea$class === void 0 && $$bindings.scrollArea$class && scrollArea$class !== void 0) $$bindings.scrollArea$class(scrollArea$class);
  if ($$props.scrollContent$use === void 0 && $$bindings.scrollContent$use && scrollContent$use !== void 0) $$bindings.scrollContent$use(scrollContent$use);
  if ($$props.scrollContent$class === void 0 && $$bindings.scrollContent$class && scrollContent$class !== void 0) $$bindings.scrollContent$class(scrollContent$class);
  if ($$props.getScrollPosition === void 0 && $$bindings.getScrollPosition && getScrollPosition !== void 0) $$bindings.getScrollPosition(getScrollPosition);
  if ($$props.getScrollContentWidth === void 0 && $$bindings.getScrollContentWidth && getScrollContentWidth !== void 0) $$bindings.getScrollContentWidth(getScrollContentWidth);
  if ($$props.incrementScroll === void 0 && $$bindings.incrementScroll && incrementScroll !== void 0) $$bindings.incrementScroll(incrementScroll);
  if ($$props.scrollTo === void 0 && $$bindings.scrollTo && scrollTo !== void 0) $$bindings.scrollTo(scrollTo);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  return `<div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "mdc-tab-scroller": true,
          "mdc-tab-scroller--align-start": align === "start",
          "mdc-tab-scroller--align-end": align === "end",
          "mdc-tab-scroller--align-center": align === "center",
          ...internalClasses
        }))
      },
      escape_object(exclude($$restProps, ["scrollArea$", "scrollContent$"]))
    ],
    {}
  )}${add_attribute("this", element, 0)}><div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [scrollArea$class]: true,
          "mdc-tab-scroller__scroll-area": true,
          ...scrollAreaClasses
        }))
      },
      {
        style: escape_attribute_value(Object.entries(scrollAreaStyles).map(([name, value]) => `${name}: ${value};`).join(" "))
      },
      escape_object(prefixFilter($$restProps, "scrollArea$"))
    ],
    {}
  )}${add_attribute("this", scrollArea, 0)}><div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [scrollContent$class]: true,
          "mdc-tab-scroller__scroll-content": true
        }))
      },
      {
        style: escape_attribute_value(Object.entries(scrollContentStyles).map(([name, value]) => `${name}: ${value};`).join(" "))
      },
      escape_object(prefixFilter($$restProps, "scrollContent$"))
    ],
    {}
  )}${add_attribute("this", scrollContent, 0)}>${slots.default ? slots.default({}) : ``}</div></div> </div>`;
});
const { Object: Object_1 } = globals;
const TabBar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, [
    "use",
    "class",
    "tabs",
    "key",
    "focusOnActivate",
    "focusOnProgrammatic",
    "useAutomaticActivation",
    "active",
    "tabindex",
    "scrollIntoView",
    "getElement"
  ]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { tabs = [] } = $$props;
  let { key = (tab) => tab } = $$props;
  let { focusOnActivate = true } = $$props;
  let { focusOnProgrammatic = false } = $$props;
  let { useAutomaticActivation = true } = $$props;
  let { active = void 0 } = $$props;
  let { tabindex = 0 } = $$props;
  let element;
  let instance;
  let tabScroller;
  let activeIndex = tabs.indexOf(active);
  let tabAccessorMap = {};
  let tabAccessorWeakMap = /* @__PURE__ */ new WeakMap();
  setContext("SMUI:tab:focusOnActivate", focusOnActivate);
  setContext("SMUI:tab:initialActive", active);
  function scrollIntoView(index) {
    instance.scrollIntoView(index);
  }
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.tabs === void 0 && $$bindings.tabs && tabs !== void 0) $$bindings.tabs(tabs);
  if ($$props.key === void 0 && $$bindings.key && key !== void 0) $$bindings.key(key);
  if ($$props.focusOnActivate === void 0 && $$bindings.focusOnActivate && focusOnActivate !== void 0) $$bindings.focusOnActivate(focusOnActivate);
  if ($$props.focusOnProgrammatic === void 0 && $$bindings.focusOnProgrammatic && focusOnProgrammatic !== void 0) $$bindings.focusOnProgrammatic(focusOnProgrammatic);
  if ($$props.useAutomaticActivation === void 0 && $$bindings.useAutomaticActivation && useAutomaticActivation !== void 0) $$bindings.useAutomaticActivation(useAutomaticActivation);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0) $$bindings.active(active);
  if ($$props.tabindex === void 0 && $$bindings.tabindex && tabindex !== void 0) $$bindings.tabindex(tabindex);
  if ($$props.scrollIntoView === void 0 && $$bindings.scrollIntoView && scrollIntoView !== void 0) $$bindings.scrollIntoView(scrollIntoView);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (active !== tabs[activeIndex]) {
        activeIndex = tabs.indexOf(active);
      }
    }
    {
      if (tabs.length) {
        const accessor = tabs[0] instanceof Object ? tabAccessorWeakMap.get(tabs[0]) : tabAccessorMap[tabs[0]];
        if (accessor) {
          accessor.forceAccessible(activeIndex === -1);
        }
      }
    }
    $$rendered = `<div${spread(
      [
        {
          class: escape_attribute_value(classMap({ [className]: true, "mdc-tab-bar": true }))
        },
        { role: "tablist" },
        {
          tabindex: escape_attribute_value(tabindex)
        },
        escape_object(exclude($$restProps, ["tabScroller$"]))
      ],
      {}
    )}${add_attribute("this", element, 0)}>${validate_component(TabScroller, "TabScroller").$$render(
      $$result,
      Object_1.assign({}, prefixFilter($$restProps, "tabScroller$"), { this: tabScroller }),
      {
        this: ($$value) => {
          tabScroller = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${each(tabs, (tab) => {
            return `${slots.default ? slots.default({ tab }) : ``}`;
          })}`;
        }
      }
    )} </div>`;
  } while (!$$settled);
  return $$rendered;
});
const css$3 = {
  code: "main.svelte-7i104c{margin:20px}.content_generator.svelte-7i104c{height:40px;margin-top:25px;width:100%}.collapsible.svelte-7i104c{overflow:hidden;margin-top:1rem;margin-bottom:3rem;margin-left:1rem}.svelte-7i104c::selection{border:0;background-color:lightblue}table.svelte-7i104c{width:100%;border-collapse:collapse}th.svelte-7i104c{position:sticky;top:0;z-index:2}th.svelte-7i104c,td.svelte-7i104c{border:1px solid #ddd;padding:1px;text-align:center}.system_div.svelte-7i104c{margin-left:10px}.dialog-field.svelte-7i104c{display:inline-block;box-sizing:border-box;margin-right:10px}.dialog-field.svelte-7i104c:first-child{width:calc(\r\n      100% - 20% - 10% - 5px\r\n    )}.dialog-field.svelte-7i104c:nth-last-child(-n + 2){width:calc(\r\n      20% - 20px\r\n    )}.container.svelte-7i104c{display:flex;justify-content:space-between}.save_content.svelte-7i104c{position:fixed;right:20px;bottom:5px;margin-top:10px}.copy_content.svelte-7i104c{position:fixed;right:120px;bottom:5px;margin-top:10px}textarea.svelte-7i104c{width:100%;resize:none}.remrec_but.svelte-7i104c{scale:2;width:25px;border-radius:35px;border:0;background-color:transparent;color:blue}.dialog_name.svelte-7i104c,.dialog_lang.svelte-7i104c,.dialog_level.svelte-7i104c{border:0}.dialog-field.svelte-7i104c{display:flex;flex-direction:column;margin-right:20px}.dialog-field.svelte-7i104c:last-child{margin-right:0}",
  map: '{"version":3,"file":"DialogEdit.svelte","sources":["DialogEdit.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { Translate } from \\"../../../translate/Transloc.js\\";\\nimport { getContext, onMount } from \\"svelte\\";\\nimport { nlang, llang, langs, dicts, view } from \\"$lib/js/stores.js\\";\\nimport List, { Item, Separator, Text } from \\"@smui/list\\";\\nimport Tab, { Label } from \\"@smui/tab\\";\\nimport TabBar from \\"@smui/tab-bar\\";\\nimport Accordion, { Panel, Header } from \\"@smui-extra/accordion\\";\\nimport Menu from \\"@smui/menu\\";\\nimport Button from \\"@smui/button\\";\\nimport IconButton from \\"@smui/icon-button\\";\\nimport Paper, { Content } from \\"@smui/paper\\";\\nimport { Anchor } from \\"@smui/menu-surface\\";\\nexport let ChangeQuizName;\\nconst abonent = getContext(\\"abonent\\");\\nconst data = getContext(\\"quiz_data\\");\\nlet content = \\"\\", new_content = false, num = 10;\\nlet dialog_data = { lang: \\"\\", content: [], words: [], html: [\\"\\"], name: \\"\\" };\\nconst name = data.name;\\nlet dialog_task, dialog_words, dialog_tmplt;\\nlet menu, anchor;\\nlet anchorClasses = {};\\nlet viewHTML = false;\\nlet prompt = ``, grammar = \\"\\", grammar_title = \\"Grammar\\", context_title = \\"Context\\", prompt_title = \\"Prompt\\", words_title = \\"Words\\", content_title = \\"Content\\";\\nlet active = \\"Prompt\\";\\n$: if (false) {\\n  (async () => {\\n    grammar_title = await Translate(\\"Grammar\\", \\"en\\", $langs);\\n    context_title = await Translate(\\"Context\\", \\"en\\", $langs);\\n    words_title = await Translate(\\"Words\\", \\"en\\", $langs);\\n    content_title = await Translate(\\"Content\\", \\"en\\", $langs);\\n  })();\\n}\\n$: if (dialog_data && $llang) {\\n  try {\\n    const dlg_content = dialog_data.content.map((line) => {\\n      return JSON.stringify(line);\\n    });\\n    let dialog_data_words = dialog_data.words || \\"\\";\\n  } catch (ex) {\\n  }\\n}\\n$: if (dialog_data && $langs) {\\n  TranslateContentToCurrentLang();\\n}\\n$: if (dialog_data.content.length > 0 && prompt) {\\n  let content2 = JSON.parse(JSON.stringify(dialog_data.content));\\n  try {\\n    content2?.forEach((item) => {\\n      item[\\"user1\\"] = item[\\"user1\\"][$llang] ? item[\\"user1\\"][$llang] : item[\\"user1\\"];\\n      item[\\"user2\\"] = item[\\"user2\\"][$llang] ? item[\\"user2\\"][$llang] : item[\\"user2\\"];\\n    });\\n  } catch (ex) {\\n  }\\n  prompt = prompt.replaceAll(\\"${dialog_content}\\", JSON.stringify(content2));\\n}\\nfetch(`./lesson?dialog=${data.name[$llang]}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then(async (resp) => {\\n  dialog_data = resp.data.dialog;\\n  if (!dialog_data)\\n    dialog_data = { content: [] };\\n  if (resp.data.html) {\\n    dialog_data.html = splitHtmlContent(resp.data.html);\\n  }\\n  dialog_data.name = name;\\n  fetch(`./admin?prompt=dialog.basic&quiz_name=${data.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data.level}&prompt_theme=${data.theme.name[$llang]}`).then((response) => response.json()).then((resp2) => {\\n    prompt = resp2.resp.prompt.system + resp2.resp.prompt.user;\\n    dialog_data.words = JSON.stringify(resp2.resp.words[0]?.data.map((item) => extractWords(item.example[$llang])).join(\\",\\"));\\n    function extractContent(str) {\\n      const match = str.match(/<<(.*?)>>/);\\n      return match ? match[1] : null;\\n    }\\n    if (resp2.resp.words[0]?.data) {\\n      prompt = prompt.replaceAll(\\"[${dialog_data_words}]\\", resp2.resp.words[0].data.map((item) => extractContent(item.example[$llang])));\\n    }\\n    if (!dialog_data.html)\\n      dialog_data.html = resp2.resp?.context[0].html;\\n    if (data.theme.grammar)\\n      prompt = prompt.replaceAll(\\"${grammar}\\", JSON.stringify(data.theme.grammar));\\n    prompt = prompt.replaceAll(\\"${llang}\\", $llang);\\n    prompt = prompt.replaceAll(\\"${name[$llang]}\\", `${data.theme.name[$llang]}.${name[$llang]}`);\\n    prompt = prompt.replaceAll(\\"${langs}\\", $langs);\\n    prompt = prompt.replaceAll(\\"${dialog_data_html}\\", dialog_data.html);\\n    prompt = prompt.replaceAll(\\"${data.level}\\", `${data.level}.${data.theme.id}(${data.module.themes.length})`);\\n    prompt = prompt.replaceAll(\\"${num}\\", num);\\n    prompt = prompt;\\n  });\\n}).catch((error) => {\\n  console.log(error);\\n});\\nonMount(async () => {\\n});\\nfunction LoadPrompt(name2, data2) {\\n  if (name2 === \\"context\\") {\\n    active = `Context`;\\n  } else if (name2 === \\"grammar\\") {\\n    active = `Grammar`;\\n  }\\n  fetch(`/admin?prompt=dialog.${name2}&quiz_name=${data2.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data2.level}&prompt_theme=${data2.theme}`).then((response) => response.json()).then((data3) => {\\n    prompt = data3.resp.prompt.system + data3.resp.prompt.user;\\n    prompt = prompt.replaceAll(\\"${llang}\\", $llang);\\n    prompt = prompt.replaceAll(\\"${name[$llang]}\\", dialog_data.name[$llang]);\\n    prompt = prompt.replaceAll(\\"${langs}\\", $langs);\\n    prompt = prompt.replaceAll(\\"${dialog_data.html}\\", dialog_data.html);\\n    prompt = prompt.replaceAll(\\"${data.level}\\", data3.level);\\n    prompt = prompt.replaceAll(\\"${num}\\", num);\\n    prompt = prompt.replaceAll(\\"${grammar}\\", data3.resp.grammar.grammar.map((el) => {\\n      return el;\\n    }));\\n    prompt = prompt;\\n  }).catch((error) => {\\n    console.log(error);\\n  });\\n}\\nfunction extractWords(text) {\\n  const regex = /<<(.*?)>>/g;\\n  let result = [];\\n  let match;\\n  while ((match = regex.exec(text)) !== null) {\\n    result.push(match[1]);\\n  }\\n  return result;\\n}\\nasync function TranslateContentToCurrentLang() {\\n  try {\\n    await Promise.all(dialog_data.content.map(async (item) => {\\n      await Promise.all(Object.keys(item).map(async (key) => {\\n        if (item[key][$llang] && !item[key][$langs]) {\\n          let tr = await Translate(item[key][$llang], $llang, $langs);\\n          item[key][$langs] = tr;\\n          dialog_data = dialog_data;\\n        }\\n      }));\\n    }));\\n  } catch (ex) {\\n  }\\n}\\nfunction splitHtmlContent(inputString) {\\n  const regex = /<(?:!DOCTYPE html|html(?:\\\\s[^>]*)?)>(.*?)<\\\\/html>/gs;\\n  const result = [];\\n  let match;\\n  while ((match = regex.exec(inputString)) !== null) {\\n    result.push(match[0]);\\n  }\\n  return result;\\n}\\nfunction addEmptyRecord() {\\n  let emptyRecord = {\\n    num: (dialog_data.content.length + 1).toString(),\\n    // Пример создания уникального номера записи\\n    user1: { nl: \\"\\", ru: \\"\\", uk: \\"\\", fr: \\"\\", en: \\"\\", de: \\"\\" },\\n    user2: { nl: \\"\\", ru: \\"\\", uk: \\"\\", fr: \\"\\", en: \\"\\", de: \\"\\" },\\n    language: $llang\\n    // Пример начального выбранного языка\\n  };\\n  dialog_data.content.push(emptyRecord);\\n  dialog_data = dialog_data;\\n}\\nfunction remRecord(ev) {\\n  const index = ev.currentTarget.attributes.index.nodeValue;\\n  dialog_data.content.splice(index, 1);\\n  dialog_data = dialog_data;\\n}\\nfunction OnSave() {\\n  SaveDialogData(name, data);\\n  ChangeQuizName(name, data.name);\\n}\\nasync function SaveDialogData(name2, data2) {\\n  const response = await fetch(`/admin/module`, {\\n    method: \\"POST\\",\\n    body: JSON.stringify({\\n      func: \\"upd_dlg\\",\\n      owner: abonent,\\n      level: data2.level,\\n      name: name2[$llang],\\n      new_name: data2.name[$llang],\\n      data: dialog_data,\\n      lang: $llang\\n    }),\\n    headers: { \\"Content-Type\\": \\"application/json\\" }\\n  });\\n  if (!response.ok) {\\n    throw new Error(`HTTP error! Status: ${response.status}`);\\n  }\\n}\\nasync function CreateContent() {\\n  let dt = prompt.replace(/<[^>]+>/gi, \\"\\");\\n  const response = await fetch(`/chat`, {\\n    method: \\"POST\\",\\n    body: JSON.stringify({\\n      topic: name,\\n      dialog: JSON.stringify(dialog_data.content)\\n    }),\\n    headers: { \\"Content-Type\\": \\"application/json\\" }\\n  }).then((response2) => response2.json()).then((data2) => {\\n    if (data2.data.content[0]) {\\n      dialog_data.content = dialog_data.content.concat(data2.data.content);\\n      if (data2.data.html) {\\n        dialog_data.html = splitHtmlContent(data2.data.html);\\n      }\\n      dialog_data.name = name;\\n      new_content = true;\\n    }\\n  }).catch((error) => {\\n    console.log(error);\\n  });\\n}\\nfunction OnContextChange() {\\n  prompt = prompt.replace(\\"${dialog_data_html}\\", dialog_data.html);\\n}\\nfunction OnWordsChange() {\\n  prompt = prompt.replaceAll(\\"${dialog_data_words}\\", dialog_data.words);\\n}\\nfunction OnChangeContent(ev) {\\n  try {\\n    if (ev.currentTarget.value) {\\n      dialog_data.content = dialog_data.content.concat(JSON.parse(ev.currentTarget.value));\\n      console.log(dialog_data.content);\\n    } else\\n      content = \\"\\";\\n  } catch (ex) {\\n    console.log(ex);\\n  }\\n}\\nfunction CopyPrompt(ev) {\\n  const stringToCopy = prompt;\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u0421\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0430 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0430 \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        active = content_title;\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction PasteContent(ev) {\\n  navigator.clipboard.readText().then((text) => {\\n    content = text;\\n    const parsed = JSON.parse(text);\\n    const parsed_html = JSON.parse(text).html;\\n    if (dialog_data && dialog_data.content)\\n      dialog_data.content = dialog_data.content.concat(parsed.content);\\n    else {\\n      dialog_data.content = parsed;\\n    }\\n    if (dialog_data && parsed_html) {\\n      dialog_data.html = parsed_html;\\n    }\\n  }).catch((err) => {\\n    console.error(\\"Failed to read clipboard contents: \\", err);\\n  });\\n}\\nfunction OnCopyContent() {\\n  const stringToCopy = JSON.stringify(dialog_data.content);\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u041A\\\\u043E\\\\u043D\\\\u0442\\\\u0435\\\\u043D\\\\u0442 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        active = content_title;\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction OnGrammarChange() {\\n  if (grammar)\\n    prompt = prompt.replace(\\"${grammar}\\", grammar);\\n}\\n<\/script>\\r\\n\\r\\n<main>\\r\\n  <div class=\\"container\\">\\r\\n    <div class=\\"dialog-field\\">\\r\\n      {#await Translate(\'Title\', \'en\', $langs) then data}\\r\\n        <label for=\\"dialog_name\\">{data}</label>\\r\\n      {/await}\\r\\n\\r\\n      <input\\r\\n        type=\\"text\\"\\r\\n        class=\\"dialog_name\\"\\r\\n        name=\\"dialog_name\\"\\r\\n        bind:value={data.name[$llang]}\\r\\n      />\\r\\n    </div>\\r\\n    {#if data.level}\\r\\n      <div class=\\"dialog-field\\">\\r\\n        {#await Translate(\'Level\', \'en\', $langs) then data}\\r\\n          <label for=\\"dialog_level\\">{data}</label>\\r\\n        {/await}\\r\\n\\r\\n        <div class=\\"dialog_level\\" name=\\"dialog_level\\">{data.level}</div>\\r\\n      </div>\\r\\n    {/if}\\r\\n\\r\\n    {#if $llang}\\r\\n      <div class=\\"dialog-field\\">\\r\\n        {#await Translate(\'Language\', \'en\', $langs) then data}\\r\\n          <label for=\\"dialog_lang\\">{data}</label>\\r\\n        {/await}\\r\\n\\r\\n        <div type=\\"text\\" class=\\"dialog_lang\\" name=\\"dialog_lang\\">\\r\\n          {$llang}\\r\\n        </div>\\r\\n      </div>\\r\\n    {/if}\\r\\n  </div>\\r\\n\\r\\n  <Accordion\\r\\n    style=\\"margin-top: 20px;margin-bottom: 20px;\\"\\r\\n  >\\r\\n    <Panel>\\r\\n      <Header\\r\\n        ><b>\\r\\n          {#await Translate(\'Content Builder\', \'en\', $langs) then data}\\r\\n            {data}\\r\\n          {/await}\\r\\n        </b></Header\\r\\n      >\\r\\n\\r\\n      <Content>\\r\\n        <div class=\\"collapsible\\">\\r\\n          <div class=\\"generator_container\\">\\r\\n            <!-- {@debug grammar_title} -->\\r\\n            <TabBar\\r\\n              tabs={[\\r\\n                context_title,\\r\\n                grammar_title,\\r\\n                words_title,\\r\\n                prompt_title,\\r\\n                content_title,\\r\\n              ]}\\r\\n              let:tab\\r\\n              bind:active\\r\\n            >\\r\\n              <Tab {tab} minWidth>\\r\\n                <Label>{tab}</Label>\\r\\n              </Tab>\\r\\n            </TabBar>\\r\\n            {#if active === context_title}\\r\\n              {#if viewHTML}\\r\\n                <!-- <div style=\\"height: 350px; overflow-y:auto\\">\\r\\n                  {@html dialog_data.html}\\r\\n                </div> -->\\r\\n                <iframe srcdoc={dialog_data.html} width=\\"100%\\" height=\\"350px\\"\\r\\n                ></iframe>\\r\\n              {:else}\\r\\n                <Paper variant=\\"unelevated\\">\\r\\n                  <Content>\\r\\n                    <textarea\\r\\n                      rows=\\"20\\"\\r\\n                      name=\\"dialog_context\\"\\r\\n                      bind:value={dialog_data.html}\\r\\n                      on:change={OnContextChange}\\r\\n                    ></textarea>\\r\\n                  </Content>\\r\\n                </Paper>\\r\\n              {/if}\\r\\n              <button\\r\\n                class=\\"paste_content\\"\\r\\n                on:click={() => {\\r\\n                  viewHTML = !viewHTML;\\r\\n                }}>HTML</button\\r\\n              >\\r\\n            {:else if active === grammar_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <textarea\\r\\n                    rows=\\"20\\"\\r\\n                    name=\\"dialog_grammar\\"\\r\\n                    bind:value={grammar}\\r\\n                    on:change={OnGrammarChange}\\r\\n                  ></textarea>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === words_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <textarea\\r\\n                    on:change={() => OnWordsChange()}\\r\\n                    rows=\\"20\\"\\r\\n                    name=\\"dialog_words\\"\\r\\n                    bind:value={dialog_data.words}\\r\\n                  ></textarea>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === prompt_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <div\\r\\n                    class={Object.keys(anchorClasses).join(\' \')}\\r\\n                    use:Anchor={{\\r\\n                      addClass: (className) => {\\r\\n                        if (!anchorClasses[className]) {\\r\\n                          anchorClasses[className] = true;\\r\\n                        }\\r\\n                      },\\r\\n                      removeClass: (className) => {\\r\\n                        if (anchorClasses[className]) {\\r\\n                          delete anchorClasses[className];\\r\\n                          anchorClasses = anchorClasses;\\r\\n                        }\\r\\n                      },\\r\\n                    }}\\r\\n                    bind:this={anchor}\\r\\n                  >\\r\\n                    <Button on:click={() => menu.setOpen(true)}>\\r\\n                      <Label>Выбрать промпт</Label>\\r\\n                    </Button>\\r\\n                    <Menu\\r\\n                      bind:this={menu}\\r\\n                      anchor={false}\\r\\n                      bind:anchorElement={anchor}\\r\\n                      anchorCorner=\\"BOTTOM_LEFT\\"\\r\\n                    >\\r\\n                      <List>\\r\\n                        <Item on:click={() => LoadPrompt(\'basic\', data)}>\\r\\n                          <Text>basic</Text>\\r\\n                        </Item>\\r\\n                        <Item on:click={() => LoadPrompt(\'context\', data)}>\\r\\n                          <Text>context</Text>\\r\\n                        </Item>\\r\\n                        <Item on:click={() => LoadPrompt(\'grammar\', data)}>\\r\\n                          <Text>grammar</Text>\\r\\n                        </Item>\\r\\n                      </List>\\r\\n                    </Menu>\\r\\n                  </div>\\r\\n                  <textarea rows=\\"20\\" name=\\"dialog_task\\" bind:value={prompt}\\r\\n                  ></textarea>\\r\\n                  <!-- <div contenteditable=\\"true\\" bind:this={dialog_task}>\\r\\n                {@html prompt}\\r\\n              </div> -->\\r\\n                  <button class=\\"copy_prompt\\" on:click={CopyPrompt}>\\r\\n                    {#await Translate(\'Copy\', \'en\', $langs) then data}\\r\\n                      {data}\\r\\n                    {/await}\\r\\n                  </button>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === content_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  {#await Translate(\'Use chatGPT to run the copied prompt and paste result here\', \'en\', $langs) then data}\\r\\n                    <textarea\\r\\n                      id=\\"dialog_content\\"\\r\\n                      rows=\\"20\\"\\r\\n                      name=\\"dialog_content\\"\\r\\n                      placeholder={data}\\r\\n                      on:input={OnChangeContent}\\r\\n                      bind:value={content}\\r\\n                    ></textarea>\\r\\n                  {/await}\\r\\n                  <button class=\\"paste_content\\" on:click={PasteContent}>\\r\\n                    {#await Translate(\'Paste Content\', \'en\', $langs) then data}\\r\\n                      {data}\\r\\n                    {/await}\\r\\n                  </button>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {/if}\\r\\n          </div>\\r\\n\\r\\n          <div class=\\"container\\">\\r\\n            <button class=\\"save\\" disabled on:click={CreateContent}>\\r\\n              {#await Translate(\'Create content\', \'en\', $langs) then data}\\r\\n                {data}\\r\\n              {/await}\\r\\n            </button>\\r\\n          </div>\\r\\n        </div>\\r\\n      </Content>\\r\\n    </Panel>\\r\\n  </Accordion>\\r\\n\\r\\n  <table>\\r\\n    <thead>\\r\\n      <tr>\\r\\n        {#await Translate(\'User 1\', \'en\', $langs) then data}\\r\\n          <th>{data}</th>{/await}\\r\\n\\r\\n        {#await Translate(\'User 2\', \'en\', $langs) then data}\\r\\n          <th>{data}</th>{/await}\\r\\n      </tr>\\r\\n    </thead>\\r\\n    <tbody>\\r\\n      {#if dialog_data}\\r\\n        {#each dialog_data.content as item, index}\\r\\n          <tr>\\r\\n            <td>\\r\\n              {#if item.user1}\\r\\n                <textarea\\r\\n                  rows=\\"3\\"\\r\\n                  type=\\"text\\"\\r\\n                  bind:value={item.user1[$langs]}\\r\\n                />\\r\\n              {:else}\\r\\n                <textarea rows=\\"3\\" type=\\"text\\" />\\r\\n              {/if}\\r\\n            </td>\\r\\n            <td>\\r\\n              {#if item.user2}\\r\\n                <textarea\\r\\n                  rows=\\"3\\"\\r\\n                  type=\\"text\\"\\r\\n                  bind:value={item.user2[$langs]}\\r\\n                />\\r\\n              {:else}\\r\\n                <textarea rows=\\"3\\" type=\\"text\\" />\\r\\n              {/if}\\r\\n            </td>\\r\\n            <td>\\r\\n              <button class=\\"remrec_but\\" on:click={remRecord} {index}>-</button>\\r\\n            </td>\\r\\n          </tr>\\r\\n        {/each}\\r\\n      {/if}\\r\\n    </tbody>\\r\\n  </table>\\r\\n\\r\\n  <div class=\\"container\\">\\r\\n    <IconButton class=\\"material-icons add-record\\" on:click={addEmptyRecord}\\r\\n      >add</IconButton\\r\\n    >\\r\\n    <div class=\\"container\\">\\r\\n      {#await Translate(\'Copy data\', \'en\', $langs) then data}\\r\\n        <button class=\\"copy_content\\" on:click={() => OnCopyContent()}>{data}</button>\\r\\n      {/await}\\r\\n      {#await Translate(\'Save\', \'en\', $langs) then data}\\r\\n        <button class=\\"save_content\\" on:click={() => OnSave()}>{data}</button>\\r\\n      {/await}\\r\\n    </div>\\r\\n  </div>\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    margin: 20px;\\r\\n  }\\r\\n  .content_generator {\\r\\n    height: 40px;\\r\\n    margin-top: 25px;\\r\\n    width: 100%;\\r\\n  }\\r\\n  .collapsible {\\r\\n    overflow: hidden;\\r\\n    margin-top: 1rem;\\r\\n    margin-bottom: 3rem;\\r\\n    margin-left: 1rem;\\r\\n  }\\r\\n  ::selection {\\r\\n    border: 0;\\r\\n    background-color: lightblue;\\r\\n  }\\r\\n  table {\\r\\n    width: 100%;\\r\\n    border-collapse: collapse;\\r\\n  }\\r\\n\\r\\n  th {\\r\\n    /* background-color: #f2f2f2; */\\r\\n    position: sticky;\\r\\n    top: 0;\\r\\n    z-index: 2;\\r\\n  }\\r\\n  th,\\r\\n  td {\\r\\n    border: 1px solid #ddd;\\r\\n    padding: 1px;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .system_div {\\r\\n    margin-left: 10px;\\r\\n  }\\r\\n\\r\\n  .dialog-field {\\r\\n    display: inline-block;\\r\\n    box-sizing: border-box; /* Учтите ширину и отступы внутри элемента */\\r\\n    margin-right: 10px; /* Установите нужный вам отступ между полями */\\r\\n  }\\r\\n\\r\\n  .dialog-field:first-child {\\r\\n    width: calc(\\r\\n      100% - 20% - 10% - 5px\\r\\n    ); /* 20px - это сумма отступов между полями */\\r\\n  }\\r\\n\\r\\n  .dialog-field:nth-last-child(-n + 2) {\\r\\n    width: calc(\\r\\n      20% - 20px\\r\\n    ); /* 5px - это примерный отступ между последними двумя полями */\\r\\n  }\\r\\n\\r\\n  /* Для последнего dialog-field может потребоваться сброс правого отступа */\\r\\n\\r\\n  .container {\\r\\n    display: flex;\\r\\n    justify-content: space-between; /* Распределяет контейнеры равномерно по горизонтали */\\r\\n  }\\r\\n  .save_content {\\r\\n    position: fixed;\\r\\n    right: 20px;\\r\\n    bottom:5px;\\r\\n    margin-top: 10px; /* Отступ для кнопки \\"Создать\\" */\\r\\n  }\\r\\n\\r\\n  \\r\\n  .copy_content {\\r\\n    position: fixed;\\r\\n    right: 120px;\\r\\n    bottom:5px;\\r\\n    margin-top: 10px; /* Отступ для кнопки \\"Создать\\" */\\r\\n  }\\r\\n\\r\\n\\r\\n  textarea {\\r\\n    width: 100%;\\r\\n    resize: none;\\r\\n  }\\r\\n\\r\\n  .remrec_but {\\r\\n    scale: 2;\\r\\n    width: 25px;\\r\\n    border-radius: 35px;\\r\\n    border: 0;\\r\\n    background-color: transparent;\\r\\n    color: blue;\\r\\n  }\\r\\n  .dialog_name,\\r\\n  .dialog_lang,\\r\\n  .dialog_level {\\r\\n    border: 0;\\r\\n  }\\r\\n\\r\\n  .dialog-field {\\r\\n    display: flex;\\r\\n    flex-direction: column; /* Устанавливает вертикальное направление потока */\\r\\n    margin-right: 20px; /* Добавляет небольшой отступ справа для каждого поля, кроме последнего */\\r\\n  }\\r\\n\\r\\n  .dialog-field:last-child {\\r\\n    margin-right: 0; /* Убирает отступ справа у последнего поля */\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA8hBE,kBAAK,CACH,MAAM,CAAE,IACV,CACA,gCAAmB,CACjB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACT,CACA,0BAAa,CACX,QAAQ,CAAE,MAAM,CAChB,UAAU,CAAE,IAAI,CAChB,aAAa,CAAE,IAAI,CACnB,WAAW,CAAE,IACf,eACA,WAAY,CACV,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,SACpB,CACA,mBAAM,CACJ,KAAK,CAAE,IAAI,CACX,eAAe,CAAE,QACnB,CAEA,gBAAG,CAED,QAAQ,CAAE,MAAM,CAChB,GAAG,CAAE,CAAC,CACN,OAAO,CAAE,CACX,CACA,gBAAE,CACF,gBAAG,CACD,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,OAAO,CAAE,GAAG,CACZ,UAAU,CAAE,MACd,CAEA,yBAAY,CACV,WAAW,CAAE,IACf,CAEA,2BAAc,CACZ,OAAO,CAAE,YAAY,CACrB,UAAU,CAAE,UAAU,CACtB,YAAY,CAAE,IAChB,CAEA,2BAAa,YAAa,CACxB,KAAK,CAAE;AACX,MAAM,IAAI,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG;AAC5B,KACE,CAEA,2BAAa,gBAAgB,MAAM,CAAE,CACnC,KAAK,CAAE;AACX,MAAM,GAAG,CAAC,CAAC,CAAC,IAAI;AAChB,KACE,CAIA,wBAAW,CACT,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aACnB,CACA,2BAAc,CACZ,QAAQ,CAAE,KAAK,CACf,KAAK,CAAE,IAAI,CACX,OAAO,GAAG,CACV,UAAU,CAAE,IACd,CAGA,2BAAc,CACZ,QAAQ,CAAE,KAAK,CACf,KAAK,CAAE,KAAK,CACZ,OAAO,GAAG,CACV,UAAU,CAAE,IACd,CAGA,sBAAS,CACP,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IACV,CAEA,yBAAY,CACV,KAAK,CAAE,CAAC,CACR,KAAK,CAAE,IAAI,CACX,aAAa,CAAE,IAAI,CACnB,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,WAAW,CAC7B,KAAK,CAAE,IACT,CACA,0BAAY,CACZ,0BAAY,CACZ,2BAAc,CACZ,MAAM,CAAE,CACV,CAEA,2BAAc,CACZ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,YAAY,CAAE,IAChB,CAEA,2BAAa,WAAY,CACvB,YAAY,CAAE,CAChB"}'
};
function extractWords$1(text) {
  const regex = /<<(.*?)>>/g;
  let result = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[1]);
  }
  return result;
}
function splitHtmlContent$1(inputString) {
  const regex = /<(?:!DOCTYPE html|html(?:\s[^>]*)?)>(.*?)<\/html>/gs;
  const result = [];
  let match;
  while ((match = regex.exec(inputString)) !== null) {
    result.push(match[0]);
  }
  return result;
}
const DialogEdit = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $llang, $$unsubscribe_llang;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  let { ChangeQuizName } = $$props;
  const abonent = getContext("abonent");
  const data = getContext("quiz_data");
  let num = 10;
  let dialog_data = {
    lang: "",
    content: [],
    words: [],
    html: [""],
    name: ""
  };
  const name = data.name;
  let menu, anchor;
  let anchorClasses = {};
  let prompt = ``, grammar_title = "Grammar", context_title = "Context", prompt_title = "Prompt", words_title = "Words", content_title = "Content";
  let active = "Prompt";
  fetch(`./lesson?dialog=${data.name[$llang]}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then(async (resp) => {
    dialog_data = resp.data.dialog;
    if (!dialog_data) dialog_data = { content: [] };
    if (resp.data.html) {
      dialog_data.html = splitHtmlContent$1(resp.data.html);
    }
    dialog_data.name = name;
    fetch(`./admin?prompt=dialog.basic&quiz_name=${data.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data.level}&prompt_theme=${data.theme.name[$llang]}`).then((response) => response.json()).then((resp2) => {
      prompt = resp2.resp.prompt.system + resp2.resp.prompt.user;
      dialog_data.words = JSON.stringify(resp2.resp.words[0]?.data.map((item) => extractWords$1(item.example[$llang])).join(","));
      function extractContent(str) {
        const match = str.match(/<<(.*?)>>/);
        return match ? match[1] : null;
      }
      if (resp2.resp.words[0]?.data) {
        prompt = prompt.replaceAll("[${dialog_data_words}]", resp2.resp.words[0].data.map((item) => extractContent(item.example[$llang])));
      }
      if (!dialog_data.html) dialog_data.html = resp2.resp?.context[0].html;
      if (data.theme.grammar) prompt = prompt.replaceAll("${grammar}", JSON.stringify(data.theme.grammar));
      prompt = prompt.replaceAll("${llang}", $llang);
      prompt = prompt.replaceAll("${name[$llang]}", `${data.theme.name[$llang]}.${name[$llang]}`);
      prompt = prompt.replaceAll("${langs}", $langs);
      prompt = prompt.replaceAll("${dialog_data_html}", dialog_data.html);
      prompt = prompt.replaceAll("${data.level}", `${data.level}.${data.theme.id}(${data.module.themes.length})`);
      prompt = prompt.replaceAll("${num}", num);
      prompt = prompt;
    });
  }).catch((error) => {
    console.log(error);
  });
  async function TranslateContentToCurrentLang() {
    try {
      await Promise.all(dialog_data.content.map(async (item) => {
        await Promise.all(Object.keys(item).map(async (key) => {
          if (item[key][$llang] && !item[key][$langs]) {
            let tr = await Translate(item[key][$llang], $llang, $langs);
            item[key][$langs] = tr;
            dialog_data = dialog_data;
          }
        }));
      }));
    } catch (ex) {
    }
  }
  if ($$props.ChangeQuizName === void 0 && $$bindings.ChangeQuizName && ChangeQuizName !== void 0) $$bindings.ChangeQuizName(ChangeQuizName);
  $$result.css.add(css$3);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (dialog_data && $llang) {
        try {
          const dlg_content = dialog_data.content.map((line) => {
            return JSON.stringify(line);
          });
          let dialog_data_words = dialog_data.words || "";
        } catch (ex) {
        }
      }
    }
    {
      if (dialog_data && $langs) {
        TranslateContentToCurrentLang();
      }
    }
    {
      if (dialog_data.content.length > 0 && prompt) {
        let content2 = JSON.parse(JSON.stringify(dialog_data.content));
        try {
          content2?.forEach((item) => {
            item["user1"] = item["user1"][$llang] ? item["user1"][$llang] : item["user1"];
            item["user2"] = item["user2"][$llang] ? item["user2"][$llang] : item["user2"];
          });
        } catch (ex) {
        }
        prompt = prompt.replaceAll("${dialog_content}", JSON.stringify(content2));
      }
    }
    $$rendered = `<main class="svelte-7i104c"><div class="container svelte-7i104c"><div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_name" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Title", "en", $langs))} <input type="text" class="dialog_name svelte-7i104c" name="dialog_name"${add_attribute("value", data.name[$llang], 0)}></div> ${data.level ? `<div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_level" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Level", "en", $langs))} <div class="dialog_level svelte-7i104c" name="dialog_level">${escape(data.level)}</div></div>` : ``} ${$llang ? `<div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_lang" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Language", "en", $langs))} <div type="text" class="dialog_lang svelte-7i104c" name="dialog_lang">${escape($llang)}</div></div>` : ``}</div> ${validate_component(Accordion, "Accordion").$$render(
      $$result,
      {
        style: "margin-top: 20px;margin-bottom: 20px;"
      },
      {},
      {
        default: () => {
          return `${validate_component(Panel, "Panel").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Header$1, "Header").$$render($$result, {}, {}, {
                default: () => {
                  return `<b class="svelte-7i104c">${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data2) {
                      return ` ${escape(data2)} `;
                    }(__value);
                  }(Translate("Content Builder", "en", $langs))}</b>`;
                }
              })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                default: () => {
                  return `<div class="collapsible svelte-7i104c"><div class="generator_container svelte-7i104c"> ${validate_component(TabBar, "TabBar").$$render(
                    $$result,
                    {
                      tabs: [
                        context_title,
                        grammar_title,
                        words_title,
                        prompt_title,
                        content_title
                      ],
                      active
                    },
                    {
                      active: ($$value) => {
                        active = $$value;
                        $$settled = false;
                      }
                    },
                    {
                      default: ({ tab }) => {
                        return `${validate_component(Tab, "Tab").$$render($$result, { tab, minWidth: true }, {}, {
                          default: () => {
                            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                              default: () => {
                                return `${escape(tab)}`;
                              }
                            })}`;
                          }
                        })}`;
                      }
                    }
                  )} ${active === context_title ? `${`${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_context" class="svelte-7i104c">${escape(dialog_data.html || "")}</textarea>`;
                        }
                      })}`;
                    }
                  })}`} <button class="paste_content svelte-7i104c" data-svelte-h="svelte-12l3g78">HTML</button>` : `${active === grammar_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_grammar" class="svelte-7i104c">${escape("")}</textarea>`;
                        }
                      })}`;
                    }
                  })}` : `${active === words_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_words" class="svelte-7i104c">${escape(dialog_data.words || "")}</textarea>`;
                        }
                      })}`;
                    }
                  })}` : `${active === prompt_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<div class="${escape(null_to_empty(Object.keys(anchorClasses).join(" ")), true) + " svelte-7i104c"}"${add_attribute("this", anchor, 0)}>${validate_component(Button, "Button").$$render($$result, {}, {}, {
                            default: () => {
                              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                                default: () => {
                                  return `Выбрать промпт`;
                                }
                              })}`;
                            }
                          })} ${validate_component(Menu, "Menu").$$render(
                            $$result,
                            {
                              anchor: false,
                              anchorCorner: "BOTTOM_LEFT",
                              this: menu,
                              anchorElement: anchor
                            },
                            {
                              this: ($$value) => {
                                menu = $$value;
                                $$settled = false;
                              },
                              anchorElement: ($$value) => {
                                anchor = $$value;
                                $$settled = false;
                              }
                            },
                            {
                              default: () => {
                                return `${validate_component(List, "List").$$render($$result, {}, {}, {
                                  default: () => {
                                    return `${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `basic`;
                                          }
                                        })}`;
                                      }
                                    })} ${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `context`;
                                          }
                                        })}`;
                                      }
                                    })} ${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `grammar`;
                                          }
                                        })}`;
                                      }
                                    })}`;
                                  }
                                })}`;
                              }
                            }
                          )}</div> <textarea rows="20" name="dialog_task" class="svelte-7i104c">${escape(prompt || "")}</textarea>  <button class="copy_prompt svelte-7i104c">${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${escape(data2)} `;
                            }(__value);
                          }(Translate("Copy", "en", $langs))}</button>`;
                        }
                      })}`;
                    }
                  })}` : `${active === content_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` <textarea id="dialog_content" rows="20" name="dialog_content"${add_attribute("placeholder", data2, 0)} class="svelte-7i104c">${escape("")}</textarea> `;
                            }(__value);
                          }(Translate("Use chatGPT to run the copied prompt and paste result here", "en", $langs))} <button class="paste_content svelte-7i104c">${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${escape(data2)} `;
                            }(__value);
                          }(Translate("Paste Content", "en", $langs))}</button>`;
                        }
                      })}`;
                    }
                  })}` : ``}`}`}`}`}</div> <div class="container svelte-7i104c"><button class="save svelte-7i104c" disabled>${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data2) {
                      return ` ${escape(data2)} `;
                    }(__value);
                  }(Translate("Create content", "en", $langs))}</button></div></div>`;
                }
              })}`;
            }
          })}`;
        }
      }
    )} <table class="svelte-7i104c"><thead class="svelte-7i104c"><tr class="svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <th class="svelte-7i104c">${escape(data2)}</th>`;
      }(__value);
    }(Translate("User 1", "en", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <th class="svelte-7i104c">${escape(data2)}</th>`;
      }(__value);
    }(Translate("User 2", "en", $langs))}</tr></thead> <tbody class="svelte-7i104c">${dialog_data ? `${each(dialog_data.content, (item, index) => {
      return `<tr class="svelte-7i104c"><td class="svelte-7i104c">${item.user1 ? `<textarea rows="3" type="text" class="svelte-7i104c">${escape(item.user1[$langs] || "")}</textarea>` : `<textarea rows="3" type="text" class="svelte-7i104c"></textarea>`}</td> <td class="svelte-7i104c">${item.user2 ? `<textarea rows="3" type="text" class="svelte-7i104c">${escape(item.user2[$langs] || "")}</textarea>` : `<textarea rows="3" type="text" class="svelte-7i104c"></textarea>`}</td> <td class="svelte-7i104c"><button class="remrec_but svelte-7i104c"${add_attribute("index", index, 0)} data-svelte-h="svelte-1orru4d">-</button></td> </tr>`;
    })}` : ``}</tbody></table> <div class="container svelte-7i104c">${validate_component(IconButton, "IconButton").$$render($$result, { class: "material-icons add-record" }, {}, {
      default: () => {
        return `add`;
      }
    })} <div class="container svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="copy_content svelte-7i104c">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Copy data", "en", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="save_content svelte-7i104c">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Save", "en", $langs))}</div></div> </main>`;
  } while (!$$settled);
  $$unsubscribe_llang();
  $$unsubscribe_langs();
  return $$rendered;
});
const css$2 = {
  code: "main.svelte-7i104c{margin:20px}.content_generator.svelte-7i104c{height:40px;margin-top:25px;width:100%}.collapsible.svelte-7i104c{overflow:hidden;margin-top:1rem;margin-bottom:3rem;margin-left:1rem}.svelte-7i104c::selection{border:0;background-color:lightblue}table.svelte-7i104c{width:100%;border-collapse:collapse}th.svelte-7i104c{position:sticky;top:0;z-index:2}th.svelte-7i104c,td.svelte-7i104c{border:1px solid #ddd;padding:1px;text-align:center}.system_div.svelte-7i104c{margin-left:10px}.dialog-field.svelte-7i104c{display:inline-block;box-sizing:border-box;margin-right:10px}.dialog-field.svelte-7i104c:first-child{width:calc(\r\n      100% - 20% - 10% - 5px\r\n    )}.dialog-field.svelte-7i104c:nth-last-child(-n + 2){width:calc(\r\n      20% - 20px\r\n    )}.container.svelte-7i104c{display:flex;justify-content:space-between}.save_content.svelte-7i104c{position:fixed;right:20px;bottom:5px;margin-top:10px}.copy_content.svelte-7i104c{position:fixed;right:120px;bottom:5px;margin-top:10px}textarea.svelte-7i104c{width:100%;resize:none}.remrec_but.svelte-7i104c{scale:2;width:25px;border-radius:35px;border:0;background-color:transparent;color:blue}.dialog_name.svelte-7i104c,.dialog_lang.svelte-7i104c,.dialog_level.svelte-7i104c{border:0}.dialog-field.svelte-7i104c{display:flex;flex-direction:column;margin-right:20px}.dialog-field.svelte-7i104c:last-child{margin-right:0}",
  map: '{"version":3,"file":"BricksEdit.svelte","sources":["BricksEdit.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { Translate } from \\"../../../translate/Transloc.js\\";\\nimport { getContext, onMount } from \\"svelte\\";\\nimport { nlang, llang, langs, dicts, view } from \\"$lib/js/stores.js\\";\\nimport List, { Item, Separator, Text } from \\"@smui/list\\";\\nimport Tab, { Label } from \\"@smui/tab\\";\\nimport TabBar from \\"@smui/tab-bar\\";\\nimport Accordion, { Panel, Header } from \\"@smui-extra/accordion\\";\\nimport Menu from \\"@smui/menu\\";\\nimport Button from \\"@smui/button\\";\\nimport IconButton from \\"@smui/icon-button\\";\\nimport Paper, { Content } from \\"@smui/paper\\";\\nimport { Anchor } from \\"@smui/menu-surface\\";\\nexport let ChangeQuizName;\\nconst abonent = getContext(\\"abonent\\");\\nconst data = getContext(\\"quiz_data\\");\\nlet content = \\"\\", new_content = false, num = 10;\\nlet dialog_data = { lang: \\"\\", content: [], words: [], html: [\\"\\"], name: \\"\\" };\\nconst name = data.name;\\nlet dialog_task, dialog_words, dialog_tmplt;\\nlet menu, anchor;\\nlet anchorClasses = {};\\nlet viewHTML = false;\\nlet prompt = ``, grammar = \\"\\", grammar_title = \\"Grammar\\", context_title = \\"Context\\", prompt_title = \\"Prompt\\", words_title = \\"Words\\", content_title = \\"Content\\";\\nlet active = \\"Prompt\\";\\n$: if (false) {\\n  (async () => {\\n    grammar_title = await Translate(\\"Grammar\\", \\"en\\", $langs);\\n    context_title = await Translate(\\"Context\\", \\"en\\", $langs);\\n    words_title = await Translate(\\"Words\\", \\"en\\", $langs);\\n    content_title = await Translate(\\"Content\\", \\"en\\", $langs);\\n  })();\\n}\\n$: if (dialog_data && $llang) {\\n  try {\\n    const dlg_content = dialog_data.content.map((line) => {\\n      return JSON.stringify(line);\\n    });\\n    let dialog_data_words = dialog_data.words || \\"\\";\\n  } catch (ex) {\\n  }\\n}\\n$: if (dialog_data && $langs) {\\n  TranslateContentToCurrentLang();\\n}\\n$: if (dialog_data.content.length > 0 && prompt) {\\n  let content2 = JSON.parse(JSON.stringify(dialog_data.content));\\n  try {\\n    content2?.forEach((item) => {\\n      item[\\"user1\\"] = item[\\"user1\\"][$llang] ? item[\\"user1\\"][$llang] : item[\\"user1\\"];\\n      item[\\"user2\\"] = item[\\"user2\\"][$llang] ? item[\\"user2\\"][$llang] : item[\\"user2\\"];\\n    });\\n  } catch (ex) {\\n  }\\n  prompt = prompt.replaceAll(\\"${dialog_content}\\", JSON.stringify(content2));\\n}\\nfetch(`./lesson?bricks=${data.name[$llang]}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then(async (resp) => {\\n  dialog_data = resp.data.dialog;\\n  if (!dialog_data)\\n    dialog_data = { content: [] };\\n  if (resp.data.html) {\\n    dialog_data.html = splitHtmlContent(resp.data.html);\\n  }\\n  dialog_data.name = name;\\n  fetch(`./admin?prompt=dialog.basic&quiz_name=${data.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data.level}&prompt_theme=${data.theme}`).then((response) => response.json()).then((resp2) => {\\n    prompt = resp2.resp.prompt.system + resp2.resp.prompt.user;\\n    prompt = prompt.replaceAll(\\"${llang}\\", $llang);\\n    prompt = prompt.replaceAll(\\"${name[$llang]}\\", `${data.theme.name[$llang]}.${name[$llang]}`);\\n    prompt = prompt.replaceAll(\\"${langs}\\", $langs);\\n    prompt = prompt.replaceAll(\\"${dialog_data.html}\\", dialog_data.html);\\n    prompt = prompt.replaceAll(\\"${data.level}\\", `${data.level}.${data.theme.id}(${data.module.themes.length})`);\\n    prompt = prompt.replaceAll(\\"${num}\\", num);\\n    dialog_data.words = JSON.stringify(resp2.resp.words[0]?.data.map((item) => extractWords(item.example[$llang])).join(\\",\\"));\\n    function extractContent(str) {\\n      const match = str.match(/<<(.*?)>>/);\\n      return match ? match[1] : null;\\n    }\\n    if (resp2.resp.words[0]?.data) {\\n      prompt = prompt.replaceAll(\\"[${dialog_data_words}]\\", resp2.resp.words[0].data.map((item) => extractContent(item.example[$llang])));\\n    }\\n    dialog_data.html = resp2.resp.words[0]?.context;\\n    if (data.theme.grammar)\\n      prompt = prompt.replaceAll(\\"${grammar}\\", JSON.stringify(data.theme.grammar));\\n    prompt = prompt;\\n  });\\n}).catch((error) => {\\n  console.log(error);\\n});\\nonMount(async () => {\\n});\\nfunction LoadPrompt(name2, data2) {\\n  if (name2 === \\"context\\") {\\n    active = `Context`;\\n  } else if (name2 === \\"grammar\\") {\\n    active = `Grammar`;\\n  }\\n  fetch(`/admin?prompt=dialog.${name2}&quiz_name=${data2.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data2.level}&prompt_theme=${data2.theme}`).then((response) => response.json()).then((data3) => {\\n    prompt = data3.resp.prompt.system + data3.resp.prompt.user;\\n    prompt = prompt.replaceAll(\\"${llang}\\", $llang);\\n    prompt = prompt.replaceAll(\\"${name[$llang]}\\", dialog_data.name[$llang]);\\n    prompt = prompt.replaceAll(\\"${langs}\\", $langs);\\n    prompt = prompt.replaceAll(\\"${dialog_data.html}\\", dialog_data.html);\\n    prompt = prompt.replaceAll(\\"${data.level}\\", data3.level);\\n    prompt = prompt.replaceAll(\\"${num}\\", num);\\n    prompt = prompt.replaceAll(\\"${grammar}\\", data3.resp.grammar.grammar.map((el) => {\\n      return el;\\n    }));\\n    prompt = prompt;\\n  }).catch((error) => {\\n    console.log(error);\\n  });\\n}\\nfunction extractWords(text) {\\n  const regex = /<<(.*?)>>/g;\\n  let result = [];\\n  let match;\\n  while ((match = regex.exec(text)) !== null) {\\n    result.push(match[1]);\\n  }\\n  return result;\\n}\\nasync function TranslateContentToCurrentLang() {\\n  try {\\n    await Promise.all(dialog_data.content.map(async (item) => {\\n      await Promise.all(Object.keys(item).map(async (key) => {\\n        if (item[key][$llang] && !item[key][$langs]) {\\n          let tr = await Translate(item[key][$llang], $llang, $langs);\\n          item[key][$langs] = tr;\\n          dialog_data = dialog_data;\\n        }\\n      }));\\n    }));\\n  } catch (ex) {\\n  }\\n}\\nfunction splitHtmlContent(inputString) {\\n  const regex = /<(?:!DOCTYPE html|html(?:\\\\s[^>]*)?)>(.*?)<\\\\/html>/gs;\\n  const result = [];\\n  let match;\\n  while ((match = regex.exec(inputString)) !== null) {\\n    result.push(match[0]);\\n  }\\n  return result;\\n}\\nfunction addEmptyRecord() {\\n  let emptyRecord = {\\n    num: (dialog_data.content.length + 1).toString(),\\n    // Пример создания уникального номера записи\\n    user1: { nl: \\"\\", ru: \\"\\", uk: \\"\\", fr: \\"\\", en: \\"\\", de: \\"\\" },\\n    user2: { nl: \\"\\", ru: \\"\\", uk: \\"\\", fr: \\"\\", en: \\"\\", de: \\"\\" },\\n    language: $llang\\n    // Пример начального выбранного языка\\n  };\\n  dialog_data.content.push(emptyRecord);\\n  dialog_data = dialog_data;\\n}\\nfunction remRecord(ev) {\\n  const index = ev.currentTarget.attributes.index.nodeValue;\\n  dialog_data.content.splice(index, 1);\\n  dialog_data = dialog_data;\\n}\\nfunction OnSave() {\\n  SaveDialogData(name, data);\\n  ChangeQuizName(name, data.name);\\n}\\nasync function SaveDialogData(name2, data2) {\\n  const response = await fetch(`/admin/module`, {\\n    method: \\"POST\\",\\n    body: JSON.stringify({\\n      func: \\"upd_dlg\\",\\n      owner: abonent,\\n      level: data2.level,\\n      name: name2[$llang],\\n      new_name: data2.name[$llang],\\n      data: dialog_data,\\n      lang: $llang\\n    }),\\n    headers: { \\"Content-Type\\": \\"application/json\\" }\\n  });\\n  if (!response.ok) {\\n    throw new Error(`HTTP error! Status: ${response.status}`);\\n  }\\n}\\nasync function CreateContent() {\\n  let dt = prompt.replace(/<[^>]+>/gi, \\"\\");\\n  const response = await fetch(`/chat`, {\\n    method: \\"POST\\",\\n    body: JSON.stringify({\\n      topic: name,\\n      dialog: JSON.stringify(dialog_data.content)\\n    }),\\n    headers: { \\"Content-Type\\": \\"application/json\\" }\\n  }).then((response2) => response2.json()).then((data2) => {\\n    if (data2.data.content[0]) {\\n      dialog_data.content = dialog_data.content.concat(data2.data.content);\\n      if (data2.data.html) {\\n        dialog_data.html = splitHtmlContent(data2.data.html);\\n      }\\n      dialog_data.name = name;\\n      new_content = true;\\n    }\\n  }).catch((error) => {\\n    console.log(error);\\n  });\\n}\\nfunction OnContextChange() {\\n  prompt = prompt.replace(\\"${dialog_data_html}\\", dialog_data.html);\\n}\\nfunction OnWordsChange() {\\n  prompt = prompt.replaceAll(\\"${dialog_data_words}\\", dialog_data.words);\\n}\\nfunction OnChangeContent(ev) {\\n  try {\\n    if (ev.currentTarget.value) {\\n      dialog_data.content = dialog_data.content.concat(JSON.parse(ev.currentTarget.value));\\n      console.log(dialog_data.content);\\n    } else\\n      content = \\"\\";\\n  } catch (ex) {\\n    console.log(ex);\\n  }\\n}\\nfunction CopyPrompt(ev) {\\n  const stringToCopy = prompt;\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u0421\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0430 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0430 \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        active = content_title;\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction PasteContent(ev) {\\n  navigator.clipboard.readText().then((text) => {\\n    content = text;\\n    const parsed = JSON.parse(text);\\n    const parsed_html = JSON.parse(text).html;\\n    if (dialog_data && dialog_data.content)\\n      dialog_data.content = dialog_data.content.concat(parsed.content);\\n    else {\\n      dialog_data.content = parsed;\\n    }\\n    if (dialog_data && parsed_html) {\\n      dialog_data.html = parsed_html;\\n    }\\n  }).catch((err) => {\\n    console.error(\\"Failed to read clipboard contents: \\", err);\\n  });\\n}\\nfunction OnCopyContent() {\\n  const stringToCopy = JSON.stringify(dialog_data.content);\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u041A\\\\u043E\\\\u043D\\\\u0442\\\\u0435\\\\u043D\\\\u0442 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        active = content_title;\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction OnGrammarChange() {\\n  if (grammar)\\n    prompt = prompt.replace(\\"${grammar}\\", grammar);\\n}\\n<\/script>\\r\\n\\r\\n<main>\\r\\n  <div class=\\"container\\">\\r\\n    <div class=\\"dialog-field\\">\\r\\n      {#await Translate(\'Title\', \'en\', $langs) then data}\\r\\n        <label for=\\"dialog_name\\">{data}</label>\\r\\n      {/await}\\r\\n\\r\\n      <input\\r\\n        type=\\"text\\"\\r\\n        class=\\"dialog_name\\"\\r\\n        name=\\"dialog_name\\"\\r\\n        bind:value={data.name[$llang]}\\r\\n      />\\r\\n    </div>\\r\\n    {#if data.level}\\r\\n      <div class=\\"dialog-field\\">\\r\\n        {#await Translate(\'Level\', \'en\', $langs) then data}\\r\\n          <label for=\\"dialog_level\\">{data}</label>\\r\\n        {/await}\\r\\n\\r\\n        <div class=\\"dialog_level\\" name=\\"dialog_level\\">{data.level}</div>\\r\\n      </div>\\r\\n    {/if}\\r\\n\\r\\n    {#if $llang}\\r\\n      <div class=\\"dialog-field\\">\\r\\n        {#await Translate(\'Language\', \'en\', $langs) then data}\\r\\n          <label for=\\"dialog_lang\\">{data}</label>\\r\\n        {/await}\\r\\n\\r\\n        <div type=\\"text\\" class=\\"dialog_lang\\" name=\\"dialog_lang\\">\\r\\n          {$llang}\\r\\n        </div>\\r\\n      </div>\\r\\n    {/if}\\r\\n  </div>\\r\\n\\r\\n  <Accordion\\r\\n    style=\\"margin-top: 20px;margin-bottom: 20px;\\"\\r\\n  >\\r\\n    <Panel>\\r\\n      <Header\\r\\n        ><b>\\r\\n          {#await Translate(\'Content Builder\', \'en\', $langs) then data}\\r\\n            {data}\\r\\n          {/await}\\r\\n        </b></Header\\r\\n      >\\r\\n\\r\\n      <Content>\\r\\n        <div class=\\"collapsible\\">\\r\\n          <div class=\\"generator_container\\">\\r\\n            <!-- {@debug grammar_title} -->\\r\\n            <TabBar\\r\\n              tabs={[\\r\\n                context_title,\\r\\n                grammar_title,\\r\\n                words_title,\\r\\n                prompt_title,\\r\\n                content_title,\\r\\n              ]}\\r\\n              let:tab\\r\\n              bind:active\\r\\n            >\\r\\n              <Tab {tab} minWidth>\\r\\n                <Label>{tab}</Label>\\r\\n              </Tab>\\r\\n            </TabBar>\\r\\n            {#if active === context_title}\\r\\n              {#if viewHTML}\\r\\n                <!-- <div style=\\"height: 350px; overflow-y:auto\\">\\r\\n                  {@html dialog_data.html}\\r\\n                </div> -->\\r\\n                <iframe srcdoc={dialog_data.html} width=\\"100%\\" height=\\"350px\\"\\r\\n                ></iframe>\\r\\n              {:else}\\r\\n                <Paper variant=\\"unelevated\\">\\r\\n                  <Content>\\r\\n                    <textarea\\r\\n                      rows=\\"20\\"\\r\\n                      name=\\"dialog_context\\"\\r\\n                      bind:value={dialog_data.html}\\r\\n                      on:change={OnContextChange}\\r\\n                    ></textarea>\\r\\n                  </Content>\\r\\n                </Paper>\\r\\n              {/if}\\r\\n              <button\\r\\n                class=\\"paste_content\\"\\r\\n                on:click={() => {\\r\\n                  viewHTML = !viewHTML;\\r\\n                }}>HTML</button\\r\\n              >\\r\\n            {:else if active === grammar_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <textarea\\r\\n                    rows=\\"20\\"\\r\\n                    name=\\"dialog_grammar\\"\\r\\n                    bind:value={grammar}\\r\\n                    on:change={OnGrammarChange}\\r\\n                  ></textarea>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === words_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <textarea\\r\\n                    on:change={() => OnWordsChange()}\\r\\n                    rows=\\"20\\"\\r\\n                    name=\\"dialog_words\\"\\r\\n                    bind:value={dialog_data.words}\\r\\n                  ></textarea>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === prompt_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  <div\\r\\n                    class={Object.keys(anchorClasses).join(\' \')}\\r\\n                    use:Anchor={{\\r\\n                      addClass: (className) => {\\r\\n                        if (!anchorClasses[className]) {\\r\\n                          anchorClasses[className] = true;\\r\\n                        }\\r\\n                      },\\r\\n                      removeClass: (className) => {\\r\\n                        if (anchorClasses[className]) {\\r\\n                          delete anchorClasses[className];\\r\\n                          anchorClasses = anchorClasses;\\r\\n                        }\\r\\n                      },\\r\\n                    }}\\r\\n                    bind:this={anchor}\\r\\n                  >\\r\\n                    <Button on:click={() => menu.setOpen(true)}>\\r\\n                      <Label>Выбрать промпт</Label>\\r\\n                    </Button>\\r\\n                    <Menu\\r\\n                      bind:this={menu}\\r\\n                      anchor={false}\\r\\n                      bind:anchorElement={anchor}\\r\\n                      anchorCorner=\\"BOTTOM_LEFT\\"\\r\\n                    >\\r\\n                      <List>\\r\\n                        <Item on:click={() => LoadPrompt(\'basic\', data)}>\\r\\n                          <Text>basic</Text>\\r\\n                        </Item>\\r\\n                        <Item on:click={() => LoadPrompt(\'context\', data)}>\\r\\n                          <Text>context</Text>\\r\\n                        </Item>\\r\\n                        <Item on:click={() => LoadPrompt(\'grammar\', data)}>\\r\\n                          <Text>grammar</Text>\\r\\n                        </Item>\\r\\n                      </List>\\r\\n                    </Menu>\\r\\n                  </div>\\r\\n                  <textarea rows=\\"20\\" name=\\"dialog_task\\" bind:value={prompt}\\r\\n                  ></textarea>\\r\\n                  <!-- <div contenteditable=\\"true\\" bind:this={dialog_task}>\\r\\n                {@html prompt}\\r\\n              </div> -->\\r\\n                  <button class=\\"copy_prompt\\" on:click={CopyPrompt}>\\r\\n                    {#await Translate(\'Copy\', \'en\', $langs) then data}\\r\\n                      {data}\\r\\n                    {/await}\\r\\n                  </button>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {:else if active === content_title}\\r\\n              <Paper variant=\\"unelevated\\">\\r\\n                <Content>\\r\\n                  {#await Translate(\'Use chatGPT to run the copied prompt and paste result here\', \'en\', $langs) then data}\\r\\n                    <textarea\\r\\n                      id=\\"dialog_content\\"\\r\\n                      rows=\\"20\\"\\r\\n                      name=\\"dialog_content\\"\\r\\n                      placeholder={data}\\r\\n                      on:input={OnChangeContent}\\r\\n                      bind:value={content}\\r\\n                    ></textarea>\\r\\n                  {/await}\\r\\n                  <button class=\\"paste_content\\" on:click={PasteContent}>\\r\\n                    {#await Translate(\'Paste Content\', \'en\', $langs) then data}\\r\\n                      {data}\\r\\n                    {/await}\\r\\n                  </button>\\r\\n                </Content>\\r\\n              </Paper>\\r\\n            {/if}\\r\\n          </div>\\r\\n\\r\\n          <div class=\\"container\\">\\r\\n            <button class=\\"save\\" disabled on:click={CreateContent}>\\r\\n              {#await Translate(\'Create content\', \'en\', $langs) then data}\\r\\n                {data}\\r\\n              {/await}\\r\\n            </button>\\r\\n          </div>\\r\\n        </div>\\r\\n      </Content>\\r\\n    </Panel>\\r\\n  </Accordion>\\r\\n\\r\\n  <table>\\r\\n    <thead>\\r\\n      <tr>\\r\\n        {#await Translate(\'User 1\', \'en\', $langs) then data}\\r\\n          <th>{data}</th>{/await}\\r\\n\\r\\n        {#await Translate(\'User 2\', \'en\', $langs) then data}\\r\\n          <th>{data}</th>{/await}\\r\\n      </tr>\\r\\n    </thead>\\r\\n    <tbody>\\r\\n      {#if dialog_data}\\r\\n        {#each dialog_data.content as item, index}\\r\\n          <tr>\\r\\n            <td>\\r\\n              {#if item.user1}\\r\\n                <textarea\\r\\n                  rows=\\"3\\"\\r\\n                  type=\\"text\\"\\r\\n                  bind:value={item.user1[$langs]}\\r\\n                />\\r\\n              {:else}\\r\\n                <textarea rows=\\"3\\" type=\\"text\\" />\\r\\n              {/if}\\r\\n            </td>\\r\\n            <td>\\r\\n              {#if item.user2}\\r\\n                <textarea\\r\\n                  rows=\\"3\\"\\r\\n                  type=\\"text\\"\\r\\n                  bind:value={item.user2[$langs]}\\r\\n                />\\r\\n              {:else}\\r\\n                <textarea rows=\\"3\\" type=\\"text\\" />\\r\\n              {/if}\\r\\n            </td>\\r\\n            <td>\\r\\n              <button class=\\"remrec_but\\" on:click={remRecord} {index}>-</button>\\r\\n            </td>\\r\\n          </tr>\\r\\n        {/each}\\r\\n      {/if}\\r\\n    </tbody>\\r\\n  </table>\\r\\n\\r\\n  <div class=\\"container\\">\\r\\n    <IconButton class=\\"material-icons add-record\\" on:click={addEmptyRecord}\\r\\n      >add</IconButton\\r\\n    >\\r\\n    <div class=\\"container\\">\\r\\n      {#await Translate(\'Copy data\', \'en\', $langs) then data}\\r\\n        <button class=\\"copy_content\\" on:click={() => OnCopyContent()}>{data}</button>\\r\\n      {/await}\\r\\n      {#await Translate(\'Save\', \'en\', $langs) then data}\\r\\n        <button class=\\"save_content\\" on:click={() => OnSave()}>{data}</button>\\r\\n      {/await}\\r\\n    </div>\\r\\n  </div>\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    margin: 20px;\\r\\n  }\\r\\n  .content_generator {\\r\\n    height: 40px;\\r\\n    margin-top: 25px;\\r\\n    width: 100%;\\r\\n  }\\r\\n  .collapsible {\\r\\n    overflow: hidden;\\r\\n    margin-top: 1rem;\\r\\n    margin-bottom: 3rem;\\r\\n    margin-left: 1rem;\\r\\n  }\\r\\n  ::selection {\\r\\n    border: 0;\\r\\n    background-color: lightblue;\\r\\n  }\\r\\n  table {\\r\\n    width: 100%;\\r\\n    border-collapse: collapse;\\r\\n  }\\r\\n\\r\\n  th {\\r\\n    /* background-color: #f2f2f2; */\\r\\n    position: sticky;\\r\\n    top: 0;\\r\\n    z-index: 2;\\r\\n  }\\r\\n  th,\\r\\n  td {\\r\\n    border: 1px solid #ddd;\\r\\n    padding: 1px;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .system_div {\\r\\n    margin-left: 10px;\\r\\n  }\\r\\n\\r\\n  .dialog-field {\\r\\n    display: inline-block;\\r\\n    box-sizing: border-box; /* Учтите ширину и отступы внутри элемента */\\r\\n    margin-right: 10px; /* Установите нужный вам отступ между полями */\\r\\n  }\\r\\n\\r\\n  .dialog-field:first-child {\\r\\n    width: calc(\\r\\n      100% - 20% - 10% - 5px\\r\\n    ); /* 20px - это сумма отступов между полями */\\r\\n  }\\r\\n\\r\\n  .dialog-field:nth-last-child(-n + 2) {\\r\\n    width: calc(\\r\\n      20% - 20px\\r\\n    ); /* 5px - это примерный отступ между последними двумя полями */\\r\\n  }\\r\\n\\r\\n  /* Для последнего dialog-field может потребоваться сброс правого отступа */\\r\\n\\r\\n  .container {\\r\\n    display: flex;\\r\\n    justify-content: space-between; /* Распределяет контейнеры равномерно по горизонтали */\\r\\n  }\\r\\n  .save_content {\\r\\n    position: fixed;\\r\\n    right: 20px;\\r\\n    bottom:5px;\\r\\n    margin-top: 10px; /* Отступ для кнопки \\"Создать\\" */\\r\\n  }\\r\\n\\r\\n  \\r\\n  .copy_content {\\r\\n    position: fixed;\\r\\n    right: 120px;\\r\\n    bottom:5px;\\r\\n    margin-top: 10px; /* Отступ для кнопки \\"Создать\\" */\\r\\n  }\\r\\n\\r\\n\\r\\n  textarea {\\r\\n    width: 100%;\\r\\n    resize: none;\\r\\n  }\\r\\n\\r\\n  .remrec_but {\\r\\n    scale: 2;\\r\\n    width: 25px;\\r\\n    border-radius: 35px;\\r\\n    border: 0;\\r\\n    background-color: transparent;\\r\\n    color: blue;\\r\\n  }\\r\\n  .dialog_name,\\r\\n  .dialog_lang,\\r\\n  .dialog_level {\\r\\n    border: 0;\\r\\n  }\\r\\n\\r\\n  .dialog-field {\\r\\n    display: flex;\\r\\n    flex-direction: column; /* Устанавливает вертикальное направление потока */\\r\\n    margin-right: 20px; /* Добавляет небольшой отступ справа для каждого поля, кроме последнего */\\r\\n  }\\r\\n\\r\\n  .dialog-field:last-child {\\r\\n    margin-right: 0; /* Убирает отступ справа у последнего поля */\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA6hBE,kBAAK,CACH,MAAM,CAAE,IACV,CACA,gCAAmB,CACjB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACT,CACA,0BAAa,CACX,QAAQ,CAAE,MAAM,CAChB,UAAU,CAAE,IAAI,CAChB,aAAa,CAAE,IAAI,CACnB,WAAW,CAAE,IACf,eACA,WAAY,CACV,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,SACpB,CACA,mBAAM,CACJ,KAAK,CAAE,IAAI,CACX,eAAe,CAAE,QACnB,CAEA,gBAAG,CAED,QAAQ,CAAE,MAAM,CAChB,GAAG,CAAE,CAAC,CACN,OAAO,CAAE,CACX,CACA,gBAAE,CACF,gBAAG,CACD,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,OAAO,CAAE,GAAG,CACZ,UAAU,CAAE,MACd,CAEA,yBAAY,CACV,WAAW,CAAE,IACf,CAEA,2BAAc,CACZ,OAAO,CAAE,YAAY,CACrB,UAAU,CAAE,UAAU,CACtB,YAAY,CAAE,IAChB,CAEA,2BAAa,YAAa,CACxB,KAAK,CAAE;AACX,MAAM,IAAI,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG;AAC5B,KACE,CAEA,2BAAa,gBAAgB,MAAM,CAAE,CACnC,KAAK,CAAE;AACX,MAAM,GAAG,CAAC,CAAC,CAAC,IAAI;AAChB,KACE,CAIA,wBAAW,CACT,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aACnB,CACA,2BAAc,CACZ,QAAQ,CAAE,KAAK,CACf,KAAK,CAAE,IAAI,CACX,OAAO,GAAG,CACV,UAAU,CAAE,IACd,CAGA,2BAAc,CACZ,QAAQ,CAAE,KAAK,CACf,KAAK,CAAE,KAAK,CACZ,OAAO,GAAG,CACV,UAAU,CAAE,IACd,CAGA,sBAAS,CACP,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IACV,CAEA,yBAAY,CACV,KAAK,CAAE,CAAC,CACR,KAAK,CAAE,IAAI,CACX,aAAa,CAAE,IAAI,CACnB,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,WAAW,CAC7B,KAAK,CAAE,IACT,CACA,0BAAY,CACZ,0BAAY,CACZ,2BAAc,CACZ,MAAM,CAAE,CACV,CAEA,2BAAc,CACZ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,YAAY,CAAE,IAChB,CAEA,2BAAa,WAAY,CACvB,YAAY,CAAE,CAChB"}'
};
function extractWords(text) {
  const regex = /<<(.*?)>>/g;
  let result = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[1]);
  }
  return result;
}
function splitHtmlContent(inputString) {
  const regex = /<(?:!DOCTYPE html|html(?:\s[^>]*)?)>(.*?)<\/html>/gs;
  const result = [];
  let match;
  while ((match = regex.exec(inputString)) !== null) {
    result.push(match[0]);
  }
  return result;
}
const BricksEdit = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $llang, $$unsubscribe_llang;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  let { ChangeQuizName } = $$props;
  const abonent = getContext("abonent");
  const data = getContext("quiz_data");
  let num = 10;
  let dialog_data = {
    lang: "",
    content: [],
    words: [],
    html: [""],
    name: ""
  };
  const name = data.name;
  let menu, anchor;
  let anchorClasses = {};
  let prompt = ``, grammar_title = "Grammar", context_title = "Context", prompt_title = "Prompt", words_title = "Words", content_title = "Content";
  let active = "Prompt";
  fetch(`./lesson?bricks=${data.name[$llang]}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then(async (resp) => {
    dialog_data = resp.data.dialog;
    if (!dialog_data) dialog_data = { content: [] };
    if (resp.data.html) {
      dialog_data.html = splitHtmlContent(resp.data.html);
    }
    dialog_data.name = name;
    fetch(`./admin?prompt=dialog.basic&quiz_name=${data.name[$llang]}&prompt_owner=${abonent}&prompt_level=${data.level}&prompt_theme=${data.theme}`).then((response) => response.json()).then((resp2) => {
      prompt = resp2.resp.prompt.system + resp2.resp.prompt.user;
      prompt = prompt.replaceAll("${llang}", $llang);
      prompt = prompt.replaceAll("${name[$llang]}", `${data.theme.name[$llang]}.${name[$llang]}`);
      prompt = prompt.replaceAll("${langs}", $langs);
      prompt = prompt.replaceAll("${dialog_data.html}", dialog_data.html);
      prompt = prompt.replaceAll("${data.level}", `${data.level}.${data.theme.id}(${data.module.themes.length})`);
      prompt = prompt.replaceAll("${num}", num);
      dialog_data.words = JSON.stringify(resp2.resp.words[0]?.data.map((item) => extractWords(item.example[$llang])).join(","));
      function extractContent(str) {
        const match = str.match(/<<(.*?)>>/);
        return match ? match[1] : null;
      }
      if (resp2.resp.words[0]?.data) {
        prompt = prompt.replaceAll("[${dialog_data_words}]", resp2.resp.words[0].data.map((item) => extractContent(item.example[$llang])));
      }
      dialog_data.html = resp2.resp.words[0]?.context;
      if (data.theme.grammar) prompt = prompt.replaceAll("${grammar}", JSON.stringify(data.theme.grammar));
      prompt = prompt;
    });
  }).catch((error) => {
    console.log(error);
  });
  async function TranslateContentToCurrentLang() {
    try {
      await Promise.all(dialog_data.content.map(async (item) => {
        await Promise.all(Object.keys(item).map(async (key) => {
          if (item[key][$llang] && !item[key][$langs]) {
            let tr = await Translate(item[key][$llang], $llang, $langs);
            item[key][$langs] = tr;
            dialog_data = dialog_data;
          }
        }));
      }));
    } catch (ex) {
    }
  }
  if ($$props.ChangeQuizName === void 0 && $$bindings.ChangeQuizName && ChangeQuizName !== void 0) $$bindings.ChangeQuizName(ChangeQuizName);
  $$result.css.add(css$2);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (dialog_data && $llang) {
        try {
          const dlg_content = dialog_data.content.map((line) => {
            return JSON.stringify(line);
          });
          let dialog_data_words = dialog_data.words || "";
        } catch (ex) {
        }
      }
    }
    {
      if (dialog_data && $langs) {
        TranslateContentToCurrentLang();
      }
    }
    {
      if (dialog_data.content.length > 0 && prompt) {
        let content2 = JSON.parse(JSON.stringify(dialog_data.content));
        try {
          content2?.forEach((item) => {
            item["user1"] = item["user1"][$llang] ? item["user1"][$llang] : item["user1"];
            item["user2"] = item["user2"][$llang] ? item["user2"][$llang] : item["user2"];
          });
        } catch (ex) {
        }
        prompt = prompt.replaceAll("${dialog_content}", JSON.stringify(content2));
      }
    }
    $$rendered = `<main class="svelte-7i104c"><div class="container svelte-7i104c"><div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_name" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Title", "en", $langs))} <input type="text" class="dialog_name svelte-7i104c" name="dialog_name"${add_attribute("value", data.name[$llang], 0)}></div> ${data.level ? `<div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_level" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Level", "en", $langs))} <div class="dialog_level svelte-7i104c" name="dialog_level">${escape(data.level)}</div></div>` : ``} ${$llang ? `<div class="dialog-field svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_lang" class="svelte-7i104c">${escape(data2)}</label> `;
      }(__value);
    }(Translate("Language", "en", $langs))} <div type="text" class="dialog_lang svelte-7i104c" name="dialog_lang">${escape($llang)}</div></div>` : ``}</div> ${validate_component(Accordion, "Accordion").$$render(
      $$result,
      {
        style: "margin-top: 20px;margin-bottom: 20px;"
      },
      {},
      {
        default: () => {
          return `${validate_component(Panel, "Panel").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Header$1, "Header").$$render($$result, {}, {}, {
                default: () => {
                  return `<b class="svelte-7i104c">${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data2) {
                      return ` ${escape(data2)} `;
                    }(__value);
                  }(Translate("Content Builder", "en", $langs))}</b>`;
                }
              })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                default: () => {
                  return `<div class="collapsible svelte-7i104c"><div class="generator_container svelte-7i104c"> ${validate_component(TabBar, "TabBar").$$render(
                    $$result,
                    {
                      tabs: [
                        context_title,
                        grammar_title,
                        words_title,
                        prompt_title,
                        content_title
                      ],
                      active
                    },
                    {
                      active: ($$value) => {
                        active = $$value;
                        $$settled = false;
                      }
                    },
                    {
                      default: ({ tab }) => {
                        return `${validate_component(Tab, "Tab").$$render($$result, { tab, minWidth: true }, {}, {
                          default: () => {
                            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                              default: () => {
                                return `${escape(tab)}`;
                              }
                            })}`;
                          }
                        })}`;
                      }
                    }
                  )} ${active === context_title ? `${`${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_context" class="svelte-7i104c">${escape(dialog_data.html || "")}</textarea>`;
                        }
                      })}`;
                    }
                  })}`} <button class="paste_content svelte-7i104c" data-svelte-h="svelte-12l3g78">HTML</button>` : `${active === grammar_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_grammar" class="svelte-7i104c">${escape("")}</textarea>`;
                        }
                      })}`;
                    }
                  })}` : `${active === words_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<textarea rows="20" name="dialog_words" class="svelte-7i104c">${escape(dialog_data.words || "")}</textarea>`;
                        }
                      })}`;
                    }
                  })}` : `${active === prompt_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `<div class="${escape(null_to_empty(Object.keys(anchorClasses).join(" ")), true) + " svelte-7i104c"}"${add_attribute("this", anchor, 0)}>${validate_component(Button, "Button").$$render($$result, {}, {}, {
                            default: () => {
                              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                                default: () => {
                                  return `Выбрать промпт`;
                                }
                              })}`;
                            }
                          })} ${validate_component(Menu, "Menu").$$render(
                            $$result,
                            {
                              anchor: false,
                              anchorCorner: "BOTTOM_LEFT",
                              this: menu,
                              anchorElement: anchor
                            },
                            {
                              this: ($$value) => {
                                menu = $$value;
                                $$settled = false;
                              },
                              anchorElement: ($$value) => {
                                anchor = $$value;
                                $$settled = false;
                              }
                            },
                            {
                              default: () => {
                                return `${validate_component(List, "List").$$render($$result, {}, {}, {
                                  default: () => {
                                    return `${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `basic`;
                                          }
                                        })}`;
                                      }
                                    })} ${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `context`;
                                          }
                                        })}`;
                                      }
                                    })} ${validate_component(Item$1, "Item").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                                          default: () => {
                                            return `grammar`;
                                          }
                                        })}`;
                                      }
                                    })}`;
                                  }
                                })}`;
                              }
                            }
                          )}</div> <textarea rows="20" name="dialog_task" class="svelte-7i104c">${escape(prompt || "")}</textarea>  <button class="copy_prompt svelte-7i104c">${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${escape(data2)} `;
                            }(__value);
                          }(Translate("Copy", "en", $langs))}</button>`;
                        }
                      })}`;
                    }
                  })}` : `${active === content_title ? `${validate_component(Paper, "Paper").$$render($$result, { variant: "unelevated" }, {}, {
                    default: () => {
                      return `${validate_component(Content, "Content").$$render($$result, {}, {}, {
                        default: () => {
                          return `${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` <textarea id="dialog_content" rows="20" name="dialog_content"${add_attribute("placeholder", data2, 0)} class="svelte-7i104c">${escape("")}</textarea> `;
                            }(__value);
                          }(Translate("Use chatGPT to run the copied prompt and paste result here", "en", $langs))} <button class="paste_content svelte-7i104c">${function(__value) {
                            if (is_promise(__value)) {
                              __value.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` ${escape(data2)} `;
                            }(__value);
                          }(Translate("Paste Content", "en", $langs))}</button>`;
                        }
                      })}`;
                    }
                  })}` : ``}`}`}`}`}</div> <div class="container svelte-7i104c"><button class="save svelte-7i104c" disabled>${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data2) {
                      return ` ${escape(data2)} `;
                    }(__value);
                  }(Translate("Create content", "en", $langs))}</button></div></div>`;
                }
              })}`;
            }
          })}`;
        }
      }
    )} <table class="svelte-7i104c"><thead class="svelte-7i104c"><tr class="svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <th class="svelte-7i104c">${escape(data2)}</th>`;
      }(__value);
    }(Translate("User 1", "en", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <th class="svelte-7i104c">${escape(data2)}</th>`;
      }(__value);
    }(Translate("User 2", "en", $langs))}</tr></thead> <tbody class="svelte-7i104c">${dialog_data ? `${each(dialog_data.content, (item, index) => {
      return `<tr class="svelte-7i104c"><td class="svelte-7i104c">${item.user1 ? `<textarea rows="3" type="text" class="svelte-7i104c">${escape(item.user1[$langs] || "")}</textarea>` : `<textarea rows="3" type="text" class="svelte-7i104c"></textarea>`}</td> <td class="svelte-7i104c">${item.user2 ? `<textarea rows="3" type="text" class="svelte-7i104c">${escape(item.user2[$langs] || "")}</textarea>` : `<textarea rows="3" type="text" class="svelte-7i104c"></textarea>`}</td> <td class="svelte-7i104c"><button class="remrec_but svelte-7i104c"${add_attribute("index", index, 0)} data-svelte-h="svelte-1orru4d">-</button></td> </tr>`;
    })}` : ``}</tbody></table> <div class="container svelte-7i104c">${validate_component(IconButton, "IconButton").$$render($$result, { class: "material-icons add-record" }, {}, {
      default: () => {
        return `add`;
      }
    })} <div class="container svelte-7i104c">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="copy_content svelte-7i104c">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Copy data", "en", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="save_content svelte-7i104c">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Save", "en", $langs))}</div></div> </main>`;
  } while (!$$settled);
  $$unsubscribe_llang();
  $$unsubscribe_langs();
  return $$rendered;
});
const css$1 = {
  code: ".row.svelte-1u45lv4{display:flex;align-items:center;gap:20px}.word_container.svelte-1u45lv4{margin:10px}.content_generator.svelte-1u45lv4{height:40px;margin-top:25px;width:100%}.collapsible.svelte-1u45lv4{overflow:hidden;margin-top:1rem;margin-bottom:1rem;margin-left:1rem}.svelte-1u45lv4::selection{border:0;background-color:lightblue}table.svelte-1u45lv4{width:100%;border-collapse:collapse}th.svelte-1u45lv4{border:0px solid black;padding:8px;text-align:left}.col-1.svelte-1u45lv4{width:30%}.col-2.svelte-1u45lv4{width:30%}.col-3.svelte-1u45lv4{width:30%}.remrec_but.svelte-1u45lv4{scale:2;width:25px;border-radius:35px;border:0;background-color:transparent;color:blue}.word_field.svelte-1u45lv4{display:inline-block;box-sizing:border-box;margin-right:10px}.word_field.svelte-1u45lv4:first-child{width:calc(\r\n      100% - 20% - 10% - 5px\r\n    )}.word_field.svelte-1u45lv4:nth-last-child(-n + 2){width:calc(\r\n      20% - 20px\r\n    )}.save.svelte-1u45lv4{margin:10px}.copy.svelte-1u45lv4{margin:10px}textarea.svelte-1u45lv4{width:100%;resize:none}.add-record.svelte-1u45lv4{height:15px;border-radius:35px;border:0;scale:2;color:red}.dialog_name.svelte-1u45lv4,.dialog_lang.svelte-1u45lv4,.dialog_level.svelte-1u45lv4{border:0}.container.svelte-1u45lv4{display:flex;justify-content:space-between}.save_container.svelte-1u45lv4{display:flex;position:fixed;right:50px;bottom:10px;justify-content:space-between}.word_field.svelte-1u45lv4{display:flex;flex-direction:column;margin-right:20px}.word_field.svelte-1u45lv4:last-child{margin-right:0}",
  map: `{"version":3,"file":"WordEdit.svelte","sources":["WordEdit.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { getContext, onMount } from \\"svelte\\";\\nimport { SortableList } from \\"@jhubbardsf/svelte-sortablejs\\";\\nimport { Translate } from \\"../../../translate/Transloc\\";\\nimport { langs, llang } from \\"$lib/js/stores.js\\";\\nimport pkg, { indexOf } from \\"lodash\\";\\nconst { find, findKey, mapValues } = pkg;\\nimport Menu from \\"@smui/menu\\";\\nimport List, { Item, Separator, Text } from \\"@smui/list\\";\\nimport Tab, { Label } from \\"@smui/tab\\";\\nimport TabBar from \\"@smui/tab-bar\\";\\nimport Button from \\"@smui/button\\";\\nimport Paper, { Content } from \\"@smui/paper\\";\\nimport { Anchor } from \\"@smui/menu-surface\\";\\nlet menu, anchor;\\nlet anchorClasses = {};\\nlet active = \\"Prompt\\";\\nlet viewHTML = false;\\nimport { slide } from \\"svelte/transition\\";\\nlet isCollapsed = true;\\nfunction toggleCollapse() {\\n  isCollapsed.update((n) => !n);\\n}\\nexport let ChangeQuizName;\\nconst abonent = getContext(\\"abonent\\");\\nconst data = getContext(\\"quiz_data\\");\\nconsole.log(data);\\nlet content, new_content = false, words_data;\\nconst name = data?.name[$llang];\\nlet words = data?.module.themes[0].words || [], prompt, dialog_task, dialog_words, dialog_tmplt;\\nconst output = \`\\n  {original:'',infinitive:'',example:'',translation:{ [\${$langs}]: '',  en: '' }}\\n  \`;\\nlet system = \`\`, context = \\"\\";\\n$: if ($langs && prompt) {\\n  prompt = prompt.replaceAll(\\"\${output}\\", output);\\n  prompt = prompt.replaceAll(\\"\${llang}\\", $llang);\\n  prompt = prompt.replaceAll(\\"\${langs}\\", $langs);\\n  prompt = prompt.replaceAll(\\"\${topic}\\", data.theme.name[$llang] + \\".\\" + data.name[$llang]);\\n  prompt = prompt.replaceAll(\\"\${level}\\", \`\${data.level}.\${data.theme.id}(\${data.module.themes.length})\`);\\n  if (data.theme.grammar)\\n    prompt = prompt.replaceAll(\\"\${grammar}\\", JSON.stringify(data.theme.grammar));\\n  prompt = prompt;\\n}\\nlet grammar_title = \\"Grammar\\", context_title = \\"Context\\", prompt_title = \\"Prompt\\", words_title = \\"Words\\", content_title = \\"Content\\";\\n$: if (false) {\\n  (async () => {\\n    grammar_title = await Translate(\\"Grammar\\", \\"en\\", $langs);\\n    context_title = await Translate(\\"Context\\", \\"en\\", $langs);\\n    words_title = await Translate(\\"Words\\", \\"en\\", $langs);\\n    content_title = await Translate(\\"Content\\", \\"en\\", $langs);\\n  })();\\n}\\nLoadPrompt(\\"basic\\");\\nfetch(\`./lesson?words=theme&name=\${data.name[$llang]}&owner=\${abonent}&level=\${data.level}\`).then((response) => response.json()).then((data2) => {\\n  words_data = data2.data.data || [];\\n  context = data2.data.context;\\n}).catch((error) => {\\n  console.log(error);\\n  words_data = [];\\n});\\nonMount(() => {\\n});\\nfunction LoadPrompt(name2) {\\n  fetch(\`/admin?prompt=words.\${name2}\`).then((response) => response.json()).then((data2) => {\\n    prompt = data2.resp.prompt.system + data2.resp.prompt.user;\\n    prompt = prompt;\\n  }).catch((error) => {\\n    console.log(error);\\n  });\\n}\\nfunction addEmptyRecord() {\\n  const emptyRecord = {\\n    example: {\\n      nl: \\" \\",\\n      ru: \\" \\",\\n      en: \\" \\"\\n    }\\n  };\\n  words_data.push(emptyRecord);\\n  words_data = words_data;\\n}\\nfunction OnSave() {\\n  SaveData(name, data.name, words_data, data.level);\\n}\\nasync function SaveData(name2, new_name, data2, level) {\\n  const response = await fetch(\`/admin/module\`, {\\n    method: \\"POST\\",\\n    body: JSON.stringify({\\n      func: \\"upd_words\\",\\n      owner: abonent,\\n      level,\\n      name: name2[$llang],\\n      new_name: new_name[$llang],\\n      context,\\n      data: data2\\n    }),\\n    headers: { \\"Content-Type\\": \\"application/json\\" }\\n  });\\n  if (!response.ok) {\\n    throw new Error(\`HTTP error! Status: \${response.status}\`);\\n  }\\n}\\nasync function CreateContent() {\\n}\\nfunction OnChangeContent(content2) {\\n  try {\\n    words_data = JSON.parse(content2);\\n  } catch (ex) {\\n    console.log(ex);\\n  }\\n}\\nfunction CopyPrompt(ev) {\\n  ev.target.focus();\\n  const stringToCopy = prompt;\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u0421\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0430 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0430 \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        active = content_title;\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction PasteContent() {\\n  navigator.clipboard.readText().then((text) => {\\n    content = text;\\n    const parsed = JSON.parse(text);\\n    if (words_data) {\\n      words_data = words_data.concat(parsed);\\n    } else {\\n      words_data = parsed;\\n    }\\n  }).catch((err) => {\\n    console.error(\\"Failed to read clipboard contents: \\", err);\\n  });\\n}\\nfunction remRecord(ind) {\\n  words_data.splice(ind, 1);\\n  words_data = words_data;\\n}\\nfunction handleSort(event, items) {\\n  const { oldIndex, newIndex } = event;\\n  function arrayMove(arr, fromIndex, toIndex) {\\n    const element = arr.splice(fromIndex, 1)[0];\\n    arr.splice(toIndex, 0, element);\\n    return arr;\\n  }\\n  items = arrayMove(items, oldIndex, newIndex);\\n}\\nasync function findWordsInText(wordAr, word) {\\n  const sentences = context.match(/(?:\\\\d+\\\\.\\\\d+|[^.!?])+[.!?]/gu) || [];\\n  let result = [];\\n  for (const sentence of sentences) {\\n    for (const word2 of wordAr) {\\n      const regex = new RegExp(\`\\\\\\\\b(\${word2})\\\\\\\\b\`, \\"gi\\");\\n      if (sentence.match(regex)) {\\n        const sent = sentence.replace(regex, \\"<<$1>>\\");\\n        const translation = await Translate(sent, $llang, $langs);\\n        result.push({\\n          example: {\\n            [$llang]: sent,\\n            // Выделяем слово в предложении\\n            [$langs]: translation\\n            // Перевод\\n          }\\n        });\\n      }\\n    }\\n  }\\n  return result;\\n}\\nfunction OnWordsChange() {\\n  if (words)\\n    prompt = prompt.replaceAll(\\"\${words}\\", words);\\n}\\nfunction OnContextChange() {\\n}\\nasync function handleSelection(event) {\\n  const textArea = event.target;\\n  const text = textArea.value;\\n  let wordAr = [];\\n  const selectionStart = textArea.selectionStart;\\n  const selectionEnd = textArea.selectionEnd;\\n  const selectedText = text.substring(selectionStart, selectionEnd).trim();\\n  if (selectedText) {\\n    wordAr = [...wordAr, selectedText];\\n  }\\n  const res = await findWordsInText(wordAr, selectedText);\\n  words_data = words_data.concat(res);\\n}\\nfunction OnCopyContent() {\\n  const stringToCopy = JSON.stringify(words_data);\\n  navigator.permissions.query({ name: \\"clipboard-write\\" }).then((result) => {\\n    if (result.state == \\"granted\\" || result.state == \\"prompt\\") {\\n      navigator.clipboard.writeText(stringToCopy).then(() => {\\n        console.log(\\"\\\\u041A\\\\u043E\\\\u043D\\\\u0442\\\\u0435\\\\u043D\\\\u0442 \\\\u0441\\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D \\\\u0432 \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430\\");\\n        content = \\"\\";\\n      }).catch((err) => {\\n        console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043A\\\\u043E\\\\u043F\\\\u0438\\\\u0440\\\\u043E\\\\u0432\\\\u0430\\\\u043D\\\\u0438\\\\u0438 \\\\u0441\\\\u0442\\\\u0440\\\\u043E\\\\u043A\\\\u0438: \\", err);\\n      });\\n    } else {\\n      console.error(\\"\\\\u0414\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F \\\\u043A \\\\u0431\\\\u0443\\\\u0444\\\\u0435\\\\u0440\\\\u0443 \\\\u043E\\\\u0431\\\\u043C\\\\u0435\\\\u043D\\\\u0430 \\\\u043D\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0435\\\\u0448\\\\u0435\\\\u043D.\\");\\n    }\\n  });\\n}\\nfunction OnReplaceContent() {\\n  words_data = \\"\\";\\n  PasteContent();\\n}\\n<\/script>\\r\\n\\r\\n<div class=\\"word_container\\">\\r\\n  <div class=\\"container\\">\\r\\n    <div class=\\"word_field\\">\\r\\n      {#await Translate('Название', 'ru', $langs) then data}\\r\\n        <label for=\\"dialog_name\\">{data}:</label>\\r\\n      {/await}\\r\\n      <input\\r\\n        type=\\"text\\"\\r\\n        class=\\"dialog_name\\"\\r\\n        name=\\"dialog_name\\"\\r\\n        bind:value={data.name[$llang]}\\r\\n      />\\r\\n    </div>\\r\\n    {#if data.level}\\r\\n      <div class=\\"word_field\\">\\r\\n        {#await Translate('Уровень', 'ru', $langs) then data}\\r\\n          <label for=\\"dialog_level\\">{data}:</label>\\r\\n        {/await}\\r\\n        <input\\r\\n          type=\\"text\\"\\r\\n          class=\\"dialog_level\\"\\r\\n          name=\\"dialog_level\\"\\r\\n          bind:value={data.level}\\r\\n        />\\r\\n      </div>\\r\\n    {/if}\\r\\n\\r\\n    {#if $llang}\\r\\n      <div class=\\"word_field\\">\\r\\n        {#await Translate('Язык', 'ru', $langs) then data}\\r\\n          <label for=\\"dialog_lang\\">{data}:</label>\\r\\n        {/await}\\r\\n        <input\\r\\n          type=\\"text\\"\\r\\n          class=\\"dialog_lang\\"\\r\\n          name=\\"dialog_lang\\"\\r\\n          bind:value={$llang}\\r\\n        />\\r\\n      </div>\\r\\n    {/if}\\r\\n  </div>\\r\\n\\r\\n  {#await Translate('Контент-генератор', 'ru', $langs) then data}\\r\\n    <button\\r\\n      class=\\"content_generator\\"\\r\\n      on:click={() => (isCollapsed = !isCollapsed)}\\r\\n    >\\r\\n      {data}\\r\\n    </button>\\r\\n  {/await}\\r\\n\\r\\n  {#if !isCollapsed}\\r\\n    <div class=\\"collapsible\\" in:slide={{ duration: 300 }}>\\r\\n      <div class=\\"generator_container\\">\\r\\n        <TabBar\\r\\n          tabs={[context_title, words_title, prompt_title, content_title]}\\r\\n          let:tab\\r\\n          bind:active\\r\\n        >\\r\\n          <Tab {tab} minWidth>\\r\\n            <Label>{tab}</Label>\\r\\n          </Tab>\\r\\n        </TabBar>\\r\\n        {#if active === context_title}\\r\\n        {#if viewHTML}\\r\\n        <!-- <div style=\\"height: 350px; overflow-y:auto\\">\\r\\n          {@html dialog_data.html}\\r\\n        </div> -->\\r\\n        <iframe srcdoc={context} width=\\"100%\\" height=\\"350px\\"\\r\\n        ></iframe>\\r\\n        {:else}\\r\\n          <Paper variant=\\"unelevated\\">\\r\\n            <Content>\\r\\n              <textarea\\r\\n                style=\\"font-size: large;\\"\\r\\n                on:select|preventDefault|stopPropagation={handleSelection}\\r\\n                rows=\\"20\\"\\r\\n                name=\\"dialog_context\\"\\r\\n                bind:value={context}\\r\\n                on:change={OnContextChange}\\r\\n              ></textarea>\\r\\n            </Content>\\r\\n          </Paper>\\r\\n          {/if}\\r\\n          <button\\r\\n          class=\\"paste_content\\"\\r\\n          on:click={() => {\\r\\n            viewHTML = !viewHTML;\\r\\n          }}>HTML</button>\\r\\n        {:else if active === 'Words'}\\r\\n          <Paper variant=\\"unelevated\\">\\r\\n            <Content>\\r\\n              <textarea\\r\\n                rows=\\"20\\"\\r\\n                name=\\"dialog_words\\"\\r\\n                bind:value={words}\\r\\n                on:change={OnWordsChange}\\r\\n              ></textarea>\\r\\n            </Content>\\r\\n          </Paper>\\r\\n        {:else if active === 'Prompt'}\\r\\n          <Paper variant=\\"unelevated\\">\\r\\n            <Content>\\r\\n              <div\\r\\n                class={Object.keys(anchorClasses).join(' ')}\\r\\n                use:Anchor={{\\r\\n                  addClass: (className) => {\\r\\n                    if (!anchorClasses[className]) {\\r\\n                      anchorClasses[className] = true;\\r\\n                    }\\r\\n                  },\\r\\n                  removeClass: (className) => {\\r\\n                    if (anchorClasses[className]) {\\r\\n                      delete anchorClasses[className];\\r\\n                      anchorClasses = anchorClasses;\\r\\n                    }\\r\\n                  },\\r\\n                }}\\r\\n                bind:this={anchor}\\r\\n              >\\r\\n                <Button on:click={() => menu.setOpen(true)}>\\r\\n                  <Label>Выбрать промпт</Label>\\r\\n                </Button>\\r\\n                <Menu\\r\\n                  bind:this={menu}\\r\\n                  anchor={false}\\r\\n                  bind:anchorElement={anchor}\\r\\n                  anchorCorner=\\"BOTTOM_LEFT\\"\\r\\n                >\\r\\n                  <List>\\r\\n                    <Item on:click={() => LoadPrompt('basic')}>\\r\\n                      <Text>basic</Text>\\r\\n                    </Item>\\r\\n                    <Item on:click={() => LoadPrompt('context')}>\\r\\n                      <Text>context</Text>\\r\\n                    </Item>\\r\\n                  </List>\\r\\n                </Menu>\\r\\n              </div>\\r\\n              <textarea rows=\\"20\\" name=\\"dialog_task\\" bind:value={prompt}\\r\\n              ></textarea>\\r\\n              {#await Translate('Копировать промпт', 'ru', $langs) then data}\\r\\n                <button class=\\"copy_prompt\\" on:click={CopyPrompt}>{data}</button\\r\\n                >\\r\\n              {/await}\\r\\n            </Content>\\r\\n          </Paper>\\r\\n        {:else if active === 'Content'}\\r\\n          <Paper variant=\\"unelevated\\">\\r\\n            <Content>\\r\\n              {#await Translate('Use chatGPT to run copied prompt and paste result here', 'en', $langs) then data}\\r\\n                <textarea\\r\\n                  id=\\"dialog_content\\"\\r\\n                  rows=\\"20\\"\\r\\n                  name=\\"dialog_content\\"\\r\\n                  placeholder={data}\\r\\n                  on:input={OnChangeContent}\\r\\n                  bind:value={content}\\r\\n                ></textarea>\\r\\n              {/await}\\r\\n              <button\\r\\n                class=\\"paste_content\\"\\r\\n                on:click={() => {\\r\\n                  PasteContent();\\r\\n                }}\\r\\n              >\\r\\n                {#await Translate('Paste Content', 'en', $langs) then data}\\r\\n                  {data}\\r\\n                {/await}\\r\\n              </button>\\r\\n            </Content>\\r\\n          </Paper>\\r\\n        {/if}\\r\\n      </div>\\r\\n\\r\\n      <div class=\\"container\\">\\r\\n        {#await Translate('Создать', 'ru', $langs) then data}\\r\\n          <button class=\\"save\\" on:click={() => CreateContent()} disabled\\r\\n            >{data}</button\\r\\n          >\\r\\n        {/await}\\r\\n      </div>\\r\\n    </div>\\r\\n  {/if}\\r\\n  <br /><br />\\r\\n\\r\\n  <table>\\r\\n    <thead>\\r\\n      <tr>\\r\\n        <th class=\\"col-1\\">{$llang}</th>\\r\\n        <th class=\\"col-2\\">{$langs}</th>\\r\\n      </tr>\\r\\n    </thead>\\r\\n  </table>\\r\\n\\r\\n  {#if words_data && words_data[0]}\\r\\n    <SortableList\\r\\n      onSort={(ev) => {\\r\\n        handleSort(ev, words_data);\\r\\n      }}\\r\\n    >\\r\\n      {#each words_data as item, index (index)}\\r\\n        <!-- {@debug item} -->\\r\\n        <div class=\\"row\\">\\r\\n          <textarea rows=\\"2\\" bind:value={item.example[$llang]} />\\r\\n          {#if item.example[$llang] != item.example[$langs]}\\r\\n            <textarea rows=\\"2\\" bind:value={item.example[$langs]} />\\r\\n          {/if}\\r\\n          <button class=\\"remrec_but\\" on:click={remRecord(index)} {index}\\r\\n            >-</button\\r\\n          >\\r\\n          <br />\\r\\n        </div>\\r\\n      {/each}\\r\\n    </SortableList>\\r\\n  {/if}\\r\\n\\r\\n  <div class=\\"container\\">\\r\\n    <button class=\\"add-record\\" on:click={addEmptyRecord}>+</button>\\r\\n    <div class=\\"save_container\\">\\r\\n      {#await Translate('Копировать контент', 'ru', $langs) then data}\\r\\n        <button class=\\"copy\\" on:click={() => OnCopyContent()}>{data}</button>\\r\\n      {/await}\\r\\n      {#await Translate('Заменить контент', 'ru', $langs) then data}\\r\\n        <button class=\\"copy\\" on:click={() => OnReplaceContent()}>{data}</button>\\r\\n      {/await}\\r\\n      {#await Translate('Сохранить', 'ru', $langs) then data}\\r\\n        <button class=\\"save\\" on:click={() => OnSave()}>{data}</button>\\r\\n      {/await}\\r\\n    </div>\\r\\n  </div>\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n  .row {\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n    gap: 20px; /* Задайте нужное расстояние между элементами */\\r\\n  }\\r\\n  .word_container {\\r\\n    margin: 10px;\\r\\n  }\\r\\n  .content_generator {\\r\\n    height: 40px;\\r\\n    margin-top: 25px;\\r\\n    width: 100%;\\r\\n  }\\r\\n  .collapsible {\\r\\n    overflow: hidden;\\r\\n    margin-top: 1rem;\\r\\n    margin-bottom: 1rem;\\r\\n    margin-left: 1rem;\\r\\n  }\\r\\n  ::selection {\\r\\n    border: 0;\\r\\n    background-color: lightblue;\\r\\n  }\\r\\n\\r\\n  table {\\r\\n    width: 100%;\\r\\n    border-collapse: collapse;\\r\\n  }\\r\\n  th,\\r\\n  td {\\r\\n    border: 0px solid black;\\r\\n    padding: 8px;\\r\\n    text-align: left;\\r\\n  }\\r\\n  .col-1 {\\r\\n    width: 30%;\\r\\n  }\\r\\n  .col-2 {\\r\\n    width: 30%;\\r\\n  }\\r\\n  .col-3 {\\r\\n    width: 30%;\\r\\n  }\\r\\n\\r\\n  .remrec_but {\\r\\n    scale: 2;\\r\\n    width: 25px;\\r\\n    border-radius: 35px;\\r\\n    border: 0;\\r\\n    background-color: transparent;\\r\\n    color: blue;\\r\\n  }\\r\\n\\r\\n  .word_field {\\r\\n    display: inline-block;\\r\\n    box-sizing: border-box; /* Учтите ширину и отступы внутри элемента */\\r\\n    margin-right: 10px; /* Установите нужный вам отступ между полями */\\r\\n  }\\r\\n\\r\\n  .word_field:first-child {\\r\\n    width: calc(\\r\\n      100% - 20% - 10% - 5px\\r\\n    ); /* 20px - это сумма отступов между полями */\\r\\n  }\\r\\n\\r\\n  .word_field:nth-last-child(-n + 2) {\\r\\n    width: calc(\\r\\n      20% - 20px\\r\\n    ); /* 5px - это примерный отступ между последними двумя полями */\\r\\n  }\\r\\n\\r\\n  /* Для последнего word_field может потребоваться сброс правого отступа */\\r\\n\\r\\n  .save {\\r\\n    margin: 10px; /* Отступ для кнопки 'Создать' */\\r\\n  }\\r\\n\\r\\n  \\r\\n  .copy {\\r\\n    margin: 10px; /* Отступ для кнопки 'Создать' */\\r\\n  }\\r\\n\\r\\n  textarea {\\r\\n    width: 100%;\\r\\n    resize: none;\\r\\n  }\\r\\n\\r\\n  .add-record {\\r\\n    height: 15px;\\r\\n    border-radius: 35px;\\r\\n    border: 0;\\r\\n    scale: 2;\\r\\n    color: red;\\r\\n  }\\r\\n  .dialog_name,\\r\\n  .dialog_lang,\\r\\n  .dialog_level {\\r\\n    border: 0;\\r\\n  }\\r\\n  .container {\\r\\n    display: flex;\\r\\n    justify-content: space-between; /* Распределяет контейнеры равномерно по горизонтали */\\r\\n  }\\r\\n\\r\\n  .save_container {\\r\\n    display: flex;\\r\\n    position: fixed;\\r\\n    right:50px;\\r\\n    bottom:10px;\\r\\n    justify-content: space-between; /* Распределяет контейнеры равномерно по горизонтали */\\r\\n  }\\r\\n\\r\\n  .word_field {\\r\\n    display: flex;\\r\\n    flex-direction: column; /* Устанавливает вертикальное направление потока */\\r\\n    margin-right: 20px; /* Добавляет небольшой отступ справа для каждого поля, кроме последнего */\\r\\n  }\\r\\n\\r\\n  .word_field:last-child {\\r\\n    margin-right: 0; /* Убирает отступ справа у последнего поля */\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAkcE,mBAAK,CACH,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,GAAG,CAAE,IACP,CACA,8BAAgB,CACd,MAAM,CAAE,IACV,CACA,iCAAmB,CACjB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACT,CACA,2BAAa,CACX,QAAQ,CAAE,MAAM,CAChB,UAAU,CAAE,IAAI,CAChB,aAAa,CAAE,IAAI,CACnB,WAAW,CAAE,IACf,gBACA,WAAY,CACV,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,SACpB,CAEA,oBAAM,CACJ,KAAK,CAAE,IAAI,CACX,eAAe,CAAE,QACnB,CACA,iBACG,CACD,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,CACvB,OAAO,CAAE,GAAG,CACZ,UAAU,CAAE,IACd,CACA,qBAAO,CACL,KAAK,CAAE,GACT,CACA,qBAAO,CACL,KAAK,CAAE,GACT,CACA,qBAAO,CACL,KAAK,CAAE,GACT,CAEA,0BAAY,CACV,KAAK,CAAE,CAAC,CACR,KAAK,CAAE,IAAI,CACX,aAAa,CAAE,IAAI,CACnB,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,WAAW,CAC7B,KAAK,CAAE,IACT,CAEA,0BAAY,CACV,OAAO,CAAE,YAAY,CACrB,UAAU,CAAE,UAAU,CACtB,YAAY,CAAE,IAChB,CAEA,0BAAW,YAAa,CACtB,KAAK,CAAE;AACX,MAAM,IAAI,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,GAAG;AAC5B,KACE,CAEA,0BAAW,gBAAgB,MAAM,CAAE,CACjC,KAAK,CAAE;AACX,MAAM,GAAG,CAAC,CAAC,CAAC,IAAI;AAChB,KACE,CAIA,oBAAM,CACJ,MAAM,CAAE,IACV,CAGA,oBAAM,CACJ,MAAM,CAAE,IACV,CAEA,uBAAS,CACP,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IACV,CAEA,0BAAY,CACV,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,IAAI,CACnB,MAAM,CAAE,CAAC,CACT,KAAK,CAAE,CAAC,CACR,KAAK,CAAE,GACT,CACA,2BAAY,CACZ,2BAAY,CACZ,4BAAc,CACZ,MAAM,CAAE,CACV,CACA,yBAAW,CACT,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aACnB,CAEA,8BAAgB,CACd,OAAO,CAAE,IAAI,CACb,QAAQ,CAAE,KAAK,CACf,MAAM,IAAI,CACV,OAAO,IAAI,CACX,eAAe,CAAE,aACnB,CAEA,0BAAY,CACV,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,YAAY,CAAE,IAChB,CAEA,0BAAW,WAAY,CACrB,YAAY,CAAE,CAChB"}`
};
function handleSort$1(event, items) {
  const { oldIndex, newIndex } = event;
  function arrayMove(arr, fromIndex, toIndex) {
    const element = arr.splice(fromIndex, 1)[0];
    arr.splice(toIndex, 0, element);
    return arr;
  }
  items = arrayMove(items, oldIndex, newIndex);
}
const WordEdit = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $llang, $$unsubscribe_llang;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  const { find, findKey, mapValues } = pkg;
  let { ChangeQuizName } = $$props;
  const abonent = getContext("abonent");
  const data = getContext("quiz_data");
  console.log(data);
  let words_data;
  data?.name[$llang];
  data?.module.themes[0].words || [];
  let prompt;
  const output = `
  {original:'',infinitive:'',example:'',translation:{ [${$langs}]: '',  en: '' }}
  `;
  LoadPrompt("basic");
  fetch(`./lesson?words=theme&name=${data.name[$llang]}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then((data2) => {
    words_data = data2.data.data || [];
    data2.data.context;
  }).catch((error) => {
    console.log(error);
    words_data = [];
  });
  function LoadPrompt(name2) {
    fetch(`/admin?prompt=words.${name2}`).then((response) => response.json()).then((data2) => {
      prompt = data2.resp.prompt.system + data2.resp.prompt.user;
      prompt = prompt;
    }).catch((error) => {
      console.log(error);
    });
  }
  if ($$props.ChangeQuizName === void 0 && $$bindings.ChangeQuizName && ChangeQuizName !== void 0) $$bindings.ChangeQuizName(ChangeQuizName);
  $$result.css.add(css$1);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($langs && prompt) {
        prompt = prompt.replaceAll("${output}", output);
        prompt = prompt.replaceAll("${llang}", $llang);
        prompt = prompt.replaceAll("${langs}", $langs);
        prompt = prompt.replaceAll("${topic}", data.theme.name[$llang] + "." + data.name[$llang]);
        prompt = prompt.replaceAll("${level}", `${data.level}.${data.theme.id}(${data.module.themes.length})`);
        if (data.theme.grammar) prompt = prompt.replaceAll("${grammar}", JSON.stringify(data.theme.grammar));
        prompt = prompt;
      }
    }
    $$rendered = `<div class="word_container svelte-1u45lv4"><div class="container svelte-1u45lv4"><div class="word_field svelte-1u45lv4">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_name" class="svelte-1u45lv4">${escape(data2)}:</label> `;
      }(__value);
    }(Translate("Название", "ru", $langs))} <input type="text" class="dialog_name svelte-1u45lv4" name="dialog_name"${add_attribute("value", data.name[$llang], 0)}></div> ${data.level ? `<div class="word_field svelte-1u45lv4">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_level" class="svelte-1u45lv4">${escape(data2)}:</label> `;
      }(__value);
    }(Translate("Уровень", "ru", $langs))} <input type="text" class="dialog_level svelte-1u45lv4" name="dialog_level"${add_attribute("value", data.level, 0)}></div>` : ``} ${$llang ? `<div class="word_field svelte-1u45lv4">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <label for="dialog_lang" class="svelte-1u45lv4">${escape(data2)}:</label> `;
      }(__value);
    }(Translate("Язык", "ru", $langs))} <input type="text" class="dialog_lang svelte-1u45lv4" name="dialog_lang"${add_attribute("value", $llang, 0)}></div>` : ``}</div> ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="content_generator svelte-1u45lv4">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Контент-генератор", "ru", $langs))} ${``} <br class="svelte-1u45lv4"><br class="svelte-1u45lv4"> <table class="svelte-1u45lv4"><thead class="svelte-1u45lv4"><tr class="svelte-1u45lv4"><th class="col-1 svelte-1u45lv4">${escape($llang)}</th> <th class="col-2 svelte-1u45lv4">${escape($langs)}</th></tr></thead></table> ${words_data && words_data[0] ? `${validate_component(SortableList, "SortableList").$$render(
      $$result,
      {
        onSort: (ev) => {
          handleSort$1(ev, words_data);
        }
      },
      {},
      {
        default: () => {
          return `${each(words_data, (item, index) => {
            return ` <div class="row svelte-1u45lv4"><textarea rows="2" class="svelte-1u45lv4">${escape(item.example[$llang] || "")}</textarea> ${item.example[$llang] != item.example[$langs] ? `<textarea rows="2" class="svelte-1u45lv4">${escape(item.example[$langs] || "")}</textarea>` : ``} <button class="remrec_but svelte-1u45lv4"${add_attribute("index", index, 0)}>-</button> <br class="svelte-1u45lv4"> </div>`;
          })}`;
        }
      }
    )}` : ``} <div class="container svelte-1u45lv4"><button class="add-record svelte-1u45lv4" data-svelte-h="svelte-78bago">+</button> <div class="save_container svelte-1u45lv4">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="copy svelte-1u45lv4">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Копировать контент", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="copy svelte-1u45lv4">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Заменить контент", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <button class="save svelte-1u45lv4">${escape(data2)}</button> `;
      }(__value);
    }(Translate("Сохранить", "ru", $langs))}</div></div> </div>`;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_llang();
  return $$rendered;
});
const WordGameEdit = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return ``;
});
const Quiz = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dc_state, $$unsubscribe_dc_state;
  let $call_but_status, $$unsubscribe_call_but_status;
  $$unsubscribe_dc_state = subscribe(dc_state, (value) => $dc_state = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  let { data } = $$props;
  let { ChangeQuizName } = $$props;
  setContext("quiz_data", data);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.ChangeQuizName === void 0 && $$bindings.ChangeQuizName && ChangeQuizName !== void 0) $$bindings.ChangeQuizName(ChangeQuizName);
  $$unsubscribe_dc_state();
  $$unsubscribe_call_but_status();
  return ` ${data.quiz ? `${data.quiz.includes("dialog") ? `${validate_component(DialogEdit, "DialogEdit").$$render($$result, { ChangeQuizName }, {}, {})}` : `${data.quiz.includes("bricks") ? `${validate_component(BricksEdit, "BricksEdit").$$render($$result, { data }, {}, {})}` : `${data.quiz === "word" ? `${$dc_state === "open" && $call_but_status === "talk" ? `${validate_component(WordGameEdit, "WordGameEdit").$$render($$result, { data }, {}, {})}` : `${validate_component(WordEdit, "WordEdit").$$render($$result, {}, {}, {})}`}` : ``}`}`}` : ``}`;
});
const css = {
  code: "main.svelte-z3kqxi.svelte-z3kqxi{margin-top:40px}.level_container.svelte-z3kqxi.svelte-z3kqxi{display:flex;justify-content:space-between;width:95%}.quiz_name.svelte-z3kqxi.svelte-z3kqxi{width:80%;margin-right:10px}.save.svelte-z3kqxi.svelte-z3kqxi{position:sticky;top:30px;margin:15px}.lesson-container.svelte-z3kqxi.svelte-z3kqxi{height:90vh;overflow-y:auto;overflow-x:hidden;max-width:100%;padding-top:10px;scrollbar-width:none;-ms-overflow-style:none}.quiz-container.svelte-z3kqxi.svelte-z3kqxi{display:flex;justify-content:space-between;align-items:center;padding:0px}.add_quiz.svelte-z3kqxi.svelte-z3kqxi,.add_theme.svelte-z3kqxi.svelte-z3kqxi,.add_module.svelte-z3kqxi.svelte-z3kqxi,.rem_quiz.svelte-z3kqxi.svelte-z3kqxi,.rem_theme.svelte-z3kqxi.svelte-z3kqxi,.rem_module.svelte-z3kqxi.svelte-z3kqxi{display:inline-flex;position:relative;background-color:aliceblue;border-radius:24px;width:24px;height:24px;scale:1.2}div.svelte-z3kqxi>.rem_quiz.svelte-z3kqxi,div.svelte-z3kqxi>.rem_theme.svelte-z3kqxi,div.svelte-z3kqxi>.rem_module.svelte-z3kqxi{display:flex;align-items:center}.rem_theme.svelte-z3kqxi.svelte-z3kqxi{position:absolute;right:0;top:5px}.add_theme.svelte-z3kqxi.svelte-z3kqxi{position:relative;top:10px}select.svelte-z3kqxi.svelte-z3kqxi{height:25px}input.svelte-z3kqxi.svelte-z3kqxi{border:0}.svelte-z3kqxi.svelte-z3kqxi::-moz-selection{background-color:grey;outline:none}.svelte-z3kqxi.svelte-z3kqxi::selection{background-color:lightblue;outline:none}.svelte-z3kqxi.svelte-z3kqxi::placeholder{font-weight:400}div.svelte-z3kqxi.svelte-z3kqxi:focus,input.svelte-z3kqxi.svelte-z3kqxi:focus{outline:none}select.svelte-z3kqxi.svelte-z3kqxi{border:0;background-color:lightgray}option.svelte-z3kqxi.svelte-z3kqxi{font-size:larger}",
  map: `{"version":3,"file":"ModuleEditor.svelte","sources":["ModuleEditor.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { setContext, onMount, onDestroy } from \\"svelte\\";\\nimport { Translate } from \\"../../translate/Transloc\\";\\nimport pkg, { indexOf } from \\"lodash\\";\\nconst { find, isObject, mapValues } = pkg;\\nimport Checkbox from \\"@smui/checkbox\\";\\nimport { SortableList } from \\"@jhubbardsf/svelte-sortablejs\\";\\nimport List, { Item, Separator, Text } from \\"@smui/list\\";\\nimport Button, { Label } from \\"@smui/button\\";\\nimport Menu from \\"@smui/menu\\";\\nimport Textfield from \\"@smui/textfield\\";\\nimport HelperText from \\"@smui/textfield/helper-text\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport Card, { PrimaryAction, Media, MediaContent } from \\"@smui/card\\";\\nimport { mdiAccountMultiple, mdiTextBoxOutline, mdiCardTextOutline, mdiEarHearing, mdiFileWordBoxOutline, mdiHelp } from \\"@mdi/js\\";\\nimport Accordion, { Panel, Header, Content } from \\"@smui-extra/accordion\\";\\nimport { langs, llang, dicts } from \\"$lib/js/stores.js\\";\\nimport Quiz from \\"../quiz/Quiz.svelte\\";\\nlet value = \\"dialog\\";\\nimport { view } from \\"$lib/js/stores.js\\";\\nlet menu;\\nlet disabled = [\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true\\n];\\nexport let abonent;\\nsetContext(\\"abonent\\", abonent);\\nlet llang_input;\\nlet theme_sort_list, quiz_sort_list, items;\\nlet lesson_data = { data: { level: \\"\\" } };\\nlet levels = [];\\nlet module_input;\\nconst quizes = [\\"\\\\u0432\\\\u044B\\\\u0431\\\\u0435\\\\u0440\\\\u0438 quiz...\\", \\"dialog\\", \\"word\\", \\"bricks\\"];\\nlet containerWidth = \\"100%\\";\\nlet containerHeight = \\"100vh\\";\\nexport async function fetchLesson(owner, level2) {\\n  try {\\n    let lev_str = level2 ? \\"&level=\\" + level2 : \\"\\";\\n    const response = await fetch(\`./lesson?lesson=\${abonent}&owner=\${abonent}\` + lev_str);\\n    if (!response.ok) {\\n      throw new Error(\\"Failed to fetch data\\");\\n    }\\n    const resp = await response.json();\\n    $llang = resp.lang;\\n    return resp;\\n  } catch (error) {\\n    return [];\\n  }\\n}\\nonMount(async () => {\\n  const parentWidth = window.innerWidth;\\n  containerWidth = parentWidth + \\"px\\";\\n  const parentHeight = window.innerHeight;\\n  containerHeight = parentHeight + \\"px\\";\\n  lesson_data = await fetchLesson(abonent, \\"\\");\\n});\\n$: if (lesson_data.data) {\\n  levels = lesson_data.levels;\\n}\\nonDestroy(() => {\\n});\\nasync function saveLessonData() {\\n  try {\\n    if (!lesson_data.level) {\\n      module_input.focus();\\n      return;\\n    }\\n    const updatedLessonData = {\\n      ...lesson_data,\\n      // Create a copy of the original lesson_data\\n      data: JSON.stringify(lesson_data.data)\\n      // Stringify the updated data\\n    };\\n    const response = await fetch(\`/admin\`, {\\n      method: \\"POST\\",\\n      body: JSON.stringify({\\n        func: \\"upd_lesson\\",\\n        lang: $llang,\\n        level: updatedLessonData.level,\\n        levels,\\n        data: updatedLessonData.data,\\n        owner: abonent\\n      }),\\n      headers: { \\"Content-Type\\": \\"application/json\\" }\\n    });\\n    if (!response.ok) {\\n      throw new Error(\\"Failed to fetch data\\");\\n    }\\n    const data = await response.json();\\n  } catch (error) {\\n    console.error(error);\\n    return [];\\n  }\\n}\\nfunction onClickQuiz(quiz, level2, theme) {\\n  $view = \\"quiz\\";\\n  lesson_data.data.llang = lesson_data.data.lang;\\n  lesson_data.data.name = quiz.name;\\n  lesson_data.data.theme = theme;\\n  lesson_data.data.quiz = quiz.type;\\n}\\nfunction disablePanel(node) {\\n  try {\\n    let t = node.attributes[\\"t\\"].value;\\n    disabled[parseInt(t)] = false;\\n  } catch (ex) {\\n  }\\n}\\nexport function findDeep(obj, predicate, path = \\"\\") {\\n  if (predicate(obj, path)) {\\n    return obj;\\n  }\\n  if (isObject(obj)) {\\n    for (let key in obj) {\\n      if (obj.hasOwnProperty(key)) {\\n        let found = findDeep(obj[key], predicate, \`\${path}.\${key}\`);\\n        if (found) {\\n          return found;\\n        }\\n      }\\n    }\\n  }\\n  return null;\\n}\\nfunction OnAddTheme() {\\n  navigator.clipboard.readText().then((text) => {\\n    const quiz_data = JSON.parse(text);\\n    pushTheme(quiz_data);\\n  }).catch((err) => {\\n    pushTheme({ theme: { name: \\"\\" } });\\n  });\\n  function pushTheme(quiz_data) {\\n    lesson_data.data.module.themes.push({\\n      name: {\\n        [$llang]: quiz_data.theme.name\\n      },\\n      words: quiz_data.words instanceof String ? quiz_data.words.split(\\", \\") : quiz_data.words,\\n      grammar: quiz_data.grammar instanceof String ? quiz_data.grammar.split(\\", \\") : quiz_data.grammar,\\n      lessons: [{ quizes: [] }]\\n    });\\n    lesson_data = lesson_data;\\n  }\\n}\\nfunction OnRemoveThemeItem(t) {\\n  lesson_data.data.module.themes.splice(t, 1);\\n  lesson_data = lesson_data;\\n}\\nfunction OnRemoveItem(name, t) {\\n  let ind = lesson_data.data.module.themes[t].lessons[0].quizes.findIndex((q) => {\\n    return q.name[$llang] === name;\\n  });\\n  lesson_data.data.module.themes[t].lessons[0].quizes.splice(ind, 1);\\n  lesson_data = lesson_data;\\n}\\nasync function OnAddQuiz(name, t) {\\n  lesson_data.data.module.themes[t].lessons[0].quizes.push({\\n    type: \\"quiz\\",\\n    name: { [$llang]: \\"\\" }\\n  });\\n  lesson_data = lesson_data;\\n}\\nfunction OnSelectQuiztype(type, t, name) {\\n  const item = find(lesson_data.data.module.themes[t].lessons[0].quizes, (quiz) => {\\n    if (quiz.name[$llang] === name)\\n      return quiz;\\n  });\\n  if (item) {\\n    item.type = type;\\n  }\\n  lesson_data = lesson_data;\\n}\\nfunction ChangeQuizName(name, new_name) {\\n  let item = findDeep(lesson_data.data.module, (value2) => value2.name === name, {\\n    childrenPath: \\"quizes\\"\\n  });\\n  if (item) {\\n    item.name = new_name;\\n  }\\n  lesson_data = lesson_data;\\n}\\nfunction OnChangeQuizName(ev) {\\n}\\nasync function ChangeLevel(ev) {\\n  lesson_data.data.module.level = ev.target.attributes[\\"level\\"].nodeValue;\\n  lesson_data = await fetchLesson(abonent, lesson_data.data.module.level);\\n  menu.setOpen(false);\\n}\\nlet level = \\"\\";\\nasync function OnInput(ev) {\\n  lesson_data.level = ev.target.value;\\n  module = {\\n    level: lesson_data.data.module.level,\\n    themes: []\\n  };\\n  levels.map(async (item) => {\\n    if (item !== lesson_data.data.module.level) {\\n      lesson_data.data.module.themes = [];\\n    } else {\\n    }\\n  });\\n}\\nfunction OnClickQuizName(ev) {\\n}\\nfunction OnAddModule(ev) {\\n  menu.getElement().attributes.style.nodeValue = \\"display:none\\";\\n  lesson_data.level = \\"\\";\\n  lesson_data.data.module.themes = [];\\n  module_input.focus();\\n}\\nasync function OnRemModule(ev) {\\n  const rem_level = lesson_data.data.module.level;\\n  const ind = lesson_data.levels.indexOf(rem_level);\\n  lesson_data.levels.splice(ind, 1);\\n  lesson_data = lesson_data;\\n  lesson_data.data = await fetchLesson(abonent, lesson_data.data.module.level)[\\"data\\"];\\n  lesson_data.data.module.level = lesson_data.levels[0];\\n}\\nfunction handleSort(event, items2) {\\n  const { oldIndex, newIndex } = event;\\n  function arrayMove(arr, fromIndex, toIndex) {\\n    const element = arr.splice(fromIndex, 1)[0];\\n    arr.splice(toIndex, 0, element);\\n    return arr;\\n  }\\n  items2 = arrayMove(items2, oldIndex, newIndex);\\n}\\nfunction OnPublish(quiz, state) {\\n  quiz.published = state ? \\"\\" : Date.now();\\n}\\n<\/script>\\r\\n\\r\\n<main>\\r\\n  {#if $view === 'quiz'}\\r\\n    <Quiz data={lesson_data.data} {ChangeQuizName} />\\r\\n  {:else if lesson_data.data && lesson_data.data.module}\\r\\n    <!-- svelte-ignore a11y-missing-content -->\\r\\n\\r\\n    <div style=\\"height:1500px; margin-top:20px\\">\\r\\n      <div class=\\"level_container\\" style=\\"\\">\\r\\n        {#await Translate('Save', 'en', $langs) then data}\\r\\n          <button class=\\"save\\" on:click={saveLessonData}>\\r\\n            {data}\\r\\n          </button>\\r\\n        {/await}\\r\\n\\r\\n        <div>\\r\\n          <div class=\\"add_module\\" style=\\"display:inline-flex\\">\\r\\n            {#await Translate('Добавить модуль', 'ru', $langs) then data}\\r\\n              <IconButton\\r\\n                class=\\"material-icons\\"\\r\\n                on:click={OnAddModule}\\r\\n                title={data}>add</IconButton\\r\\n              >{/await}\\r\\n          </div>\\r\\n          <Textfield\\r\\n            bind:this={module_input}\\r\\n            class=\\"module_text\\"\\r\\n            style=\\"width:50px; text-align:center\\"\\r\\n            value={lesson_data.level}\\r\\n            label=\\"Module\\"\\r\\n            on:input={OnInput}\\r\\n            on:click={() => menu.setOpen(true)}\\r\\n          ></Textfield>\\r\\n\\r\\n          <Textfield\\r\\n            bind:this={llang_input}\\r\\n            class=\\"module_text\\"\\r\\n            style=\\"display:inline-flex; width:55px;text-align:center\\"\\r\\n            bind:value={$llang}\\r\\n            label=\\"Language\\"\\r\\n          ></Textfield>\\r\\n\\r\\n          <div class=\\"rem_module\\" style=\\"display:inline-flex\\">\\r\\n            {#await Translate('Удалить модуль', 'ru', $langs) then data}\\r\\n              <IconButton\\r\\n                class=\\"material-icons rem_module\\"\\r\\n                on:click={OnRemModule}\\r\\n                title={data}>remove</IconButton\\r\\n              >\\r\\n            {/await}\\r\\n          </div>\\r\\n\\r\\n          <Menu bind:this={menu}>\\r\\n            <List>\\r\\n              {#each levels as level}\\r\\n                <Item\\r\\n                  on:SMUI:action={ChangeLevel}\\r\\n                  {level}\\r\\n                  style=\\"text-align:center\\"\\r\\n                >\\r\\n                  <Text>{level}</Text>\\r\\n                </Item>\\r\\n              {/each}\\r\\n            </List>\\r\\n          </Menu>\\r\\n        </div>\\r\\n      </div>\\r\\n\\r\\n      <div class=\\"lesson-container\\" style=\\"\\">\\r\\n        <SortableList\\r\\n          onSort={(ev) => {\\r\\n            handleSort(ev, lesson_data.data.module.themes);\\r\\n          }}\\r\\n          bind:this={theme_sort_list}\\r\\n        >\\r\\n          {#each lesson_data.data.module.themes as theme, t}\\r\\n            <div class=\\"accordion-container\\">\\r\\n              <Accordion multiple>\\r\\n                <Panel class=\\"panel\\">\\r\\n                  <Header>\\r\\n                    <!-- <h4><input value={theme.name[$langs]} /></h4> -->\\r\\n                    <!-- <Textfield bind:value={theme.name[$langs]} style=\\"width: 368px;\\">\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<HelperText slot=\\"helper\\">Helper Text</HelperText>\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t</Textfield> -->\\r\\n                    {#await Translate('Input Theme Name', 'en', $langs) then data}\\r\\n                      <input\\r\\n                        placeholder={data}\\r\\n                        bind:value={theme.name[$llang]}\\r\\n                        style=\\"font-weight: bold; width:90%\\"\\r\\n                      />\\r\\n                      <!-- {@debug theme, $llang} -->\\r\\n                    {/await}\\r\\n                    <div class=\\"rem_theme\\">\\r\\n                      {#await Translate('Remove theme', 'en', $langs) then data}\\r\\n                        <IconButton\\r\\n                          class=\\"material-icons\\"\\r\\n                          title={data}\\r\\n                          name={theme.name[$llang]}\\r\\n                          on:click={() => OnRemoveThemeItem(t)}\\r\\n                          >remove</IconButton\\r\\n                        >\\r\\n                      {/await}\\r\\n                    </div>\\r\\n                  </Header>\\r\\n                  <Content>\\r\\n                    {#if theme.lessons}\\r\\n                      {#each theme.lessons as lesson}\\r\\n                        <!-- <div>{lesson.num}.{lesson.title}</div> -->\\r\\n                        {#if lesson.quizes}\\r\\n                          <SortableList\\r\\n                            onSort={(ev) => {\\r\\n                              handleSort(ev, lesson.quizes);\\r\\n                            }}\\r\\n                            bind:this={quiz_sort_list}\\r\\n                          >\\r\\n                            {#each lesson.quizes as quiz, q}\\r\\n                              <!-- {@debug quiz} -->\\r\\n\\r\\n                              <div class=\\"quiz-container\\">\\r\\n                                <Checkbox\\r\\n                         \\r\\n                                  on:click={()=>OnPublish(lesson_data.data.module.themes[t].lessons[0].quizes[q], quiz.published)}\\r\\n    \\r\\n                                  checked={quiz.published ? 'true' : ''}\\r\\n                                  touch\\r\\n                                ></Checkbox>\\r\\n\\r\\n                                <div\\r\\n                                  on:click={() => {\\r\\n                                    onClickQuiz(\\r\\n                                      quiz,\\r\\n                                      lesson_data.data.module.level,\\r\\n                                      theme\\r\\n                                    );\\r\\n                                  }}\\r\\n                                  type={quiz.type}\\r\\n                                  name={quiz.name[$llang]}\\r\\n                                  level={lesson_data.data.module.level}\\r\\n                                  highlight={quiz.highlight || ''}\\r\\n                                >\\r\\n                                  {#if quiz.type === 'dialog'}\\r\\n                                    <Icon\\r\\n                                      tag=\\"svg\\"\\r\\n                                      viewBox=\\"0 0 24 24\\"\\r\\n                                      width=\\"30px\\"\\r\\n                                      height=\\"30px\\"\\r\\n                                    >\\r\\n                                      <path\\r\\n                                        fill=\\"grey\\"\\r\\n                                        d={mdiAccountMultiple}\\r\\n                                      />\\r\\n                                    </Icon>\\r\\n                                  {:else if quiz.type === 'text'}\\r\\n                                    <Icon\\r\\n                                      tag=\\"svg\\"\\r\\n                                      viewBox=\\"0 0 24 24\\"\\r\\n                                      width=\\"30px\\"\\r\\n                                      height=\\"30px\\"\\r\\n                                    >\\r\\n                                      <path fill=\\"grey\\" d={mdiTextBoxOutline} />\\r\\n                                    </Icon>\\r\\n                                  {:else if quiz.type === 'word'}\\r\\n                                    <Icon\\r\\n                                      tag=\\"svg\\"\\r\\n                                      viewBox=\\"0 0 24 24\\"\\r\\n                                      width=\\"30px\\"\\r\\n                                      height=\\"30px\\"\\r\\n                                    >\\r\\n                                      <path\\r\\n                                        fill=\\"grey\\"\\r\\n                                        d={mdiFileWordBoxOutline}\\r\\n                                      />\\r\\n                                    </Icon>\\r\\n                                  {:else if quiz.type === 'bricks'}\\r\\n                                    <Icon\\r\\n                                      tag=\\"svg\\"\\r\\n                                      viewBox=\\"0 0 24 24\\"\\r\\n                                      width=\\"30px\\"\\r\\n                                      height=\\"30px\\"\\r\\n                                    >                          \\r\\n                                      <rect x=\\"3\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"13\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"3\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"9\\" y=\\"8\\" width=\\"6\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"17\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"3\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"13\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"3\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"9\\" y=\\"18\\" width=\\"6\\" height=\\"3\\" />\\r\\n                                      <rect x=\\"17\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                    </Icon>\\r\\n                  \\r\\n                                  {:else if quiz.type === 'quiz'}\\r\\n                                    <select\\r\\n                                      on:click|preventDefault|once|stopPropagation={() => {}}\\r\\n                                      on:change={(event) =>\\r\\n                                        OnSelectQuiztype(\\r\\n                                          event.target.value,\\r\\n                                          t,\\r\\n                                          quiz.name[$llang]\\r\\n                                        )}\\r\\n                                      name={quiz.name[$llang]}\\r\\n                                    >\\r\\n                                      {#each quizes as quizOption}\\r\\n                                        <option value={quizOption}\\r\\n                                          >{quizOption}</option\\r\\n                                        >\\r\\n                                      {/each}\\r\\n                                    </select>\\r\\n                                  {/if}\\r\\n                                </div>\\r\\n                                <!-- svelte-ignore a11y-invalid-attribute -->\\r\\n                                {#if quiz.type === 'quiz'}\\r\\n                                  {#await Translate('Quiz Name', $llang, $langs) then data}\\r\\n                                    <input\\r\\n                                      class=\\"quiz_name\\"\\r\\n                                      on:click={OnClickQuizName}\\r\\n                                      autofocus\\r\\n                                      contenteditable\\r\\n                                      {t}\\r\\n                                      placeholder={data}\\r\\n                                      name={quiz.name[$langs]}\\r\\n                                      theme={theme.num}\\r\\n                                      theme_name={theme.name[$llang]}\\r\\n                                      bind:value={quiz.name[$langs]}\\r\\n                                    />\\r\\n                                  {/await}\\r\\n                                {:else}\\r\\n                                  {#await Translate('Quiz Name', $llang, $langs) then data}\\r\\n                                    <input\\r\\n                                      on:click={OnClickQuizName}\\r\\n                                      style=\\"width:80%\\"\\r\\n                                      {t}\\r\\n                                      placeholder={data}\\r\\n                                      name={quiz.name[$llang]}\\r\\n                                      level={lesson_data.data.level}\\r\\n                                      theme={theme.num}\\r\\n                                      theme_name={theme.name[$llang]}\\r\\n                                      bind:value={quiz.name[$llang]}\\r\\n                                    />\\r\\n                                  {/await}\\r\\n                                {/if}\\r\\n\\r\\n                                <div class=\\"rem_quiz\\">\\r\\n                                  {#await Translate('Remove quiz', 'en', $langs) then data}\\r\\n                                    <IconButton\\r\\n                                      class=\\"material-icons\\"\\r\\n                                      title={data}\\r\\n                                      name={quiz.name[$llang]}\\r\\n                                      on:click={() => {\\r\\n                                        OnRemoveItem(quiz.name[$llang], t);\\r\\n                                      }}>remove</IconButton\\r\\n                                    >\\r\\n                                  {/await}\\r\\n                                </div>\\r\\n                              </div>\\r\\n                            {/each}\\r\\n                          </SortableList>\\r\\n                        {/if}\\r\\n                      {/each}\\r\\n                      <div class=\\"add_quiz\\" style=\\"left:10px\\">\\r\\n                        {#await Translate('Add quiz', 'en', $langs) then data}\\r\\n                          <IconButton\\r\\n                            class=\\"material-icons\\"\\r\\n                            title={data}\\r\\n                            name={theme.name[$llang]}\\r\\n                            on:click={() => {\\r\\n                              OnAddQuiz(theme.name[$llang], t);\\r\\n                            }}>add</IconButton\\r\\n                          >\\r\\n                        {/await}\\r\\n                      </div>\\r\\n                    {/if}\\r\\n                  </Content>\\r\\n                </Panel>\\r\\n              </Accordion>\\r\\n            </div>\\r\\n          {/each}\\r\\n        </SortableList>\\r\\n        {#if lesson_data.level && $llang !== ' '}\\r\\n          <div class=\\"add_theme\\">\\r\\n            {#await Translate('Add theme', 'en', $langs) then data}\\r\\n              <IconButton\\r\\n                class=\\"material-icons\\"\\r\\n                on:click={() => OnAddTheme()}\\r\\n                title={data}>add</IconButton\\r\\n              >\\r\\n            {/await}\\r\\n          </div>\\r\\n        {/if}\\r\\n      </div>\\r\\n\\r\\n      <div style=\\"height:100px\\"></div>\\r\\n    </div>\\r\\n  {/if}\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    margin-top: 40px;\\r\\n  }\\r\\n  .module_level {\\r\\n    position: fixed;\\r\\n    background-color: rgba(255, 255, 255, 0.8);\\r\\n    padding: 10px;\\r\\n    bottom: -15px;\\r\\n    left: 50%;\\r\\n    transform: translate(-50%, -50%);\\r\\n    z-index: 1;\\r\\n  }\\r\\n\\r\\n  .level_container {\\r\\n    display: flex;\\r\\n    justify-content: space-between;\\r\\n    width: 95%;\\r\\n  }\\r\\n\\r\\n  .quiz_name {\\r\\n    width: 80%;\\r\\n    margin-right: 10px;\\r\\n  }\\r\\n\\r\\n  .save {\\r\\n    position: sticky;\\r\\n    top: 30px;\\r\\n    /* width: 15%; */\\r\\n    margin: 15px;\\r\\n  }\\r\\n\\r\\n  .lesson-container {\\r\\n    height: 90vh;\\r\\n    overflow-y: auto;\\r\\n    overflow-x: hidden;\\r\\n    max-width: 100%;\\r\\n    padding-top: 10px;\\r\\n    scrollbar-width: none;\\r\\n    -ms-overflow-style: none;\\r\\n  }\\r\\n  .quiz-container {\\r\\n    display: flex;\\r\\n    justify-content: space-between;\\r\\n    align-items: center;\\r\\n    padding: 0px; /* Установите желаемый отступ вокруг элемента */\\r\\n  }\\r\\n\\r\\n  .add_quiz,\\r\\n  .add_theme,\\r\\n  .add_module,\\r\\n  .rem_quiz,\\r\\n  .rem_theme,\\r\\n  .rem_module {\\r\\n    display: inline-flex;\\r\\n    position: relative;\\r\\n\\r\\n    background-color: aliceblue;\\r\\n    border-radius: 24px;\\r\\n    width: 24px;\\r\\n    height: 24px;\\r\\n    scale: 1.2;\\r\\n  }\\r\\n\\r\\n  div > .rem_quiz,\\r\\n  div > .rem_theme,\\r\\n  div > .rem_module {\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n  }\\r\\n\\r\\n  .rem_theme {\\r\\n    position: absolute;\\r\\n    right: 0;\\r\\n    top: 5px;\\r\\n  }\\r\\n\\r\\n  .add_theme {\\r\\n    position: relative;\\r\\n    top: 10px;\\r\\n  }\\r\\n\\r\\n  select {\\r\\n    height: 25px;\\r\\n  }\\r\\n\\r\\n  input {\\r\\n    border: 0;\\r\\n  }\\r\\n  ::-moz-selection {\\r\\n    background-color: grey;\\r\\n    outline: none;\\r\\n  }\\r\\n\\r\\n  ::selection {\\r\\n    background-color: lightblue;\\r\\n    outline: none;\\r\\n  }\\r\\n\\r\\n  ::placeholder {\\r\\n    font-weight: 400;\\r\\n  }\\r\\n  div:focus,\\r\\n  input:focus {\\r\\n    /* background: lightcyan; */\\r\\n    outline: none; /* Убираем также контур */\\r\\n  }\\r\\n\\r\\n  select {\\r\\n    border: 0;\\r\\n    background-color: lightgray;\\r\\n  }\\r\\n\\r\\n  option {\\r\\n    font-size: larger;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA0hBE,gCAAK,CACH,UAAU,CAAE,IACd,CAWA,4CAAiB,CACf,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,KAAK,CAAE,GACT,CAEA,sCAAW,CACT,KAAK,CAAE,GAAG,CACV,YAAY,CAAE,IAChB,CAEA,iCAAM,CACJ,QAAQ,CAAE,MAAM,CAChB,GAAG,CAAE,IAAI,CAET,MAAM,CAAE,IACV,CAEA,6CAAkB,CAChB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IAAI,CAChB,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,IAAI,CACf,WAAW,CAAE,IAAI,CACjB,eAAe,CAAE,IAAI,CACrB,kBAAkB,CAAE,IACtB,CACA,2CAAgB,CACd,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,GACX,CAEA,qCAAS,CACT,sCAAU,CACV,uCAAW,CACX,qCAAS,CACT,sCAAU,CACV,uCAAY,CACV,OAAO,CAAE,WAAW,CACpB,QAAQ,CAAE,QAAQ,CAElB,gBAAgB,CAAE,SAAS,CAC3B,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,GACT,CAEA,iBAAG,CAAG,uBAAS,CACf,iBAAG,CAAG,wBAAU,CAChB,iBAAG,CAAG,yBAAY,CAChB,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MACf,CAEA,sCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,CAAC,CACR,GAAG,CAAE,GACP,CAEA,sCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IACP,CAEA,kCAAO,CACL,MAAM,CAAE,IACV,CAEA,iCAAM,CACJ,MAAM,CAAE,CACV,6BACA,gBAAiB,CACf,gBAAgB,CAAE,IAAI,CACtB,OAAO,CAAE,IACX,6BAEA,WAAY,CACV,gBAAgB,CAAE,SAAS,CAC3B,OAAO,CAAE,IACX,6BAEA,aAAc,CACZ,WAAW,CAAE,GACf,CACA,+BAAG,MAAM,CACT,iCAAK,MAAO,CAEV,OAAO,CAAE,IACX,CAEA,kCAAO,CACL,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,SACpB,CAEA,kCAAO,CACL,SAAS,CAAE,MACb"}`
};
function handleSort(event, items2) {
  const { oldIndex, newIndex } = event;
  function arrayMove(arr, fromIndex, toIndex) {
    const element = arr.splice(fromIndex, 1)[0];
    arr.splice(toIndex, 0, element);
    return arr;
  }
  items2 = arrayMove(items2, oldIndex, newIndex);
}
const ModuleEditor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $llang, $$unsubscribe_llang;
  let $view, $$unsubscribe_view;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  const { find, isObject, mapValues } = pkg;
  let menu;
  let { abonent } = $$props;
  setContext("abonent", abonent);
  let llang_input;
  let theme_sort_list, quiz_sort_list;
  let lesson_data = { data: { level: "" } };
  let levels = [];
  let module_input;
  const quizes = ["выбери quiz...", "dialog", "word", "bricks"];
  async function fetchLesson(owner, level2) {
    try {
      let lev_str = level2 ? "&level=" + level2 : "";
      const response = await fetch(`./lesson?lesson=${abonent}&owner=${abonent}` + lev_str);
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const resp = await response.json();
      set_store_value(llang, $llang = resp.lang, $llang);
      return resp;
    } catch (error) {
      return [];
    }
  }
  onDestroy(() => {
  });
  function findDeep(obj, predicate, path = "") {
    if (predicate(obj, path)) {
      return obj;
    }
    if (isObject(obj)) {
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          let found = findDeep(obj[key], predicate, `${path}.${key}`);
          if (found) {
            return found;
          }
        }
      }
    }
    return null;
  }
  function ChangeQuizName(name, new_name) {
    let item = findDeep(lesson_data.data.module, (value2) => value2.name === name, { childrenPath: "quizes" });
    if (item) {
      item.name = new_name;
    }
    lesson_data = lesson_data;
  }
  if ($$props.abonent === void 0 && $$bindings.abonent && abonent !== void 0) $$bindings.abonent(abonent);
  if ($$props.fetchLesson === void 0 && $$bindings.fetchLesson && fetchLesson !== void 0) $$bindings.fetchLesson(fetchLesson);
  if ($$props.findDeep === void 0 && $$bindings.findDeep && findDeep !== void 0) $$bindings.findDeep(findDeep);
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (lesson_data.data) {
        levels = lesson_data.levels;
      }
    }
    $$rendered = `<main class="svelte-z3kqxi">${$view === "quiz" ? `${validate_component(Quiz, "Quiz").$$render($$result, { data: lesson_data.data, ChangeQuizName }, {}, {})}` : `${lesson_data.data && lesson_data.data.module ? ` <div style="height:1500px; margin-top:20px" class="svelte-z3kqxi"><div class="level_container svelte-z3kqxi" style="">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` <button class="save svelte-z3kqxi">${escape(data)}</button> `;
      }(__value);
    }(Translate("Save", "en", $langs))} <div class="svelte-z3kqxi"><div class="add_module svelte-z3kqxi" style="display:inline-flex">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(IconButton, "IconButton").$$render($$result, { class: "material-icons", title: data }, {}, {
          default: () => {
            return `add`;
          }
        })}`;
      }(__value);
    }(Translate("Добавить модуль", "ru", $langs))}</div> ${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        class: "module_text",
        style: "width:50px; text-align:center",
        value: lesson_data.level,
        label: "Module",
        this: module_input
      },
      {
        this: ($$value) => {
          module_input = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        class: "module_text",
        style: "display:inline-flex; width:55px;text-align:center",
        label: "Language",
        this: llang_input,
        value: $llang
      },
      {
        this: ($$value) => {
          llang_input = $$value;
          $$settled = false;
        },
        value: ($$value) => {
          $llang = $$value;
          $$settled = false;
        }
      },
      {}
    )} <div class="rem_module svelte-z3kqxi" style="display:inline-flex">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(IconButton, "IconButton").$$render(
          $$result,
          {
            class: "material-icons rem_module",
            title: data
          },
          {},
          {
            default: () => {
              return `remove`;
            }
          }
        )} `;
      }(__value);
    }(Translate("Удалить модуль", "ru", $langs))}</div> ${validate_component(Menu, "Menu").$$render(
      $$result,
      { this: menu },
      {
        this: ($$value) => {
          menu = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(List, "List").$$render($$result, {}, {}, {
            default: () => {
              return `${each(levels, (level) => {
                return `${validate_component(Item$1, "Item").$$render($$result, { level, style: "text-align:center" }, {}, {
                  default: () => {
                    return `${validate_component(Text, "Text").$$render($$result, {}, {}, {
                      default: () => {
                        return `${escape(level)}`;
                      }
                    })} `;
                  }
                })}`;
              })}`;
            }
          })}`;
        }
      }
    )}</div></div> <div class="lesson-container svelte-z3kqxi" style="">${validate_component(SortableList, "SortableList").$$render(
      $$result,
      {
        onSort: (ev) => {
          handleSort(ev, lesson_data.data.module.themes);
        },
        this: theme_sort_list
      },
      {
        this: ($$value) => {
          theme_sort_list = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${each(lesson_data.data.module.themes, (theme, t) => {
            return `<div class="accordion-container svelte-z3kqxi">${validate_component(Accordion, "Accordion").$$render($$result, { multiple: true }, {}, {
              default: () => {
                return `${validate_component(Panel, "Panel").$$render($$result, { class: "panel" }, {}, {
                  default: () => {
                    return `${validate_component(Header$1, "Header").$$render($$result, {}, {}, {
                      default: () => {
                        return `  ${function(__value) {
                          if (is_promise(__value)) {
                            __value.then(null, noop);
                            return ``;
                          }
                          return function(data) {
                            return ` <input${add_attribute("placeholder", data, 0)} style="font-weight: bold; width:90%" class="svelte-z3kqxi"${add_attribute("value", theme.name[$llang], 0)}>  `;
                          }(__value);
                        }(Translate("Input Theme Name", "en", $langs))} <div class="rem_theme svelte-z3kqxi">${function(__value) {
                          if (is_promise(__value)) {
                            __value.then(null, noop);
                            return ``;
                          }
                          return function(data) {
                            return ` ${validate_component(IconButton, "IconButton").$$render(
                              $$result,
                              {
                                class: "material-icons",
                                title: data,
                                name: theme.name[$llang]
                              },
                              {},
                              {
                                default: () => {
                                  return `remove`;
                                }
                              }
                            )} `;
                          }(__value);
                        }(Translate("Remove theme", "en", $langs))}</div> `;
                      }
                    })} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                      default: () => {
                        return `${theme.lessons ? `${each(theme.lessons, (lesson2) => {
                          return ` ${lesson2.quizes ? `${validate_component(SortableList, "SortableList").$$render(
                            $$result,
                            {
                              onSort: (ev) => {
                                handleSort(ev, lesson2.quizes);
                              },
                              this: quiz_sort_list
                            },
                            {
                              this: ($$value) => {
                                quiz_sort_list = $$value;
                                $$settled = false;
                              }
                            },
                            {
                              default: () => {
                                return `${each(lesson2.quizes, (quiz, q) => {
                                  return ` <div class="quiz-container svelte-z3kqxi">${validate_component(Checkbox, "Checkbox").$$render(
                                    $$result,
                                    {
                                      checked: quiz.published ? "true" : "",
                                      touch: true
                                    },
                                    {},
                                    {}
                                  )} <div${add_attribute("type", quiz.type, 0)}${add_attribute("name", quiz.name[$llang], 0)}${add_attribute("level", lesson_data.data.module.level, 0)}${add_attribute("highlight", quiz.highlight || "", 0)} class="svelte-z3kqxi">${quiz.type === "dialog" ? `${validate_component(CommonIcon, "Icon").$$render(
                                    $$result,
                                    {
                                      tag: "svg",
                                      viewBox: "0 0 24 24",
                                      width: "30px",
                                      height: "30px"
                                    },
                                    {},
                                    {
                                      default: () => {
                                        return `<path fill="grey"${add_attribute("d", mdiAccountMultiple, 0)} class="svelte-z3kqxi"></path> `;
                                      }
                                    }
                                  )}` : `${quiz.type === "text" ? `${validate_component(CommonIcon, "Icon").$$render(
                                    $$result,
                                    {
                                      tag: "svg",
                                      viewBox: "0 0 24 24",
                                      width: "30px",
                                      height: "30px"
                                    },
                                    {},
                                    {
                                      default: () => {
                                        return `<path fill="grey"${add_attribute("d", mdiTextBoxOutline, 0)} class="svelte-z3kqxi"></path> `;
                                      }
                                    }
                                  )}` : `${quiz.type === "word" ? `${validate_component(CommonIcon, "Icon").$$render(
                                    $$result,
                                    {
                                      tag: "svg",
                                      viewBox: "0 0 24 24",
                                      width: "30px",
                                      height: "30px"
                                    },
                                    {},
                                    {
                                      default: () => {
                                        return `<path fill="grey"${add_attribute("d", mdiFileWordBoxOutline, 0)} class="svelte-z3kqxi"></path> `;
                                      }
                                    }
                                  )}` : `${quiz.type === "bricks" ? `${validate_component(CommonIcon, "Icon").$$render(
                                    $$result,
                                    {
                                      tag: "svg",
                                      viewBox: "0 0 24 24",
                                      width: "30px",
                                      height: "30px"
                                    },
                                    {},
                                    {
                                      default: () => {
                                        return `<rect x="3" y="3" width="8" height="3" class="svelte-z3kqxi"></rect> <rect x="13" y="3" width="8" height="3" class="svelte-z3kqxi"></rect> <rect x="3" y="8" width="4" height="3" class="svelte-z3kqxi"></rect> <rect x="9" y="8" width="6" height="3" class="svelte-z3kqxi"></rect> <rect x="17" y="8" width="4" height="3" class="svelte-z3kqxi"></rect> <rect x="3" y="13" width="8" height="3" class="svelte-z3kqxi"></rect> <rect x="13" y="13" width="8" height="3" class="svelte-z3kqxi"></rect> <rect x="3" y="18" width="4" height="3" class="svelte-z3kqxi"></rect> <rect x="9" y="18" width="6" height="3" class="svelte-z3kqxi"></rect> <rect x="17" y="18" width="4" height="3" class="svelte-z3kqxi"></rect> `;
                                      }
                                    }
                                  )}` : `${quiz.type === "quiz" ? `<select${add_attribute("name", quiz.name[$llang], 0)} class="svelte-z3kqxi">${each(quizes, (quizOption) => {
                                    return `<option${add_attribute("value", quizOption, 0)} class="svelte-z3kqxi">${escape(quizOption)}</option>`;
                                  })}</select>` : ``}`}`}`}`}</div>  ${quiz.type === "quiz" ? `${function(__value) {
                                    if (is_promise(__value)) {
                                      __value.then(null, noop);
                                      return ``;
                                    }
                                    return function(data) {
                                      return ` <input class="quiz_name svelte-z3kqxi" autofocus contenteditable${add_attribute("t", t, 0)}${add_attribute("placeholder", data, 0)}${add_attribute("name", quiz.name[$langs], 0)}${add_attribute("theme", theme.num, 0)}${add_attribute("theme_name", theme.name[$llang], 0)}${add_attribute("value", quiz.name[$langs], 0)}> `;
                                    }(__value);
                                  }(Translate("Quiz Name", $llang, $langs))}` : `${function(__value) {
                                    if (is_promise(__value)) {
                                      __value.then(null, noop);
                                      return ``;
                                    }
                                    return function(data) {
                                      return ` <input style="width:80%"${add_attribute("t", t, 0)}${add_attribute("placeholder", data, 0)}${add_attribute("name", quiz.name[$llang], 0)}${add_attribute("level", lesson_data.data.level, 0)}${add_attribute("theme", theme.num, 0)}${add_attribute("theme_name", theme.name[$llang], 0)} class="svelte-z3kqxi"${add_attribute("value", quiz.name[$llang], 0)}> `;
                                    }(__value);
                                  }(Translate("Quiz Name", $llang, $langs))}`} <div class="rem_quiz svelte-z3kqxi">${function(__value) {
                                    if (is_promise(__value)) {
                                      __value.then(null, noop);
                                      return ``;
                                    }
                                    return function(data) {
                                      return ` ${validate_component(IconButton, "IconButton").$$render(
                                        $$result,
                                        {
                                          class: "material-icons",
                                          title: data,
                                          name: quiz.name[$llang]
                                        },
                                        {},
                                        {
                                          default: () => {
                                            return `remove`;
                                          }
                                        }
                                      )} `;
                                    }(__value);
                                  }(Translate("Remove quiz", "en", $langs))}</div> </div>`;
                                })} `;
                              }
                            }
                          )}` : ``}`;
                        })} <div class="add_quiz svelte-z3kqxi" style="left:10px">${function(__value) {
                          if (is_promise(__value)) {
                            __value.then(null, noop);
                            return ``;
                          }
                          return function(data) {
                            return ` ${validate_component(IconButton, "IconButton").$$render(
                              $$result,
                              {
                                class: "material-icons",
                                title: data,
                                name: theme.name[$llang]
                              },
                              {},
                              {
                                default: () => {
                                  return `add`;
                                }
                              }
                            )} `;
                          }(__value);
                        }(Translate("Add quiz", "en", $langs))} </div>` : ``} `;
                      }
                    })} `;
                  }
                })} `;
              }
            })} </div>`;
          })}`;
        }
      }
    )} ${lesson_data.level && $llang !== " " ? `<div class="add_theme svelte-z3kqxi">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(IconButton, "IconButton").$$render($$result, { class: "material-icons", title: data }, {}, {
          default: () => {
            return `add`;
          }
        })} `;
      }(__value);
    }(Translate("Add theme", "en", $langs))}</div>` : ``}</div> <div style="height:100px" class="svelte-z3kqxi"></div></div>` : ``}`} </main>`;
  } while (!$$settled);
  $$unsubscribe_llang();
  $$unsubscribe_view();
  $$unsubscribe_langs();
  return $$rendered;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $nlang, $$unsubscribe_nlang;
  let $dicts, $$unsubscribe_dicts;
  let $view, $$unsubscribe_view;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_nlang = subscribe(nlang, (value) => $nlang = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  let { data } = $$props;
  let operator = data.operator, abonent = data.abonent;
  data.name;
  if (data.lang) {
    set_store_value(nlang, $nlang = data.lang, $nlang);
    set_store_value(langs, $langs = data.lang, $langs);
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    if (data.dict[0]) {
      set_store_value(dicts, $dicts = data.dict[0], $dicts);
    }
  }
  $$unsubscribe_langs();
  $$unsubscribe_nlang();
  $$unsubscribe_dicts();
  $$unsubscribe_view();
  return `${operator ? `${validate_component(Header, "Header").$$render($$result, {}, {}, {})} ${$view === "group" ? `${validate_component(GroupEditor, "GroupEditor").$$render($$result, { data }, {}, {})}` : `${$view === "lesson" || $view === "quiz" ? ` ${validate_component(ModuleEditor, "ModuleEditor").$$render($$result, { abonent }, {}, {})}` : ``}`}` : `${validate_component(Login, "Login").$$render($$result, { operator, abonent }, {}, {})}`}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-C877tCm-.js.map
