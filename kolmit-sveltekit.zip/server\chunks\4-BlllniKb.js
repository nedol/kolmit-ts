import md5 from 'md5';
import { d as dict } from './dict-DqfG9VE-.js';
import { G as GetGroups, C as CreatePool_neon } from './db.admin-BSGKTkbW.js';
import './db-LknqzByu.js';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

const prerender = false;
const ssr = false;

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  prerender: prerender,
  ssr: ssr
});

await CreatePool_neon();
let kolmit;
async function load({ fetch, cookies, route, url, stuff }) {
  let res;
  let abonent = url.searchParams.get("abonent");
  let lang = url.searchParams.get("lang");
  let name = url.searchParams.get("name");
  let operator = url.searchParams.get("operator");
  let psw = url.searchParams.get("psw");
  let host = url.origin;
  let resp = {
    dict
  };
  try {
    res = cookies.get("kolmit.admin." + abonent);
    if (psw) {
      kolmit = { operator, psw: md5(psw), name, lang };
    } else {
      if (res) {
        kolmit = JSON.parse(res);
      } else {
        resp.check = false;
        resp.abonent = abonent;
        resp.users = "{}";
        resp.host = host;
        return resp;
      }
    }
  } catch (ex) {
    console.log();
  }
  let params = {
    abonent,
    psw: kolmit.psw
  };
  let { operators, admin, groups } = await GetGroups(params);
  return {
    check: true,
    host,
    groups,
    operators,
    // url: decodeURIComponent(url.toString()),
    operator: kolmit.operator,
    name: kolmit.name,
    abonent,
    lang: kolmit.lang,
    dict
  };
}

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C877tCm-.js')).default;
const universal_id = "src/routes/admin/+page.js";
const server_id = "src/routes/admin/+page.server.ts";
const imports = ["_app/immutable/nodes/4.iBh_tv6r.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js","_app/immutable/chunks/CnDslQqG.js","_app/immutable/chunks/C-TImyHC.js","_app/immutable/chunks/CjtaZ3kr.js"];
const stylesheets = ["_app/immutable/assets/4.C7An0s3F.css","_app/immutable/assets/index.CI7HwAql.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=4-BlllniKb.js.map
