const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-Bir7QoT3.js')).default;
const imports = ["_app/immutable/nodes/1.CYT9Fh-Z.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js","_app/immutable/chunks/CjtaZ3kr.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-BgKJlv9T.js.map
