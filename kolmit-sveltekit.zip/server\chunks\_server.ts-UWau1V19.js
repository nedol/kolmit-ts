import './index-BIAFQWR9.js';
import { D as DeleteUser, A as AddUser } from './db.admin-BSGKTkbW.js';
import 'md5';
import './db-LknqzByu.js';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

async function POST({ request, url, fetch }) {
  let resp;
  const { func, class_name, role, name, email, operator, abonent, lang } = await request.json();
  switch (func) {
    case "add_user":
      resp = await AddUser({ class_name, role, name, email, abonent, lang });
      break;
    case "del_user":
      resp = await DeleteUser({ operator, abonent });
      break;
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}

export { POST };
//# sourceMappingURL=_server.ts-UWau1V19.js.map
