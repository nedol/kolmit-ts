import { config } from 'dotenv';
import { C as Client } from './index-7vFat6VW.js';
import { k as GetPrompt, T as Translate } from './db-LknqzByu.js';
import Groq from 'groq-sdk';
import { HfInference } from '@huggingface/inference';
import 'lodash';
import 'md5';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

config();
const HF_TOKEN = process.env.HF_TOKEN;
new HfInference(HF_TOKEN);
const GROQ_API_KEY = process.env.GROQ_API_KEY;
new Groq({
  apiKey: GROQ_API_KEY
});
async function POST({ request, fetch }) {
  let { question } = await request.json();
  const prompt = await GetPrompt("chat");
  await Translate(question.text, question.lang, "en");
  let answer = await chatLlama(prompt.prompt.system);
  let res = {
    ["nl"]: await Translate(answer, question.llang, "nl"),
    ["en"]: await Translate(answer, question.llang, "en"),
    [question.lang]: await Translate(answer, question.llang, question.lang)
  };
  let response = new Response(JSON.stringify({ res }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
async function chatLlama(system, task) {
  const app = await Client.connect("NiansuhAI/HFLLMs", {
    hf_token: HF_TOKEN
  });
  await app.view_api();
  let result;
  result = await app.predict("/chat", {
    message: "Hello!!",
    system_prompt: "Hello!!",
    max_new_tokens: 1,
    temperature: 0.1,
    top_p: 0.05,
    top_k: 1,
    repetition_penalty: 1
  });
  return result?.data[0];
}

export { POST };
//# sourceMappingURL=_server-Bk4cZD5p.js.map
