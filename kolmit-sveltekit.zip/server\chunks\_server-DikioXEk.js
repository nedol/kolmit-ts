import 'ws';
import path, { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import * as googleTTS from 'google-tts-api';
import 'google-translate-api-x';
import speech from '@google-cloud/speech';
import './db-LknqzByu.js';
import 'buffer';
import 'wav';
import md5 from 'md5';
import './index-BIAFQWR9.js';
import { config } from 'dotenv';
import 'iso-google-locales';
import './index-7vFat6VW.js';
import 'fluent-ffmpeg';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'deeplx';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
new speech.SpeechClient();
config();
process.env.HF_TOKEN_3;
const audioDir = path.join(__dirname, "audio");
async function POST({ url, fetch, cookies, request, response }) {
  let resp;
  let abonent = url.searchParams.get("abonent");
  const { par } = await request.json();
  const q = par;
  switch (q.func) {
    case "tts":
      resp = await tts_google(q.text, q.lang, abonent, q.quiz);
      break;
  }
  response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
async function tts_google(text, lang, abonent, quiz) {
  const fileName = md5(text) + ".mp3";
  join(audioDir, fileName);
  try {
    let base64 = "";
    let url_b64 = await googleTTS.getAllAudioBase64(text, {
      //getAudioUrl(text, {
      lang,
      slow: false,
      host: "https://translate.google.com",
      timeout: 1e4
    });
    url_b64.map((e) => {
      base64 += e.base64;
    });
    let timestamps = [];
    return { audio: "data:audio/mpeg;base64," + base64, ts: timestamps };
  } catch (error) {
    console.error("Error converting text to speech:", error);
  }
}

export { POST };
//# sourceMappingURL=_server-DikioXEk.js.map
