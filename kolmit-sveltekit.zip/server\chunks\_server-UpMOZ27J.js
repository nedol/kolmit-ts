import './index-BIAFQWR9.js';
import { c as UpdateWords, d as UpdateListen, e as UpdateDialog } from './db.admin-BSGKTkbW.js';
import 'md5';
import './db-LknqzByu.js';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

async function POST({ request, url, fetch }) {
  let resp;
  const { func, owner, level, name, new_name, data, lang, context } = await request.json();
  switch (func) {
    case "upd_dlg":
      UpdateDialog({ owner, level, new_name, data });
      break;
    case "upd_listen":
      UpdateListen({ owner, new_name, data, lang });
      break;
    case "upd_words":
      UpdateWords({ owner, level, new_name, data, context });
      break;
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}

export { POST };
//# sourceMappingURL=_server-UpMOZ27J.js.map
