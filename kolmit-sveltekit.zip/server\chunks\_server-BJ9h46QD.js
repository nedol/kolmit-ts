import './index-BIAFQWR9.js';
import 'node-turn';
import { r as rtcPool_st } from './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';

rtcPool_st.subscribe((data) => {
  globalThis.rtcPool = data;
});
async function POST(event) {
  const { par } = await event.request.json();
  const q = par;
  let resp = {};
  switch (q.func) {
    case "operatorwaiting":
      try {
        let promise = new Promise((resolve, reject) => {
          try {
            OperatorWaiting(q, resolve);
          } catch (ex) {
            console.log(ex);
          }
        });
        resp = await promise;
        console.log(resp);
      } catch (ex) {
        console.log(par.func, ex);
      }
      break;
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
function OperatorWaiting(q, resolve) {
  try {
    if (!globalThis.rtcPool[q.type][q.abonent]) globalThis.rtcPool[q.type][q.abonent] = {};
    if (!globalThis.rtcPool[q.type][q.abonent][q.operator])
      globalThis.rtcPool[q.type][q.abonent][q.operator] = { resolve: "" };
    globalThis.rtcPool[q.type][q.abonent][q.operator].resolve = resolve;
  } catch (ex) {
    console.log("OperatorWaiting ex:" + ex);
  }
}

export { POST };
//# sourceMappingURL=_server-BJ9h46QD.js.map
