import md5 from 'md5';
import { g as getLevels, S as SendEmail } from './db-LknqzByu.js';
import postgres from 'postgres';
import pkg from 'lodash';

const { find, remove, findIndex, difference } = pkg;
let sql;
let conStrNeon = {
  connectionString: "postgresql://nedooleg:nHLhfQB0WS5Y@ep-polished-bush-a2n4g5y9-pooler.eu-central-1.aws.neon.tech:5432/neondb?sslmode=require"
};
async function CreatePool_neon() {
  sql = postgres(conStrNeon.connectionString, {
    host: "ep-polished-bush-a2n4g5y9-pooler.eu-central-1.aws.neon.tech",
    // Postgres ip address[s] or domain name[s]
    port: 5432,
    // Postgres server port[s]
    database: "neondb",
    // Name of database to connect to
    username: "nedooleg",
    // Username of database user
    password: "nHLhfQB0WS5Y"
    // Password of database user
  });
}
async function CreateAdmin(par) {
  try {
    let res = await sql`INSERT INTO admins
			(name , email, operator, psw, lang)
			VALUES(${par.name},${par.email},${md5(par.email)},${md5(par.psw)},${par.lang})
			ON CONFLICT ( email)
			DO NOTHING
			`;
    return {
      name: par.name,
      email: par.email,
      operator: md5(par.email),
      psw: md5(par.psw),
      lang: par.lang
    };
  } catch (ex) {
    console.log();
  }
}
async function GetGroups(par) {
  let groups, operators, admin;
  try {
    operators = await sql`
      SELECT *
      FROM operators
      WHERE role <> 'admin' AND operators.abonent = ${par.abonent}`;
    admin = await sql`
      SELECT *
      FROM operators
      WHERE role = 'admin' AND operators.abonent = ${par.abonent}`;
    groups = await sql`
      SELECT groups.name::text 
      FROM groups
      INNER JOIN operators ON (operators.abonent = groups.owner)
      WHERE operators.operator = ${par.abonent} 
      AND operators.role = 'admin' 
      AND operators.psw = ${par.psw}`;
  } catch (ex) {
    console.log(ex);
  }
  return { groups, operators, admin };
}
async function DeleteUser(par) {
  let resp;
  try {
    resp = await sql`UPDATE operators SET "group"='public', abonent='public' 
    WHERE operator=${par.operator} AND abonent=${par.abonent}`;
  } catch (ex) {
    console.log(ex);
  }
  return { resp };
}
async function AddUser(q) {
  try {
    let operator = md5(q.email);
    let resp = await sql`INSERT INTO operators
			("group", role, operator , email, abonent , name, lang )
			VALUES(${q.class_name}, ${q.role},${operator}, ${q.email}, ${q.abonent}, ${q.name}, ${q.lang})
			ON CONFLICT (operator, abonent)
			DO NOTHING`;
    if (resp.count > 0) {
      SendEmail({ send_email: q.email, abonent: q.abonent, lang: q.lang, name: q.name });
    }
    return { resp };
  } catch (ex) {
    return JSON.stringify({ func: q.func, resp: ex });
  }
}
async function UpdateLesson(q) {
  try {
    let levels = await getLevels(q.owner);
    levels.map((item) => {
      if (q.levels.indexOf(item) === -1) removeModule(item);
    });
    let res = await sql`INSERT INTO lessons
			(level , owner, data, lang, timestamp )
			VALUES(${q.level},${q.owner},${JSON.parse(q.data)}, ${q.lang}, NOW())
			ON CONFLICT (level, owner, lang)
			DO UPDATE SET
			owner = EXCLUDED.owner,
			level = EXCLUDED.level,
      lang = EXCLUDED.lang,
			data = EXCLUDED.data,
      timestamp = NOW()`;
    return { res };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function removeModule(item) {
  return await sql`DELETE FROM lessons WHERE level=${item}`;
}
async function UpdateDialog(q) {
  try {
    let res = await sql`INSERT INTO dialogs
			(name , dialog, owner, html, level,timestamp)
			VALUES(${q.new_name},${q.data},${q.owner},${q.data.html || ""}, ${q.level}, NOW() )
			ON CONFLICT (name, owner, level)
			DO UPDATE SET
			name = EXCLUDED.name,
      html = EXCLUDED.html,
			dialog = EXCLUDED.dialog,
      timestamp = NOW()`;
    return { res };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function UpdateListen(q) {
  try {
    let res = await sql`INSERT INTO listen
			(owner, name , data, lang,timestamp)
			VALUES(${q.owner},${q.new_name},${q.data},${q.lang}, NOW() )
			ON CONFLICT (name, lang, owner)
			DO UPDATE SET
			data = EXCLUDED.data, 
      timestamp = NOW() `;
    return { res };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function UpdateWords(q) {
  try {
    let res = await sql`INSERT INTO word
			(name , data, owner, level,context,timestamp)
			VALUES(${q.new_name},${q.data},${q.owner}, ${q.level}, ${q.context},NOW())
			ON CONFLICT (name, owner, level)
			DO UPDATE SET
			name = EXCLUDED.name,
      level = EXCLUDED.level,
			data = EXCLUDED.data,
      context = EXCLUDED.context,
      timestamp = NOW()`;
    return { res };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function GetPrompt(prompt = "", quiz_name = "", owner = "", level = "", theme = "") {
  let prompt_res, words_res, gram_res, gram, context;
  try {
    if (prompt)
      prompt_res = await sql`SELECT * FROM prompts WHERE name=${prompt}`;
    if (quiz_name)
      words_res = await sql`SELECT * FROM word WHERE name=${quiz_name}`;
    if (owner && level) {
      gram_res = await sql`SELECT * FROM grammar WHERE owner=${owner} AND level=${level}`;
      if (gram_res[0])
        gram = find(gram_res[0].data, { theme });
      context = await sql`SELECT html FROM bricks WHERE owner=${owner} AND level=${level} AND name=${quiz_name}`;
    }
  } catch (ex) {
    console.log(JSON.stringify({ res: ex }));
  }
  return {
    prompt: prompt_res[0],
    words: words_res,
    grammar: gram,
    context
  };
}

export { AddUser as A, CreatePool_neon as C, DeleteUser as D, GetGroups as G, UpdateLesson as U, GetPrompt as a, CreateAdmin as b, UpdateWords as c, UpdateListen as d, UpdateDialog as e };
//# sourceMappingURL=db.admin-BSGKTkbW.js.map
