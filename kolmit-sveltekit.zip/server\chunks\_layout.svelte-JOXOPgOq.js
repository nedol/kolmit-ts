import { c as create_ssr_component } from './ssr2-CjWPy-sK.js';
import './utils-DaVwj2Zu.js';

const css = {
  code: ".app.svelte-11uokw2{display:flex;flex-direction:column;min-height:100vh}main.svelte-11uokw2{flex:1;display:flex;flex-direction:column;width:100%;box-sizing:border-box}@media(min-width: 480px){}",
  map: `{"version":3,"file":"+layout.svelte","sources":["+layout.svelte"],"sourcesContent":["<script>\\r\\n\\timport \\"../app.scss\\";\\r\\n\\r\\n  \\r\\n\\r\\n    import './styles.css';\\r\\n    import './smui.css';\\r\\n    import './smui.1.css';\\r\\n    // import './smui.2.css';\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"app\\">\\r\\n\\t\\r\\n\\r\\n\\t<main>\\r\\n\\t\\t<slot></slot>\\r\\n\\t</main>\\r\\n\\r\\n\\t<!-- \\r\\n\\t<footer>\\r\\n\\t\\t<p>\\r\\n\\t\\t\\tvisit <a href=\\"https://kit.svelte.dev\\">kit.svelte.dev</a> to learn SvelteKit\\r\\n\\t\\t</p>\\r\\n\\t</footer> -->\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n\\t.app {\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\tmin-height: 100vh;\\r\\n\\t}\\r\\n\\r\\n\\tmain {\\r\\n\\t\\tflex: 1;\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\twidth: 100%;\\r\\n\\t\\t/* max-width: 64rem; */\\r\\n\\t\\t/* margin: 0 auto; */\\r\\n\\t\\tbox-sizing: border-box;\\r\\n\\t\\t/* margin-top: 40px; */\\r\\n\\t}\\r\\n\\r\\n\\tfooter {\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\tjustify-content: center;\\r\\n\\t\\talign-items: center;\\r\\n\\t\\tpadding: 12px;\\r\\n\\t}\\r\\n\\r\\n\\t/* footer a {\\r\\n\\t\\tfont-weight: bold;\\r\\n\\t} */\\r\\n\\r\\n\\t@media (min-width: 480px) {\\r\\n\\t\\tfooter {\\r\\n\\t\\t\\tpadding: 12px 0;\\r\\n\\t\\t}\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA2BC,mBAAK,CACJ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,UAAU,CAAE,KACb,CAEA,mBAAK,CACJ,IAAI,CAAE,CAAC,CACP,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,KAAK,CAAE,IAAI,CAGX,UAAU,CAAE,UAEb,CAcA,MAAO,YAAY,KAAK,CAAE,CAI1B"}`
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<div class="app svelte-11uokw2"><main class="svelte-11uokw2">${slots.default ? slots.default({}) : ``}</main>  </div>`;
});

export { Layout as default };
//# sourceMappingURL=_layout.svelte-JOXOPgOq.js.map
