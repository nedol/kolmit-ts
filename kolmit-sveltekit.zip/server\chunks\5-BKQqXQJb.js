const prerender = false;

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  prerender: prerender
});

async function load({ fetch, cookies, route, url, stuff }) {
  console.log();
}

var _page_server = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 5;
const universal_id = "src/routes/lesson/+page.js";
const server_id = "src/routes/lesson/+page.server.js";
const imports = ["_app/immutable/nodes/5.Bm0xxThf.js"];
const stylesheets = [];
const fonts = [];

export { fonts, imports, index, _page_server as server, server_id, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=5-BKQqXQJb.js.map
