import { D as DEV } from './false-B2gHlHjM.js';

const dev = DEV;
const csr = dev;
const prerender = false;

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  csr: csr,
  prerender: prerender
});

const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DRPokWfl.js')).default;
const universal_id = "src/routes/site/about/+page.js";
const imports = ["_app/immutable/nodes/8.DPGkRTCm.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=8-B6Rdxdfz.js.map
