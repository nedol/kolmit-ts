import { c as create_ssr_component, e as escape } from './ssr2-CjWPy-sK.js';
import './utils-DaVwj2Zu.js';

const css = {
  code: "footer.svelte-15q17qn{display:flex;position:static;flex-direction:column;justify-content:center;align-items:center;padding:12px}",
  map: `{"version":3,"file":"+layout.svelte","sources":["+layout.svelte"],"sourcesContent":["<script>\\r\\n\\tlet level = 'level 1.2';\\r\\n<\/script>\\r\\n\\r\\n<header />\\r\\n<!-- <main>\\r\\n\\t<slot />\\r\\n</main> -->\\r\\n<footer><p>{level}</p></footer>\\r\\n\\r\\n<style>\\r\\n\\tmain {\\r\\n\\t\\tflex: 1;\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\twidth: 100%;\\r\\n\\t\\tmax-width: 64rem;\\r\\n\\t\\tmargin: 0 auto;\\r\\n\\t\\tbox-sizing: border-box;\\r\\n\\t}\\r\\n\\tfooter {\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tposition: static;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\tjustify-content: center;\\r\\n\\t\\talign-items: center;\\r\\n\\t\\tpadding: 12px;\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAoBC,qBAAO,CACN,OAAO,CAAE,IAAI,CACb,QAAQ,CAAE,MAAM,CAChB,cAAc,CAAE,MAAM,CACtB,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,IACV"}`
};
let level = "level 1.2";
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<header></header>  <footer class="svelte-15q17qn"><p>${escape(level)}</p></footer>`;
});

export { Layout as default };
//# sourceMappingURL=_layout.svelte-HdPICp3h.js.map
