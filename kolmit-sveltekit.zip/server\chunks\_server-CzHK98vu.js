import './index-BIAFQWR9.js';
import { r as rtcPool_st } from './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';

rtcPool_st.subscribe((data) => {
  globalThis.rtcPool = data;
});
const config = {
  // runtime: 'edge'
  // isr: {
  // 	expiration: false // 10
  // }
};
async function POST(event) {
  const { par } = await event.request.json();
  const q = par;
  let resp;
  switch (q.func) {
    case "operators":
      break;
    case "callwaiting":
      try {
        let promise = new Promise((resolve, reject) => {
          CallWaiting(q, resolve);
          if (globalThis.rtcPool[q.type][q.abonent][q.operator].resolve_post)
            globalThis.rtcPool[q.type][q.abonent][q.operator].resolve_post();
        });
        resp = await promise;
        globalThis.rtcPool[q.type][q.abonent][q.operator].promise = new Promise((resolve, reject) => {
          globalThis.rtcPool[q.type][q.abonent][q.operator].resolve_post = resolve;
        });
      } catch (ex) {
        console.log("callwaiting" + ex);
      }
      break;
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
function CallWaiting(q, resolve) {
  try {
    if (!globalThis.rtcPool[q.type][q.abonent]) globalThis.rtcPool[q.type][q.abonent] = {};
    if (!globalThis.rtcPool[q.type][q.abonent][q.operator])
      globalThis.rtcPool[q.type][q.abonent][q.operator] = { resolve: "" };
    globalThis.rtcPool[q.type][q.abonent][q.operator].resolve = resolve;
  } catch (e) {
    console.log();
  }
}

export { POST, config };
//# sourceMappingURL=_server-CzHK98vu.js.map
