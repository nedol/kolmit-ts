import { c as GetUsers } from './db-LknqzByu.js';
import pkg from 'lodash';
import 'md5';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

const { find, findKey } = pkg;
async function GET({ url, fetch, cookies }) {
  const abonent = url.searchParams.get("abonent");
  const operator = url.searchParams.get("operator");
  const func = url.searchParams.get("func");
  let resp = {};
  switch (func) {
    case "operators":
      resp = await getOperators({ operator, abonent });
      break;
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}
async function getOperators(q, func) {
  const users = await GetUsers(q);
  let operators = { [q.operator]: {} };
  for (let oper in globalThis.rtcPool["operator"][q.abonent]) {
    const user = find(users.operators, { operator: oper });
    operators[oper] = {
      type: q.type,
      abonent: q.abonent,
      operator: oper,
      status: globalThis.rtcPool["operator"][q.abonent][oper][oper].status ? globalThis.rtcPool["operator"][q.abonent][oper][oper].status : "",
      picture: user.picture,
      name: user.name
    };
  }
  return operators;
}

export { GET };
//# sourceMappingURL=_server-BrA9W1X-.js.map
