const e=Object.freeze(Object.defineProperty({__proto__:null,prerender:!1},Symbol.toStringTag,{value:"Module"}));export{e as universal};
//# sourceMappingURL=5.Bm0xxThf.js.map
