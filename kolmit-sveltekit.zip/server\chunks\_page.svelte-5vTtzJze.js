import { s as subscribe, a as set_store_value, n as null_to_empty, i as is_promise, b as noop, c as compute_rest_props } from './utils-DaVwj2Zu.js';
import { c as create_ssr_component, v as validate_component, s as setContext, g as getContext, e as escape, o as onDestroy, a as add_attribute, b as each, d as get_current_component, f as spread, h as escape_attribute_value, i as escape_object } from './ssr2-CjWPy-sK.js';
import './client-QR49yHlf.js';
import ISO6391 from 'iso-google-locales';
import { T as Translate, a as TopAppBar, R as Row, S as Section$1, b as Title, I as IconButton, C as CommonIcon, c as Item, d as Supporting, e as CommonLabel, P as Paper, f as Card, M as MediaContent, g as Content, A as Accordion, h as Panel, H as Header$1, i as Checkbox, j as Menu, L as List, k as Item$1, l as Text, m as dispatch } from './Checkbox-DH6qE2ah.js';
import { B as Button, f as forwardEventsBuilder, c as classMap, e as exclude, T as Textfield, p as prefixFilter } from './Textfield-CFaEN1yp.js';
import { d as dicts, a as signal, l as langs, i as ice_conf, u as users, e as editable, v as view, b as lesson, c as showBottomAppBar, m as msg, f as call_but_status, g as click_call_func, h as dc_state, p as posterst, j as llang, k as dc, O as OnCheckQU, o as operatorst, n as muted } from './stores-9atq2JWj.js';
import { w as writable, r as readable } from './index2-Iz8xeDhy.js';
import { mdiArrowLeft, mdiMicrophoneOutline, mdiAccountConvertOutline, mdiArrowRight, mdiRepeat, mdiThumbUpOutline, mdiPlay, mdiEarHearing, mdiTranslate, mdiShareVariant, mdiShuffle, mdiTranslateOff, mdiTextBoxCheckOutline, mdiFileWordBoxOutline, mdiTextBoxOutline, mdiAccountMultiple, mdiMicrophone, mdiVolumeHigh, mdiVolumeOff, mdiAccountBox } from '@mdi/js';
import pkg from 'lodash';
import 'md5';
import 'blueimp-load-image/js/load-image.js';
import 'blueimp-load-image/js/load-image-scale.js';
import moment from 'moment';
import 'extendable-media-recorder';
import emojiRegex from 'emoji-regex';
import './exports-DVe6os7E.js';

const google_langs_list = [
  "English",
  "Dutch",
  "German",
  "French",
  "Portuguese",
  "Spanish",
  "Ukrainian",
  "Russian",
  "Afrikaans",
  "Akan",
  "Albanian",
  "Amharic",
  "Arabic",
  "Armenian",
  "Assamese",
  "Aymara",
  "Azerbaijani",
  "Belarusian",
  "Bulgarian",
  "Bihari",
  "Bambara",
  "Bengali",
  "Bosnian",
  "Burmese",
  "Catalan",
  "Chinese",
  "Corsican",
  "Czech",
  "Danish",
  "Divehi",
  "Ewe",
  "Ganda",
  "Georgian",
  "Greek",
  "Esperanto",
  "Estonian",
  "Basque",
  "Persian",
  "Finnish",
  "Irish",
  "Galician",
  "Guaraní",
  "Gujarati",
  "Hausa",
  "Hebrew",
  "Hindi",
  "Chichewa",
  "Croatian",
  "Haitian",
  "Hungarian",
  "Herero",
  "Indonesian",
  "Igbo",
  "Icelandic",
  "Italian",
  "Japanese",
  "Javanese",
  "Kazakh",
  "Kalaallisut",
  "Khmer",
  "Kannada",
  "Korean",
  "Kurdish",
  "Kyrgyz",
  "Latin",
  "Luxembourgish",
  "Lingala",
  "Lao",
  "Lithuanian",
  "Latvian",
  "Malagasy",
  "Māori",
  "Macedonian",
  "Malayalam",
  "Mongolian",
  "Maithili",
  "Marathi",
  "Malay",
  "Maltese",
  "Norwegian Bokmål",
  "Nepali",
  "Norwegian",
  "Occitan",
  "Oromo",
  "Oriya",
  "Panjabi",
  "Polish",
  "Pashto",
  "Quechua",
  "Kirundi",
  "Kinyarwanda",
  "Romanian",
  "Sanskrit",
  "Scottish Gaelic",
  "Sindhi",
  "Sinhala",
  "Slovak",
  "Slovenian",
  "Samoan",
  "Shona",
  "Somali",
  "Serbian",
  "Southern Sotho",
  "Sundanese",
  "Swedish",
  "Swahili",
  "Tamil",
  "Telugu",
  "Tajik",
  "Thai",
  "Tigrinya",
  "Turkmen",
  "Tagalog",
  "Turkish",
  "Tsonga",
  "Tatar",
  "Twi",
  "Tahitian",
  "Uyghur",
  "Urdu",
  "Uzbek",
  "Vietnamese",
  "Xhosa",
  "Yiddish",
  "Yoruba",
  "Zulu",
  "Welsh",
  "Western Frisian",
  "Javanese"
];
const css$j = {
  code: "header.svelte-1wza90m{display:flex;justify-content:space-between;width:100%}.active.svelte-1wza90m{color:#007bff;font-weight:bold}.top-app-bar-container.svelte-1wza90m{top:0;border:1px solid\r\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));margin:0 18px 18px 0;background-color:var(--mdc-theme-background, #fff);overflow:auto;display:inline-block}.level.svelte-1wza90m{position:absolute;font-size:.6em;top:25px;left:10px;color:rgb(148, 35, 35)}.lang_span.svelte-1wza90m{font-size:medium;position:absolute;top:10px;right:20px;border:0px solid aliceblue;padding:5px;border-radius:2px}.lang_list.svelte-1wza90m{position:absolute;right:0;top:50px;height:80vh;overflow:auto;justify-content:center;align-items:center;background-color:white}@media(max-width: 480px){.top-app-bar-container.svelte-1wza90m{margin-right:0}}.flexor.svelte-1wza90m{display:inline-flex;flex-direction:column}.flexor-content.svelte-1wza90m{flex-basis:0;flex-grow:1;overflow:auto}",
  map: `{"version":3,"file":"Header.svelte","sources":["Header.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy, getContext, setContext } from \\"svelte\\";\\nimport { page, navigating, updated } from \\"$app/stores\\";\\nimport langs_list from \\"$lib/dict/google_lang_list.json\\";\\nimport ISO6391 from \\"iso-google-locales\\";\\nimport { Translate } from \\"./translate/Transloc.ts\\";\\nimport List, { Item, Graphic, Separator, Text } from \\"@smui/list\\";\\nimport TopAppBar, { Row, Section, Title, AutoAdjust } from \\"@smui/top-app-bar\\";\\nimport IconButton from \\"@smui/icon-button\\";\\nimport { lesson, view, langs, dicts, users, editable, showBottomAppBar } from \\"$lib/js/stores.js\\";\\n$: if ($editable) {\\n  edited_display = $editable;\\n}\\n$: if ($users) {\\n  console.log($users);\\n}\\nlet menu = \\"menu\\";\\nlet topAppBar;\\nlet abonent = \\"\\";\\nlet lvl = new URL(window.location.href).searchParams.get(\\"lvl\\") || \\"\\";\\nif (!lvl)\\n  lvl = getContext(\\"lvl\\") || \\"\\";\\nonMount(async () => {\\n  let params = new URL(document.location).searchParams;\\n  abonent = params.get(\\"abonent\\");\\n});\\nlet lang_menu = false;\\n$: if ($dicts && !$dicts[\\"CLASS\\"][$langs]) {\\n  (async () => {\\n    try {\\n      $dicts[\\"CLASS\\"][$langs] = await Translate($dicts[\\"CLASS\\"][\\"en\\"], $langs);\\n    } catch (ex) {\\n      let name = ISO6391.getName($langs);\\n      let ind = langs_list.indexOf(name);\\n      if (ind !== -1) {\\n        let ar = langs_list.splice(ind, 1);\\n        $langs = \\"en\\";\\n      }\\n    }\\n  })();\\n}\\n$: if ($dicts && !$dicts[\\"LESSON\\"][$langs]) {\\n  (async () => {\\n    try {\\n      $dicts[\\"LESSON\\"][$langs] = await Translate($dicts[\\"LESSON\\"][\\"en\\"], $langs);\\n    } catch (ex) {\\n      console.log(ex);\\n      $langs = \\"en\\";\\n    }\\n  })();\\n}\\nfunction setLang(ev) {\\n  let lang = ev.currentTarget.outerText;\\n  let code = ISO6391.getCode(lang);\\n  if (code !== \\"English\\") {\\n    $langs = code;\\n  }\\n  lang_menu = false;\\n  fetch(\`./?func=cookie&abonent=\${abonent}&lang=\${$langs}&lvl=\${lvl}\`).then(() => console.log()).catch((error) => {\\n    console.log(error);\\n  });\\n}\\n<\/script>\\r\\n\\r\\n{#if $dicts && $langs && $dicts['CLASS'][$langs]}\\r\\n  <header>\\r\\n    <div class=\\"top-app-bar-container flexor\\">\\r\\n      <TopAppBar bind:this={topAppBar} variant=\\"fixed\\">\\r\\n      \\r\\n        <Row>\\r\\n  \\r\\n            {#if $view !== 'login'}\\r\\n              <Section align=\\"start\\">\\r\\n                <span class=\\"level\\">{lvl}</span>\\r\\n              </Section>\\r\\n              <Section align=\\"start\\">\\r\\n  \\r\\n                <div class={$view !== 'lesson' ? 'active' : ''}>               \\r\\n                  <Title\\r\\n                    on:click={() => {\\r\\n                      if ($lesson.data?.quiz) {\\r\\n                        // if (confirm(data)) {\\r\\n                          // $view = 'group';\\r\\n                          // $showBottomAppBar = true;\\r\\n                        // }\\r\\n                      } else {\\r\\n                        $view = 'group';\\r\\n                        $showBottomAppBar = true;\\r\\n                      }\\r\\n                    }}\\r\\n                  >\\r\\n               \\r\\n                  {#await Translate('КЛАСС', 'ru', $langs) then data}\\r\\n                    <span>{data.toUpperCase()}</span>\\r\\n                  {/await}\\r\\n                    \\r\\n                    <span >{Object.keys($users).length>0?\`(\${Object.keys($users).length})\`:''}</span>\\r\\n\\r\\n                  </Title>\\r\\n                </div>\\r\\n     \\r\\n              </Section>\\r\\n              <Section>\\r\\n                \\r\\n                <div class={$view === 'lesson' ? 'active' : ''}>\\r\\n                  {#await Translate('Quit the exercise?', 'en', $langs) then data}\\r\\n                  <Title\\r\\n                    on:click={async () => {\\r\\n                      if ($lesson.data?.quiz) {\\r\\n                       \\r\\n                        if (confirm(data)) {\\r\\n                          $lesson.data = { quiz: '' };\\r\\n                          $view = 'lesson';\\r\\n                          $showBottomAppBar = true;\\r\\n                        }\\r\\n                       \\r\\n                      } else {\\r\\n                        $lesson.data = { quiz: '' };\\r\\n                        $view = 'lesson';\\r\\n                        $showBottomAppBar = true;\\r\\n                      }\\r\\n                    }}\\r\\n                  >\\r\\n                    {#await Translate('УРОК', 'ru', $langs) then data}\\r\\n                       <span>{data.toUpperCase()}</span>\\r\\n                    {/await}\\r\\n                  </Title>\\r\\n                  {/await}\\r\\n                </div>\\r\\n                \\r\\n      \\r\\n                <!-- <IconButton class=\\"material-icons\\" aria-label=\\"Bookmark this page\\">bookmark</IconButton> -->\\r\\n              </Section>\\r\\n              <Section align=\\"end\\">\\r\\n                <span\\r\\n                class=\\"lang_span\\"\\r\\n                on:click={() => {\\r\\n                  lang_menu = !lang_menu;\\r\\n                }}\\r\\n                >{(() => {\\r\\n                  return $langs;\\r\\n                })()}</span\\r\\n              >\\r\\n              {#if lang_menu}\\r\\n                <div class=\\"lang_list\\">\\r\\n                  {#each langs_list as lang}\\r\\n                    <div\\r\\n                      style=\\"color:black;width:min-content; margin:10px;font-size:smaller\\"\\r\\n                      on:click={setLang}\\r\\n                    >\\r\\n                      {lang}\\r\\n                    </div>\\r\\n                  {/each}\\r\\n                </div>\\r\\n              {/if}\\r\\n              </Section>\\r\\n            {/if}\\r\\n      \\r\\n\\r\\n\\r\\n\\r\\n    </Row>\\r\\n      </TopAppBar>\\r\\n      <div class=\\"flexor-content\\"></div>\\r\\n    </div>\\r\\n  </header>\\r\\n{/if}\\r\\n\\r\\n<style>\\r\\n  header {\\r\\n    display: flex;\\r\\n    justify-content: space-between;\\r\\n    width: 100%;\\r\\n  }\\r\\n\\r\\n  .active {\\r\\n  color: #007bff; /* Выбранный цвет */\\r\\n  font-weight: bold;\\r\\n}\\r\\n\\r\\n\\r\\n  .top-app-bar-container {\\r\\n    top: 0;\\r\\n    border: 1px solid\\r\\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));\\r\\n    margin: 0 18px 18px 0;\\r\\n    background-color: var(--mdc-theme-background, #fff);\\r\\n    overflow: auto;\\r\\n    display: inline-block;\\r\\n  }\\r\\n\\r\\n  .level{\\r\\n    position: absolute;\\r\\n    font-size: .6em;\\r\\n    top:25px;\\r\\n    left: 10px;\\r\\n    color: rgb(148, 35, 35);\\r\\n  }\\r\\n\\r\\n  .lang_span {\\r\\n    font-size: medium;\\r\\n    position: absolute;\\r\\n    top: 10px;\\r\\n    right: 20px;\\r\\n    border: 0px solid aliceblue;\\r\\n    padding: 5px;\\r\\n    border-radius: 2px;\\r\\n  }\\r\\n\\r\\n  .lang_list {\\r\\n    position: absolute;\\r\\n    right: 0;\\r\\n    top: 50px;\\r\\n    height: 80vh;\\r\\n    overflow: auto;\\r\\n    justify-content: center; /* Выравниваем содержимое по центру вертикально */\\r\\n    align-items: center; /* Выравниваем содержимое по центру горизонтально */\\r\\n    background-color: white;\\r\\n    /* opacity: 50%; */\\r\\n  }\\r\\n\\r\\n  img {\\r\\n    width: 30px;\\r\\n    opacity: 100%;\\r\\n  }\\r\\n\\r\\n  /* .sec_items {\\r\\n    position: absolute;\\r\\n    top: 40%;\\r\\n    left: 50%;\\r\\n    transform: translate(-50%, -50%);\\r\\n  } */\\r\\n\\r\\n\\r\\n  button.sec_right {\\r\\n    left: 100px;\\r\\n  }\\r\\n\\r\\n  @media (max-width: 480px) {\\r\\n    .top-app-bar-container {\\r\\n      margin-right: 0;\\r\\n    }\\r\\n  }\\r\\n\\r\\n  .flexy {\\r\\n    display: flex;\\r\\n    flex-wrap: wrap;\\r\\n  }\\r\\n\\r\\n  .flexor {\\r\\n    display: inline-flex;\\r\\n    flex-direction: column;\\r\\n  }\\r\\n\\r\\n  .flexor-content {\\r\\n    flex-basis: 0;\\r\\n    /* height: 100vh; */\\r\\n    flex-grow: 1;\\r\\n    overflow: auto;\\r\\n  }\\r\\n\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAwKE,qBAAO,CACL,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,aAAa,CAC9B,KAAK,CAAE,IACT,CAEA,sBAAQ,CACR,KAAK,CAAE,OAAO,CACd,WAAW,CAAE,IACf,CAGE,qCAAuB,CACrB,GAAG,CAAE,CAAC,CACN,MAAM,CAAE,GAAG,CAAC,KAAK;AACrB,MAAM,IAAI,mCAAmC,CAAC,mBAAmB,CAAC,CAC9D,MAAM,CAAE,CAAC,CAAC,IAAI,CAAC,IAAI,CAAC,CAAC,CACrB,gBAAgB,CAAE,IAAI,sBAAsB,CAAC,KAAK,CAAC,CACnD,QAAQ,CAAE,IAAI,CACd,OAAO,CAAE,YACX,CAEA,qBAAM,CACJ,QAAQ,CAAE,QAAQ,CAClB,SAAS,CAAE,IAAI,CACf,IAAI,IAAI,CACR,IAAI,CAAE,IAAI,CACV,KAAK,CAAE,IAAI,GAAG,CAAC,CAAC,EAAE,CAAC,CAAC,EAAE,CACxB,CAEA,yBAAW,CACT,SAAS,CAAE,MAAM,CACjB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CACT,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,SAAS,CAC3B,OAAO,CAAE,GAAG,CACZ,aAAa,CAAE,GACjB,CAEA,yBAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,CAAC,CACR,GAAG,CAAE,IAAI,CACT,MAAM,CAAE,IAAI,CACZ,QAAQ,CAAE,IAAI,CACd,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,gBAAgB,CAAE,KAEpB,CAmBA,MAAO,YAAY,KAAK,CAAE,CACxB,qCAAuB,CACrB,YAAY,CAAE,CAChB,CACF,CAOA,sBAAQ,CACN,OAAO,CAAE,WAAW,CACpB,cAAc,CAAE,MAClB,CAEA,8BAAgB,CACd,UAAU,CAAE,CAAC,CAEb,SAAS,CAAE,CAAC,CACZ,QAAQ,CAAE,IACZ"}`
};
const Header = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $dicts, $$unsubscribe_dicts;
  let $users, $$unsubscribe_users;
  let $editable, $$unsubscribe_editable;
  let $view, $$unsubscribe_view;
  let $$unsubscribe_lesson;
  let $$unsubscribe_showBottomAppBar;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  $$unsubscribe_users = subscribe(users, (value) => $users = value);
  $$unsubscribe_editable = subscribe(editable, (value) => $editable = value);
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => value);
  $$unsubscribe_showBottomAppBar = subscribe(showBottomAppBar, (value) => value);
  let topAppBar;
  let lvl = new URL(window.location.href).searchParams.get("lvl") || "";
  if (!lvl) lvl = getContext("lvl") || "";
  $$result.css.add(css$j);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($editable) {
        edited_display = $editable;
      }
    }
    {
      if ($users) {
        console.log($users);
      }
    }
    {
      if ($dicts && !$dicts["CLASS"][$langs]) {
        (async () => {
          try {
            set_store_value(dicts, $dicts["CLASS"][$langs] = await Translate($dicts["CLASS"]["en"], $langs), $dicts);
          } catch (ex) {
            let name = ISO6391.getName($langs);
            let ind = google_langs_list.indexOf(name);
            if (ind !== -1) {
              google_langs_list.splice(ind, 1);
              set_store_value(langs, $langs = "en", $langs);
            }
          }
        })();
      }
    }
    {
      if ($dicts && !$dicts["LESSON"][$langs]) {
        (async () => {
          try {
            set_store_value(dicts, $dicts["LESSON"][$langs] = await Translate($dicts["LESSON"]["en"], $langs), $dicts);
          } catch (ex) {
            console.log(ex);
            set_store_value(langs, $langs = "en", $langs);
          }
        })();
      }
    }
    $$rendered = `${$dicts && $langs && $dicts["CLASS"][$langs] ? `<header class="svelte-1wza90m"><div class="top-app-bar-container flexor svelte-1wza90m">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      { variant: "fixed", this: topAppBar },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `${$view !== "login" ? `${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<span class="level svelte-1wza90m">${escape(lvl)}</span>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<div class="${escape(null_to_empty($view !== "lesson" ? "active" : ""), true) + " svelte-1wza90m"}">${validate_component(Title, "Title").$$render($$result, {}, {}, {
                    default: () => {
                      return `${function(__value) {
                        if (is_promise(__value)) {
                          __value.then(null, noop);
                          return ``;
                        }
                        return function(data) {
                          return ` <span>${escape(data.toUpperCase())}</span> `;
                        }(__value);
                      }(Translate("КЛАСС", "ru", $langs))} <span>${escape(Object.keys($users).length > 0 ? `(${Object.keys($users).length})` : "")}</span>`;
                    }
                  })}</div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return `<div class="${escape(null_to_empty($view === "lesson" ? "active" : ""), true) + " svelte-1wza90m"}">${function(__value) {
                    if (is_promise(__value)) {
                      __value.then(null, noop);
                      return ``;
                    }
                    return function(data) {
                      return ` ${validate_component(Title, "Title").$$render($$result, {}, {}, {
                        default: () => {
                          return `${function(__value2) {
                            if (is_promise(__value2)) {
                              __value2.then(null, noop);
                              return ``;
                            }
                            return function(data2) {
                              return ` <span>${escape(data2.toUpperCase())}</span> `;
                            }(__value2);
                          }(Translate("УРОК", "ru", $langs))}`;
                        }
                      })} `;
                    }();
                  }(Translate("Quit the exercise?", "en", $langs))}</div> `;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<span class="lang_span svelte-1wza90m">${escape(/* @__PURE__ */ (() => {
                    return $langs;
                  })())}</span> ${``}`;
                }
              })}` : ``}`;
            }
          })}`;
        }
      }
    )} <div class="flexor-content svelte-1wza90m"></div></div></header>` : ``}`;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_dicts();
  $$unsubscribe_users();
  $$unsubscribe_editable();
  $$unsubscribe_view();
  $$unsubscribe_lesson();
  $$unsubscribe_showBottomAppBar();
  return $$rendered;
});
const BottomAppBar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["use", "class", "style", "color", "variant", "getPropStore", "getElement"]);
  let $colorStore, $$unsubscribe_colorStore;
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { style = "" } = $$props;
  let { color = "primary" } = $$props;
  let { variant = "standard" } = $$props;
  let element;
  let internalStyles = {};
  const colorStore = writable(color);
  $$unsubscribe_colorStore = subscribe(colorStore, (value) => $colorStore = value);
  let withFab = false;
  let adjustOffset = 0;
  setContext("SMUI:bottom-app-bar:color", colorStore);
  let propStoreSet;
  let propStore = readable({ withFab, adjustOffset, variant }, (set) => {
    propStoreSet = set;
  });
  function getPropStore() {
    return propStore;
  }
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.style === void 0 && $$bindings.style && style !== void 0) $$bindings.style(style);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0) $$bindings.color(color);
  if ($$props.variant === void 0 && $$bindings.variant && variant !== void 0) $$bindings.variant(variant);
  if ($$props.getPropStore === void 0 && $$bindings.getPropStore && getPropStore !== void 0) $$bindings.getPropStore(getPropStore);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  set_store_value(colorStore, $colorStore = color, $colorStore);
  {
    if (propStoreSet) {
      propStoreSet({ withFab, adjustOffset, variant });
    }
  }
  $$unsubscribe_colorStore();
  return ` <div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "smui-bottom-app-bar": true,
          "smui-bottom-app-bar--standard": variant === "standard",
          "smui-bottom-app-bar--fixed": variant === "fixed"
        }))
      },
      {
        style: escape_attribute_value(Object.entries(internalStyles).map(([name, value]) => `${name}: ${value};`).concat([style]).join(" "))
      },
      escape_object($$restProps)
    ],
    {}
  )}${add_attribute("this", element, 0)}>${slots.default ? slots.default({}) : ``} </div>`;
});
const Section = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let usePass;
  let $$restProps = compute_rest_props($$props, ["use", "class", "fabInset", "getElement"]);
  let $color, $$unsubscribe_color;
  const forwardEvents = forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { fabInset = false } = $$props;
  let element;
  const color = getContext("SMUI:bottom-app-bar:color");
  $$unsubscribe_color = subscribe(color, (value) => $color = value);
  function getElement() {
    return element.getElement();
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.fabInset === void 0 && $$bindings.fabInset && fabInset !== void 0) $$bindings.fabInset(fabInset);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    usePass = [forwardEvents, ...use];
    $$rendered = `${validate_component(Paper, "Paper").$$render(
      $$result,
      Object.assign(
        {},
        { use: usePass },
        {
          class: classMap({
            [className]: true,
            "smui-bottom-app-bar__section": true,
            "smui-bottom-app-bar__section--fab-inset": fabInset
          })
        },
        { color: $color },
        { variant: "unelevated" },
        { square: true },
        $$restProps,
        { this: element }
      ),
      {
        this: ($$value) => {
          element = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${slots.default ? slots.default({}) : ``}`;
        }
      }
    )}`;
  } while (!$$settled);
  $$unsubscribe_color();
  return $$rendered;
});
const CircularProgress = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["use", "class", "indeterminate", "closed", "progress", "fourColor", "getElement"]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { indeterminate = false } = $$props;
  let { closed = false } = $$props;
  let { progress = 0 } = $$props;
  let { fourColor = false } = $$props;
  let element;
  let internalClasses = {};
  let internalAttrs = {};
  let determinateCircleAttrs = {};
  let determinateCircle;
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.indeterminate === void 0 && $$bindings.indeterminate && indeterminate !== void 0) $$bindings.indeterminate(indeterminate);
  if ($$props.closed === void 0 && $$bindings.closed && closed !== void 0) $$bindings.closed(closed);
  if ($$props.progress === void 0 && $$bindings.progress && progress !== void 0) $$bindings.progress(progress);
  if ($$props.fourColor === void 0 && $$bindings.fourColor && fourColor !== void 0) $$bindings.fourColor(fourColor);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  return `<div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "mdc-circular-progress": true,
          "mdc-circular-progress--indeterminate": indeterminate,
          "mdc-circular-progress--closed": closed,
          ...internalClasses
        }))
      },
      { role: "progressbar" },
      {
        "aria-valuemin": escape_attribute_value(0)
      },
      {
        "aria-valuemax": escape_attribute_value(1)
      },
      {
        "aria-valuenow": escape_attribute_value(indeterminate ? void 0 : progress)
      },
      escape_object(internalAttrs),
      escape_object($$restProps)
    ],
    {}
  )}${add_attribute("this", element, 0)}><div class="mdc-circular-progress__determinate-container"><svg class="mdc-circular-progress__determinate-circle-graphic" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><circle class="mdc-circular-progress__determinate-track" cx="24" cy="24" r="18" stroke-width="4"></circle><circle${spread(
    [
      {
        class: "mdc-circular-progress__determinate-circle"
      },
      { cx: "24" },
      { cy: "24" },
      { r: "18" },
      { "stroke-dasharray": "113.097" },
      { "stroke-dashoffset": "113.097" },
      { "stroke-width": "4" },
      escape_object(determinateCircleAttrs)
    ],
    {}
  )}${add_attribute("this", determinateCircle, 0)}></circle></svg></div> <div class="mdc-circular-progress__indeterminate-container">${each(fourColor ? [1, 2, 3, 4] : [1], (color) => {
    return `<div${add_attribute(
      "class",
      classMap({
        [className]: true,
        "mdc-circular-progress__spinner-layer": true,
        ["mdc-circular-progress__color-" + color]: fourColor
      }),
      0
    )}><div class="mdc-circular-progress__circle-clipper mdc-circular-progress__circle-left" data-svelte-h="svelte-1d4f91x"><svg class="mdc-circular-progress__indeterminate-circle-graphic" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="18" stroke-dasharray="113.097" stroke-dashoffset="56.549" stroke-width="4"></circle></svg></div> <div class="mdc-circular-progress__gap-patch" data-svelte-h="svelte-qvm4qv"><svg class="mdc-circular-progress__indeterminate-circle-graphic" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="18" stroke-dasharray="113.097" stroke-dashoffset="56.549" stroke-width="3.2"></circle></svg></div> <div class="mdc-circular-progress__circle-clipper mdc-circular-progress__circle-right" data-svelte-h="svelte-c3k2p4"><svg class="mdc-circular-progress__indeterminate-circle-graphic" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="18" stroke-dasharray="113.097" stroke-dashoffset="56.549" stroke-width="4"></circle></svg></div> </div>`;
  })}</div> </div>`;
});
const Media = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["use", "class", "aspectRatio", "getElement"]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { aspectRatio = void 0 } = $$props;
  let element;
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.aspectRatio === void 0 && $$bindings.aspectRatio && aspectRatio !== void 0) $$bindings.aspectRatio(aspectRatio);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  return `<div${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "mdc-card__media": true,
          "mdc-card__media--square": aspectRatio === "square",
          "mdc-card__media--16-9": aspectRatio === "16x9"
        }))
      },
      escape_object($$restProps)
    ],
    {}
  )}${add_attribute("this", element, 0)}>${slots.default ? slots.default({}) : ``} </div>`;
});
const poster = "/_app/immutable/assets/tutor.Dw8pvcdV.png";
const css$i = {
  code: "video.svelte-rq0s7q{display:block;margin-right:auto;margin-left:auto;margin-top:auto;max-width:65px;max-height:65px}.card-display.svelte-rq0s7q{position:relative}",
  map: `{"version":3,"file":"Tutor.svelte","sources":["Tutor.svelte"],"sourcesContent":["<script>\\r\\n  import { getContext, onMount } from 'svelte';\\r\\n  import Card, {\\r\\n    Content,\\r\\n    PrimaryAction,\\r\\n    Media,\\r\\n    MediaContent,\\r\\n  } from '@smui/card';\\r\\n\\r\\n  import CallButtonUser from './CallButtonUser.svelte';\\r\\n  import { view } from '$lib/js/stores.js';\\r\\n\\r\\n  export let abonent, operator, name;\\r\\n\\r\\n  import poster from '$lib/images/tutor.png';\\r\\n\\r\\n  import { users, call_but_status, click_call_func} from '$lib/js/stores.js';\\r\\n\\r\\n  $click_call_func = null;\\r\\n\\r\\n  import pkg from 'lodash';\\r\\n  const { groupBy, find } = pkg;\\r\\n\\r\\n  let checked = false;\\r\\n\\r\\n  let rtc;\\r\\n\\r\\n  let call_cnt;\\r\\n  let selected,\\r\\n    inter,\\r\\n    status = 'inactive',\\r\\n    profile = false,\\r\\n    card;\\r\\n\\r\\n  let video_button_display = false;\\r\\n  let video_element, parent_div;\\r\\n\\r\\n  $: if (status && operator) {\\r\\n     $users[operator].status = status;\\r\\n  }\\r\\n\\r\\n  let progress = {\\r\\n    display: 'none',\\r\\n    value: 0,\\r\\n  };\\r\\n\\r\\n  let video = {\\r\\n    display: 'none',\\r\\n  };\\r\\n\\r\\n  let local = {\\r\\n    video: {\\r\\n      display: 'none',\\r\\n      srcObject: '',\\r\\n    },\\r\\n    audio: {\\r\\n      paused: true,\\r\\n      src: '',\\r\\n    },\\r\\n  };\\r\\n\\r\\n  let remote = {\\r\\n    video: {\\r\\n      display: 'block',\\r\\n      srcObject: '',\\r\\n      poster: poster,\\r\\n    },\\r\\n  };\\r\\n\\r\\n  let select = {\\r\\n    display: false,\\r\\n  };\\r\\n\\r\\n  let user = {\\r\\n    operator: operator,\\r\\n    abonent: abonent,\\r\\n    type: 'user',\\r\\n  };\\r\\n\\r\\n  onMount(async () => {\\r\\n    // $call_but_status = status;\\r\\n  });\\r\\n\\r\\n  // onDestroy();\\r\\n\\r\\n  function OnLongPress() {\\r\\n    select.display = true;\\r\\n  }\\r\\n\\r\\n  function OnMessage(data) {\\r\\n    if (data.operators && data.operators[operator]) {\\r\\n      let res = groupBy(data.operators[operator], 'status');\\r\\n      try {\\r\\n        if (res && res['offer']) {\\r\\n          if (status !== 'call') {\\r\\n            status = 'active';\\r\\n            // $call_but_status = 'active';\\r\\n          }\\r\\n        } else if (res['busy']) {\\r\\n          // if ($click_call_func === null)\\r\\n          if (\\r\\n            !rtc.DC ||\\r\\n            (rtc.DC &&\\r\\n              rtc.DC.dc.readyState !== 'open' &&\\r\\n              rtc.DC.dc.readyState !== 'connecting')\\r\\n          )\\r\\n            status = 'busy';\\r\\n        } else if (res['close']) {\\r\\n          local.video.display = 'none';\\r\\n          // remote.video.display = 'none';\\r\\n          local.audio.paused = true;\\r\\n\\r\\n          //rtc.abonent = url.searchParams.get('abonent');\\r\\n          status = 'inactive';\\r\\n          // $call_but_status = 'inactive';\\r\\n          $click_call_func = null; //operator -> OnClickCallButton\\r\\n          parent_div.appendChild(card);\\r\\n          rtc.OnInactive();\\r\\n          video_element.src = '';\\r\\n        }\\r\\n      } catch (ex) {\\r\\n        console.log(ex);\\r\\n      }\\r\\n    }\\r\\n\\r\\n    if (data.operator && data.operator.operator === rtc.operator) {\\r\\n      status = 'active';\\r\\n      // $call_but_status = 'active';\\r\\n    }\\r\\n\\r\\n    // TODO: to delete\\r\\n    if (data.desc && data.cand) {\\r\\n      if (status === 'talk') {\\r\\n        // status = 'talk';\\r\\n      } else {\\r\\n        // status = 'call';\\r\\n      }\\r\\n    }\\r\\n\\r\\n    if (data.func === 'call') {\\r\\n      remote.video.muted = true;\\r\\n    }\\r\\n\\r\\n    if (data.func === 'mute') {\\r\\n      local.audio.paused = true;\\r\\n\\r\\n      video_button_display = false;\\r\\n      local.video.display = 'none';\\r\\n      // remote.video.display = 'none';\\r\\n      // rtc.abonent = url.searchParams.get('abonent');\\r\\n      status = 'inactive';\\r\\n      $call_but_status = 'inactive';\\r\\n      $click_call_func = null; //operator -> OnClickCallButton\\r\\n      parent_div.appendChild(card);\\r\\n      // video_element.load();\\r\\n    }\\r\\n\\r\\n    if (data.func === 'talk') {\\r\\n      console.log('user talk', data.operator);\\r\\n      if (data.operator === operator) {\\r\\n        $call_but_status = 'talk';\\r\\n        status = 'talk';\\r\\n        video_button_display = true;\\r\\n        local.audio.paused = true;\\r\\n        remote.video.muted = false;\\r\\n        video_button_display = 'block';\\r\\n        // local.video.display = \\"block\\";\\r\\n        remote.video.display = 'block';\\r\\n      }\\r\\n    }\\r\\n\\r\\n    if (data.func === 'redirect') {\\r\\n      status = 'call';\\r\\n      // $call_but_status = 'call';\\r\\n      local.audio.paused = true;\\r\\n\\r\\n      remote.video.srcObject = null;\\r\\n      remote.video.display = 'none';\\r\\n    }\\r\\n\\r\\n    // $call_but_status = status;\\r\\n  }\\r\\n\\r\\n  let SetDlgDisplay = getContext('SetDlgDisplay');\\r\\n\\r\\n  let OnClickCallButton = function (ev, email) {\\r\\n    SetDlgDisplay();\\r\\n  };\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"card-display\\" bind:this={parent_div}>\\r\\n  <div class=\\"card-container\\" bind:this={card}>\\r\\n    <!-- <Card style=\\"min-width: 50px;\\"> -->\\r\\n\\r\\n    <video\\r\\n      class=\\"user_video_remote\\"\\r\\n      bind:this={video_element}\\r\\n      on:click\\r\\n      {poster}\\r\\n      autoplay\\r\\n      playsinline\\r\\n      on:click={OnClickCallButton}\\r\\n    >\\r\\n      <track kind=\\"captions\\" />\\r\\n    </video>\\r\\n  </div>\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n  video {\\r\\n    display: block;\\r\\n    margin-right: auto;\\r\\n    margin-left: auto;\\r\\n    margin-top: auto;\\r\\n    max-width: 65px;\\r\\n    max-height: 65px;\\r\\n  }\\r\\n\\r\\n  .card-display {\\r\\n    position: relative;\\r\\n    /* bottom: 70px; */\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAiNE,mBAAM,CACJ,OAAO,CAAE,KAAK,CACd,YAAY,CAAE,IAAI,CAClB,WAAW,CAAE,IAAI,CACjB,UAAU,CAAE,IAAI,CAChB,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,IACd,CAEA,2BAAc,CACZ,QAAQ,CAAE,QAEZ"}`
};
const Tutor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_call_but_status;
  let $click_call_func, $$unsubscribe_click_call_func;
  let $users, $$unsubscribe_users;
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => value);
  $$unsubscribe_click_call_func = subscribe(click_call_func, (value) => $click_call_func = value);
  $$unsubscribe_users = subscribe(users, (value) => $users = value);
  let { abonent, operator, name } = $$props;
  set_store_value(click_call_func, $click_call_func = null, $click_call_func);
  const { groupBy, find } = pkg;
  let status = "inactive", card;
  let video_element, parent_div;
  getContext("SetDlgDisplay");
  if ($$props.abonent === void 0 && $$bindings.abonent && abonent !== void 0) $$bindings.abonent(abonent);
  if ($$props.operator === void 0 && $$bindings.operator && operator !== void 0) $$bindings.operator(operator);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0) $$bindings.name(name);
  $$result.css.add(css$i);
  {
    if (operator) {
      set_store_value(users, $users[operator].status = status, $users);
    }
  }
  $$unsubscribe_call_but_status();
  $$unsubscribe_click_call_func();
  $$unsubscribe_users();
  return `<div class="card-display svelte-rq0s7q"${add_attribute("this", parent_div, 0)}><div class="card-container"${add_attribute("this", card, 0)}> <video class="user_video_remote svelte-rq0s7q"${add_attribute("poster", poster, 0)} autoplay playsinline${add_attribute("this", video_element, 0)} data-svelte-h="svelte-bpp899"><track kind="captions"></video></div> </div>`;
});
const css$h = {
  code: ".card-container.svelte-hamr0z{position:relative;scale:1;top:10px;left:0px;height:70px;width:70px;margin:0 auto}video.svelte-hamr0z{display:block;margin-right:auto;margin-left:auto;margin-top:5px;max-height:70%}[status='call'].svelte-hamr0z{opacity:1}[status='talk'].svelte-hamr0z{opacity:1}[status='muted'].svelte-hamr0z{opacity:0.05}[status='inactive'].svelte-hamr0z{opacity:0.05}[status='active'].svelte-hamr0z{opacity:1}[status='busy'].svelte-hamr0z{opacity:0.05}",
  map: `{"version":3,"file":"Video.remote.svelte","sources":["Video.remote.svelte"],"sourcesContent":["<script>\\r\\n  import { onMount } from 'svelte';\\r\\n  import Card, {\\r\\n    Content,\\r\\n    PrimaryAction,\\r\\n    Media,\\r\\n    MediaContent,\\r\\n  } from '@smui/card';\\r\\n  import { muted } from '$lib/js/stores.js';\\r\\n  export let srcObject;\\r\\n  export let poster;\\r\\n  export let status;\\r\\n\\r\\n  export let video_element, card;\\r\\n  export let parent_div;\\r\\n  export let name, operator;\\r\\n  let rv;\\r\\n\\r\\n  onMount(async () => {\\r\\n    rv = video_element;\\r\\n  });\\r\\n\\r\\n  $: if (rv && srcObject) {\\r\\n    rv.srcObject = srcObject;\\r\\n  } else if (rv && rv.srcObject) {\\r\\n    rv.srcObject.getVideoTracks().forEach((track) => {\\r\\n      track.stop();\\r\\n      rv.srcObject.removeTrack(track);\\r\\n    });\\r\\n    rv.src = '';\\r\\n  }\\r\\n\\r\\n  $: if (status) {\\r\\n    console.log(status);\\r\\n  }\\r\\n\\r\\n  $: if (status === 'talk') {\\r\\n    $muted = false;\\r\\n  } else {\\r\\n    $muted = true;\\r\\n  }\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"card-display\\" bind:this={parent_div}>\\r\\n  <div class=\\"card-container\\" bind:this={card}>\\r\\n    <Card style=\\"min-width: 50px;\\">\\r\\n      <Media class=\\"card-media-square\\" aspectRatio=\\"square\\">\\r\\n        <MediaContent>\\r\\n          <video\\r\\n            class=\\"user_video_remote\\"\\r\\n            bind:this={video_element}\\r\\n            on:click    \\r\\n            muted={$muted}\\r\\n            {status}\\r\\n            {poster}\\r\\n            autoplay\\r\\n            playsinline\\r\\n          >\\r\\n            <track kind=\\"captions\\" />\\r\\n          </video>\\r\\n        </MediaContent>\\r\\n      </Media>\\r\\n      <!-- <Content style=\\"color: #888; font-size:smaller\\">{name}</Content> -->\\r\\n    </Card>\\r\\n  </div>\\r\\n</div>\\r\\n<slot name=\\"mute_button\\" />\\r\\n\\r\\n<style>\\r\\n  .card-container {\\r\\n    position: relative;\\r\\n    scale: 1;\\r\\n    top: 10px;\\r\\n    left: 0px;\\r\\n    height: 70px;\\r\\n    width: 70px;\\r\\n    margin: 0 auto;\\r\\n  }\\r\\n  video {\\r\\n    display: block;\\r\\n    margin-right: auto;\\r\\n    margin-left: auto;\\r\\n    margin-top: 5px;\\r\\n    max-height: 70%;\\r\\n  }\\r\\n  [status='call'] {\\r\\n    opacity: 1;\\r\\n  }\\r\\n  [status='talk'] {\\r\\n    opacity: 1;\\r\\n  }\\r\\n  [status='muted'] {\\r\\n    opacity: 0.05;\\r\\n  }\\r\\n  [status='inactive'] {\\r\\n    opacity: 0.05;\\r\\n  }\\r\\n  [status='active'] {\\r\\n    opacity: 1;\\r\\n  }\\r\\n  [status='busy'] {\\r\\n    opacity: 0.05;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAqEE,6BAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,CAAC,CACR,GAAG,CAAE,IAAI,CACT,IAAI,CAAE,GAAG,CACT,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,CAAC,CAAC,IACZ,CACA,mBAAM,CACJ,OAAO,CAAE,KAAK,CACd,YAAY,CAAE,IAAI,CAClB,WAAW,CAAE,IAAI,CACjB,UAAU,CAAE,GAAG,CACf,UAAU,CAAE,GACd,CACA,CAAC,MAAM,CAAC,MAAM,eAAE,CACd,OAAO,CAAE,CACX,CACA,CAAC,MAAM,CAAC,MAAM,eAAE,CACd,OAAO,CAAE,CACX,CACA,CAAC,MAAM,CAAC,OAAO,eAAE,CACf,OAAO,CAAE,IACX,CACA,CAAC,MAAM,CAAC,UAAU,eAAE,CAClB,OAAO,CAAE,IACX,CACA,CAAC,MAAM,CAAC,QAAQ,eAAE,CAChB,OAAO,CAAE,CACX,CACA,CAAC,MAAM,CAAC,MAAM,eAAE,CACd,OAAO,CAAE,IACX"}`
};
const Video_remote$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $muted, $$unsubscribe_muted;
  $$unsubscribe_muted = subscribe(muted, (value) => $muted = value);
  let { srcObject } = $$props;
  let { poster: poster2 } = $$props;
  let { status } = $$props;
  let { video_element, card } = $$props;
  let { parent_div } = $$props;
  let { name, operator } = $$props;
  if ($$props.srcObject === void 0 && $$bindings.srcObject && srcObject !== void 0) $$bindings.srcObject(srcObject);
  if ($$props.poster === void 0 && $$bindings.poster && poster2 !== void 0) $$bindings.poster(poster2);
  if ($$props.status === void 0 && $$bindings.status && status !== void 0) $$bindings.status(status);
  if ($$props.video_element === void 0 && $$bindings.video_element && video_element !== void 0) $$bindings.video_element(video_element);
  if ($$props.card === void 0 && $$bindings.card && card !== void 0) $$bindings.card(card);
  if ($$props.parent_div === void 0 && $$bindings.parent_div && parent_div !== void 0) $$bindings.parent_div(parent_div);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0) $$bindings.name(name);
  if ($$props.operator === void 0 && $$bindings.operator && operator !== void 0) $$bindings.operator(operator);
  $$result.css.add(css$h);
  {
    if (status) {
      console.log(status);
    }
  }
  {
    if (status === "talk") {
      set_store_value(muted, $muted = false, $muted);
    } else {
      set_store_value(muted, $muted = true, $muted);
    }
  }
  $$unsubscribe_muted();
  return `<div class="card-display"${add_attribute("this", parent_div, 0)}><div class="card-container svelte-hamr0z"${add_attribute("this", card, 0)}>${validate_component(Card, "Card").$$render($$result, { style: "min-width: 50px;" }, {}, {
    default: () => {
      return `${validate_component(Media, "Media").$$render(
        $$result,
        {
          class: "card-media-square",
          aspectRatio: "square"
        },
        {},
        {
          default: () => {
            return `${validate_component(MediaContent, "MediaContent").$$render($$result, {}, {}, {
              default: () => {
                return `<video class="user_video_remote svelte-hamr0z" ${$muted ? "muted" : ""}${add_attribute("status", status, 0)}${add_attribute("poster", poster2, 0)} autoplay playsinline${add_attribute("this", video_element, 0)}><track kind="captions"></video>`;
              }
            })}`;
          }
        }
      )} `;
    }
  })}</div></div> ${slots.mute_button ? slots.mute_button({}) : ``}`;
});
const call = "/_app/immutable/assets/call.C8lmx5LD.mp3";
const Audio_local$1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { paused = true } = $$props;
  let ls;
  if ($$props.paused === void 0 && $$bindings.paused && paused !== void 0) $$bindings.paused(paused);
  return `<audio loop${add_attribute("src", call, 0)}${add_attribute("this", ls, 0)} data-svelte-h="svelte-zfqvhd"><track kind="captions"></audio>`;
});
const User = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $users, $$unsubscribe_users;
  let $call_but_status, $$unsubscribe_call_but_status;
  let $posterst, $$unsubscribe_posterst;
  let $click_call_func, $$unsubscribe_click_call_func;
  $$unsubscribe_users = subscribe(users, (value) => $users = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  $$unsubscribe_posterst = subscribe(posterst, (value) => $posterst = value);
  $$unsubscribe_click_call_func = subscribe(click_call_func, (value) => $click_call_func = value);
  let { user_, group } = $$props;
  let name = user_.name;
  let operator = user_.operator;
  user_.abonent;
  user_.display = "none";
  let poster2 = user_.picture ? user_.picture : "/assets/operator.svg";
  set_store_value(click_call_func, $click_call_func = null, $click_call_func);
  const { groupBy, find, findIndex } = pkg;
  let { rtc = "" } = $$props;
  let status = "active", card;
  let video_element, parent_div;
  let local = {
    video: { display: "none" },
    audio: { paused: true, src: "" }
  };
  let remote = {
    video: { display: "block", srcObject: "", poster: poster2 }
  };
  getContext("operator");
  let res_talk;
  let OnClickCallButton = function(resolve) {
    res_talk = resolve;
    switch (status) {
      case "active":
        if ($call_but_status === "call" || $call_but_status === "talk") break;
        user_.display = "block";
        set_store_value(click_call_func, $click_call_func = OnClickCallButton, $click_call_func);
        (() => {
          set_store_value(posterst, $posterst = poster2, $posterst);
          rtc.Call(operator);
          status = "call";
          video_element.load();
          window.scrollTo({ top: 0, behavior: "smooth" });
        })();
        break;
    }
  };
  set_store_value(users, $users[operator] = { OnClickCallButton }, $users);
  onDestroy(async () => {
    local.video.display = "none";
    remote.video.display = "none";
    console.log();
  });
  if ($$props.user_ === void 0 && $$bindings.user_ && user_ !== void 0) $$bindings.user_(user_);
  if ($$props.group === void 0 && $$bindings.group && group !== void 0) $$bindings.group(group);
  if ($$props.rtc === void 0 && $$bindings.rtc && rtc !== void 0) $$bindings.rtc(rtc);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      switch ($call_but_status) {
        case "talk":
          if (typeof res_talk === "function") res_talk();
          break;
      }
    }
    $$rendered = `${validate_component(Video_remote$1, "VideoRemote").$$render(
      $$result,
      Object.assign({}, remote.video, { name }, { operator }, { parent_div }, { video_element }, { card }, { status }),
      {
        parent_div: ($$value) => {
          parent_div = $$value;
          $$settled = false;
        },
        video_element: ($$value) => {
          video_element = $$value;
          $$settled = false;
        },
        card: ($$value) => {
          card = $$value;
          $$settled = false;
        },
        status: ($$value) => {
          status = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${validate_component(Audio_local$1, "AudioLocal").$$render(
      $$result,
      Object.assign({}, local.audio, { paused: local.audio.paused }),
      {
        paused: ($$value) => {
          local.audio.paused = $$value;
          $$settled = false;
        }
      },
      {}
    )}`;
  } while (!$$settled);
  $$unsubscribe_users();
  $$unsubscribe_call_but_status();
  $$unsubscribe_posterst();
  $$unsubscribe_click_call_func();
  return $$rendered;
});
const css$g = {
  code: ".deps_div.svelte-1ne0ilq{overflow-y:scroll;margin-left:0px;margin-top:40px}.svelte-1ne0ilq::-webkit-scrollbar{display:none}.flexy-dad.svelte-1ne0ilq{display:flex;flex-wrap:wrap;margin-bottom:35px;justify-content:flex-start}.tutor.svelte-1ne0ilq{position:absolute;bottom:50px;display:flex;flex-wrap:wrap;justify-content:start}.flexy-boy.svelte-1ne0ilq{display:flex;justify-content:center;width:90px;height:100px;margin:0 0px 0px 0;scale:0.8}",
  map: `{"version":3,"file":"Group.svelte","sources":["Group.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { getContext, onMount } from \\"svelte\\";\\nimport { Translate } from \\"../translate/Transloc.js\\";\\nimport Tutor from \\"../tutor/Tutor.svelte\\";\\nimport \\"$lib/css/Elevation.scss\\";\\nimport ImageList, { Item, ImageAspectContainer, Image, Supporting } from \\"@smui/image-list\\";\\nimport Button, { Label } from \\"@smui/button\\";\\nimport pkg from \\"lodash\\";\\nconst { mapValues, find } = pkg;\\nexport let rtc, oper_display;\\nimport { signal, users, langs, dc, msg, call_but_status } from \\"$lib/js/stores.js\\";\\nimport User from \\"../user/User.svelte\\";\\nlet operator = getContext(\\"operator\\");\\nlet cnt;\\nlet lang = $langs;\\nexport let group = [];\\nlet no_users_display = \\"block\\";\\nconst headers = {\\n  \\"Content-Type\\": \\"application/json\\"\\n  // Authorization: \`Bearer \${token}\`\\n};\\n$: if ($msg) {\\n  onMessage($msg);\\n}\\n$: if ($call_but_status === \\"active\\") {\\n  GetOperators({\\n    type: \\"user\\",\\n    func: \\"operators\\",\\n    abonent: operator.abonent,\\n    operator: operator.operator\\n  });\\n} else if ($call_but_status === \\"inactive\\") {\\n  group = group = [];\\n  $users = {};\\n}\\nasync function GetOperators(par) {\\n  $signal.SendMessage(par, (data) => {\\n    onMessage({ operators: data.resp });\\n  });\\n}\\nfunction OnClickUser() {\\n}\\nonMount(async () => {\\n});\\nfunction OnClickUpload() {\\n}\\n$: if (group.length > 0) {\\n  mapValues($users, function(o) {\\n  });\\n  no_users_display = \\"none\\";\\n} else {\\n  console.log();\\n  no_users_display = \\"block\\";\\n}\\nfunction onMessage(data) {\\n  console.log();\\n  if (data.operators) {\\n    Object.keys(data.operators).map((el) => {\\n      if (data.operators[el].status === \\"offer\\" && !find(group, { operator: el })) {\\n        group.push(data.operators[el]);\\n      } else {\\n        const ind = group.indexOf(data.operators[el]);\\n        if (ind !== -1)\\n          group.splice(ind, 1);\\n      }\\n    });\\n    group = group;\\n  }\\n  if (data.status === \\"offer\\" && $call_but_status === \\"active\\") {\\n    const el = {\\n      display: \\"block\\",\\n      abonent: data.abonent,\\n      operator: data.operator,\\n      name: data.name,\\n      uid: data.uid,\\n      picture: data.picture\\n    };\\n    if (!find(group, { operator: data.operator })) {\\n      group?.push(el);\\n      group = group;\\n    }\\n    $msg = \\"\\";\\n  } else if (data.status === \\"close\\") {\\n    console.log();\\n    let el = find(group, { uid: data.operator });\\n    const ind = group.indexOf(el);\\n    group.splice(ind, 1);\\n    group = group;\\n    $msg = \\"\\";\\n  }\\n}\\n<\/script>\\r\\n\\r\\n<!-- {@debug operator} -->\\r\\n<div class=\\"deps_div\\">\\r\\n  {#await Translate('Нет пользователей онлайн', 'ru', $langs) then data}\\r\\n    <span\\r\\n      style=\\"display:{no_users_display};position: relative;top:0px;text-align: center; font-size: smaller;\\r\\n      font-family: monospace;\\">{data}</span\\r\\n    >\\r\\n  {/await}\\r\\n  <div class=\\"flexy-dad\\">\\r\\n    {#each group as user, i}\\r\\n      {#if user && user.operator !== operator.operator}\\r\\n        <br />\\r\\n        <div\\r\\n          class=\\"mdc-elevation--z{i + 1} flexy-boy\\"\\r\\n          style=\\"display:block\\"\\r\\n          on:click={(ev) => {\\r\\n            OnClickUser({ user });\\r\\n          }}\\r\\n        >\\r\\n          <Item style=\\"text-align: center\\">\\r\\n            <User bind:user_={user} bind:group {OnClickUpload} {rtc}/>\\r\\n            <Supporting>\\r\\n              <Label>{user.name}</Label>\\r\\n            </Supporting>\\r\\n          </Item>\\r\\n        </div>\\r\\n      {/if}\\r\\n    {/each}\\r\\n  </div>\\r\\n  {#if window.location.hostname==='localhost'}\\r\\n    <div class=\\"flexy-dad tutor\\">\\r\\n      <div class=\\"mdc-elevation--z{1} flexy-boy\\">\\r\\n        <Item style=\\"text-align: center\\">\\r\\n          <Tutor name=\\"AI Tutor\\"></Tutor>\\r\\n\\r\\n          <Supporting>\\r\\n            <Label>AI Tutor</Label>\\r\\n          </Supporting>\\r\\n        </Item>\\r\\n      </div>\\r\\n    </div>\\r\\n  {/if}\\r\\n  <!-- <div class=\\"empty\\" style=\\"height:100px\\" /> -->\\r\\n</div>\\r\\n<div style=\\"height:100px\\"></div>\\r\\n\\r\\n<style>\\r\\n  .deps_div {\\r\\n    /* height: 90vh; */\\r\\n    overflow-y: scroll;\\r\\n    margin-left: 0px;\\r\\n    margin-top: 40px;\\r\\n  }\\r\\n  ::-webkit-scrollbar {\\r\\n    display: none;\\r\\n  }\\r\\n\\r\\n  .flexy-dad {\\r\\n    display: flex;\\r\\n    flex-wrap: wrap;\\r\\n    margin-bottom: 35px;\\r\\n    justify-content: flex-start;\\r\\n  }\\r\\n\\r\\n  .tutor {\\r\\n    position: absolute;\\r\\n    bottom: 50px;\\r\\n    display: flex;\\r\\n    flex-wrap: wrap;\\r\\n    justify-content: start;\\r\\n  }\\r\\n\\r\\n  .flexy-boy {\\r\\n    display: flex;\\r\\n    justify-content: center;\\r\\n    width: 90px;\\r\\n    height: 100px;\\r\\n    margin: 0 0px 0px 0;\\r\\n    scale: 0.8;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA2IE,wBAAU,CAER,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,GAAG,CAChB,UAAU,CAAE,IACd,gBACA,mBAAoB,CAClB,OAAO,CAAE,IACX,CAEA,yBAAW,CACT,OAAO,CAAE,IAAI,CACb,SAAS,CAAE,IAAI,CACf,aAAa,CAAE,IAAI,CACnB,eAAe,CAAE,UACnB,CAEA,qBAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,IAAI,CACb,SAAS,CAAE,IAAI,CACf,eAAe,CAAE,KACnB,CAEA,yBAAW,CACT,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,KAAK,CACb,MAAM,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,CAAC,CACnB,KAAK,CAAE,GACT"}`
};
function OnClickUpload() {
}
const Group = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $msg, $$unsubscribe_msg;
  let $call_but_status, $$unsubscribe_call_but_status;
  let $users, $$unsubscribe_users;
  let $signal, $$unsubscribe_signal;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  $$unsubscribe_users = subscribe(users, (value) => $users = value);
  $$unsubscribe_signal = subscribe(signal, (value) => $signal = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  const { mapValues, find } = pkg;
  let { rtc, oper_display } = $$props;
  let operator = getContext("operator");
  let { group = [] } = $$props;
  let no_users_display = "block";
  async function GetOperators(par) {
    $signal.SendMessage(par, (data) => {
      onMessage({ operators: data.resp });
    });
  }
  function onMessage(data) {
    console.log();
    if (data.operators) {
      Object.keys(data.operators).map((el) => {
        if (data.operators[el].status === "offer" && !find(group, { operator: el })) {
          group.push(data.operators[el]);
        } else {
          const ind = group.indexOf(data.operators[el]);
          if (ind !== -1) group.splice(ind, 1);
        }
      });
      group = group;
    }
    if (data.status === "offer" && $call_but_status === "active") {
      const el = {
        display: "block",
        abonent: data.abonent,
        operator: data.operator,
        name: data.name,
        uid: data.uid,
        picture: data.picture
      };
      if (!find(group, { operator: data.operator })) {
        group?.push(el);
        group = group;
      }
      set_store_value(msg, $msg = "", $msg);
    } else if (data.status === "close") {
      console.log();
      let el = find(group, { uid: data.operator });
      const ind = group.indexOf(el);
      group.splice(ind, 1);
      group = group;
      set_store_value(msg, $msg = "", $msg);
    }
  }
  if ($$props.rtc === void 0 && $$bindings.rtc && rtc !== void 0) $$bindings.rtc(rtc);
  if ($$props.oper_display === void 0 && $$bindings.oper_display && oper_display !== void 0) $$bindings.oper_display(oper_display);
  if ($$props.group === void 0 && $$bindings.group && group !== void 0) $$bindings.group(group);
  $$result.css.add(css$g);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($msg) {
        onMessage($msg);
      }
    }
    {
      if ($call_but_status === "active") {
        GetOperators({
          type: "user",
          func: "operators",
          abonent: operator.abonent,
          operator: operator.operator
        });
      } else if ($call_but_status === "inactive") {
        group = group = [];
        set_store_value(users, $users = {}, $users);
      }
    }
    {
      if (group.length > 0) {
        mapValues($users, function(o) {
        });
        no_users_display = "none";
      } else {
        console.log();
        no_users_display = "block";
      }
    }
    $$rendered = ` <div class="deps_div svelte-1ne0ilq">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` <span style="${"display:" + escape(no_users_display, true) + ";position: relative;top:0px;text-align: center; font-size: smaller; font-family: monospace;"}" class="svelte-1ne0ilq">${escape(data)}</span> `;
      }(__value);
    }(Translate("Нет пользователей онлайн", "ru", $langs))} <div class="flexy-dad svelte-1ne0ilq">${each(group, (user, i) => {
      return `${user && user.operator !== operator.operator ? `<br class="svelte-1ne0ilq"> <div class="${"mdc-elevation--z" + escape(i + 1, true) + " flexy-boy svelte-1ne0ilq"}" style="display:block">${validate_component(Item, "Item").$$render($$result, { style: "text-align: center" }, {}, {
        default: () => {
          return `${validate_component(User, "User").$$render(
            $$result,
            { OnClickUpload, rtc, user_: user, group },
            {
              user_: ($$value) => {
                user = $$value;
                $$settled = false;
              },
              group: ($$value) => {
                group = $$value;
                $$settled = false;
              }
            },
            {}
          )} ${validate_component(Supporting, "Supporting").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
                default: () => {
                  return `${escape(user.name)}`;
                }
              })} `;
            }
          })} `;
        }
      })} </div>` : ``}`;
    })}</div> ${window.location.hostname === "localhost" ? `<div class="flexy-dad tutor svelte-1ne0ilq"><div class="${"mdc-elevation--z" + escape(1, true) + " flexy-boy svelte-1ne0ilq"}">${validate_component(Item, "Item").$$render($$result, { style: "text-align: center" }, {}, {
      default: () => {
        return `${validate_component(Tutor, "Tutor").$$render($$result, { name: "AI Tutor" }, {}, {})} ${validate_component(Supporting, "Supporting").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
              default: () => {
                return `AI Tutor`;
              }
            })}`;
          }
        })}`;
      }
    })}</div></div>` : ``} </div> <div style="height:100px" class="svelte-1ne0ilq"></div>`;
  } while (!$$settled);
  $$unsubscribe_msg();
  $$unsubscribe_call_but_status();
  $$unsubscribe_users();
  $$unsubscribe_signal();
  $$unsubscribe_langs();
  return $$rendered;
});
operatorst.subscribe((data) => {
});
posterst.subscribe((data) => {
});
const css$f = {
  code: ".callButton.svelte-mw3tu7.svelte-mw3tu7{position:relative;top:-10px;right:10px;z-index:1}[status='call'].svelte-mw3tu7.svelte-mw3tu7{transform:rotate(0deg) !important;animation-iteration-count:infinite}[status='call'].svelte-mw3tu7 g.svelte-mw3tu7{fill:orange}[status='talk'].svelte-mw3tu7.svelte-mw3tu7{transform:rotate(0deg) !important}[status='talk'].svelte-mw3tu7 g.svelte-mw3tu7{fill:green}[status='muted'].svelte-mw3tu7.svelte-mw3tu7{transform:rotate(120deg) !important;color:#232323}[status='inactive'].svelte-mw3tu7.svelte-mw3tu7{color:#dea677;transform:rotate(120deg)}[status='inactive'].svelte-mw3tu7 g.svelte-mw3tu7{fill:grey}[status='active'].svelte-mw3tu7.svelte-mw3tu7{transform:rotate(120deg);color:black;opacity:1}[status='active'].svelte-mw3tu7 g.svelte-mw3tu7{fill:orange}[status='busy'].svelte-mw3tu7.svelte-mw3tu7{transform:rotate(120deg);opacity:0.3;color:indianred}@keyframes svelte-mw3tu7-shake{0%{transform:translate(1px, 1px) rotate(0deg)}10%{transform:translate(-1px, -2px) rotate(-1deg)}20%{transform:translate(-3px, 0px) rotate(1deg)}30%{transform:translate(3px, 2px) rotate(0deg)}40%{transform:translate(1px, -1px) rotate(1deg)}50%{transform:translate(-1px, 2px) rotate(-1deg)}60%{transform:translate(-3px, 1px) rotate(0deg)}70%{transform:translate(3px, 1px) rotate(-1deg)}80%{transform:translate(-1px, -1px) rotate(1deg)}90%{transform:translate(1px, 2px) rotate(0deg)}100%{transform:translate(1px, -2px) rotate(-1deg)}}",
  map: `{"version":3,"file":"CallButtonOperator.svelte","sources":["CallButtonOperator.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { call_but_status } from \\"$lib/js/stores.js\\";\\nlet status;\\n$: if ($call_but_status) {\\n  status = $call_but_status;\\n}\\n<\/script>\\r\\n\\r\\n<div class=\\"callObject\\" style=\\"display: block;\\">\\r\\n  <!-- {@debug status} -->\\r\\n  <svg class=\\"callButton\\" {status} on:click width=\\"50\\" height=\\"50\\">\\r\\n    <!-- <rect id=\\"backgroundrect\\" width=\\"100%\\" height=\\"100%\\" x=\\"0\\" y=\\"0\\" fill=\\"none\\" stroke=\\"none\\"/>\\r\\n        <glyph glyph-name=\\"phone\\" unicode=\\"\\" horiz-adv-x=\\"1000\\"/>         -->\\r\\n    <g class=\\"currentLayer\\" style=\\" stroke:lightgrey; stroke-width:10px\\">\\r\\n      <title>Layer 1</title>\\r\\n      <path\\r\\n        d=\\"M390.7 353.3c-120.30000000000001 69.5 63.19999999999999 413.59999999999997 194.90000000000003 337.59999999999997l122.10000000000002 211.39999999999998c-55.60000000000002 32.10000000000002-102.5 52.30000000000007-166.9000000000001 15.5-178.79999999999995-102.19999999999993-375.59999999999997-442.9-369.99999999999994-646.0999999999999 1.8999999999999773-70.60000000000005 43.599999999999994-98.30000000000004 97.89999999999998-129.70000000000005 23.30000000000001 40.400000000000006 98.60000000000002 170.8 122 211.3z m50.400000000000034-5.699999999999989c-13 7.5-29.700000000000045 3.099999999999966-37.30000000000001-10l-115-199.3c-7.5-13.000000000000014-3.1000000000000227-29.700000000000017 10-37.30000000000001l60.5-34.900000000000006c13-7.499999999999993 29.69999999999999-3.0999999999999943 37.30000000000001 10l115.09999999999997 199.29999999999998c7.500000000000057 13 3.099999999999966 29.700000000000045-10 37.200000000000045l-60.599999999999966 35z m314.4 544.5c-13 7.5-29.700000000000045 3.1000000000000227-37.299999999999955-10l-115-199.30000000000007c-7.5-13-3.1000000000000227-29.699999999999932 10-37.299999999999955l60.5-34.89999999999998c13-7.5 29.699999999999932-3.1000000000000227 37.299999999999955 10l115.10000000000002 199.29999999999995c7.5 13 3.1000000000000227 29.700000000000045-10 37.30000000000007l-60.60000000000002 34.89999999999998z\\"\\r\\n        id=\\"svg_1\\"\\r\\n        class=\\"selected\\"\\r\\n        transform=\\"scale(.04)\\"\\r\\n      />\\r\\n    </g>\\r\\n  </svg>\\r\\n\\r\\n  <!-- <slot></slot> -->\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n  .callButton {\\r\\n    position: relative;\\r\\n    top: -10px;\\r\\n    right: 10px;\\r\\n    z-index: 1;\\r\\n  }\\r\\n  [status='call'] {\\r\\n    /* -webkit-animation: rotation 1s 1 linear; */\\r\\n    transform: rotate(0deg) !important;\\r\\n    /* Start the shake animation and make the animation last for 0.5 seconds */\\r\\n    /* animation: shake 0.5s; */\\r\\n    /* When the animation is finished, start again */\\r\\n    animation-iteration-count: infinite;\\r\\n  }\\r\\n  [status='call'] g {\\r\\n    fill: orange;\\r\\n  }\\r\\n  [status='talk'] {\\r\\n    transform: rotate(0deg) !important;\\r\\n  }\\r\\n  [status='talk'] g {\\r\\n    fill: green;\\r\\n  }\\r\\n  [status='muted'] {\\r\\n    transform: rotate(120deg) !important;\\r\\n    color: #232323;\\r\\n  }\\r\\n  [status='inactive'] {\\r\\n    color: #dea677;\\r\\n    transform: rotate(120deg);\\r\\n  }\\r\\n  [status='inactive'] g {\\r\\n    fill: grey;\\r\\n  }\\r\\n  [status='active'] {\\r\\n    transform: rotate(120deg);\\r\\n    color: black;\\r\\n    opacity: 1;\\r\\n  }\\r\\n  [status='active'] g {\\r\\n    fill: orange;\\r\\n  }\\r\\n  [status='busy'] {\\r\\n    transform: rotate(120deg);\\r\\n    opacity: 0.3;\\r\\n    color: indianred;\\r\\n  }\\r\\n\\r\\n  @keyframes shake {\\r\\n    0% {\\r\\n      transform: translate(1px, 1px) rotate(0deg);\\r\\n    }\\r\\n    10% {\\r\\n      transform: translate(-1px, -2px) rotate(-1deg);\\r\\n    }\\r\\n    20% {\\r\\n      transform: translate(-3px, 0px) rotate(1deg);\\r\\n    }\\r\\n    30% {\\r\\n      transform: translate(3px, 2px) rotate(0deg);\\r\\n    }\\r\\n    40% {\\r\\n      transform: translate(1px, -1px) rotate(1deg);\\r\\n    }\\r\\n    50% {\\r\\n      transform: translate(-1px, 2px) rotate(-1deg);\\r\\n    }\\r\\n    60% {\\r\\n      transform: translate(-3px, 1px) rotate(0deg);\\r\\n    }\\r\\n    70% {\\r\\n      transform: translate(3px, 1px) rotate(-1deg);\\r\\n    }\\r\\n    80% {\\r\\n      transform: translate(-1px, -1px) rotate(1deg);\\r\\n    }\\r\\n    90% {\\r\\n      transform: translate(1px, 2px) rotate(0deg);\\r\\n    }\\r\\n    100% {\\r\\n      transform: translate(1px, -2px) rotate(-1deg);\\r\\n    }\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA2BE,uCAAY,CACV,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,KAAK,CACV,KAAK,CAAE,IAAI,CACX,OAAO,CAAE,CACX,CACA,CAAC,MAAM,CAAC,MAAM,6BAAE,CAEd,SAAS,CAAE,OAAO,IAAI,CAAC,CAAC,UAAU,CAIlC,yBAAyB,CAAE,QAC7B,CACA,CAAC,MAAM,CAAC,MAAM,eAAC,CAAC,eAAE,CAChB,IAAI,CAAE,MACR,CACA,CAAC,MAAM,CAAC,MAAM,6BAAE,CACd,SAAS,CAAE,OAAO,IAAI,CAAC,CAAC,UAC1B,CACA,CAAC,MAAM,CAAC,MAAM,eAAC,CAAC,eAAE,CAChB,IAAI,CAAE,KACR,CACA,CAAC,MAAM,CAAC,OAAO,6BAAE,CACf,SAAS,CAAE,OAAO,MAAM,CAAC,CAAC,UAAU,CACpC,KAAK,CAAE,OACT,CACA,CAAC,MAAM,CAAC,UAAU,6BAAE,CAClB,KAAK,CAAE,OAAO,CACd,SAAS,CAAE,OAAO,MAAM,CAC1B,CACA,CAAC,MAAM,CAAC,UAAU,eAAC,CAAC,eAAE,CACpB,IAAI,CAAE,IACR,CACA,CAAC,MAAM,CAAC,QAAQ,6BAAE,CAChB,SAAS,CAAE,OAAO,MAAM,CAAC,CACzB,KAAK,CAAE,KAAK,CACZ,OAAO,CAAE,CACX,CACA,CAAC,MAAM,CAAC,QAAQ,eAAC,CAAC,eAAE,CAClB,IAAI,CAAE,MACR,CACA,CAAC,MAAM,CAAC,MAAM,6BAAE,CACd,SAAS,CAAE,OAAO,MAAM,CAAC,CACzB,OAAO,CAAE,GAAG,CACZ,KAAK,CAAE,SACT,CAEA,WAAW,mBAAM,CACf,EAAG,CACD,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,IAAI,CAC5C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,IAAI,CAAC,CAAC,OAAO,KAAK,CAC/C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,IAAI,CAC7C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,IAAI,CAC5C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,IAAI,CAAC,CAAC,OAAO,IAAI,CAC7C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,KAAK,CAC9C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,IAAI,CAC7C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,KAAK,CAC7C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,IAAI,CAAC,CAAC,OAAO,IAAI,CAC9C,CACA,GAAI,CACF,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,OAAO,IAAI,CAC5C,CACA,IAAK,CACH,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,IAAI,CAAC,CAAC,OAAO,KAAK,CAC9C,CACF"}`
};
const CallButtonOperator = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $call_but_status, $$unsubscribe_call_but_status;
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  let status;
  $$result.css.add(css$f);
  {
    if ($call_but_status) {
      status = $call_but_status;
    }
  }
  $$unsubscribe_call_but_status();
  return `<div class="callObject" style="display: block;"> <svg class="callButton svelte-mw3tu7"${add_attribute("status", status, 0)} width="50" height="50"><g class="currentLayer svelte-mw3tu7" style="stroke:lightgrey; stroke-width:10px"><title>Layer 1</title><path d="M390.7 353.3c-120.30000000000001 69.5 63.19999999999999 413.59999999999997 194.90000000000003 337.59999999999997l122.10000000000002 211.39999999999998c-55.60000000000002 32.10000000000002-102.5 52.30000000000007-166.9000000000001 15.5-178.79999999999995-102.19999999999993-375.59999999999997-442.9-369.99999999999994-646.0999999999999 1.8999999999999773-70.60000000000005 43.599999999999994-98.30000000000004 97.89999999999998-129.70000000000005 23.30000000000001 40.400000000000006 98.60000000000002 170.8 122 211.3z m50.400000000000034-5.699999999999989c-13 7.5-29.700000000000045 3.099999999999966-37.30000000000001-10l-115-199.3c-7.5-13.000000000000014-3.1000000000000227-29.700000000000017 10-37.30000000000001l60.5-34.900000000000006c13-7.499999999999993 29.69999999999999-3.0999999999999943 37.30000000000001 10l115.09999999999997 199.29999999999998c7.500000000000057 13 3.099999999999966 29.700000000000045-10 37.200000000000045l-60.599999999999966 35z m314.4 544.5c-13 7.5-29.700000000000045 3.1000000000000227-37.299999999999955-10l-115-199.30000000000007c-7.5-13-3.1000000000000227-29.699999999999932 10-37.299999999999955l60.5-34.89999999999998c13-7.5 29.699999999999932-3.1000000000000227 37.299999999999955 10l115.10000000000002 199.29999999999995c7.5 13 3.1000000000000227 29.700000000000045-10 37.30000000000007l-60.60000000000002 34.89999999999998z" id="svg_1" class="selected" transform="scale(.04)"></path></g></svg>  </div>`;
});
const css$e = {
  code: "video.svelte-1cgyaki{display:block;margin-right:auto;margin-left:auto;margin-top:auto;max-width:40px;max-height:40px}",
  map: `{"version":3,"file":"Video.local.svelte","sources":["Video.local.svelte"],"sourcesContent":["<script>\\r\\n\\timport { onMount, getContext } from 'svelte';\\r\\n\\timport Card, { Content, PrimaryAction, Media, MediaContent } from '@smui/card';\\r\\n\\r\\n\\tlet display = 'block';\\r\\n\\texport let srcObject = '';\\r\\n\\tlet lv, card, parent_div;\\r\\n\\r\\n\\r\\n\\tconst oper = getContext('operator')\\r\\n\\tconst poster = oper.picture;\\r\\n\\r\\n\\tonMount(async () => {});\\r\\n\\r\\n\\t$: if (lv && srcObject) {\\r\\n\\t\\tlv.srcObject = srcObject;\\r\\n\\t} else if (lv && lv.srcObject) {\\r\\n\\t\\tlv.srcObject.getVideoTracks().forEach((track) => {\\r\\n\\t\\t\\ttrack.stop();\\r\\n\\t\\t\\tlv.srcObject.removeTrack(track);\\r\\n\\t\\t});\\r\\n\\t\\tlv.src = '';\\r\\n\\t}\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"card-display\\" bind:this={parent_div}>\\r\\n\\t<div class=\\"card-container\\" bind:this={card}>\\r\\n\\t\\t<Card style=\\"min-width: 40px;\\">\\r\\n\\t\\t\\t<Media class=\\"card-media-square\\" aspectRatio=\\"square\\">\\r\\n\\t\\t\\t\\t<MediaContent>\\r\\n\\t\\t\\t\\t\\t<video\\r\\n\\t\\t\\t\\t\\t\\tclass=\\"oper_video_local\\"\\r\\n\\t\\t\\t\\t\\t\\tbind:this={lv}\\r\\n\\t\\t\\t\\t\\t\\tposter={poster}\\r\\n\\t\\t\\t\\t\\t\\tautoplay\\r\\n\\t\\t\\t\\t\\t\\tplaysinline\\r\\n\\t\\t\\t\\t\\t\\t\\r\\n\\t\\t\\t\\t\\t\\tstyle=\\"display: {display}\\"\\r\\n\\t\\t\\t\\t\\t/>\\r\\n\\t\\t\\t\\t</MediaContent>\\r\\n\\t\\t\\t</Media>\\r\\n\\t\\t\\t<!-- <Content style=\\"color: #888; font-size:smaller\\">{name}</Content> -->\\r\\n\\t\\t\\t<h3\\r\\n\\t\\t\\t\\tclass=\\"mdc-typography--subtitle2\\"\\r\\n\\t\\t\\t\\tstyle=\\"margin: 0; color: #888;font-size:smaller;text-align:center; z-index:1\\"\\r\\n\\t\\t\\t/>\\r\\n\\t\\t</Card>\\r\\n\\t</div>\\r\\n</div>\\r\\n<!-- </div> -->\\r\\n<slot name=\\"footer\\" />\\r\\n\\r\\n<style>\\r\\n\\tvideo {\\r\\n\\t\\tdisplay: block;\\r\\n\\t\\tmargin-right: auto;\\r\\n\\t\\tmargin-left: auto;\\r\\n\\t\\tmargin-top: auto;\\r\\n\\t\\tmax-width: 40px;\\r\\n\\t\\tmax-height: 40px;\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAqDC,oBAAM,CACL,OAAO,CAAE,KAAK,CACd,YAAY,CAAE,IAAI,CAClB,WAAW,CAAE,IAAI,CACjB,UAAU,CAAE,IAAI,CAChB,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,IACb"}`
};
let display = "block";
const Video_local = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { srcObject = "" } = $$props;
  let lv, card, parent_div;
  const oper = getContext("operator");
  const poster2 = oper.picture;
  if ($$props.srcObject === void 0 && $$bindings.srcObject && srcObject !== void 0) $$bindings.srcObject(srcObject);
  $$result.css.add(css$e);
  return `<div class="card-display"${add_attribute("this", parent_div, 0)}><div class="card-container"${add_attribute("this", card, 0)}>${validate_component(Card, "Card").$$render($$result, { style: "min-width: 40px;" }, {}, {
    default: () => {
      return `${validate_component(Media, "Media").$$render(
        $$result,
        {
          class: "card-media-square",
          aspectRatio: "square"
        },
        {},
        {
          default: () => {
            return `${validate_component(MediaContent, "MediaContent").$$render($$result, {}, {}, {
              default: () => {
                return `<video class="oper_video_local svelte-1cgyaki"${add_attribute("poster", poster2, 0)} autoplay playsinline style="${"display: " + escape(display, true)}"${add_attribute("this", lv, 0)}></video>`;
              }
            })}`;
          }
        }
      )}  <h3 class="mdc-typography--subtitle2" style="margin: 0; color: #888;font-size:smaller;text-align:center; z-index:1"></h3>`;
    }
  })}</div></div>  ${slots.footer ? slots.footer({}) : ``}`;
});
const css$d = {
  code: ".card-container.svelte-13c68d2{position:relative;left:-8px;scale:0.8;bottom:20px}video.svelte-13c68d2{display:block;margin-right:auto;margin-left:auto;margin-top:auto;max-width:50px;max-height:50px}.oper_video_remote.svelte-13c68d2{position:relative;top:7px}",
  map: `{"version":3,"file":"Video.remote.svelte","sources":["Video.remote.svelte"],"sourcesContent":["<script lang='ts'>import { getContext, onMount } from \\"svelte\\";\\nimport Card, { Content, PrimaryAction, Media, MediaContent } from \\"@smui/card\\";\\nexport let display = \\"block\\";\\nexport let status;\\nexport let isRemoteAudioMute = false;\\nexport let card;\\nexport let srcObject;\\nexport let operator;\\nexport let name;\\nexport let poster;\\nlet rv, video;\\nonMount(async () => {\\n  rv = video;\\n  rv.poster = poster;\\n});\\n$: if (rv && srcObject) {\\n  rv.srcObject = srcObject;\\n} else if (rv && rv.srcObject) {\\n  rv.srcObject.getVideoTracks().forEach((track) => {\\n    track.stop();\\n    rv.srcObject.removeTrack(track);\\n  });\\n  rv.src = \\"\\";\\n} else if (rv && poster) {\\n  rv.poster = poster;\\n}\\n<\/script>\\r\\n\\r\\n<!-- <div\\r\\n\\tstyle=\\"\\r\\n    display:{display};\\r\\n    position: relative;\\r\\n    width: 55px;\\r\\n\\tmargin: 0 auto;\\r\\n    background-color: transparent;\\r\\n    border-radius:5px;\\"\\r\\n> -->\\r\\n<div class=\\"card-display\\" bind:this={card} style=\\"display:{display}\\">\\r\\n  <div class=\\"card-container\\">\\r\\n    <Card style=\\"min-width: 60px;\\">\\r\\n      <Media class=\\"card-media-square\\" aspectRatio=\\"square\\">\\r\\n        <MediaContent>\\r\\n          <video\\r\\n            class=\\"oper_video_remote\\"\\r\\n            bind:this={video}\\r\\n            on:click\\r\\n            on:mute\\r\\n\\t\\t\\t\\t\\t\\tmuted={isRemoteAudioMute}\\r\\n            {status}\\r\\n\\r\\n            autoplay\\r\\n            playsinline\\r\\n            poster={poster}\\r\\n          >\\r\\n            <track kind=\\"captions\\" />\\r\\n          </video>\\r\\n        </MediaContent>\\r\\n      </Media>\\r\\n      <!-- <Content style=\\"color: #888; font-size:smaller\\">{name}</Content> -->\\r\\n      <!-- <h3\\r\\n        class=\\"mdc-typography--subtitle2\\"\\r\\n        style=\\"margin: 0; color: #888;font-size:smaller;text-align:center;z-index:1\\"\\r\\n      >\\r\\n        {#if name}\\r\\n          {name.slice(0, 8)}\\r\\n        {:else}\\r\\n          {operator.slice(0, 8)}\\r\\n        {/if}\\r\\n      </h3> -->\\r\\n    </Card>\\r\\n  </div>\\r\\n</div>\\r\\n\\r\\n<!-- </div> -->\\r\\n\\r\\n<style>\\r\\n  .card-container {\\r\\n    position: relative;\\r\\n    left: -8px;\\r\\n    scale: 0.8;\\r\\n    bottom: 20px;\\r\\n   \\r\\n  }\\r\\n\\r\\n  video {\\r\\n    display: block;\\r\\n    margin-right: auto;\\r\\n    margin-left: auto;\\r\\n    margin-top: auto;\\r\\n    max-width: 50px;\\r\\n    max-height: 50px;\\r\\n  }\\r\\n\\r\\n  .oper_video_remote {\\r\\n    position: relative;\\r\\n    top: 7px;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA4EE,8BAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,IAAI,CAAE,IAAI,CACV,KAAK,CAAE,GAAG,CACV,MAAM,CAAE,IAEV,CAEA,oBAAM,CACJ,OAAO,CAAE,KAAK,CACd,YAAY,CAAE,IAAI,CAClB,WAAW,CAAE,IAAI,CACjB,UAAU,CAAE,IAAI,CAChB,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,IACd,CAEA,iCAAmB,CACjB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GACP"}`
};
const Video_remote = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { display: display2 = "block" } = $$props;
  let { status } = $$props;
  let { isRemoteAudioMute = false } = $$props;
  let { card } = $$props;
  let { srcObject } = $$props;
  let { operator } = $$props;
  let { name } = $$props;
  let { poster: poster2 } = $$props;
  let video;
  if ($$props.display === void 0 && $$bindings.display && display2 !== void 0) $$bindings.display(display2);
  if ($$props.status === void 0 && $$bindings.status && status !== void 0) $$bindings.status(status);
  if ($$props.isRemoteAudioMute === void 0 && $$bindings.isRemoteAudioMute && isRemoteAudioMute !== void 0) $$bindings.isRemoteAudioMute(isRemoteAudioMute);
  if ($$props.card === void 0 && $$bindings.card && card !== void 0) $$bindings.card(card);
  if ($$props.srcObject === void 0 && $$bindings.srcObject && srcObject !== void 0) $$bindings.srcObject(srcObject);
  if ($$props.operator === void 0 && $$bindings.operator && operator !== void 0) $$bindings.operator(operator);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0) $$bindings.name(name);
  if ($$props.poster === void 0 && $$bindings.poster && poster2 !== void 0) $$bindings.poster(poster2);
  $$result.css.add(css$d);
  return ` <div class="card-display" style="${"display:" + escape(display2, true)}"${add_attribute("this", card, 0)}><div class="card-container svelte-13c68d2">${validate_component(Card, "Card").$$render($$result, { style: "min-width: 60px;" }, {}, {
    default: () => {
      return `${validate_component(Media, "Media").$$render(
        $$result,
        {
          class: "card-media-square",
          aspectRatio: "square"
        },
        {},
        {
          default: () => {
            return `${validate_component(MediaContent, "MediaContent").$$render($$result, {}, {}, {
              default: () => {
                return `<video class="oper_video_remote svelte-13c68d2" ${isRemoteAudioMute ? "muted" : ""}${add_attribute("status", status, 0)} autoplay playsinline${add_attribute("poster", poster2, 0)}${add_attribute("this", video, 0)}><track kind="captions"></video>`;
              }
            })}`;
          }
        }
      )}  `;
    }
  })}</div></div> `;
});
const ring = "/_app/immutable/assets/ring.C9X-rfjT.mp3";
const Audio_local = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { paused = true } = $$props;
  let ls;
  if ($$props.paused === void 0 && $$bindings.paused && paused !== void 0) $$bindings.paused(paused);
  return `<audio${add_attribute("src", ring, 0)} loop${add_attribute("this", ls, 0)} data-svelte-h="svelte-zjfzj1"><track kind="captions"></audio>`;
});
const Badge = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$restProps = compute_rest_props($$props, ["use", "class", "square", "color", "position", "align", "getElement"]);
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { square = false } = $$props;
  let { color = "primary" } = $$props;
  let { position = "middle" } = $$props;
  let { align = "top-end" } = $$props;
  let element;
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.square === void 0 && $$bindings.square && square !== void 0) $$bindings.square(square);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0) $$bindings.color(color);
  if ($$props.position === void 0 && $$bindings.position && position !== void 0) $$bindings.position(position);
  if ($$props.align === void 0 && $$bindings.align && align !== void 0) $$bindings.align(align);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  return `<span${spread(
    [
      {
        class: escape_attribute_value(classMap({
          [className]: true,
          "smui-badge": true,
          "smui-badge--rounded": !square,
          ["smui-badge--color-" + color]: true,
          ["smui-badge--position-" + position]: true,
          ["smui-badge--align-" + align]: true
        }))
      },
      { role: "status" },
      escape_object($$restProps)
    ],
    {}
  )}${add_attribute("this", element, 0)}>${slots.default ? slots.default({}) : ``} </span>`;
});
let counter = 0;
const Autocomplete = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let menuOpen;
  let $$restProps = compute_rest_props($$props, [
    "use",
    "class",
    "options",
    "value",
    "getOptionDisabled",
    "getOptionLabel",
    "text",
    "label",
    "disabled",
    "toggle",
    "combobox",
    "clearOnBlur",
    "selectOnExactMatch",
    "showMenuWithNoInput",
    "noMatchesActionDisabled",
    "search",
    "menu$class",
    "menu$anchor",
    "menu$anchorCorner",
    "focus",
    "blur",
    "getElement"
  ]);
  var _a;
  forwardEventsBuilder(get_current_component());
  let { use = [] } = $$props;
  let { class: className = "" } = $$props;
  let { options = [] } = $$props;
  let { value = void 0 } = $$props;
  let { getOptionDisabled = () => false } = $$props;
  let { getOptionLabel = (option) => option == null ? "" : `${option}` } = $$props;
  let { text = getOptionLabel(value) } = $$props;
  let { label = void 0 } = $$props;
  let { disabled = false } = $$props;
  let { toggle = false } = $$props;
  let { combobox = false } = $$props;
  let { clearOnBlur = !combobox } = $$props;
  let { selectOnExactMatch = true } = $$props;
  let { showMenuWithNoInput = true } = $$props;
  let { noMatchesActionDisabled = true } = $$props;
  let { search = async (input) => {
    const linput = input.toLowerCase();
    const fullOptions = typeof options == "function" ? await options() : options || [];
    if (linput === "") {
      return fullOptions;
    }
    const result = fullOptions.filter((item) => getOptionLabel(item).toLowerCase().includes(linput));
    result.sort((a, b) => {
      const aString = getOptionLabel(a).toLowerCase();
      const bString = getOptionLabel(b).toLowerCase();
      if (aString.startsWith(linput) && !bString.startsWith(linput)) {
        return -1;
      } else if (bString.startsWith(linput) && !aString.startsWith(linput)) {
        return 1;
      }
      return 0;
    });
    return result;
  } } = $$props;
  let { menu$class = "" } = $$props;
  let { menu$anchor = false } = $$props;
  let { menu$anchorCorner = "BOTTOM_START" } = $$props;
  let element;
  let inputContainer;
  let loading = false;
  let error = false;
  let focused = false;
  let matches = [];
  let focusedIndex = -1;
  let menuId = (_a = $$restProps["menu$id"]) !== null && _a !== void 0 ? _a : "SMUI-autocomplete-" + counter++ + "-menu";
  let previousText = text;
  let previousValue = value;
  let previousFocusedIndex = void 0;
  async function performSearch() {
    loading = true;
    error = false;
    try {
      const searchResult = await search(text);
      if (searchResult !== false) {
        matches = searchResult;
        if (selectOnExactMatch) {
          const exactMatch = matches.find((match) => getOptionLabel(match) === text);
          if (exactMatch && value !== exactMatch) {
            selectOption(exactMatch);
          }
        }
      }
    } catch (e) {
      error = true;
    }
    loading = false;
  }
  function selectOption(option, setText = true) {
    const event = dispatch(element, "SMUIAutocomplete:selected", option, { bubbles: true, cancelable: true });
    if (event.defaultPrevented) {
      return;
    }
    if (setText) {
      text = getOptionLabel(option);
    }
    value = option;
    if (!setText) {
      previousValue = option;
    }
  }
  function deselectOption(option, setText = true) {
    const event = dispatch(element, "SMUIAutocomplete:deselected", option, { bubbles: true, cancelable: true });
    if (event.defaultPrevented) {
      return;
    }
    if (setText) {
      text = "";
    }
    value = void 0;
    if (!setText) {
      previousValue = void 0;
    }
  }
  function getActiveMenuItems() {
    {
      return [];
    }
  }
  function focus() {
  }
  function blur() {
  }
  function getElement() {
    return element;
  }
  if ($$props.use === void 0 && $$bindings.use && use !== void 0) $$bindings.use(use);
  if ($$props.class === void 0 && $$bindings.class && className !== void 0) $$bindings.class(className);
  if ($$props.options === void 0 && $$bindings.options && options !== void 0) $$bindings.options(options);
  if ($$props.value === void 0 && $$bindings.value && value !== void 0) $$bindings.value(value);
  if ($$props.getOptionDisabled === void 0 && $$bindings.getOptionDisabled && getOptionDisabled !== void 0) $$bindings.getOptionDisabled(getOptionDisabled);
  if ($$props.getOptionLabel === void 0 && $$bindings.getOptionLabel && getOptionLabel !== void 0) $$bindings.getOptionLabel(getOptionLabel);
  if ($$props.text === void 0 && $$bindings.text && text !== void 0) $$bindings.text(text);
  if ($$props.label === void 0 && $$bindings.label && label !== void 0) $$bindings.label(label);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0) $$bindings.disabled(disabled);
  if ($$props.toggle === void 0 && $$bindings.toggle && toggle !== void 0) $$bindings.toggle(toggle);
  if ($$props.combobox === void 0 && $$bindings.combobox && combobox !== void 0) $$bindings.combobox(combobox);
  if ($$props.clearOnBlur === void 0 && $$bindings.clearOnBlur && clearOnBlur !== void 0) $$bindings.clearOnBlur(clearOnBlur);
  if ($$props.selectOnExactMatch === void 0 && $$bindings.selectOnExactMatch && selectOnExactMatch !== void 0) $$bindings.selectOnExactMatch(selectOnExactMatch);
  if ($$props.showMenuWithNoInput === void 0 && $$bindings.showMenuWithNoInput && showMenuWithNoInput !== void 0) $$bindings.showMenuWithNoInput(showMenuWithNoInput);
  if ($$props.noMatchesActionDisabled === void 0 && $$bindings.noMatchesActionDisabled && noMatchesActionDisabled !== void 0) $$bindings.noMatchesActionDisabled(noMatchesActionDisabled);
  if ($$props.search === void 0 && $$bindings.search && search !== void 0) $$bindings.search(search);
  if ($$props.menu$class === void 0 && $$bindings.menu$class && menu$class !== void 0) $$bindings.menu$class(menu$class);
  if ($$props.menu$anchor === void 0 && $$bindings.menu$anchor && menu$anchor !== void 0) $$bindings.menu$anchor(menu$anchor);
  if ($$props.menu$anchorCorner === void 0 && $$bindings.menu$anchorCorner && menu$anchorCorner !== void 0) $$bindings.menu$anchorCorner(menu$anchorCorner);
  if ($$props.focus === void 0 && $$bindings.focus && focus !== void 0) $$bindings.focus(focus);
  if ($$props.blur === void 0 && $$bindings.blur && blur !== void 0) $$bindings.blur(blur);
  if ($$props.getElement === void 0 && $$bindings.getElement && getElement !== void 0) $$bindings.getElement(getElement);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (previousValue !== value) {
        text = getOptionLabel(value);
        previousValue = value;
      } else if (combobox && value !== text) {
        value = text;
        previousValue = value;
      }
    }
    menuOpen = focused;
    {
      if (previousText !== text) {
        if (!combobox && value != null && getOptionLabel(value) !== text) {
          deselectOption(value, false);
        }
      }
    }
    {
      if (options) {
        performSearch();
      }
    }
    {
      if (previousFocusedIndex !== focusedIndex) {
        const activeItems = getActiveMenuItems();
        activeItems.forEach((item, i) => {
          if (i !== focusedIndex) {
            item.activated = false;
          }
        });
        previousFocusedIndex = focusedIndex;
      }
    }
    $$rendered = `<div${spread(
      [
        {
          class: escape_attribute_value(classMap({
            [className]: true,
            "smui-autocomplete": true
          }))
        },
        escape_object(exclude($$restProps, ["menu$", "textfield$", "list$"]))
      ],
      {}
    )}${add_attribute("this", element, 0)}><div${add_attribute("aria-controls", menuId, 0)}${add_attribute("aria-expanded", menuOpen ? "true" : "false", 0)} role="combobox" tabindex="0"${add_attribute("this", inputContainer, 0)}>${slots.default ? slots.default({}) : ` ${validate_component(Textfield, "Textfield").$$render(
      $$result,
      Object.assign({}, { label }, { disabled }, prefixFilter($$restProps, "textfield$"), { value: text }),
      {
        value: ($$value) => {
          text = $$value;
          $$settled = false;
        }
      },
      {}
    )} `}</div> ${validate_component(Menu, "Menu").$$render(
      $$result,
      Object.assign(
        {},
        {
          class: classMap({
            [menu$class]: true,
            "smui-autocomplete__menu": true
          })
        },
        { id: menuId },
        { managed: true },
        { neverRestoreFocus: true },
        { open: menuOpen },
        { anchor: menu$anchor },
        { anchorCorner: menu$anchorCorner },
        prefixFilter($$restProps, "menu$"),
        { anchorElement: element }
      ),
      {
        anchorElement: ($$value) => {
          element = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(List, "List").$$render($$result, Object.assign({}, prefixFilter($$restProps, "list$")), {}, {
            default: () => {
              return `${loading ? `${validate_component(Item$1, "Item").$$render($$result, { disabled: true }, {}, {
                default: () => {
                  return `${slots.loading ? slots.loading({}) : ` ${validate_component(Text, "Text").$$render($$result, {}, {}, {
                    default: () => {
                      return `Loading...`;
                    }
                  })} `}`;
                }
              })}` : `${error ? `${validate_component(Item$1, "Item").$$render($$result, { disabled: true }, {}, {
                default: () => {
                  return `${slots.error ? slots.error({}) : ` ${validate_component(Text, "Text").$$render($$result, {}, {}, {
                    default: () => {
                      return `Error while fetching suggestions.`;
                    }
                  })} `}`;
                }
              })}` : `${matches.length ? each(matches, (match, i) => {
                return `${validate_component(Item$1, "Item").$$render(
                  $$result,
                  {
                    disabled: getOptionDisabled(match),
                    selected: match === value
                  },
                  {},
                  {
                    default: () => {
                      return `${slots.match ? slots.match({ match }) : ` ${validate_component(Text, "Text").$$render($$result, {}, {}, {
                        default: () => {
                          return `${escape(getOptionLabel(match))}`;
                        }
                      })} `} `;
                    }
                  }
                )}`;
              }) : `${validate_component(Item$1, "Item").$$render($$result, { disabled: noMatchesActionDisabled }, {}, {
                default: () => {
                  return `${slots["no-matches"] ? slots["no-matches"]({}) : ` ${validate_component(Text, "Text").$$render($$result, {}, {}, {
                    default: () => {
                      return `No matches found.`;
                    }
                  })} `} `;
                }
              })}`}`}`}`;
            }
          })}`;
        }
      }
    )} </div>`;
  } while (!$$settled);
  return $$rendered;
});
function CollectGarbage() {
}
function Cancel() {
}
function Pause() {
}
function Resume() {
}
async function initSpeech() {
}
const Tts = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  let audio;
  async function GetGoogleTTS(lang, text, quiz) {
    console.log();
    if (!audio || audio && text !== audio.text) {
      text = text.replace(/<[^>]+>.*?<\/[^>]+>/g, "");
      const par = {
        func: "tts",
        text,
        lang,
        //(lang=='nl'?lang+'-BE':lang)
        quiz
      };
      const response = await fetch("/speech/tts", {
        method: "POST",
        body: JSON.stringify({ par })
      });
      if (!response.ok) {
        throw new Error(`Ошибка сервера: ${response.status}`);
      }
      return await response.json();
    }
  }
  async function Speak_server(lang, text, quiz, cb_end) {
    console.log();
    const resp = await GetGoogleTTS(lang, text, quiz);
    if (resp?.resp.audio) audio = new Audio(resp.resp.audio);
    audio.type = "audio/mpeg";
    audio.text = text;
    audio.playbackRate = lang === $langs ? 1 : 0.9;
    if (cb_end) audio.addEventListener("ended", function() {
      cb_end();
    });
    audio.play();
  }
  onDestroy(() => {
    audio = "";
  });
  if ($$props.GetGoogleTTS === void 0 && $$bindings.GetGoogleTTS && GetGoogleTTS !== void 0) $$bindings.GetGoogleTTS(GetGoogleTTS);
  if ($$props.Speak_server === void 0 && $$bindings.Speak_server && Speak_server !== void 0) $$bindings.Speak_server(Speak_server);
  if ($$props.CollectGarbage === void 0 && $$bindings.CollectGarbage && CollectGarbage !== void 0) $$bindings.CollectGarbage(CollectGarbage);
  if ($$props.Cancel === void 0 && $$bindings.Cancel && Cancel !== void 0) $$bindings.Cancel(Cancel);
  if ($$props.Pause === void 0 && $$bindings.Pause && Pause !== void 0) $$bindings.Pause(Pause);
  if ($$props.Resume === void 0 && $$bindings.Resume && Resume !== void 0) $$bindings.Resume(Resume);
  if ($$props.initSpeech === void 0 && $$bindings.initSpeech && initSpeech !== void 0) $$bindings.initSpeech(initSpeech);
  $$unsubscribe_langs();
  return ``;
});
const css$c = {
  code: "audio.svelte-1wq1rn3{height:25px;margin:0 auto}",
  map: '{"version":3,"file":"Stt.svelte","sources":["Stt.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy } from \\"svelte\\";\\nimport { MediaRecorder } from \\"extendable-media-recorder\\";\\nexport let SttResult, StopListening, display_audio;\\nlet mediaRecorder, mediaStream, audioAnalyser, audioChunks = [], audioUrl, audioPlayer, isRecording = false, soundTimer, silenceTimer;\\nconst threshold = 10;\\nconst silenceDelay = 2e3;\\nlet checkLoop = true;\\nlet from_lang = \\"en\\";\\nlet to_lang = \\"en\\";\\nonMount(async () => {\\n  try {\\n    mediaStream = await navigator.mediaDevices.getUserMedia({\\n      audio: {\\n        echoCancellation: true,\\n        noiseSuppression: true,\\n        autoGainControl: true,\\n        channelCount: 1,\\n        sampleRate: 48e3,\\n        sampleSize: 16,\\n        volume: 1\\n      },\\n      video: false\\n      // Если видео не нужно\\n    });\\n    if (mediaStream) {\\n      const audioContext = new AudioContext();\\n      audioAnalyser = audioContext.createAnalyser();\\n      const source = audioContext.createMediaStreamSource(mediaStream);\\n      source.connect(audioAnalyser);\\n      const noiseSuppression = audioContext.createDynamicsCompressor();\\n      noiseSuppression.threshold.value = -20;\\n      source.connect(noiseSuppression);\\n    } else {\\n      console.error(\\"\\\\u041D\\\\u0435\\\\u0442 \\\\u0434\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F\\\\u0430 \\\\u043A \\\\u043C\\\\u0438\\\\u043A\\\\u0440\\\\u043E\\\\u0444\\\\u043E\\\\u043D\\\\u0443 \\\\u0438\\\\u043B\\\\u0438 \\\\u043F\\\\u043E\\\\u043B\\\\u044C\\\\u0437\\\\u043E\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043B\\\\u044C \\\\u043E\\\\u0442\\\\u043A\\\\u0430\\\\u0437\\\\u0430\\\\u043B\\\\u0441\\\\u044F \\\\u043E\\\\u0442 \\\\u0434\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F\\\\u0430.\\");\\n    }\\n  } catch (error) {\\n    console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u0434\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F\\\\u0430 \\\\u043A \\\\u043C\\\\u0438\\\\u043A\\\\u0440\\\\u043E\\\\u0444\\\\u043E\\\\u043D\\\\u0443:\\", error);\\n  }\\n  audioChunks = [];\\n  audioUrl = \\"\\";\\n  const options = {\\n    bitsPerSecond: 44100\\n    // mimeType: \'audio/wav\',\\n    // audioBitsPerSecond: 128000 // Битрейт аудио (по желанию)\\n  };\\n  mediaRecorder = new MediaRecorder(mediaStream, options);\\n  mediaRecorder.ondataavailable = (e) => {\\n    audioChunks.push(e.data);\\n  };\\n  mediaRecorder.onstop = (e) => {\\n    stopRecording();\\n    StopListening();\\n  };\\n});\\nexport async function startAudioMonitoring(from, to) {\\n  from_lang = from;\\n  to_lang = to;\\n  try {\\n    startRecording();\\n    checkAudio();\\n  } catch (error) {\\n    console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u0434\\\\u043E\\\\u0441\\\\u0442\\\\u0443\\\\u043F\\\\u0430 \\\\u043A \\\\u043C\\\\u0438\\\\u043A\\\\u0440\\\\u043E\\\\u0444\\\\u043E\\\\u043D\\\\u0443:\\", error);\\n  }\\n}\\nfunction checkAudio() {\\n  console.log(\\"startRecording\\");\\n  const dataArray = new Uint8Array(audioAnalyser.frequencyBinCount);\\n  const checkSilence = () => {\\n    audioAnalyser.getByteFrequencyData(dataArray);\\n    const sum = dataArray.reduce((a, b) => a + b, 0);\\n    const average = sum / dataArray.length;\\n    console.log(\\"average:\\", average);\\n    if (average > threshold) {\\n      console.log(\\"threshold:\\", average);\\n      clearTimeout(silenceTimer);\\n      silenceTimer = \\"\\";\\n      console.log(\\"silenceTimer after:\\", silenceTimer);\\n    } else if (average <= threshold && isRecording) {\\n      if (!silenceTimer)\\n        silenceTimer = setTimeout(() => {\\n          MediaRecorderStop();\\n          console.log(\\"stopRecording:\\", average);\\n        }, silenceDelay);\\n    }\\n    if (checkLoop) {\\n      requestAnimationFrame(checkSilence);\\n    }\\n  };\\n  checkSilence();\\n}\\nexport function SendRecognition() {\\n  const len = audioChunks.length;\\n  sendAudioToRecognition(audioChunks[len - 1]);\\n}\\nexport function MediaRecorderStop() {\\n  isRecording = false;\\n  silenceTimer = \\"\\";\\n  checkLoop = false;\\n  clearTimeout(silenceTimer);\\n  mediaRecorder.stop();\\n}\\nfunction startRecording() {\\n  if (Array.isArray(audioChunks) && audioChunks.length > 0) {\\n    audioChunks.splice(0, 1);\\n  }\\n  mediaRecorder.start();\\n  isRecording = true;\\n  checkLoop = true;\\n  mediaStream.enable = false;\\n}\\nasync function stopRecording() {\\n  mediaStream.enable = true;\\n  const len = audioChunks.length;\\n  if (audioChunks[len - 1]?.size > 0) {\\n    sendAudioToRecognition(audioChunks[len - 1]);\\n    audioUrl = URL.createObjectURL(audioChunks[len - 1]);\\n    display_audio = \\"block\\";\\n  }\\n}\\nexport async function sendLoadModel() {\\n  fetch(\\"/speech/stt\\", {\\n    method: \\"POST\\",\\n    // mode: \'no-cors\',\\n    body: JSON.stringify({\\n      load: \\"model\\"\\n    }),\\n    headers: {\\n      \\"Content-Type\\": \\"application/json\\"\\n      // Authorization: `Bearer ${token}`\\n    }\\n  });\\n}\\nexport async function sendAudioToRecognition(blob) {\\n  try {\\n    const headers = {\\n      \\"Content-Type\\": \\"application/json\\"\\n      // Authorization: `Bearer ${token}`\\n    };\\n    const formData = new FormData();\\n    formData.append(\\"file\\", blob, \\"audio.wav\\");\\n    formData.append(\\"from_lang\\", from_lang);\\n    formData.append(\\"to_lang\\", to_lang);\\n    fetch(\\"/speech/stt\\", {\\n      method: \\"POST\\",\\n      // mode: \'no-cors\',\\n      body: formData,\\n      headers: { headers }\\n    }).then((response) => response.json()).then((data) => {\\n      SttResult(data.resp);\\n    }).catch((error) => {\\n      console.log(error);\\n      return [];\\n    });\\n  } catch (error) {\\n    console.log(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043E\\\\u0442\\\\u043F\\\\u0440\\\\u0430\\\\u0432\\\\u043A\\\\u0438 \\\\u0430\\\\u0443\\\\u0434\\\\u0438\\\\u043E:\\", error);\\n  }\\n}\\nfunction playAudio() {\\n  if (audioPlayer) {\\n    audioPlayer.play();\\n  }\\n}\\nonDestroy(() => {\\n  mediaRecorder = \\"\\";\\n  mediaStream = \\"\\";\\n  audioAnalyser = \\"\\";\\n  audioUrl = \\"\\";\\n  audioPlayer = \\"\\";\\n  audioChunks = \\"\\";\\n  clearTimeout(silenceTimer);\\n});\\n<\/script>\\r\\n\\r\\n<audio\\r\\n  bind:this={audioPlayer}\\r\\n  src={audioUrl}\\r\\n  controls\\r\\n  style=\\"display:{display_audio}\\"\\r\\n></audio>\\r\\n\\r\\n<!-- <button on:click={playAudio}>Воспроизвести</button> -->\\r\\n\\r\\n<style>\\r\\n  audio {\\r\\n    height: 25px;\\r\\n    margin: 0 auto;\\r\\n    /* width: 30vw; */\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAuLE,oBAAM,CACJ,MAAM,CAAE,IAAI,CACZ,MAAM,CAAE,CAAC,CAAC,IAEZ"}'
};
const threshold = 10;
const silenceDelay = 2e3;
async function sendLoadModel() {
  fetch("/speech/stt", {
    method: "POST",
    // mode: 'no-cors',
    body: JSON.stringify({ load: "model" }),
    headers: { "Content-Type": "application/json" }
    // Authorization: `Bearer ${token}`
  });
}
const Stt = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { SttResult, StopListening, display_audio } = $$props;
  let mediaRecorder, mediaStream, audioAnalyser, audioChunks = [], audioUrl, audioPlayer, isRecording = false, silenceTimer;
  let checkLoop = true;
  let from_lang = "en";
  let to_lang = "en";
  async function startAudioMonitoring(from, to) {
    from_lang = from;
    to_lang = to;
    try {
      startRecording();
      checkAudio();
    } catch (error) {
      console.error("Ошибка доступа к микрофону:", error);
    }
  }
  function checkAudio() {
    console.log("startRecording");
    const dataArray = new Uint8Array(audioAnalyser.frequencyBinCount);
    const checkSilence = () => {
      audioAnalyser.getByteFrequencyData(dataArray);
      const sum = dataArray.reduce((a, b) => a + b, 0);
      const average = sum / dataArray.length;
      console.log("average:", average);
      if (average > threshold) {
        console.log("threshold:", average);
        clearTimeout(silenceTimer);
        silenceTimer = "";
        console.log("silenceTimer after:", silenceTimer);
      } else if (average <= threshold && isRecording) {
        if (!silenceTimer) silenceTimer = setTimeout(
          () => {
            MediaRecorderStop();
            console.log("stopRecording:", average);
          },
          silenceDelay
        );
      }
      if (checkLoop) {
        requestAnimationFrame(checkSilence);
      }
    };
    checkSilence();
  }
  function SendRecognition() {
    const len = audioChunks.length;
    sendAudioToRecognition(audioChunks[len - 1]);
  }
  function MediaRecorderStop() {
    isRecording = false;
    silenceTimer = "";
    checkLoop = false;
    clearTimeout(silenceTimer);
    mediaRecorder.stop();
  }
  function startRecording() {
    if (Array.isArray(audioChunks) && audioChunks.length > 0) {
      audioChunks.splice(0, 1);
    }
    mediaRecorder.start();
    isRecording = true;
    checkLoop = true;
    mediaStream.enable = false;
  }
  async function sendAudioToRecognition(blob) {
    try {
      const headers = { "Content-Type": "application/json" };
      const formData = new FormData();
      formData.append("file", blob, "audio.wav");
      formData.append("from_lang", from_lang);
      formData.append("to_lang", to_lang);
      fetch("/speech/stt", {
        method: "POST",
        // mode: 'no-cors',
        body: formData,
        headers: { headers }
      }).then((response) => response.json()).then((data) => {
        SttResult(data.resp);
      }).catch((error) => {
        console.log(error);
        return [];
      });
    } catch (error) {
      console.log("Ошибка отправки аудио:", error);
    }
  }
  onDestroy(() => {
    mediaRecorder = "";
    mediaStream = "";
    audioAnalyser = "";
    audioUrl = "";
    audioPlayer = "";
    audioChunks = "";
    clearTimeout(silenceTimer);
  });
  if ($$props.SttResult === void 0 && $$bindings.SttResult && SttResult !== void 0) $$bindings.SttResult(SttResult);
  if ($$props.StopListening === void 0 && $$bindings.StopListening && StopListening !== void 0) $$bindings.StopListening(StopListening);
  if ($$props.display_audio === void 0 && $$bindings.display_audio && display_audio !== void 0) $$bindings.display_audio(display_audio);
  if ($$props.startAudioMonitoring === void 0 && $$bindings.startAudioMonitoring && startAudioMonitoring !== void 0) $$bindings.startAudioMonitoring(startAudioMonitoring);
  if ($$props.SendRecognition === void 0 && $$bindings.SendRecognition && SendRecognition !== void 0) $$bindings.SendRecognition(SendRecognition);
  if ($$props.MediaRecorderStop === void 0 && $$bindings.MediaRecorderStop && MediaRecorderStop !== void 0) $$bindings.MediaRecorderStop(MediaRecorderStop);
  if ($$props.sendLoadModel === void 0 && $$bindings.sendLoadModel && sendLoadModel !== void 0) $$bindings.sendLoadModel(sendLoadModel);
  if ($$props.sendAudioToRecognition === void 0 && $$bindings.sendAudioToRecognition && sendAudioToRecognition !== void 0) $$bindings.sendAudioToRecognition(sendAudioToRecognition);
  $$result.css.add(css$c);
  return `<audio${add_attribute("src", audioUrl, 0)} controls style="${"display:" + escape(display_audio, true)}" class="svelte-1wq1rn3"${add_attribute("this", audioPlayer, 0)}></audio> `;
});
const css$b = {
  code: "main_dlg.svelte-1tyd79t.svelte-1tyd79t{transition:transform 0.3s ease-in-out;width:100vw;margin:0 auto;position:relative;transform-style:preserve-3d;transition:transform 0.5s;height:120vh}.repeat_alert.svelte-1tyd79t.svelte-1tyd79t{position:absolute;left:30px;scale:0.7;z-index:2}.thumb_alert.svelte-1tyd79t.svelte-1tyd79t{position:absolute;width:30px;z-index:2;scale:0.7;right:40px}.container.svelte-1tyd79t.svelte-1tyd79t{top:15px;margin-bottom:15px;position:relative;justify-content:space-between;align-items:center;border:1px solid lightgrey;border-radius:5px}.thumb_but.svelte-1tyd79t.svelte-1tyd79t,.repeat_but.svelte-1tyd79t.svelte-1tyd79t{display:inline-flex;color:grey;margin-right:5px;font-size:xx-small;top:0px;z-index:2;scale:.8;border:grey solid 1px;border-radius:15px}.top-app-bar-container.svelte-1tyd79t.svelte-1tyd79t{position:relative;top:0px;border:1px solid\r\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));margin:0 18px 18px 0;background-color:var(--mdc-theme-background, #fff)}.margins.svelte-1tyd79t.svelte-1tyd79t{top:10px;position:relative;margin-right:10px;margin-left:10px}.margins.svelte-1tyd79t>.svelte-1tyd79t{margin-right:10px}.button_shared_true.svelte-1tyd79t.svelte-1tyd79t{position:relative;font-size:1.5em;color:blue;border:none;border-radius:5px;cursor:pointer}.button_shared_false.svelte-1tyd79t.svelte-1tyd79t{position:relative;font-size:1.5em;color:grey;border:none;border-radius:5px;cursor:pointer}.flip_button.svelte-1tyd79t.svelte-1tyd79t{position:relative;font-size:1.5em;text-align:center;color:grey;border:none;border-radius:5px;cursor:pointer;width:50px;bottom:5px}.speaker-button.svelte-1tyd79t.svelte-1tyd79t{position:relative;color:#2196f3;font-size:large;border-radius:25px;left:100%;margin-left:-30px;width:fit-content;z-index:0}.html_data.svelte-1tyd79t.svelte-1tyd79t{display:grid;width:100vw;position:relative;overflow-y:auto;height:100vh;margin:0 auto;margin-top:30px;border:0}.counter.svelte-1tyd79t.svelte-1tyd79t{background-color:#f0f0f0;padding:0px;border-radius:25px;width:30px;height:30px;top:-10px;left:-6px;box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);text-align:center}.counter.svelte-1tyd79t p.svelte-1tyd79t{margin:0;font-size:15px;color:#333}.counter.svelte-1tyd79t span.svelte-1tyd79t{font-weight:700;font-size:15px;color:#ff5733}.cnt.svelte-1tyd79t.svelte-1tyd79t{position:absolute;text-align:left;left:15px;top:-2px;z-index:2;font-size:1em;margin-bottom:10px;color:#501d94}.title.svelte-1tyd79t.svelte-1tyd79t{width:fit-content;margin:5px auto;margin-top:5px;color:lightgrey;line-height:normal;text-align:center;font-size:0.8em;background-color:transparent}.title2.svelte-1tyd79t.svelte-1tyd79t{font-size:0.7em}.user1.svelte-1tyd79t.svelte-1tyd79t{position:relative;text-align:center;line-height:normal;font-size:0.8em;margin-bottom:0px;color:#333;z-index:-1}.user2.svelte-1tyd79t.svelte-1tyd79t{position:relative;top:10px;text-align:center;color:#2196f3;margin-left:10px;margin-right:10px}.user2_tr.svelte-1tyd79t.svelte-1tyd79t{text-align:center;line-height:normal;font-size:0.8em;margin-bottom:0px;color:#333;z-index:-1}.tip.svelte-1tyd79t.svelte-1tyd79t{position:relative;top:0px;text-align:center;line-height:normal;font-size:1em;margin-top:10px;color:#2196f3}.arrow-button.svelte-1tyd79t.svelte-1tyd79t{position:relative;top:0px;font-weight:600;background-color:white;color:#101c88;border:1px solid;border-radius:5px;cursor:pointer}.arrow-button-left.svelte-1tyd79t.svelte-1tyd79t{transform:translateY(-50%)}.arrow-button-right.svelte-1tyd79t.svelte-1tyd79t{transform:translateY(-50%)}.hint-button.svelte-1tyd79t.svelte-1tyd79t{position:absolute;right:0;top:0;border:1px solid;color:#2196f3;border-radius:3px;padding:1px 7px;scale:0.8}.card.svelte-1tyd79t.svelte-1tyd79t{transition:transform 0.3s ease-in-out;transform-style:preserve-3d;transition:transform 0.5s;top:40px;overflow-y:auto;border-radius:5px;margin:0 auto;position:relative;height:calc(100vh - 80px);margin-left:10px;margin-right:10px}.words_div.svelte-1tyd79t.svelte-1tyd79t{position:relative;text-align:center;overflow-y:auto}.hint_button.svelte-1tyd79t.svelte-1tyd79t{display:inline-block;font-size:larger;border:solid 0.1em #9f3f3f;border-radius:5px;text-align:center;width:50px;padding-left:8px;margin:5px;background-color:transparent}.hidden-text.svelte-1tyd79t.svelte-1tyd79t{opacity:1}p.svelte-1tyd79t.svelte-1tyd79t{cursor:pointer;user-select:text}.highlight.svelte-1tyd79t.svelte-1tyd79t{background-color:yellow}.svelte-1tyd79t.svelte-1tyd79t::-webkit-scrollbar{display:none}",
  map: `{"version":3,"file":"Dialog.svelte","sources":["Dialog.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy, getContext } from \\"svelte\\";\\nimport ConText from \\"../Context.svelte\\";\\nimport TopAppBar, { Row, Title, Section } from \\"@smui/top-app-bar\\";\\nimport Button, { Label } from \\"@smui/button\\";\\nimport Badge from \\"@smui-extra/badge\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport { Translate } from \\"../../../translate/Transloc\\";\\nimport { slide } from \\"svelte/transition\\";\\nimport CircularProgress from \\"@smui/circular-progress\\";\\nimport Chip, { Set, LeadingIcon, TrailingIcon, Text } from \\"@smui/chips\\";\\nimport \\"$lib/css/Typography.scss\\";\\nimport md5 from \\"md5\\";\\nimport { lesson, langs, dicts, llang, view, dc, dc_state, msg, call_but_status, showBottomAppBar, OnCheckQU } from \\"$lib/js/stores.js\\";\\nconst dict = $dicts;\\nimport { mdiRepeat, mdiArrowRight, mdiArrowLeft, mdiShareVariant, mdiMicrophone, mdiMicrophoneOutline, mdiAccountConvertOutline, mdiPlay, mdiThumbUpOutline, mdiEarHearing } from \\"@mdi/js\\";\\nimport pkg from \\"lodash\\";\\nconst { maxBy } = pkg;\\nlet voice;\\nimport Tts from \\"../../../speech/tts/Tts.svelte\\";\\nimport Stt from \\"../../../speech/stt/Stt.svelte\\";\\nconst operator = getContext(\\"operator\\");\\nlet stt, tts;\\nlet dialog_data;\\nlet isFlipped = false;\\nlet isRepeat = false, isThumb = false;\\nlet isPlayAuto = false;\\nlet isSTT = false;\\nlet isCollapsed = true;\\nlet playAutoColor = \\"currentColor\\";\\nlet example_lang = $langs;\\n$: if (isPlayAuto) {\\n  playAutoColor = \\"green\\";\\n} else {\\n  playAutoColor = \\"currentColor\\";\\n}\\nconst visibility = [\\"visible\\", \\"hidden\\", \\"hidden\\"];\\nlet visibility_cnt = 1;\\nlet topAppBar;\\nlet share_mode = false;\\nexport let data;\\nif (data.name) {\\n  if (data.quiz !== \\"dialog.client\\")\\n    init();\\n}\\n$: if (dialog_data && $call_but_status === \\"talk\\") {\\n  if (!share_mode)\\n    onShare();\\n}\\n$: switch ($call_but_status) {\\n  case \\"talk\\":\\n    break;\\n  case \\"inactive\\":\\n    if (share_mode)\\n      $lesson.data = { quiz: \\"\\" };\\n    break;\\n  default:\\n    share_mode = false;\\n    break;\\n}\\nlet showSpeakerButton = false;\\nlet tip_hidden_text = \\"hidden-text\\";\\nlet cur_html = 0;\\nlet cur_qa = 0;\\nlet q, q_shfl, a_shfl, a, d;\\nlet display_audio = \\"none\\";\\nlet stt_text = \\"\\", hints = [\\"test\\"];\\nlet isListening = false;\\nlet total_cnt = 0;\\nlet share_button_class = \\"button_shared_false\\";\\nlet variant = \\"outlined\\";\\nlet speechData = {};\\n$: if ($msg) {\\n  if ($msg.lesson?.quiz === \\"dialog\\") {\\n    dialog_data = $msg.lesson.dialog_data;\\n    isFlipped = !$msg.lesson.isFlipped;\\n    cur_qa = $msg.lesson.cur_qa;\\n    visibility[1] = \\"hidden\\";\\n    visibility[2] = \\"hidden\\";\\n    visibility_cnt = 1;\\n    Dialog();\\n    $OnCheckQU(null, \\"dialog\\", dialog_data.name);\\n  }\\n  if ($msg.command === \\"repeat\\") {\\n    isRepeat = true;\\n    setTimeout(() => {\\n      isRepeat = false;\\n    }, 2e3);\\n  } else if ($msg.command === \\"thumb\\") {\\n    isThumb = true;\\n    setTimeout(() => {\\n      isThumb = false;\\n      if (!isFlipped) {\\n        onNextQA();\\n      }\\n    }, 2e3);\\n  } else if ($msg.command === \\"quit\\") {\\n    $msg.command = \\"\\";\\n    setTimeout(() => {\\n      $lesson.data = { quiz: \\"\\" };\\n    }, 100);\\n  }\\n}\\n$: if ($msg) {\\n  if ($msg.lesson?.quiz === \\"dialog\\") {\\n    dialog_data = $msg.lesson.dialog_data;\\n    isFlipped = !$msg.lesson.isFlipped;\\n    cur_qa = $msg.lesson.cur_qa;\\n    visibility[1] = \\"hidden\\";\\n    visibility[2] = \\"hidden\\";\\n    visibility_cnt = 1;\\n    Dialog();\\n    $OnCheckQU(null, \\"dialog\\", dialog_data.name);\\n  }\\n  if ($msg.command === \\"repeat\\") {\\n    isRepeat = true;\\n    setTimeout(() => {\\n      isRepeat = false;\\n    }, 2e3);\\n  } else if ($msg.command === \\"thumb\\") {\\n    isThumb = true;\\n    setTimeout(() => {\\n      isThumb = false;\\n    }, 2e3);\\n  } else if ($msg.command === \\"quit\\") {\\n    $msg.command = \\"\\";\\n    setTimeout(() => {\\n      $lesson.data = { quiz: \\"\\" };\\n    }, 100);\\n  }\\n}\\n$: if ($msg?.msg || $msg?.msg) {\\n  (async () => {\\n    alert(await Translate($msg?.msg || $msg?.msg, \\"ru\\", $langs));\\n  })();\\n}\\n$: if (data.html) {\\n  share_mode = true;\\n}\\n$: if (q && !q[$langs]) {\\n  (async () => {\\n    q[$langs] = await Translate(q[$llang], $llang, $langs);\\n  })();\\n}\\n$: if (a && !a[$langs]) {\\n  (async () => {\\n    a[$langs] = await Translate(a[$llang], $llang, $langs);\\n  })();\\n}\\n$: if ($langs) {\\n  example_lang = $langs;\\n}\\nif (data.func) {\\n  onChangeUserClick();\\n}\\nonMount(async () => {\\n  window.scrollTo({ top: 0, behavior: \\"smooth\\" });\\n  setTimeout(() => {\\n    if (!share_mode) {\\n    }\\n  }, 3e3);\\n});\\nfunction flipCard() {\\n  isFlipped = !isFlipped;\\n  Dialog();\\n}\\nasync function init() {\\n  function splitHtmlContent(inputString) {\\n    const regex = /<(?:!DOCTYPE html|html(?:\\\\s[^>]*)?)>(.*?)<\\\\/html>/gs;\\n    const matches = inputString.matchAll(regex);\\n    const result = Array.from(matches, (match) => match[1]);\\n    return result;\\n  }\\n  fetch(\`./lesson?dialog=\${data.name}&owner=\${operator.abonent}&level=\${data.level}\`).then((response) => response.json()).then(async (dlg_data) => {\\n    dialog_data = dlg_data.data.dialog;\\n    total_cnt = dialog_data.content.length;\\n    if (dlg_data.data.html) {\\n      dialog_data.html = dlg_data.data.html;\\n    }\\n    dialog_data.name = data.name;\\n    Dialog();\\n  }).catch((error) => {\\n    console.log(error);\\n    return [];\\n  });\\n}\\nfunction Dialog() {\\n  if (!dialog_data.content[0]) {\\n    return;\\n  }\\n  return new Promise(async (resolve, reject) => {\\n    let qa = dialog_data.content[cur_qa];\\n    if (!qa) {\\n      cur_qa = 0;\\n      qa = dialog_data.content[cur_qa];\\n      cur_html++;\\n      if (dialog_data.html && !dialog_data.html[cur_html]) {\\n        cur_html = 0;\\n      }\\n      if (!isPlayAuto)\\n        setTimeout(() => {\\n          onChangeUserClick();\\n        }, 0);\\n      return;\\n    }\\n    q = isFlipped ? qa.user2 : qa.user1;\\n    if (!q[$langs])\\n      q[$langs] = await Translate(q[$llang], $llang, $langs);\\n    q[$llang] = q[$llang]?.replace(\\"\${user1_name}\\", $dc ? \\"user_name\\" : \\"Kolmit\\");\\n    q[$langs] = q[$langs]?.replace(\\"\${user1_name}\\", $dc ? \\"user_name\\" : \\"Kolmit\\");\\n    q[$llang] = q[$llang]?.replace(\\"\${user2_name}\\", operator.name);\\n    q[$langs] = q[$langs]?.replace(\\"\${user2_name}\\", operator.name);\\n    q_shfl = q[$llang].slice(0);\\n    const dc2 = $dc?.dc.readyState === \\"open\\" ? $dc : \\"\\";\\n    let ar = q_shfl.toLowerCase().replaceAll(\\"?\\", \\"\\").replaceAll(\\",\\", \\" \\").split(\\" \\");\\n    a = isFlipped ? qa.user1 : qa.user2;\\n    if (!a[$langs])\\n      a[$langs] = await Translate(a[$llang], $llang, $langs);\\n    a[$llang] = a[$llang]?.replace(\\"\${user2_name}\\", \\"...\\");\\n    a[$langs] = a[$langs]?.replace(\\"\${user2_name}\\", \\"...\\");\\n    hints = a.hints;\\n    dialog_data.hints = a.hints;\\n    a_shfl = a[$llang].slice(0);\\n    ar = a_shfl.toLowerCase().replaceAll(\\"?\\", \\"\\").replaceAll(\\",\\", \\" \\").split(\\" \\");\\n    resolve();\\n  });\\n}\\nfunction handleBackClick() {\\n  $lesson.data = { quiz: \\"\\" };\\n}\\nasync function onNextQA() {\\n  cur_qa++;\\n  visibility[1] = \\"hidden\\";\\n  visibility[2] = \\"hidden\\";\\n  visibility_cnt = 1;\\n  display_audio = \\"none\\";\\n  tip_hidden_text = \\"\\";\\n  selectedSentence = \\"\\";\\n  setTimeout(() => {\\n    tip_hidden_text = \\"hidden-text\\";\\n  }, 50);\\n  SendData();\\n  stt_text = \\"\\";\\n  showSpeakerButton = false;\\n  return Dialog();\\n}\\nfunction onBackQA() {\\n  cur_qa--;\\n  visibility[1] = \\"hidden\\";\\n  visibility[2] = \\"hidden\\";\\n  visibility_cnt = 1;\\n  selectedSentence = \\"\\";\\n  Dialog();\\n  SendData();\\n  stt_text = \\"\\";\\n}\\nfunction onShare() {\\n  share_mode = true;\\n  share_button_class = \`button_shared_\${share_mode}\`;\\n  selectedSentence = \\"\\";\\n  Dialog();\\n  SendData();\\n}\\nasync function SendData() {\\n  const dc2 = $dc?.dc.readyState === \\"open\\" ? $dc : \\"\\";\\n  if (share_mode && dc2) {\\n    dialog_data.content[cur_qa].user2[\\"a_shfl\\"] = a_shfl;\\n    $msg = $msg = null;\\n    await dc2.SendData({\\n      lesson: {\\n        quiz: \\"dialog\\",\\n        llang: $llang,\\n        level: data.level,\\n        name: dialog_data.name,\\n        html: dialog_data.html ? dialog_data.html[cur_html] : null,\\n        dialog_data,\\n        cur_qa,\\n        isFlipped\\n      }\\n    }, (ex) => {\\n      console.log(dc2);\\n    });\\n  }\\n}\\nfunction onChangeUserClick() {\\n  flipCard();\\n  data = {\\n    llang: $llang,\\n    html: dialog_data.html ? dialog_data.html[cur_html] : \\"\\",\\n    user1: dialog_data.content[cur_qa].user1,\\n    user2: dialog_data.content[cur_qa].user2,\\n    a_shfl,\\n    quiz: data.quiz\\n  };\\n  data.quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  const client_quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  const dc2 = $dc?.dc.readyState === \\"open\\" ? $dc : \\"\\";\\n  dialog_data.content[cur_qa].user2[\\"a_shfl\\"] = a_shfl;\\n  if (dc2 && share_mode)\\n    SendData();\\n  visibility_cnt = 1;\\n}\\nfunction onClickQ(cnt) {\\n  visibility[cnt] = \\"visible\\";\\n}\\nfunction shuffle(array) {\\n  for (let i = array.length - 1; i > 0; i--) {\\n    const j = Math.floor(Math.random() * (i + 1));\\n    [array[i], array[j]] = [array[j], array[i]];\\n  }\\n  return array;\\n}\\nasync function speak(text, cb_end) {\\n  function endSpeak() {\\n  }\\n  if (!text)\\n    return;\\n  const hash = md5(text);\\n  if (speechData[hash]) {\\n    let audio = new Audio(speechData[hash]);\\n    audio.playbackRate = 0.9;\\n    audio.play();\\n  } else {\\n    tts.Speak_server($llang, text, dialog_data.name, endSpeak);\\n  }\\n}\\nfunction onClickMicrophone() {\\n  if (isListening) {\\n    stt.MediaRecorderStop();\\n    isListening = false;\\n    return;\\n  }\\n  stt.startAudioMonitoring($llang, $langs);\\n  isListening = true;\\n}\\nfunction StopListening() {\\n  isListening = false;\\n}\\nfunction SttResult(text) {\\n  stt_text = text[$llang];\\n  const numbers = dialog_data.content[cur_qa].user2[$llang].match(/\\\\b\\\\d+\\\\b/g);\\n  if (numbers)\\n    dialog_data.content[cur_qa].user2[$llang] = dialog_data.content[cur_qa].user2[$llang].replace(/\\\\b\\\\d+\\\\b/g, numberToDutchString(numbers[0]));\\n  if (stt_text) {\\n    const similarity = compareStrings(\\n      dialog_data.content[cur_qa].user2[$llang].toLowerCase().trim().replace(/[^\\\\w\\\\s]|_/g, \\"\\"),\\n      stt_text.toLowerCase().trim().replace(/[^\\\\w\\\\s]|_/g, \\"\\")\\n      //replace(/[0-9!\\"#$%&'()*+,-./:;<=>?@[\\\\]^_\`{|}~]/g, '')\\n    );\\n    stt_text += \` (\${similarity.toFixed(0)}%)\`;\\n    if (similarity > 75) {\\n      setTimeout(() => {\\n      }, 3e3);\\n    }\\n  }\\n}\\nfunction compareStrings(str1, str2) {\\n  function levenshteinDistance(s, t) {\\n    const d2 = [];\\n    for (let i = 0; i <= s.length; i++) {\\n      d2[i] = [i];\\n    }\\n    for (let j = 0; j <= t.length; j++) {\\n      d2[0][j] = j;\\n    }\\n    for (let j = 1; j <= t.length; j++) {\\n      for (let i = 1; i <= s.length; i++) {\\n        if (s.charAt(i - 1) === t.charAt(j - 1)) {\\n          d2[i][j] = d2[i - 1][j - 1];\\n        } else {\\n          d2[i][j] = Math.min(\\n            d2[i - 1][j] + 1,\\n            // удаление\\n            d2[i][j - 1] + 1,\\n            // вставка\\n            d2[i - 1][j - 1] + 1\\n            // замена\\n          );\\n        }\\n      }\\n    }\\n    return d2[s.length][t.length];\\n  }\\n  const len1 = str1.length;\\n  const len2 = str2.length;\\n  const maxLength = Math.max(len1, len2);\\n  const distance = levenshteinDistance(str1, str2);\\n  const similarity = (1 - distance / maxLength) * 100;\\n  console.log(\\"similarityPercentage\\", similarity);\\n  return similarity;\\n}\\nfunction SendCommand(cmd, ev) {\\n  variant = \\"unelevated\\";\\n  setTimeout(() => {\\n    variant = \\"outlined\\";\\n  }, 1e3);\\n  if (ev)\\n    ev.target.style.color = \\"red\\";\\n  const dc2 = $dc?.dc.readyState === \\"open\\" ? $dc : \\"\\";\\n  if (dc2) {\\n    return new Promise((resolve) => {\\n      dc2.SendData({\\n        command: cmd\\n      }, () => {\\n        console.log();\\n        resolve();\\n      });\\n    });\\n  }\\n}\\nlet selectedSentence = \\"\\";\\nconst getSentenceFromSelection = function(ev) {\\n  const text = ev.currentTarget.outerText;\\n  const selection = window.getSelection();\\n  const selectedText = selection.toString();\\n  console.log(selectedText);\\n  if (selectedText) {\\n    const sentenceRegex = /[^.!?]*[.!?]/g;\\n    const sentences = text.match(sentenceRegex);\\n    if (sentences) {\\n      for (let sentence of sentences) {\\n        if (sentence.includes(selectedText)) {\\n          selectedSentence = sentence.trim();\\n          const translateUrl = \`https://translate.google.com/?sl=auto&tl=ru&text=\${encodeURIComponent(selectedSentence)}&op=translate\`;\\n          window.open(translateUrl, \\"_blank\\");\\n          break;\\n        }\\n      }\\n    }\\n  }\\n};\\nfunction PlayAutoContent() {\\n  isPlayAuto = !isPlayAuto;\\n  if (!isPlayAuto)\\n    return;\\n  async function onEndSpeak() {\\n    if (!isPlayAuto)\\n      return;\\n    visibility[2] = \\"visible\\";\\n    if (active === q[$langs]) {\\n      active = q[$llang];\\n      tts.Speak_server($llang, active, onEndSpeak);\\n    } else if (active === a[$llang]) {\\n      await onNextQA();\\n      visibility[1] = \\"visible\\";\\n      active = q[$langs];\\n      tts.Speak_server($langs, active, onEndSpeak);\\n    } else if (active === q[$llang]) {\\n      active = a[$langs];\\n      tts.Speak_server($langs, active, onEndSpeak);\\n    } else if (active === a[$langs]) {\\n      active = a[$llang];\\n      tts.Speak_server($llang, active, onEndSpeak);\\n    }\\n  }\\n  visibility[1] = \\"visible\\";\\n  let active = q[$langs];\\n  tts.Speak_server($langs, active, onEndSpeak);\\n}\\nfunction onSTT() {\\n  isSTT = !isSTT;\\n}\\nonDestroy(async () => {\\n  $lesson.data = { quiz: \\"\\" };\\n  dialog_data = \\"\\";\\n  data = \\"\\";\\n  stt_text = \\"\\";\\n  stt = \\"\\";\\n  tts = \\"\\";\\n  $showBottomAppBar = true;\\n  await SendCommand(\\"quit\\", null);\\n});\\n<\/script>\\r\\n\\r\\n<link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/>\\r\\n\\r\\n<Tts bind:this={tts}></Tts>\\r\\n\\r\\n<main_dlg>\\r\\n  <div class=\\"top-app-bar-container flexor\\">\\r\\n    <TopAppBar bind:this={topAppBar} variant=\\"fixed\\">\\r\\n      <Row>\\r\\n        <Section align=\\"start\\">\\r\\n          <!-- {#if !isFlipped} -->\\r\\n            {#if cur_qa > 0}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={onBackQA}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"margin-top:0px; scale:.5;width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"white\\" d={mdiArrowLeft} />\\r\\n              </Icon>\\r\\n            {:else}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={onBackQA}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"visibility:hidden;margin-top:0px; scale:.5;width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"\\" d={mdiArrowLeft} />\\r\\n              </Icon>\\r\\n            {/if}\\r\\n          <!-- {/if} -->\\r\\n        </Section>\\r\\n        <Section align=\\"start\\">\\r\\n          <div>\\r\\n            <IconButton\\r\\n              class=\\"material-icons\\"\\r\\n              aria-label=\\"Back\\"\\r\\n              on:click={onSTT}\\r\\n            >\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" style=\\"position:absolute; margin:10px 5px 10px 5px; scale:1.1;width:30px\\">\\r\\n                {#if isSTT}\\r\\n                  <path fill=\\"grey\\" d={mdiMicrophone} />\\r\\n                {:else}\\r\\n                  <path fill=\\"white\\" d={mdiMicrophoneOutline} />\\r\\n                {/if}\\r\\n              </Icon>\\r\\n            </IconButton>\\r\\n          </div>\\r\\n\\r\\n          <!-- {#if $dc_state === 'close'}\\r\\n            <IconButton on:click={PlayAutoContent}>\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                <path fill={playAutoColor} d={mdiEarHearing} />\\r\\n              </Icon>\\r\\n            </IconButton>\\r\\n          {/if} -->\\r\\n        </Section>\\r\\n        <Section align=\\"start\\">\\r\\n          <div class=\\"flip_button\\">\\r\\n            <IconButton>\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                <path fill=\\"currentColor\\" d={mdiAccountConvertOutline} />\\r\\n              </Icon>\\r\\n              {#if !isFlipped}\\r\\n                <Badge\\r\\n                  position=\\"middle\\"\\r\\n                  align=\\"bottom-end - bottom-middle\\"\\r\\n                  aria-label=\\"unread count\\"\\r\\n                  style=\\"scale:.8\\">A</Badge\\r\\n                >\\r\\n              {:else}\\r\\n                <Badge\\r\\n                  color=\\"secondary\\"\\r\\n                  position=\\"middle\\"\\r\\n                  align=\\"bottom-end - bottom-middle\\"\\r\\n                  aria-label=\\"unread count\\"\\r\\n                  style=\\"scale:.8\\">B</Badge\\r\\n                >\\r\\n              {/if}\\r\\n            </IconButton>\\r\\n          </div>\\r\\n        </Section>\\r\\n        <Section align=\\"start\\">\\r\\n          <div class=\\"counter\\">\\r\\n            <p>\\r\\n              <span class=\\"mdc-typography--overline\\" style=\\"position:relative\\"\\r\\n                >{cur_qa + 1}\\r\\n                <Badge\\r\\n                  position=\\"middle\\"\\r\\n                  align=\\"bottom-end - bottom-middle\\"\\r\\n                  aria-label=\\"unread count\\"\\r\\n                  style=\\"margin-right:-10px;scale:.8\\">{total_cnt}</Badge\\r\\n                >\\r\\n              </span>\\r\\n            </p>\\r\\n          </div>\\r\\n        </Section>\\r\\n        <Section align=\\"end\\">\\r\\n\\r\\n        </Section>\\r\\n        <Section align=\\"end\\">\\r\\n          <!-- {#if !isFlipped} -->\\r\\n            <Icon\\r\\n              tag=\\"svg\\"\\r\\n              on:click={onNextQA}\\r\\n              viewBox=\\"0 0 24 24\\"\\r\\n              style=\\"margin-top:0px; scale:.5; width:50px\\"\\r\\n            >\\r\\n              <path fill=\\"white\\" d={mdiArrowRight} />\\r\\n            </Icon>\\r\\n          <!-- {/if} -->\\r\\n        </Section>\\r\\n      </Row>\\r\\n    </TopAppBar>\\r\\n  </div>\\r\\n  <!-- Ваш контент для лицевой стороны -->\\r\\n  <div class=\\"card\\">\\r\\n\\r\\n    {#if !dialog_data?.html}\\r\\n      <span\\r\\n        style=\\"display:block-inline;position:relative;width:80%;color: lightgray;font-style: italic;font-size:smaller;font-family: serif;\\"\\r\\n        >{dialog_data?.name}</span\\r\\n      >\\r\\n\\r\\n    {:else if dialog_data?.html}\\r\\n      <span on:click={() => (isCollapsed = !isCollapsed)}\\r\\n        style=\\"display:block-inline;position:relative;width:80%;color: black;font-style: italic;font-size:smaller;font-family: serif;\\"\\r\\n        >{dialog_data?.name}</span\\r\\n      >\\r\\n    <!-- // <span  on:click={() => (isCollapsed = !isCollapsed)}\\r\\n    //   class=\\"not_collapsed\\"\\r\\n    //     style=\\"position:absolute; right:20px;color:gray;font-style: italic;font-size:smaller;font-family: serif;\\"     \\r\\n    // >context</span> -->\\r\\n\\r\\n        {#if !isCollapsed}\\r\\n            <div class=\\"collapsible\\" in:slide={{ duration: 300 }}>\\r\\n              <ConText data={dialog_data} {tts} />\\r\\n            </div>\\r\\n        {/if}\\r\\n    {/if}\\r\\n\\r\\n   \\r\\n    {#if q || a}\\r\\n      {#if !isFlipped}\\r\\n      <div class=\\"container\\">\\r\\n\\r\\n          {#if $call_but_status == 'talk'}\\r\\n            <div class=\\"repeat_but\\">\\r\\n              <IconButton on:click={(ev) => SendCommand('repeat', ev)}>\\r\\n                <Icon tag=\\"svg\\" color=\\"secondary\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiRepeat} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            </div>\\r\\n          {/if}\\r\\n\\r\\n\\r\\n          {#await Translate('Послушай вопрос', 'ru', $langs) then data}\\r\\n            <div class=\\"title\\">{data}:</div>\\r\\n          {/await}\\r\\n\\r\\n          {#if visibility[1]==='hidden' }\\r\\n          <button class=\\"hint-button\\" on:click={()=>onClickQ(1)}>\\r\\n            <span class=\\"material-symbols-outlined\\">?</span>\\r\\n          </button>\\r\\n          {/if}\\r\\n\\r\\n        \\r\\n       \\r\\n          {#if $call_but_status == 'talk'}\\r\\n            <div class=\\"thumb_but\\">\\r\\n              <IconButton on:click={(ev) => SendCommand('thumb', ev)}>\\r\\n                <Icon tag=\\"svg\\" color=\\"secondary\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiThumbUpOutline} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n\\r\\n            </div>\\r\\n          {/if}\\r\\n\\r\\n        <div class=\\"\\" style=\\"text-align: center;\\">\\r\\n          {#if visibility[1]==='visible'}\\r\\n          <div class=\\"user1\\" style=\\"visibility:{visibility[1]}\\">\\r\\n            <span>\\r\\n                {#await Translate(q[$llang], $llang, $langs) then data}\\r\\n                  {@html data}\\r\\n                {/await}\\r\\n            </span>\\r\\n\\r\\n          </div>   \\r\\n          {/if}\\r\\n\\r\\n\\r\\n        <div\\r\\n          class=\\"tip mdc-typography--headline6 {tip_hidden_text}\\"\\r\\n          on:mouseup={getSentenceFromSelection}\\r\\n          on:touchend={getSentenceFromSelection}\\r\\n        >\\r\\n          {#if selectedSentence}\\r\\n            <p><span class=\\"highlight\\">{selectedSentence}</span></p>\\r\\n          {:else}\\r\\n            {@html q[$llang].replace(/\\"([^\\"]*)\\"/g, '$1')}\\r\\n          {/if}\\r\\n          <div style=\\"display: inline-flex; float: right; margin-right: 10px;}\\">\\r\\n            <br />\\r\\n            <!-- {#if showSpeakerButton} -->\\r\\n\\r\\n            <!-- {/if} -->\\r\\n          </div>\\r\\n        </div>\\r\\n\\r\\n        \\r\\n\\r\\n        <div class=\\"speaker-button\\" on:click={speak(q[$llang])}>\\r\\n          <IconButton>\\r\\n            <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n            </Icon>\\r\\n          </IconButton>\\r\\n        </div>\\r\\n      \\r\\n\\r\\n\\r\\n        {#if isThumb}\\r\\n          <div class=\\"thumb_alert\\" style=\\"margin-top: 10px;\\">\\r\\n            <Icon tag=\\"svg\\" color=\\"green\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiThumbUpOutline} />\\r\\n            </Icon>\\r\\n          </div>\\r\\n        {/if}\\r\\n\\r\\n        {#if isRepeat}\\r\\n          <div class=\\"repeat_alert\\" style=\\"margin-top: 10px;\\">\\r\\n            <Button>\\r\\n              <Label>{dict['Repeat'][$langs]}</Label>\\r\\n            </Button>\\r\\n          </div>\\r\\n        {/if}\\r\\n      </div>\\r\\n      </div>\\r\\n  \\r\\n\\r\\n      <div class=\\"container\\">\\r\\n\\r\\n\\r\\n\\r\\n        {#await Translate('Переведи и ответь', 'ru', $langs) then data_1}\\r\\n        <div class=\\"title\\">{data_1}:</div>\\r\\n        {/await}\\r\\n        {#await Translate('(используй подсказки слов в случае необходимости)', 'ru', $langs) then data_2}\\r\\n          <div class=\\"title title2\\">{data_2}:</div>\\r\\n        {/await}\\r\\n\\r\\n        {#if visibility[2]==='hidden' }\\r\\n        <button class=\\"hint-button\\" on:click={()=>onClickQ(2)}>\\r\\n          <span class=\\"material-symbols-outlined\\">?</span>\\r\\n        </button>\\r\\n        {/if}\\r\\n\\r\\n        <div class=\\"user2_tr\\">\\r\\n          {#if a && visibility[0] === 'visible'}\\r\\n              {#await Translate(a[$llang], $llang, $langs) then data}\\r\\n                {data}\\r\\n              {/await}    \\r\\n          {/if}  \\r\\n\\r\\n\\r\\n        <div class=\\"user2\\">\\r\\n  \\r\\n          {#if a && visibility[2] === 'hidden'}   \\r\\n   \\r\\n            {@html a[$llang].replace(\\r\\n              /(?<!\\")\\\\b\\\\p{L}+(?<!\\\\s)(?!\\")/gu,\\r\\n              (match) => {\\r\\n                return \`<span class=\\"span_hidden\\" onclick=\\"(this.style.color='#2196f3')\\" \\r\\n                style=\\"display:inline-block; font-size:1.2em ; margin: 5px 0px; padding: 1px 5px;font-weight: 600;\\r\\n                border:1px;border-style:groove;border-color:lightblue;\\r\\n                border-radius: 5px;color:transparent;\\">\${match}</span>\`;\\r\\n              }\\r\\n            )}\\r\\n          {:else if visibility[2] === 'visible'}\\r\\n            {@html a[$llang].replace(\\r\\n              /(?<!\\")\\\\b\\\\p{L}+(?<!\\\\s)(?!\\")/gu,\\r\\n              (match) => {\\r\\n                return \`<span class=\\"span_visible\\"  \\r\\n                style=\\"display:inline-block; font-size:1.2em; margin: 5px 0px; padding: 1px 5px;font-weight: 600;\\r\\n                border:1px; border-style:groove;border-color:lightblue;\\r\\n                border-radius: 5px;color:#2196f3\\">\${match}</span>\`;\\r\\n              }\\r\\n            )}\\r\\n          {/if}\\r\\n      \\r\\n        </div>\\r\\n\\r\\n        <div class=\\"speaker-button\\" on:click={speak(a[$llang])}>\\r\\n          <IconButton>\\r\\n            <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n            </Icon>\\r\\n          </IconButton>\\r\\n        </div>  \\r\\n\\r\\n\\r\\n          {#if !share_mode && isSTT}\\r\\n            <div\\r\\n              class=\\"margins\\"\\r\\n              style=\\"text-align: center; display: flex; align-items: center; justify-content: space-between;\\"\\r\\n            >\\r\\n              <div>\\r\\n                <IconButton\\r\\n                  class=\\"material-icons\\"\\r\\n                  aria-label=\\"Back\\"\\r\\n                  on:click={onClickMicrophone}\\r\\n                >\\r\\n                  <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                    {#if isListening}\\r\\n                      <path fill=\\"currentColor\\" d={mdiMicrophone} />\\r\\n                    {:else}\\r\\n                      <path fill=\\"currentColor\\" d={mdiMicrophoneOutline} />\\r\\n                    {/if}\\r\\n                  </Icon>\\r\\n                </IconButton>\\r\\n                {#if isListening}\\r\\n                  {#await Translate('говори', 'ru', $llang) then data}\\r\\n                    <span>{data}</span>\\r\\n                  {/await}\\r\\n                {/if}\\r\\n              </div>\\r\\n              <Stt\\r\\n                bind:this={stt}\\r\\n                {SttResult}\\r\\n                {StopListening}\\r\\n                bind:display_audio\\r\\n              ></Stt>\\r\\n            </div>\\r\\n          {/if}\\r\\n        </div>\\r\\n\\r\\n        <div style=\\"text-align: center;  margin-top: 20px;\\">\\r\\n          <span style=\\"color: darkgreen;\\">\\r\\n            {@html stt_text}\\r\\n          </span>\\r\\n        </div>\\r\\n      </div>\\r\\n      {:else}\\r\\n\\r\\n        {#if isThumb}\\r\\n          <div class=\\"thumb_alert\\" style=\\"    margin-top: -2px;\\">\\r\\n            <Icon tag=\\"svg\\" color=\\"green\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiThumbUpOutline} />\\r\\n            </Icon>\\r\\n          </div>\\r\\n        {/if}\\r\\n\\r\\n        {#if isRepeat}\\r\\n          <div class=\\"repeat_alert\\" style=\\"margin-top: -4px;\\">\\r\\n            <Button>\\r\\n              <Label>{dict['Repeat'][$langs]}</Label>\\r\\n            </Button>\\r\\n          </div>\\r\\n        {/if}\\r\\n\\r\\n        {#await Translate('Переведи и спроси', 'ru', $langs) then data}\\r\\n          <div class=\\"title\\">{data}:</div>\\r\\n        {/await}\\r\\n        {#await Translate('(используй подсказки слов в случае необходимости)', 'ru', $langs) then data_2}\\r\\n          <div class=\\"title title2\\">{data_2}:</div>\\r\\n        {/await}\\r\\n\\r\\n        <div class=\\"user2_tr\\">\\r\\n          {#if a}\\r\\n            {#if !a[$langs]}\\r\\n              {#await Translate(a[$llang], $llang, $langs) then data}\\r\\n                {data}\\r\\n              {/await}\\r\\n            {:else}\\r\\n              {@html a[$langs]}\\r\\n            {/if}\\r\\n          {/if}\\r\\n        </div>\\r\\n\\r\\n        <div class=\\"user2\\">\\r\\n            {#if a && visibility[1] === 'hidden'}\\r\\n              {@html a[$llang].replace(\\r\\n                /(?<!\\")\\\\b[\\\\p{L}\\\\p{M}]+\\\\b(?!\\")/gu,\\r\\n                (match) => {\\r\\n                  return \`<span class=\\"span_hidden\\" onclick=\\"(this.style.color='#2196f3')\\" \\r\\n                  style=\\"display:inline-block;margin: 5px 0px;border:1px;border-style:groove;border-color:light-blue;\\r\\n                  color:transparent; backgroung-color:white\\">\${match}</span>\`;\\r\\n                }\\r\\n              )}\\r\\n            {:else if visibility[1] === 'visible'}\\r\\n              {@html a[$llang].replace(\\r\\n                /(?<!\\")\\\\b[\\\\p{L}\\\\p{M}]+\\\\b(?!\\")/gu,\\r\\n                (match) => {\\r\\n                  return \`<span class=\\"span_hidden\\"  \\r\\n                  style=\\"display:inline-block;margin: 5px 0px;border:1px;border-style:groove;border-color:light-blue;\\r\\n                  color:#2196f3;backgroung-color:white\\"\\">\${match}</span>\`;\\r\\n                }\\r\\n              )}\\r\\n            {/if}\\r\\n\\r\\n            <div class=\\"speaker-button\\" on:click={speak(a[$llang])}>\\r\\n              <IconButton>\\r\\n                <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            </div>\\r\\n\\r\\n            {#if !share_mode && isSTT}\\r\\n              <div\\r\\n                class=\\"margins\\"\\r\\n                style=\\"text-align: center; display: flex; align-items: center; justify-content: space-between;\\"\\r\\n              >\\r\\n                <div>\\r\\n                  <IconButton\\r\\n                    class=\\"material-icons\\"\\r\\n                    aria-label=\\"Back\\"\\r\\n                    on:click={onClickMicrophone}\\r\\n                  >\\r\\n                    <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                      {#if isListening}\\r\\n                        <path fill=\\"currentColor\\" d={mdiMicrophone} />\\r\\n                      {:else}\\r\\n                        <path fill=\\"currentColor\\" d={mdiMicrophoneOutline} />\\r\\n                      {/if}\\r\\n                    </Icon>\\r\\n                  </IconButton>\\r\\n                </div>\\r\\n                <Stt\\r\\n                  bind:this={stt}\\r\\n                  {SttResult}\\r\\n                  {StopListening}\\r\\n                  bind:display_audio\\r\\n                ></Stt>\\r\\n              </div>\\r\\n            {/if}\\r\\n          </div>\\r\\n\\r\\n          <div style=\\"text-align: center;   margin-top: 10px; \\">\\r\\n            <span style=\\"color: darkgreen;\\">\\r\\n              {@html stt_text}\\r\\n            </span>\\r\\n          </div>\\r\\n\\r\\n \\r\\n        <div class=\\"container\\">\\r\\n          {#if $call_but_status == 'talk'}\\r\\n            <div class=\\"repeat_but\\">\\r\\n              <IconButton on:click={(ev) => SendCommand('repeat', ev)}>\\r\\n                <Icon tag=\\"svg\\" color=\\"secondary\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiRepeat} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            </div>\\r\\n          {/if}\\r\\n\\r\\n          {#await Translate('Послушай ответ', 'ru', $langs) then data}\\r\\n            <div class=\\"title\\">{data}:</div>\\r\\n          {/await}\\r\\n\\r\\n          {#if $call_but_status == 'talk'}\\r\\n            <div class=\\"thumb_but\\">\\r\\n              <IconButton on:click={(ev) => SendCommand('thumb', ev)}>\\r\\n                <Icon tag=\\"svg\\" color=\\"secondary\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiThumbUpOutline} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            </div>\\r\\n          {/if}\\r\\n        </div>\\r\\n\\r\\n        <div class=\\"tip mdc-typography--headline6\\">\\r\\n          {@html q[$llang]}     \\r\\n\\r\\n\\r\\n        </div>\\r\\n\\r\\n        <div class=\\"speaker-button\\" on:click={speak(q[$llang])}>\\r\\n          <IconButton>\\r\\n            <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n            </Icon>\\r\\n          </IconButton>\\r\\n        </div>   \\r\\n\\r\\n        <div style=\\"text-align: center;\\">\\r\\n          <div class=\\"user1\\" style=\\"visibility:{visibility[2]}\\">\\r\\n            {#if !dialog_data.content[cur_qa].user1[$langs]}\\r\\n              {#await Translate(q[$llang], $llang, $langs) then data}\\r\\n                {data}\\r\\n              {/await}\\r\\n            {:else}\\r\\n              {@html q[$langs]}\\r\\n            {/if}\\r\\n\\r\\n            <div\\r\\n              class=\\"margins\\"\\r\\n              style=\\"text-align: center; display: flex; align-items: center; justify-content: space-between;\\"\\r\\n            >\\r\\n              <br />\\r\\n            </div>\\r\\n            <!-- {#if showSpeakerButton} -->\\r\\n            <!-- {/if} -->         \\r\\n          \\r\\n          </div>\\r\\n        </div>\\r\\n\\r\\n      {/if}\\r\\n\\r\\n      <br />\\r\\n     \\r\\n    {:else}\\r\\n      <div style=\\"text-align:center\\">\\r\\n        <span\\r\\n          class=\\"material-symbols-outlined\\"\\r\\n          style=\\"font-size: 20px; color: blue; scale:1.5;\\"\\r\\n        >\\r\\n          <CircularProgress\\r\\n            style=\\"top: 100px;height: 50px; width: 50px;\\"\\r\\n            indeterminate\\r\\n          />\\r\\n        </span>\\r\\n      </div>\\r\\n    {/if}\\r\\n    <div style=\\"height:200px\\" />\\r\\n  </div>\\r\\n</main_dlg>\\r\\n\\r\\n<style scoped>\\r\\n  main_dlg {\\r\\n    /* overflow-y: auto; */\\r\\n    transition: transform 0.3s ease-in-out;\\r\\n    width: 100vw;\\r\\n    margin: 0 auto;\\r\\n    position: relative;\\r\\n    transform-style: preserve-3d;\\r\\n    transition: transform 0.5s;\\r\\n    height: 120vh;\\r\\n  }\\r\\n\\r\\n  .repeat_alert {\\r\\n    position: absolute;\\r\\n    left: 30px;\\r\\n    scale: 0.7;\\r\\n    z-index: 2;\\r\\n  }\\r\\n\\r\\n  .thumb_alert {\\r\\n    position: absolute;\\r\\n\\r\\n    width: 30px;\\r\\n    z-index: 2;\\r\\n    scale: 0.7;\\r\\n    right: 40px;\\r\\n  }\\r\\n\\r\\n  .container {\\r\\n    /* display: flex; */\\r\\n    top: 15px;\\r\\n    margin-bottom: 15px;\\r\\n    position: relative;\\r\\n    justify-content: space-between;\\r\\n    align-items: center;\\r\\n    border: 1px solid lightgrey;\\r\\n    border-radius: 5px;\\r\\n  }\\r\\n\\r\\n\\r\\n  .thumb_but,.repeat_but{\\r\\n    display: inline-flex;\\r\\n    color: grey;\\r\\n    margin-right: 5px;\\r\\n    font-size: xx-small;\\r\\n    top: 0px;\\r\\n    z-index: 2;\\r\\n    scale: .8;\\r\\n    border: grey solid 1px;\\r\\n    border-radius: 15px;\\r\\n  }\\r\\n  .top-app-bar-container {\\r\\n    /* display: inline-block; */\\r\\n    position: relative;\\r\\n    top: 0px;\\r\\n    border: 1px solid\\r\\n      var(--mdc-theme-text-hint-on-background, rgba(0, 0, 0, 0.1));\\r\\n    margin: 0 18px 18px 0;\\r\\n    background-color: var(--mdc-theme-background, #fff);\\r\\n    /* overflow: auto; */\\r\\n  }\\r\\n\\r\\n  .margins {\\r\\n    top: 10px;\\r\\n    position: relative;\\r\\n    margin-right: 10px;\\r\\n    margin-left: 10px;\\r\\n  }\\r\\n\\r\\n  /* Если вы хотите добавить пространство между элементами, вы можете использовать margin */\\r\\n  .margins > * {\\r\\n    margin-right: 10px; /* Пример: 10px пространства между элементами */\\r\\n  }\\r\\n\\r\\n  .button_shared_true {\\r\\n    position: relative;\\r\\n    font-size: 1.5em;\\r\\n    color: blue;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n  .button_shared_false {\\r\\n    position: relative;\\r\\n    font-size: 1.5em;\\r\\n    color: grey;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  .flip_button {\\r\\n    position: relative;\\r\\n    font-size: 1.5em;\\r\\n    text-align: center;\\r\\n    color: grey;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    width: 50px;\\r\\n    bottom:5px;\\r\\n  }\\r\\n\\r\\n  .speaker-button {\\r\\n    position: relative;\\r\\n    color: #2196f3;\\r\\n    font-size: large;\\r\\n    border-radius: 25px;\\r\\n    left: 100%;\\r\\n    margin-left: -30px;\\r\\n    width: fit-content;\\r\\n    z-index: 0;\\r\\n  }\\r\\n\\r\\n  .html_data {\\r\\n    display: grid;\\r\\n    width: 100vw;\\r\\n    position: relative;\\r\\n    overflow-y: auto;\\r\\n    height: 100vh;\\r\\n    margin: 0 auto;\\r\\n    margin-top: 30px;\\r\\n    border: 0;\\r\\n  }\\r\\n\\r\\n  .counter {\\r\\n    /* position: absolute; */\\r\\n    background-color: #f0f0f0;\\r\\n    padding: 0px;\\r\\n    border-radius: 25px;\\r\\n    width: 30px;\\r\\n    height: 30px;\\r\\n    top: -10px;\\r\\n    left: -6px;\\r\\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .counter p {\\r\\n    margin: 0;\\r\\n    font-size: 15px;\\r\\n    color: #333;\\r\\n  }\\r\\n\\r\\n  .counter span {\\r\\n    font-weight: 700;\\r\\n    font-size: 15px;\\r\\n    color: #ff5733; /* цвет счетчика */\\r\\n  }\\r\\n  .cnt {\\r\\n    position: absolute;\\r\\n    text-align: left;\\r\\n    left: 15px;\\r\\n    top: -2px;\\r\\n    z-index: 2;\\r\\n    font-size: 1em;\\r\\n    margin-bottom: 10px;\\r\\n    color: #501d94;\\r\\n  }\\r\\n\\r\\n  .title {\\r\\n    width: fit-content;\\r\\n    margin: 5px auto; /* Центрирование второго элемента */\\r\\n    margin-top: 5px;\\r\\n    color:lightgrey;\\r\\n    line-height: normal;\\r\\n    text-align: center;\\r\\n    font-size: 0.8em;\\r\\n    background-color:transparent; \\r\\n  }\\r\\n\\r\\n  .title2{\\r\\n    font-size: 0.7em;\\r\\n  }\\r\\n\\r\\n\\r\\n\\r\\n  .user1 {\\r\\n    /* width: 100vw;*/\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    line-height: normal;\\r\\n    font-size: 0.8em;\\r\\n    margin-bottom: 0px;\\r\\n    color: #333;\\r\\n    z-index: -1;\\r\\n  }\\r\\n\\r\\n  .user2 {\\r\\n    position: relative;\\r\\n    top: 10px;\\r\\n    text-align: center;\\r\\n    color: #2196f3;\\r\\n    margin-left: 10px;\\r\\n    margin-right: 10px;\\r\\n  }\\r\\n\\r\\n  .user2_tr {\\r\\n    text-align: center;\\r\\n    line-height: normal;\\r\\n    font-size: 0.8em;\\r\\n    margin-bottom: 0px;\\r\\n    color: #333;\\r\\n    z-index: -1;\\r\\n  }\\r\\n\\r\\n  .tip {\\r\\n    position: relative;\\r\\n    top: 0px;\\r\\n    text-align: center;\\r\\n    line-height: normal;\\r\\n    font-size: 1em;\\r\\n    margin-top: 10px;\\r\\n    color: #2196f3;\\r\\n  }\\r\\n\\r\\n  .arrow-button {\\r\\n    position: relative;\\r\\n    top: 0px;\\r\\n    /* margin: 10px */\\r\\n    /* font-size: 1.5em; */\\r\\n    font-weight: 600;\\r\\n    background-color: white;\\r\\n    color: #101c88;\\r\\n    border: 1px solid;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  .arrow-button-left {\\r\\n    transform: translateY(-50%);\\r\\n  }\\r\\n\\r\\n  .arrow-button-right {\\r\\n    transform: translateY(-50%);\\r\\n  }\\r\\n\\r\\n  .hint-button {\\r\\n    position: absolute;\\r\\n    right:0;\\r\\n    top:0;\\r\\n    border: 1px solid;\\r\\n    color: #2196f3;\\r\\n    border-radius: 3px;\\r\\n    padding: 1px 7px;\\r\\n    /* z-index: 1; */\\r\\n    scale: 0.8;\\r\\n\\r\\n  }\\r\\n\\r\\n  .card {\\r\\n    transition: transform 0.3s ease-in-out;\\r\\n    transform-style: preserve-3d;\\r\\n    transition: transform 0.5s;\\r\\n    top: 40px;\\r\\n    overflow-y: auto;\\r\\n    border-radius: 5px;\\r\\n    margin: 0 auto;\\r\\n    position: relative;\\r\\n    height: calc(100vh - 80px);\\r\\n    margin-left: 10px;\\r\\n    margin-right: 10px;\\r\\n  }\\r\\n\\r\\n  .words_div {\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    overflow-y: auto;\\r\\n  }\\r\\n  .hint_button {\\r\\n    display: inline-block;\\r\\n    font-size: larger;\\r\\n    border: solid 0.1em #9f3f3f;\\r\\n    border-radius: 5px;\\r\\n    text-align: center;\\r\\n    width: 50px;\\r\\n    padding-left: 8px;\\r\\n    margin: 5px;\\r\\n    background-color: transparent;\\r\\n  }\\r\\n\\r\\n  .hidden-text {\\r\\n    opacity: 1;\\r\\n    /* animation: fadeIn 2s ease-in forwards;\\r\\n    animation-delay: 2s; */\\r\\n  }\\r\\n\\r\\n  p {\\r\\n    cursor: pointer;\\r\\n    user-select: text; /* Позволяет выделять текст на мобильных устройствах */\\r\\n  }\\r\\n\\r\\n  .highlight {\\r\\n    background-color: yellow;\\r\\n  }\\r\\n\\r\\n  ::-webkit-scrollbar {\\r\\n    display: none; /* Для Chrome, Safari и Opera */\\r\\n  }\\r\\n\\r\\n  /* @keyframes fadeIn {\\r\\n    to {\\r\\n      opacity: 1;\\r\\n    }\\r\\n  } */\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA8+BE,sCAAS,CAEP,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,WAAW,CACtC,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,QAAQ,CAAE,QAAQ,CAClB,eAAe,CAAE,WAAW,CAC5B,UAAU,CAAE,SAAS,CAAC,IAAI,CAC1B,MAAM,CAAE,KACV,CAEA,2CAAc,CACZ,QAAQ,CAAE,QAAQ,CAClB,IAAI,CAAE,IAAI,CACV,KAAK,CAAE,GAAG,CACV,OAAO,CAAE,CACX,CAEA,0CAAa,CACX,QAAQ,CAAE,QAAQ,CAElB,KAAK,CAAE,IAAI,CACX,OAAO,CAAE,CAAC,CACV,KAAK,CAAE,GAAG,CACV,KAAK,CAAE,IACT,CAEA,wCAAW,CAET,GAAG,CAAE,IAAI,CACT,aAAa,CAAE,IAAI,CACnB,QAAQ,CAAE,QAAQ,CAClB,eAAe,CAAE,aAAa,CAC9B,WAAW,CAAE,MAAM,CACnB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,SAAS,CAC3B,aAAa,CAAE,GACjB,CAGA,wCAAU,CAAC,yCAAW,CACpB,OAAO,CAAE,WAAW,CACpB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,GAAG,CACjB,SAAS,CAAE,QAAQ,CACnB,GAAG,CAAE,GAAG,CACR,OAAO,CAAE,CAAC,CACV,KAAK,CAAE,EAAE,CACT,MAAM,CAAE,IAAI,CAAC,KAAK,CAAC,GAAG,CACtB,aAAa,CAAE,IACjB,CACA,oDAAuB,CAErB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,MAAM,CAAE,GAAG,CAAC,KAAK;AACrB,MAAM,IAAI,mCAAmC,CAAC,mBAAmB,CAAC,CAC9D,MAAM,CAAE,CAAC,CAAC,IAAI,CAAC,IAAI,CAAC,CAAC,CACrB,gBAAgB,CAAE,IAAI,sBAAsB,CAAC,KAAK,CAEpD,CAEA,sCAAS,CACP,GAAG,CAAE,IAAI,CACT,QAAQ,CAAE,QAAQ,CAClB,YAAY,CAAE,IAAI,CAClB,WAAW,CAAE,IACf,CAGA,uBAAQ,CAAG,eAAE,CACX,YAAY,CAAE,IAChB,CAEA,iDAAoB,CAClB,QAAQ,CAAE,QAAQ,CAClB,SAAS,CAAE,KAAK,CAChB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OACV,CACA,kDAAqB,CACnB,QAAQ,CAAE,QAAQ,CAClB,SAAS,CAAE,KAAK,CAChB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OACV,CAEA,0CAAa,CACX,QAAQ,CAAE,QAAQ,CAClB,SAAS,CAAE,KAAK,CAChB,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OAAO,CACf,KAAK,CAAE,IAAI,CACX,OAAO,GACT,CAEA,6CAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,OAAO,CACd,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,IAAI,CACnB,IAAI,CAAE,IAAI,CACV,WAAW,CAAE,KAAK,CAClB,KAAK,CAAE,WAAW,CAClB,OAAO,CAAE,CACX,CAEA,wCAAW,CACT,OAAO,CAAE,IAAI,CACb,KAAK,CAAE,KAAK,CACZ,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,KAAK,CACb,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,CACV,CAEA,sCAAS,CAEP,gBAAgB,CAAE,OAAO,CACzB,OAAO,CAAE,GAAG,CACZ,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,KAAK,CACV,IAAI,CAAE,IAAI,CACV,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CACxC,UAAU,CAAE,MACd,CAEA,uBAAQ,CAAC,gBAAE,CACT,MAAM,CAAE,CAAC,CACT,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IACT,CAEA,uBAAQ,CAAC,mBAAK,CACZ,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,OACT,CACA,kCAAK,CACH,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,IAAI,CAChB,IAAI,CAAE,IAAI,CACV,GAAG,CAAE,IAAI,CACT,OAAO,CAAE,CAAC,CACV,SAAS,CAAE,GAAG,CACd,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,OACT,CAEA,oCAAO,CACL,KAAK,CAAE,WAAW,CAClB,MAAM,CAAE,GAAG,CAAC,IAAI,CAChB,UAAU,CAAE,GAAG,CACf,MAAM,SAAS,CACf,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,KAAK,CAChB,iBAAiB,WACnB,CAEA,qCAAO,CACL,SAAS,CAAE,KACb,CAIA,oCAAO,CAEL,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,IAAI,CACX,OAAO,CAAE,EACX,CAEA,oCAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CACT,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,OAAO,CACd,WAAW,CAAE,IAAI,CACjB,YAAY,CAAE,IAChB,CAEA,uCAAU,CACR,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,IAAI,CACX,OAAO,CAAE,EACX,CAEA,kCAAK,CACH,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,GAAG,CACd,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,OACT,CAEA,2CAAc,CACZ,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CAGR,WAAW,CAAE,GAAG,CAChB,gBAAgB,CAAE,KAAK,CACvB,KAAK,CAAE,OAAO,CACd,MAAM,CAAE,GAAG,CAAC,KAAK,CACjB,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OACV,CAEA,gDAAmB,CACjB,SAAS,CAAE,WAAW,IAAI,CAC5B,CAEA,iDAAoB,CAClB,SAAS,CAAE,WAAW,IAAI,CAC5B,CAEA,0CAAa,CACX,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAC,CACP,IAAI,CAAC,CACL,MAAM,CAAE,GAAG,CAAC,KAAK,CACjB,KAAK,CAAE,OAAO,CACd,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,GAAG,CAEhB,KAAK,CAAE,GAET,CAEA,mCAAM,CACJ,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,WAAW,CACtC,eAAe,CAAE,WAAW,CAC5B,UAAU,CAAE,SAAS,CAAC,IAAI,CAC1B,GAAG,CAAE,IAAI,CACT,UAAU,CAAE,IAAI,CAChB,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,KAAK,KAAK,CAAC,CAAC,CAAC,IAAI,CAAC,CAC1B,WAAW,CAAE,IAAI,CACjB,YAAY,CAAE,IAChB,CAEA,wCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,IACd,CACA,0CAAa,CACX,OAAO,CAAE,YAAY,CACrB,SAAS,CAAE,MAAM,CACjB,MAAM,CAAE,KAAK,CAAC,KAAK,CAAC,OAAO,CAC3B,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,GAAG,CACjB,MAAM,CAAE,GAAG,CACX,gBAAgB,CAAE,WACpB,CAEA,0CAAa,CACX,OAAO,CAAE,CAGX,CAEA,+BAAE,CACA,MAAM,CAAE,OAAO,CACf,WAAW,CAAE,IACf,CAEA,wCAAW,CACT,gBAAgB,CAAE,MACpB,+BAEA,mBAAoB,CAClB,OAAO,CAAE,IACX"}`
};
const Dialog_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $showBottomAppBar, $$unsubscribe_showBottomAppBar;
  let $lesson, $$unsubscribe_lesson;
  let $langs, $$unsubscribe_langs;
  let $llang, $$unsubscribe_llang;
  let $dc, $$unsubscribe_dc;
  let $msg, $$unsubscribe_msg;
  let $OnCheckQU, $$unsubscribe_OnCheckQU;
  let $call_but_status, $$unsubscribe_call_but_status;
  let $dicts, $$unsubscribe_dicts;
  $$unsubscribe_showBottomAppBar = subscribe(showBottomAppBar, (value) => $showBottomAppBar = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  $$unsubscribe_OnCheckQU = subscribe(OnCheckQU, (value) => $OnCheckQU = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  const dict = $dicts;
  const { maxBy } = pkg;
  const operator = getContext("operator");
  let tts;
  let dialog_data;
  let isFlipped = false;
  let isRepeat = false, isThumb = false;
  const visibility = ["visible", "hidden", "hidden"];
  let topAppBar;
  let share_mode = false;
  let { data } = $$props;
  if (data.name) {
    if (data.quiz !== "dialog.client") init();
  }
  let tip_hidden_text = "hidden-text";
  let cur_html2 = 0;
  let cur_qa = 0;
  let q, q_shfl, a_shfl, a;
  let stt_text = "";
  let total_cnt = 0;
  if (data.func) {
    onChangeUserClick();
  }
  function flipCard() {
    isFlipped = !isFlipped;
    Dialog();
  }
  async function init() {
    fetch(`./lesson?dialog=${data.name}&owner=${operator.abonent}&level=${data.level}`).then((response) => response.json()).then(async (dlg_data) => {
      dialog_data = dlg_data.data.dialog;
      total_cnt = dialog_data.content.length;
      if (dlg_data.data.html) {
        dialog_data.html = dlg_data.data.html;
      }
      dialog_data.name = data.name;
      Dialog();
    }).catch((error) => {
      console.log(error);
      return [];
    });
  }
  function Dialog() {
    if (!dialog_data.content[0]) {
      return;
    }
    return new Promise(async (resolve, reject) => {
      let qa = dialog_data.content[cur_qa];
      if (!qa) {
        cur_qa = 0;
        qa = dialog_data.content[cur_qa];
        cur_html2++;
        if (dialog_data.html && !dialog_data.html[cur_html2]) {
          cur_html2 = 0;
        }
        setTimeout(
          () => {
            onChangeUserClick();
          },
          0
        );
        return;
      }
      q = isFlipped ? qa.user2 : qa.user1;
      if (!q[$langs]) q[$langs] = await Translate(q[$llang], $llang, $langs);
      q[$llang] = q[$llang]?.replace("${user1_name}", $dc ? "user_name" : "Kolmit");
      q[$langs] = q[$langs]?.replace("${user1_name}", $dc ? "user_name" : "Kolmit");
      q[$llang] = q[$llang]?.replace("${user2_name}", operator.name);
      q[$langs] = q[$langs]?.replace("${user2_name}", operator.name);
      q_shfl = q[$llang].slice(0);
      $dc?.dc.readyState === "open" ? $dc : "";
      q_shfl.toLowerCase().replaceAll("?", "").replaceAll(",", " ").split(" ");
      a = isFlipped ? qa.user1 : qa.user2;
      if (!a[$langs]) a[$langs] = await Translate(a[$llang], $llang, $langs);
      a[$llang] = a[$llang]?.replace("${user2_name}", "...");
      a[$langs] = a[$langs]?.replace("${user2_name}", "...");
      a.hints;
      dialog_data.hints = a.hints;
      a_shfl = a[$llang].slice(0);
      a_shfl.toLowerCase().replaceAll("?", "").replaceAll(",", " ").split(" ");
      resolve();
    });
  }
  async function onNextQA() {
    cur_qa++;
    visibility[1] = "hidden";
    visibility[2] = "hidden";
    tip_hidden_text = "";
    selectedSentence = "";
    setTimeout(
      () => {
        tip_hidden_text = "hidden-text";
      },
      50
    );
    SendData();
    stt_text = "";
    return Dialog();
  }
  function onShare() {
    share_mode = true;
    selectedSentence = "";
    Dialog();
    SendData();
  }
  async function SendData() {
    const dc2 = $dc?.dc.readyState === "open" ? $dc : "";
    if (share_mode && dc2) {
      dialog_data.content[cur_qa].user2["a_shfl"] = a_shfl;
      set_store_value(msg, $msg = set_store_value(msg, $msg = null, $msg), $msg);
      await dc2.SendData(
        {
          lesson: {
            quiz: "dialog",
            llang: $llang,
            level: data.level,
            name: dialog_data.name,
            html: dialog_data.html ? dialog_data.html[cur_html2] : null,
            dialog_data,
            cur_qa,
            isFlipped
          }
        },
        (ex) => {
          console.log(dc2);
        }
      );
    }
  }
  function onChangeUserClick() {
    flipCard();
    data = {
      llang: $llang,
      html: dialog_data.html ? dialog_data.html[cur_html2] : "",
      user1: dialog_data.content[cur_qa].user1,
      user2: dialog_data.content[cur_qa].user2,
      a_shfl,
      quiz: data.quiz
    };
    data.quiz = data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    const dc2 = $dc?.dc.readyState === "open" ? $dc : "";
    dialog_data.content[cur_qa].user2["a_shfl"] = a_shfl;
    if (dc2 && share_mode) SendData();
  }
  function SendCommand(cmd, ev) {
    setTimeout(
      () => {
      },
      1e3
    );
    const dc2 = $dc?.dc.readyState === "open" ? $dc : "";
    if (dc2) {
      return new Promise((resolve) => {
        dc2.SendData({ command: cmd }, () => {
          console.log();
          resolve();
        });
      });
    }
  }
  let selectedSentence = "";
  onDestroy(async () => {
    set_store_value(lesson, $lesson.data = { quiz: "" }, $lesson);
    dialog_data = "";
    data = "";
    stt_text = "";
    tts = "";
    set_store_value(showBottomAppBar, $showBottomAppBar = true, $showBottomAppBar);
    await SendCommand("quit");
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$b);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($msg) {
        if ($msg.lesson?.quiz === "dialog") {
          dialog_data = $msg.lesson.dialog_data;
          isFlipped = !$msg.lesson.isFlipped;
          cur_qa = $msg.lesson.cur_qa;
          visibility[1] = "hidden";
          visibility[2] = "hidden";
          Dialog();
          $OnCheckQU(null, "dialog", dialog_data.name);
        }
        if ($msg.command === "repeat") {
          isRepeat = true;
          setTimeout(
            () => {
              isRepeat = false;
            },
            2e3
          );
        } else if ($msg.command === "thumb") {
          isThumb = true;
          setTimeout(
            () => {
              isThumb = false;
              if (!isFlipped) {
                onNextQA();
              }
            },
            2e3
          );
        } else if ($msg.command === "quit") {
          set_store_value(msg, $msg.command = "", $msg);
          setTimeout(
            () => {
              set_store_value(lesson, $lesson.data = { quiz: "" }, $lesson);
            },
            100
          );
        }
      }
    }
    {
      if ($msg) {
        if ($msg.lesson?.quiz === "dialog") {
          dialog_data = $msg.lesson.dialog_data;
          isFlipped = !$msg.lesson.isFlipped;
          cur_qa = $msg.lesson.cur_qa;
          visibility[1] = "hidden";
          visibility[2] = "hidden";
          Dialog();
          $OnCheckQU(null, "dialog", dialog_data.name);
        }
        if ($msg.command === "repeat") {
          isRepeat = true;
          setTimeout(
            () => {
              isRepeat = false;
            },
            2e3
          );
        } else if ($msg.command === "thumb") {
          isThumb = true;
          setTimeout(
            () => {
              isThumb = false;
            },
            2e3
          );
        } else if ($msg.command === "quit") {
          set_store_value(msg, $msg.command = "", $msg);
          setTimeout(
            () => {
              set_store_value(lesson, $lesson.data = { quiz: "" }, $lesson);
            },
            100
          );
        }
      }
    }
    {
      switch ($call_but_status) {
        case "talk":
          break;
        case "inactive":
          if (share_mode) set_store_value(lesson, $lesson.data = { quiz: "" }, $lesson);
          break;
        default:
          share_mode = false;
          break;
      }
    }
    {
      if (data.html) {
        share_mode = true;
      }
    }
    {
      if (dialog_data && $call_but_status === "talk") {
        if (!share_mode) onShare();
      }
    }
    {
      if ($msg?.msg || $msg?.msg) {
        (async () => {
          alert(await Translate($msg?.msg || $msg?.msg, "ru", $langs));
        })();
      }
    }
    {
      if (q && !q[$langs]) {
        (async () => {
          q[$langs] = await Translate(q[$llang], $llang, $langs);
        })();
      }
    }
    {
      if (a && !a[$langs]) {
        (async () => {
          a[$langs] = await Translate(a[$llang], $llang, $langs);
        })();
      }
    }
    $$rendered = `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" class="svelte-1tyd79t"> ${validate_component(Tts, "Tts").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )} <main_dlg class="svelte-1tyd79t"><div class="top-app-bar-container flexor svelte-1tyd79t">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      { variant: "fixed", this: topAppBar },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return ` ${cur_qa > 0 ? `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin-top:0px; scale:.5;width:50px"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white"${add_attribute("d", mdiArrowLeft, 0)} class="svelte-1tyd79t"></path>`;
                      }
                    }
                  )}` : `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "visibility:hidden;margin-top:0px; scale:.5;width:50px"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill=""${add_attribute("d", mdiArrowLeft, 0)} class="svelte-1tyd79t"></path>`;
                      }
                    }
                  )}`} `;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<div class="svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render(
                    $$result,
                    {
                      class: "material-icons",
                      "aria-label": "Back"
                    },
                    {},
                    {
                      default: () => {
                        return `${validate_component(CommonIcon, "Icon").$$render(
                          $$result,
                          {
                            tag: "svg",
                            viewBox: "0 0 24 24",
                            style: "position:absolute; margin:10px 5px 10px 5px; scale:1.1;width:30px"
                          },
                          {},
                          {
                            default: () => {
                              return `${`<path fill="white"${add_attribute("d", mdiMicrophoneOutline, 0)} class="svelte-1tyd79t"></path>`}`;
                            }
                          }
                        )}`;
                      }
                    }
                  )}</div> `;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<div class="flip_button svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
                    default: () => {
                      return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
                        default: () => {
                          return `<path fill="currentColor"${add_attribute("d", mdiAccountConvertOutline, 0)} class="svelte-1tyd79t"></path>`;
                        }
                      })} ${!isFlipped ? `${validate_component(Badge, "Badge").$$render(
                        $$result,
                        {
                          position: "middle",
                          align: "bottom-end - bottom-middle",
                          "aria-label": "unread count",
                          style: "scale:.8"
                        },
                        {},
                        {
                          default: () => {
                            return `A`;
                          }
                        }
                      )}` : `${validate_component(Badge, "Badge").$$render(
                        $$result,
                        {
                          color: "secondary",
                          position: "middle",
                          align: "bottom-end - bottom-middle",
                          "aria-label": "unread count",
                          style: "scale:.8"
                        },
                        {},
                        {
                          default: () => {
                            return `B`;
                          }
                        }
                      )}`}`;
                    }
                  })}</div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<div class="counter svelte-1tyd79t"><p class="svelte-1tyd79t"><span class="mdc-typography--overline svelte-1tyd79t" style="position:relative">${escape(cur_qa + 1)} ${validate_component(Badge, "Badge").$$render(
                    $$result,
                    {
                      position: "middle",
                      align: "bottom-end - bottom-middle",
                      "aria-label": "unread count",
                      style: "margin-right:-10px;scale:.8"
                    },
                    {},
                    {
                      default: () => {
                        return `${escape(total_cnt)}`;
                      }
                    }
                  )}</span></p></div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {})} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return ` ${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin-top:0px; scale:.5; width:50px"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white"${add_attribute("d", mdiArrowRight, 0)} class="svelte-1tyd79t"></path>`;
                      }
                    }
                  )} `;
                }
              })}`;
            }
          })}`;
        }
      }
    )}</div>  <div class="card svelte-1tyd79t">${!dialog_data?.html ? `<span style="display:block-inline;position:relative;width:80%;color: lightgray;font-style: italic;font-size:smaller;font-family: serif;" class="svelte-1tyd79t">${escape(dialog_data?.name)}</span>` : `${dialog_data?.html ? `<span style="display:block-inline;position:relative;width:80%;color: black;font-style: italic;font-size:smaller;font-family: serif;" class="svelte-1tyd79t">${escape(dialog_data?.name)}</span>  ${``}` : ``}`} ${q || a ? `${!isFlipped ? `<div class="container svelte-1tyd79t">${$call_but_status == "talk" ? `<div class="repeat_but svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render(
          $$result,
          {
            tag: "svg",
            color: "secondary",
            viewBox: "0 0 24 24"
          },
          {},
          {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiRepeat, 0)} class="svelte-1tyd79t"></path>`;
            }
          }
        )}`;
      }
    })}</div>` : ``} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-1tyd79t">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("Послушай вопрос", "ru", $langs))} ${visibility[1] === "hidden" ? `<button class="hint-button svelte-1tyd79t" data-svelte-h="svelte-19ehws4"><span class="material-symbols-outlined svelte-1tyd79t">?</span></button>` : ``} ${$call_but_status == "talk" ? `<div class="thumb_but svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render(
          $$result,
          {
            tag: "svg",
            color: "secondary",
            viewBox: "0 0 24 24"
          },
          {},
          {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiThumbUpOutline, 0)} class="svelte-1tyd79t"></path>`;
            }
          }
        )}`;
      }
    })}</div>` : ``} <div class=" svelte-1tyd79t" style="text-align: center;">${visibility[1] === "visible" ? `<div class="user1 svelte-1tyd79t" style="${"visibility:" + escape(visibility[1], true)}"><span class="svelte-1tyd79t">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <!-- HTML_TAG_START -->${data2}<!-- HTML_TAG_END --> `;
      }(__value);
    }(Translate(q[$llang], $llang, $langs))}</span></div>` : ``} <div class="${"tip mdc-typography--headline6 " + escape(tip_hidden_text, true) + " svelte-1tyd79t"}">${selectedSentence ? `<p class="svelte-1tyd79t"><span class="highlight svelte-1tyd79t">${escape(selectedSentence)}</span></p>` : `<!-- HTML_TAG_START -->${q[$llang].replace(/"([^"]*)"/g, "$1")}<!-- HTML_TAG_END -->`} <div style="display: inline-flex; float: right; margin-right: 10px;}" class="svelte-1tyd79t" data-svelte-h="svelte-1iciefo"><br class="svelte-1tyd79t">  </div></div> <div class="speaker-button svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)} class="svelte-1tyd79t"></path>`;
          }
        })}`;
      }
    })}</div> ${isThumb ? `<div class="thumb_alert svelte-1tyd79t" style="margin-top: 10px;">${validate_component(CommonIcon, "Icon").$$render(
      $$result,
      {
        tag: "svg",
        color: "green",
        viewBox: "0 0 24 24"
      },
      {},
      {
        default: () => {
          return `<path fill="currentColor"${add_attribute("d", mdiThumbUpOutline, 0)} class="svelte-1tyd79t"></path>`;
        }
      }
    )}</div>` : ``} ${isRepeat ? `<div class="repeat_alert svelte-1tyd79t" style="margin-top: 10px;">${validate_component(Button, "Button").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
          default: () => {
            return `${escape(dict["Repeat"][$langs])}`;
          }
        })}`;
      }
    })}</div>` : ``}</div></div> <div class="container svelte-1tyd79t">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data_1) {
        return ` <div class="title svelte-1tyd79t">${escape(data_1)}:</div> `;
      }(__value);
    }(Translate("Переведи и ответь", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data_2) {
        return ` <div class="title title2 svelte-1tyd79t">${escape(data_2)}:</div> `;
      }(__value);
    }(Translate("(используй подсказки слов в случае необходимости)", "ru", $langs))} ${visibility[2] === "hidden" ? `<button class="hint-button svelte-1tyd79t" data-svelte-h="svelte-1ufvyit"><span class="material-symbols-outlined svelte-1tyd79t">?</span></button>` : ``} <div class="user2_tr svelte-1tyd79t">${a && visibility[0] === "visible" ? `${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)} `;
      }(__value);
    }(Translate(a[$llang], $llang, $langs))}` : ``} <div class="user2 svelte-1tyd79t">${a && visibility[2] === "hidden" ? `<!-- HTML_TAG_START -->${a[$llang].replace(new RegExp('(?<!")\\b\\p{L}+(?<!\\s)(?!")', "gu"), (match) => {
      return `<span class="span_hidden" onclick="(this.style.color='#2196f3')" 
                style="display:inline-block; font-size:1.2em ; margin: 5px 0px; padding: 1px 5px;font-weight: 600;
                border:1px;border-style:groove;border-color:lightblue;
                border-radius: 5px;color:transparent;">${match}</span>`;
    })}<!-- HTML_TAG_END -->` : `${visibility[2] === "visible" ? `<!-- HTML_TAG_START -->${a[$llang].replace(new RegExp('(?<!")\\b\\p{L}+(?<!\\s)(?!")', "gu"), (match) => {
      return `<span class="span_visible"  
                style="display:inline-block; font-size:1.2em; margin: 5px 0px; padding: 1px 5px;font-weight: 600;
                border:1px; border-style:groove;border-color:lightblue;
                border-radius: 5px;color:#2196f3">${match}</span>`;
    })}<!-- HTML_TAG_END -->` : ``}`}</div> <div class="speaker-button svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)} class="svelte-1tyd79t"></path>`;
          }
        })}`;
      }
    })}</div> ${``}</div> <div style="text-align: center; margin-top: 20px;" class="svelte-1tyd79t"><span style="color: darkgreen;" class="svelte-1tyd79t"><!-- HTML_TAG_START -->${stt_text}<!-- HTML_TAG_END --></span></div></div>` : `${isThumb ? `<div class="thumb_alert svelte-1tyd79t" style="margin-top: -2px;">${validate_component(CommonIcon, "Icon").$$render(
      $$result,
      {
        tag: "svg",
        color: "green",
        viewBox: "0 0 24 24"
      },
      {},
      {
        default: () => {
          return `<path fill="currentColor"${add_attribute("d", mdiThumbUpOutline, 0)} class="svelte-1tyd79t"></path>`;
        }
      }
    )}</div>` : ``} ${isRepeat ? `<div class="repeat_alert svelte-1tyd79t" style="margin-top: -4px;">${validate_component(Button, "Button").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
          default: () => {
            return `${escape(dict["Repeat"][$langs])}`;
          }
        })}`;
      }
    })}</div>` : ``} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-1tyd79t">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("Переведи и спроси", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data_2) {
        return ` <div class="title title2 svelte-1tyd79t">${escape(data_2)}:</div> `;
      }(__value);
    }(Translate("(используй подсказки слов в случае необходимости)", "ru", $langs))} <div class="user2_tr svelte-1tyd79t">${a ? `${!a[$langs] ? `${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)} `;
      }(__value);
    }(Translate(a[$llang], $llang, $langs))}` : `<!-- HTML_TAG_START -->${a[$langs]}<!-- HTML_TAG_END -->`}` : ``}</div> <div class="user2 svelte-1tyd79t">${a && visibility[1] === "hidden" ? `<!-- HTML_TAG_START -->${a[$llang].replace(/(?<!")\b[\p{L}\p{M}]+\b(?!")/gu, (match) => {
      return `<span class="span_hidden" onclick="(this.style.color='#2196f3')" 
                  style="display:inline-block;margin: 5px 0px;border:1px;border-style:groove;border-color:light-blue;
                  color:transparent; backgroung-color:white">${match}</span>`;
    })}<!-- HTML_TAG_END -->` : `${visibility[1] === "visible" ? `<!-- HTML_TAG_START -->${a[$llang].replace(/(?<!")\b[\p{L}\p{M}]+\b(?!")/gu, (match) => {
      return `<span class="span_hidden"  
                  style="display:inline-block;margin: 5px 0px;border:1px;border-style:groove;border-color:light-blue;
                  color:#2196f3;backgroung-color:white"">${match}</span>`;
    })}<!-- HTML_TAG_END -->` : ``}`} <div class="speaker-button svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)} class="svelte-1tyd79t"></path>`;
          }
        })}`;
      }
    })}</div> ${``}</div> <div style="text-align: center; margin-top: 10px; " class="svelte-1tyd79t"><span style="color: darkgreen;" class="svelte-1tyd79t"><!-- HTML_TAG_START -->${stt_text}<!-- HTML_TAG_END --></span></div> <div class="container svelte-1tyd79t">${$call_but_status == "talk" ? `<div class="repeat_but svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render(
          $$result,
          {
            tag: "svg",
            color: "secondary",
            viewBox: "0 0 24 24"
          },
          {},
          {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiRepeat, 0)} class="svelte-1tyd79t"></path>`;
            }
          }
        )}`;
      }
    })}</div>` : ``} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-1tyd79t">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("Послушай ответ", "ru", $langs))} ${$call_but_status == "talk" ? `<div class="thumb_but svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render(
          $$result,
          {
            tag: "svg",
            color: "secondary",
            viewBox: "0 0 24 24"
          },
          {},
          {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiThumbUpOutline, 0)} class="svelte-1tyd79t"></path>`;
            }
          }
        )}`;
      }
    })}</div>` : ``}</div> <div class="tip mdc-typography--headline6 svelte-1tyd79t"><!-- HTML_TAG_START -->${q[$llang]}<!-- HTML_TAG_END --></div> <div class="speaker-button svelte-1tyd79t">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)} class="svelte-1tyd79t"></path>`;
          }
        })}`;
      }
    })}</div> <div style="text-align: center;" class="svelte-1tyd79t"><div class="user1 svelte-1tyd79t" style="${"visibility:" + escape(visibility[2], true)}">${!dialog_data.content[cur_qa].user1[$langs] ? `${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)} `;
      }(__value);
    }(Translate(q[$llang], $llang, $langs))}` : `<!-- HTML_TAG_START -->${q[$langs]}<!-- HTML_TAG_END -->`} <div class="margins svelte-1tyd79t" style="text-align: center; display: flex; align-items: center; justify-content: space-between;" data-svelte-h="svelte-82ky8a"><br class="svelte-1tyd79t"></div>  </div></div>`} <br class="svelte-1tyd79t">` : `<div style="text-align:center" class="svelte-1tyd79t"><span class="material-symbols-outlined svelte-1tyd79t" style="font-size: 20px; color: blue; scale:1.5;">${validate_component(CircularProgress, "CircularProgress").$$render(
      $$result,
      {
        style: "top: 100px;height: 50px; width: 50px;",
        indeterminate: true
      },
      {},
      {}
    )}</span></div>`} <div style="height:200px" class="svelte-1tyd79t"></div></div> </main_dlg>`;
  } while (!$$settled);
  $$unsubscribe_showBottomAppBar();
  $$unsubscribe_lesson();
  $$unsubscribe_langs();
  $$unsubscribe_llang();
  $$unsubscribe_dc();
  $$unsubscribe_msg();
  $$unsubscribe_OnCheckQU();
  $$unsubscribe_call_but_status();
  $$unsubscribe_dicts();
  return $$rendered;
});
const css$a = {
  code: ".mdc-top-app-bar__row{height:48px\r\n  }.mdc-icon-button{top:5px\r\n  }.top-app-bar-container.svelte-13nnokv.svelte-13nnokv{position:relative;top:0px;height:45px}.hint-button.svelte-13nnokv.svelte-13nnokv{border:0px;color:white;background-color:#2196f3;border-radius:3px;padding:8px 10px}.bricks_name.svelte-13nnokv.svelte-13nnokv{position:relative;margin:10px;width:80%;color:black;font-style:italic;font-size:small;font-family:serif}.invisible.svelte-13nnokv.svelte-13nnokv{color:transparent\r\n  }.article.svelte-13nnokv.svelte-13nnokv{display:flex;;;justify-content:center;align-items:center;height:3vh;color:#2196f3;font-style:italic;font-size:small}.speaker-button.svelte-13nnokv.svelte-13nnokv{display:inline-flex;float:right;font-size:large;border-radius:25px;margin-right:0px;margin-left:10px;z-index:0}.counter.svelte-13nnokv.svelte-13nnokv{position:relative;background-color:#f0f0f0;border-radius:25px;width:30px;height:30px;top:0px;left:-5px;box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);text-align:center}.counter.svelte-13nnokv p.svelte-13nnokv{margin:0;font-size:15px;color:#333}.counter.svelte-13nnokv span.svelte-13nnokv{font-weight:700;font-size:15px;color:#ff5733}main.svelte-13nnokv.svelte-13nnokv{overflow-y:auto;height:calc(90vh - 56px);margin:0px 15px 0 15px}.trans.svelte-13nnokv.svelte-13nnokv{font-size:0.8em;flex-direction:column;align-items:center;margin-top:10px;text-align:center;line-height:1.2 !important}.placeholder.svelte-13nnokv.svelte-13nnokv{border-bottom:1px dashed #000;cursor:pointer}.title.svelte-13nnokv.svelte-13nnokv{width:fit-content;margin:5px auto;margin-top:5px;color:#9eb2cc;line-height:normal;text-align:center;font-size:0.9em;background-color:transparent}.word-list.svelte-13nnokv.svelte-13nnokv{display:flex;text-align:center;margin:10px 2px 15px 2px;gap:10px;font-weight:500;flex-wrap:wrap;color:rgb(67, 65, 65)}.formatted-list.svelte-13nnokv.svelte-13nnokv{display:flex;text-align:center;margin:10px 2px 15px 2px;gap:10px;font-weight:700;flex-wrap:wrap;color:rgb(67, 65, 65)}.word-list.svelte-13nnokv span.svelte-13nnokv:not(.ver):not(.subj):not(.tijd):not(.plaats):not(.adv),.formatted-list.svelte-13nnokv span.svelte-13nnokv:not(.ver):not(.subj):not(.tijd):not(.plaats):not(.adv){padding:0px 6px;border:1px solid #ddd;border-radius:5px;background:#f9f9f9;cursor:pointer;user-select:none}.formatted-list.svelte-13nnokv span.svelte-13nnokv:focus{outline:2px solid transparent\r\n  }.word-list.svelte-13nnokv span.svelte-13nnokv{border-color:lightgray}.incorrect.svelte-13nnokv.svelte-13nnokv{color:red;animation:svelte-13nnokv-color-blink 1s infinite}.material-symbols-outlined.svelte-13nnokv.svelte-13nnokv{font-size:15px;scale:1.5;font-variation-settings:'FILL' 0,\r\n      'wght' 400,\r\n      'GRAD' 0,\r\n      'opsz' 24}.ver.svelte-13nnokv.svelte-13nnokv{position:relative;border:2px solid;border-color:rgb(225, 111, 111);--border-color:rgb(225, 111, 111);border-radius:5px;padding:0px 6px}.word-list.svelte-13nnokv .ver.svelte-13nnokv,.formatted-list.svelte-13nnokv .ver.svelte-13nnokv:not(.invisible){color:rgb(225, 111, 111)}.subj.svelte-13nnokv.svelte-13nnokv{position:relative;border:2px solid;border-color:rgb(49, 49, 169);--border-color:rgb(49, 49, 169);border-radius:7px;padding:0px 6px}.word-list.svelte-13nnokv .subj.svelte-13nnokv,.formatted-list.svelte-13nnokv .subj.svelte-13nnokv:not(.invisible){color:rgb(49, 49, 169)}.tijd.svelte-13nnokv.svelte-13nnokv{position:relative;border:2px solid;border-color:rgb(119, 201, 119);--border-color:rgb(119, 201, 119);border-radius:5px;padding:0px 6px}.word-list.svelte-13nnokv .tijd.svelte-13nnokv,.formatted-list.svelte-13nnokv .tijd.svelte-13nnokv:not(.invisible){color:rgb(119, 201, 119)}.plaats.svelte-13nnokv.svelte-13nnokv{position:relative;border:2px solid;border-color:darkmagenta;--border-color:darkmagenta;border-radius:5px;padding:0px 6px}.word-list.svelte-13nnokv .plaats.svelte-13nnokv,.formatted-list.svelte-13nnokv .plaats.svelte-13nnokv:not(.invisible){color:darkmagenta\r\n  }.adv.svelte-13nnokv.svelte-13nnokv{position:relative;border:2px solid;border-color:darkmagenta;--border-color:darkmagenta;border-radius:5px;padding:0px 6px}.word-list.svelte-13nnokv .adv.svelte-13nnokv,.formatted-list.svelte-13nnokv .adv.svelte-13nnokv:not(.invisible){color:darkmagenta\r\n  }@keyframes svelte-13nnokv-color-blink{0%,100%{color:red}50%{color:white}}@keyframes svelte-13nnokv-border-blink{0%,100%{box-shadow:0 0 0px 0 var(--border-color, rgb(124, 124, 139))}50%{box-shadow:0 0 10px 4px var(--border-color, rgb(124, 124, 139))}}span.svelte-13nnokv.svelte-13nnokv:focus{animation:svelte-13nnokv-border-blink 1s infinite;border-width:2px}@media screen and (max-width: 767px){.trans.svelte-13nnokv.svelte-13nnokv{font-size:0.7em}.word-list.svelte-13nnokv.svelte-13nnokv,.formatted-list.svelte-13nnokv.svelte-13nnokv{font-size:0.9em;padding:0 5px\r\n      }.title.svelte-13nnokv.svelte-13nnokv{font-size:small}}",
  map: `{"version":3,"file":"Bricks.svelte","sources":["Bricks.svelte"],"sourcesContent":["<script>\\r\\n  import { onMount , getContext} from 'svelte';\\r\\n  import { slide } from 'svelte/transition';\\r\\n  import ConText from '../Context.svelte';\\r\\n  import { Translate } from '../../../translate/Transloc';\\r\\n  import Tts from '../../../speech/tts/Tts.svelte';\\r\\n  import emojiRegex from 'emoji-regex';\\r\\n  import TopAppBar, { Row, Title, Section } from '@smui/top-app-bar';\\r\\n  import IconButton, { Icon } from '@smui/icon-button';\\r\\n  import Badge from '@smui-extra/badge';\\r\\n  import CircularProgress from '@smui/circular-progress';\\r\\n\\r\\n  import Stt from '../../../speech/stt/Stt.svelte';\\r\\n\\r\\n  \\r\\n  let isListening = false;\\r\\n\\r\\n  let isSTT = false;\\r\\n\\r\\n  let topAppBar;\\r\\n\\r\\n  let translate = false;\\r\\n\\r\\n  let span_equal = true;\\r\\n\\r\\n  let stt_text = '';\\r\\n\\r\\n  let isPlayAuto = false;\\r\\n\\r\\n  let playAutoColor = 'currentColor';\\r\\n\\r\\n  let article_name = ''\\r\\n\\r\\n  let stt, tts;\\r\\n  // Разделяем предложение на слова\\r\\n  let words = [];\\r\\n\\r\\n// Функция для отслеживания сфокусированных элементов\\r\\nlet focusedIndex = 0;\\r\\n\\r\\n// Разделение предложения на placeholder'ы\\r\\nlet formattedSentence = [];\\r\\n\\r\\nlet bricks_data;\\r\\n\\r\\nlet isCollapsed = true;\\r\\n\\r\\nlet curSentence = 0;\\r\\n\\r\\n// let speechData = '';\\r\\nlet current_word = 0;\\r\\nlet audio;\\r\\nlet display_audio;\\r\\n\\r\\nlet keys = [];\\r\\n\\r\\n  export let data;\\r\\n  const operator = getContext('operator');\\r\\n  // Исходное предложение\\r\\n  let sentence = \\"\\";\\r\\n\\r\\n  $: if (isPlayAuto) {\\r\\n      playAutoColor = 'green';\\r\\n  } else {\\r\\n      playAutoColor = 'currentColor';\\r\\n  }\\r\\n\\r\\n  import {\\r\\n      langs,\\r\\n      llang,\\r\\n  } from '$lib/js/stores.js';\\r\\n\\r\\n  import {\\r\\n      mdiArrowRight,\\r\\n      mdiArrowLeft,\\r\\n      mdiMicrophoneOutline ,\\r\\n      mdiMicrophone,\\r\\n      mdiEarHearing,\\r\\n      mdiPlay,\\r\\n      mdiTranslate,\\r\\n      mdiTranslateOff\\r\\n  } from '@mdi/js';\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n  fetch(\\r\\n    \`./lesson?bricks=\${data.name}&theme=\${data.theme}&owner=\${operator.abonent}&level=\${data.level}\`\\r\\n  )\\r\\n    .then((response) => response.json())\\r\\n    .then(async (data) => {\\r\\n    \\r\\n      bricks_data = data.data\\r\\n      // Преобразуем HTML в текст и разбиваем на массив предложений\\r\\n      // bricks_data.text = htmlToText(bricks_data.html).replaceAll('\\"','').split(/(?<=[.?!])\\\\s+/);\\r\\n      bricks_data.text = splitHtmlIntoSentencesWithInnerTags(data.data.html.replaceAll('\\"',''));//.replaceAll('\\"','').split(/(?<=[.?!])\\\\s+/);\\r\\n\\r\\n      InitData();\\r\\n\\r\\n    })\\r\\n    .catch((error) => {\\r\\n      console.log(error);\\r\\n      return [];\\r\\n    });\\r\\n\\r\\n  function extractTagName(tagString) {\\r\\n      const match = tagString.match(/^<(\\\\w+)/); // Находим первую часть тега\\r\\n      return match ? match[1] : ''; // Возвращаем название тега или null, если не найдено\\r\\n  }\\r\\n  \\r\\n  const InitData = async () => {\\r\\n    if (!bricks_data?.text) return;\\r\\n\\r\\n    try {\\r\\n\\r\\n\\r\\n      // Собираем все предложения\\r\\n      const sentences = bricks_data.text;\\r\\n\\r\\n      // Убираем HTML-теги\\r\\n      const cleanedSentences = sentences.map(sent_obj => sent_obj.sentence.replace(/<[^>]*>/g, ''));\\r\\n\\r\\n      // Функция для разделения массива на пакеты по 5 предложений\\r\\n      const chunkArray = (arr, size) =>\\r\\n        arr.reduce((chunks, _, i) =>\\r\\n          i % size === 0 ? [...chunks, arr.slice(i, i + size)] : chunks, []\\r\\n        );\\r\\n\\r\\n\\r\\n      // Проверяем наличие curSentence\\r\\n      if (typeof curSentence === 'undefined' || !keys[curSentence]) {\\r\\n        curSentence = 0;\\r\\n      }\\r\\n\\r\\n      // Текущее предложение\\r\\n      const sentence = bricks_data.text[curSentence];\\r\\n\\r\\n      article_name = sentence.article || '\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0'\\r\\n\\r\\n      // Получение озвучки через TTS\\r\\n      // const { resp } = await tts.GetGoogleTTS($llang, sentence.replace(/<[^>]*>/g, ''), data?.name);\\r\\n      // speechData = resp;\\r\\n\\r\\n      // Разбиваем на слова\\r\\n      words = formatWords(sentence);\\r\\n      formattedSentence = formatWords(sentence);\\r\\n\\r\\n      // Создаём кирпичики\\r\\n      MakeBricks();\\r\\n    } catch (error) {\\r\\n      console.error(\\"Error in InitData:\\", error);\\r\\n    }\\r\\n  };\\r\\n\\r\\n  const formatWords = (sent_obj) =>\\r\\n    sent_obj.sentence\\r\\n    .trim()\\r\\n    .split(/[\\\\s,:\\\\.]+/)\\r\\n    .filter(word => word)\\r\\n    .map(word => ({\\r\\n        gr: extractTagName(word),\\r\\n        placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\",\\r\\n        value: word.trim(),\\r\\n    }));\\r\\n\\r\\n  onMount(() => {\\r\\n\\r\\n  });\\r\\n\\r\\n\\r\\n  function MakeBricks(){\\r\\n      // Перемешиваем formattedSentence\\r\\n\\r\\n      const firstElement = document.querySelector('.formatted-list span');\\r\\n      if (firstElement) {\\r\\n          firstElement.focus();\\r\\n      }\\r\\n      onToggleWord()\\r\\n  }\\r\\n\\r\\n  // Функция для перемешивания массива\\r\\n  function shuffleArray(array) {\\r\\n      for (let i = array.length - 1; i > 0; i--) {\\r\\n          const j = Math.floor(Math.random() * (i + 1)); // Случайный индекс от 0 до i\\r\\n          [array[i], array[j]] = [array[j], array[i]]; // Обмен элементов\\r\\n      }\\r\\n      return array;\\r\\n  }\\r\\n\\r\\n\\r\\n  function splitHtmlIntoSentencesWithInnerTags(html) {\\r\\n    function removeEmojis(input) {\\r\\n        const regex = emojiRegex();\\r\\n        return input.replace(regex, '');\\r\\n    }\\r\\n\\r\\n    function formatTaggedText(input) {\\r\\n        return input.replace(/<(\\\\w+)>(.*?)<\\\\/\\\\1>/g, (match, tag, content) => {\\r\\n            const words = content.match(/\\\\S+|\\\\s+/g) || []; // Разделяем на слова + пробелы\\r\\n            return words.map(word => {\\r\\n                if (word.trim()) return \`<\${tag}>\${word}</\${tag}>\`;\\r\\n                return word; // Оставляем пробелы как есть\\r\\n            }).join('');\\r\\n        });\\r\\n    }\\r\\n\\r\\n      function shouldNotSplit(text, index) {\\r\\n          // Проверяем, находимся ли внутри любого тега (кроме <article>)\\r\\n          const match = text.slice(Math.max(0, index - 10), index + 10);\\r\\n          return /<(\\\\w+)>([^<]*[A-Z]\\\\.[A-Z]\\\\.[^<]*)<\\\\/\\\\1>/i.test(match);\\r\\n      }\\r\\n\\r\\n      const parser = new DOMParser();\\r\\n      const doc = parser.parseFromString(html, 'text/html');\\r\\n      const articles = doc.querySelectorAll('article, aticle');\\r\\n\\r\\n      const sentences = Array.from(articles).flatMap(article => {\\r\\n          const htmlContent = formatTaggedText(removeEmojis(article.innerHTML.trim()));\\r\\n          const articleName = article.getAttribute('name') || ''; // Извлекаем название статьи из атрибута name\\r\\n      \\r\\n          return htmlContent\\r\\n              .split(/(?<!\\\\b(?:Dr|Mr|Ms|Mrs|St))(?<=[.!?])\\\\s+(?=<|\\\\w|<\\\\/\\\\w+>)/g)\\r\\n              .map((sentence, index, arr) => {\\r\\n                  if (index > 0 && shouldNotSplit(arr[index - 1], arr[index - 1].length)) {\\r\\n                      return arr[index - 1] + ' ' + sentence; // Объединяем части, если не должно быть разделения\\r\\n                  }\\r\\n                  return sentence;\\r\\n              })\\r\\n              .filter(sentence => sentence.length > 0)\\r\\n              .map(sentence => ({\\r\\n                sentence,\\r\\n                article: articleName // Добавляем название статьи вместо outerHTML\\r\\n            }));;\\r\\n      });\\r\\n\\r\\n      return sentences;\\r\\n  }\\r\\n\\r\\n  // Обработчик клика на слово\\r\\n  const handleClick = (word) => {\\r\\n      // Присваиваем выбранное слово фокусируемому элементу\\r\\n      if(formattedSentence[focusedIndex].value.toLowerCase().replace(/<[^>]*>/g, '') === word.value.toLowerCase().replace(/<[^>]*>/g, '')){\\r\\n\\r\\n          formattedSentence[focusedIndex].word =  word.value ;\\r\\n          formattedSentence[focusedIndex].class = \\"correct\\";\\r\\n\\r\\n          // После того как слово присвоено, ищем следующий элемент для фокуса\\r\\n          if(formattedSentence.length-1 > focusedIndex){\\r\\n            focusedIndex = Math.min(focusedIndex + 1, formattedSentence.length - 1);\\r\\n          }\\r\\n\\r\\n          // Устанавливаем фокус на следующий элемент\\r\\n          requestAnimationFrame(() => {\\r\\n              const nextElement = document.querySelectorAll('.formatted-list span')[focusedIndex];\\r\\n              if (nextElement) {\\r\\n              nextElement.focus();\\r\\n              }\\r\\n          });\\r\\n\\r\\n           // Проверяем, все ли слова правильно заполнены\\r\\n          setTimeout(()=>{\\r\\n            checkCompletion();\\r\\n          },100) \\r\\n        \\r\\n\\r\\n      }else{\\r\\n          formattedSentence[focusedIndex].word =  word.value ;\\r\\n          formattedSentence[focusedIndex].class = \\"incorrect\\";\\r\\n      }\\r\\n  };\\r\\n\\r\\n      // Проверка завершения\\r\\n  const checkCompletion = () => {\\r\\n      // Если все элементы имеют класс \\"correct\\", вызываем функцию Speak\\r\\n      if (formattedSentence.every(item => item.class === \\"correct\\")) {\\r\\n          SpeakText(true);\\r\\n      }\\r\\n  };\\r\\n\\r\\n\\r\\n  \\r\\n  const navSentence = async(nav)=>{\\r\\n\\r\\n    if(nav==='prev'){\\r\\n      --curSentence\\r\\n    }else if(nav==='next'){\\r\\n      ++curSentence\\r\\n    }\\r\\n\\r\\n    current_word = 0;\\r\\n    focusedIndex = 0;\\r\\n    // isSTT = false;\\r\\n\\r\\n\\r\\n    if(curSentence >= bricks_data.text.length){\\r\\n      curSentence = 0;\\r\\n    }\\r\\n\\r\\n    sentence = bricks_data.text[curSentence].sentence;\\r\\n    article_name = bricks_data.text[curSentence].article || '\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0'\\r\\n\\r\\n    // const resp = await tts.GetGoogleTTS($llang, sentence.replace(/<[^>]*>/g, ''),  data.name);\\r\\n    //   speechData = resp.resp;\\r\\n    //   console.log('speechData:',speechData)\\r\\n      // sentence = sentence;\\r\\n      words = sentence.trim().split(/[\\\\s,:\\\\.]+/)\\r\\n        .filter(word => word) // Оставляем только существующие слова\\r\\n        .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n        })); \\r\\n      // Создаём массив для предложения с placeholder'ами\\r\\n      formattedSentence = sentence.trim().split(/[\\\\s,:\\\\.]+/)\\r\\n          .filter(word => word) // Оставляем только существующие слова\\r\\n          .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n          }));\\r\\n\\r\\n      // words =  Array.from(new Set(sentence.trim().split(/[\\\\s,:\\\\.]+/).filter(word => word !== \\"\\")))    \\r\\n\\r\\n      MakeBricks();\\r\\n  }\\r\\n\\r\\n  function getCorrectSpanString(isCorrect){\\r\\n    const elements = document.querySelectorAll(isCorrect?\\".formatted-list > .correct\\":\\".formatted-list > span:not(.correct)\\");\\r\\n    return Array.from(elements)\\r\\n    .map(el => el.getAttribute('value')?.trim() || \\"\\")\\r\\n    .join(\\" \\");;\\r\\n  }\\r\\n\\r\\n\\r\\n  const SpeakText = async (isEndSpeak) => {\\r\\n\\r\\n      const endSpeak = ()=> {\\r\\n          if(isEndSpeak===true)\\r\\n          setTimeout(()=>{\\r\\n            if(!isSTT)\\r\\n              navSentence(++curSentence)\\r\\n          },500)          \\r\\n      }\\r\\n\\r\\n      const textToSpeak = getCorrectSpanString(isSTT || formattedSentence.every(item => item.class === \\"correct\\"));\\r\\n\\r\\n      if (textToSpeak) {\\r\\n        const resp = await tts.GetGoogleTTS($llang, textToSpeak,  data.name);\\r\\n        const speechData = resp.resp;\\r\\n        audio = new Audio(speechData.audio);\\r\\n        let  endTime;\\r\\n        audio.playbackRate = 0.9;   \\r\\n  \\r\\n\\r\\n        if (focusedIndex >= formattedSentence.length-1){\\r\\n          audio.playbackRate = 0.9;   \\r\\n          audio.currentTime  = 0;\\r\\n        }\\r\\n\\r\\n        if(!isSTT)\\r\\n            audio.addEventListener('ended', function () {\\r\\n              endSpeak();\\r\\n              audio = '';\\r\\n            });\\r\\n                 \\r\\n         // Отслеживание текущего времени\\r\\n        //  if( false && endTime)\\r\\n          audio.addEventListener('timeupdate', () => {\\r\\n            let endTime;\\r\\n            // if (speechData.ts.length > current_word + 5) {\\r\\n            //   endTime = speechData.ts[current_word + 5].end;\\r\\n            // } else if(speechData.ts.length>0){\\r\\n            //   endTime = speechData.ts[speechData.ts.length].end; // Если выходит за пределы массива, берем последний элемент\\r\\n            // }\\r\\n            // if(audio.currentTime  >= endTime)\\r\\n            //   audio.pause()\\r\\n          });\\r\\n         audio.play();\\r\\n      } \\r\\n  }\\r\\n\\r\\n\\r\\n  // Обработчик для фокуса на placeholder\\r\\n  const handleFocus = (index) => {\\r\\n    // focusedIndex = index;\\r\\n  };\\r\\n\\r\\n  const handleFormatted = (item, index)=>{\\r\\n\\r\\n    if(formattedSentence[index].class === \\"correct\\"){\\r\\n      formattedSentence[index].class= 'incorrect';\\r\\n      formattedSentence[index].word =  \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\";\\r\\n      return;\\r\\n    }\\r\\n\\r\\n    if(formattedSentence[index].value ===  item.word){\\r\\n      formattedSentence[index].word = item.word;\\r\\n      formattedSentence[index].class = \\"correct\\";\\r\\n          // После того как слово присвоено, ищем следующий элемент для фокуса\\r\\n      focusedIndex = Math.min(index + 1, formattedSentence.length - 1);\\r\\n    }\\r\\n    setTimeout(()=>{\\r\\n      checkCompletion();\\r\\n    },100)\\r\\n\\r\\n    // // Устанавливаем фокус на следующий элемент\\r\\n    requestAnimationFrame(() => {\\r\\n        const nextElement = document.querySelectorAll('.formatted-list span')[focusedIndex];\\r\\n        if (nextElement) {\\r\\n          nextElement.focus();\\r\\n        }\\r\\n    });        \\r\\n  }\\r\\n\\r\\n  const onToggleWord = ()=>{\\r\\n\\r\\n    const sent_obj = bricks_data.text[curSentence];\\r\\n\\r\\n    sentence = sent_obj.sentence.trim();\\r\\n\\r\\n      if(!span_equal){    \\r\\n\\r\\n        formattedSentence = sentence.split(/[\\\\s:\\\\.]+/)\\r\\n          .filter(word => word) // Оставляем только существующие слова\\r\\n          .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n          }));\\r\\n\\r\\n        formattedSentence.forEach((item)=>{\\r\\n            item.placeholder = item.value;\\r\\n            item.class = \\"invisible\\"\\r\\n        });\\r\\n\\r\\n       // Разбиваем на слова\\r\\n        words =  sentence.trim().split(/[\\\\s:\\\\.]+/) \\r\\n        .filter(word => word) // Оставляем только существующие слова\\r\\n        .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n        }));\\r\\n\\r\\n      }else{\\r\\n\\r\\n        formattedSentence = sentence.replace(/<[^>]*>/g, '').split(/[\\\\s,:\\\\.]+/)\\r\\n          .filter(word => word) // Оставляем только существующие слова\\r\\n          .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n          }));\\r\\n        formattedSentence.forEach((item)=>{\\r\\n            item.placeholder = \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\";\\r\\n            item.class = \\"\\"\\r\\n        });     \\r\\n        \\r\\n        // Разбиваем на слова\\r\\n        words =  sentence.replace(/<[^>]*>/g, '').trim().split(/[\\\\s,:\\\\.]+/) \\r\\n        .filter(word => word) // Оставляем только существующие слова\\r\\n        .map((word) => ({\\r\\n            gr: extractTagName(word),\\r\\n            placeholder: \\"\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\\\u00a0\\", \\r\\n            value: word.trim()\\r\\n        }));\\r\\n      }\\r\\n\\r\\n      words = shuffleArray(words);\\r\\n\\r\\n      formattedSentence = formattedSentence\\r\\n  }\\r\\n\\r\\n  function ToggleTranslate(){\\r\\n    translate = !translate\\r\\n  }\\r\\n\\r\\n  function onClickMicrophone() {\\r\\n    if (isListening) {\\r\\n      stt_text = ''\\r\\n      stt.MediaRecorderStop();\\r\\n      isListening = false;\\r\\n      return;\\r\\n    }\\r\\n\\r\\n    stt_text = ''\\r\\n\\r\\n    stt.startAudioMonitoring($llang, $langs);\\r\\n\\r\\n    // const text = dialog_data.content[cur_qa].user1[llang].replace(/[^\\\\w\\\\s]/gi, ''); //.split(' ');\\r\\n\\r\\n    isListening = true;\\r\\n  }\\r\\n\\r\\n  function StopListening() {\\r\\n    isListening = false;\\r\\n  }\\r\\n\\r\\n  function SttResult(text) {\\r\\n    stt_text = text[$llang];\\r\\n    const correct_str = getCorrectSpanString();\\r\\n    let sent_compare = correct_str;\\r\\n\\r\\n    const numbers = sent_compare.match(/\\\\b\\\\d+\\\\b/g);\\r\\n    if (numbers)\\r\\n      sent_compare = sent_compare.replace(/\\\\b\\\\d+\\\\b/g, numberToDutchString(numbers[0]));\\r\\n\\r\\n    if (stt_text) {\\r\\n      const similarity = compareStrings(\\r\\n        sent_compare\\r\\n          .toLowerCase()\\r\\n          .trim()\\r\\n          .replace(/[^\\\\w\\\\s]|_/g, ''),\\r\\n        stt_text\\r\\n          .toLowerCase()\\r\\n          .trim()\\r\\n          .replace(/[^\\\\w\\\\s]|_/g, '') //replace(/[0-9!\\"#$%&'()*+,-./:;<=>?@[\\\\]^_\`{|}~]/g, '')\\r\\n      );\\r\\n      stt_text += \` (\${similarity.toFixed(0)}%)\`;\\r\\n      if (similarity > 75) {\\r\\n        setTimeout(() => {\\r\\n          // onNextQA();\\r\\n        }, 3000);\\r\\n      }\\r\\n    }\\r\\n  }\\r\\n\\r\\n\\r\\n\\r\\n  function compareStrings(str1, str2) {\\r\\n    // Используем алгоритм Левенштейна для вычисления расстояния между строками\\r\\n\\r\\n    function levenshteinDistance(s, t) {\\r\\n      const d = []; // Массив для хранения результатов вычислений\\r\\n\\r\\n      // Заполняем массив нулями\\r\\n      for (let i = 0; i <= s.length; i++) {\\r\\n        d[i] = [i];\\r\\n      }\\r\\n      for (let j = 0; j <= t.length; j++) {\\r\\n        d[0][j] = j;\\r\\n      }\\r\\n\\r\\n      // Вычисляем расстояние Левенштейна\\r\\n      for (let j = 1; j <= t.length; j++) {\\r\\n        for (let i = 1; i <= s.length; i++) {\\r\\n          if (s.charAt(i - 1) === t.charAt(j - 1)) {\\r\\n            d[i][j] = d[i - 1][j - 1];\\r\\n          } else {\\r\\n            d[i][j] = Math.min(\\r\\n              d[i - 1][j] + 1, // удаление\\r\\n              d[i][j - 1] + 1, // вставка\\r\\n              d[i - 1][j - 1] + 1 // замена\\r\\n            );\\r\\n          }\\r\\n        }\\r\\n      }\\r\\n\\r\\n      // Расстояние Левенштейна между строками находится в d[s.length][t.length]\\r\\n      return d[s.length][t.length];\\r\\n    }\\r\\n\\r\\n    // Вычисляем длины строк\\r\\n    const len1 = str1.length;\\r\\n    const len2 = str2.length;\\r\\n\\r\\n    // Вычисляем максимальную длину строки из двух строк\\r\\n    const maxLength = Math.max(len1, len2);\\r\\n\\r\\n    // Вычисляем расстояние Левенштейна между строками\\r\\n    const distance = levenshteinDistance(str1, str2);\\r\\n\\r\\n    // Вычисляем процент совпадения\\r\\n    const similarity = (1 - distance / maxLength) * 100;\\r\\n\\r\\n    console.log('similarityPercentage', similarity);\\r\\n\\r\\n    // Возвращаем true, если процент совпадения больше 75, иначе false\\r\\n    return similarity;\\r\\n  }\\r\\n\\r\\n  function onSTT(){\\r\\n    isSTT = !isSTT\\r\\n  }\\r\\n\\r\\n  function PlayAutoContent(){\\r\\n\\r\\n    if (!isPlayAuto) return;\\r\\n\\r\\n    async function endSpeak() {\\r\\n\\r\\n      async function endLangSpeak(){\\r\\n        await navSentence('next');\\r\\n        PlayAutoContent();\\r\\n      }\\r\\n\\r\\n      tts.Speak_server($langs, bricks_data.translate[curSentence],data.name,endLangSpeak)\\r\\n\\r\\n    }\\r\\n\\r\\n    if (sentence) {\\r\\n        audio = new Audio(speechData.audio);\\r\\n        let  endTime;\\r\\n        audio.playbackRate = 0.9;   \\r\\n        audio.addEventListener('ended', function () {\\r\\n          endSpeak();\\r\\n          audio = '';\\r\\n        });\\r\\n        audio.play();\\r\\n    }\\r\\n\\r\\n  }\\r\\n\\r\\n  const toNextArticle = ()=>{\\r\\n\\r\\n      const arr=bricks_data.text;\\r\\n      if (curSentence < 0 || curSentence >= arr.length) return null;\\r\\n      \\r\\n      let currentArticle = arr[curSentence].article;\\r\\n      \\r\\n      for (let i = curSentence + 1; i < arr.length; i++) {\\r\\n          if (arr[i].article !== currentArticle) {\\r\\n            curSentence=i;\\r\\n            MakeBricks()\\r\\n            article_name = arr[i].article;\\r\\n            return;\\r\\n          }\\r\\n      }\\r\\n      // Если нет следующего объекта с другим article\\r\\n      curSentence = 0;\\r\\n      MakeBricks()\\r\\n      article_name = arr[0].article;\\r\\n      return; \\r\\n  }\\r\\n\\r\\n  \\r\\n\\r\\n<\/script>\\r\\n\\r\\n<Tts bind:this={tts}></Tts>\\r\\n\\r\\n{#if bricks_data?.length < 1}\\r\\n  <div style=\\"text-align:center\\">\\r\\n    <span\\r\\n      class=\\"material-symbols-outlined\\"\\r\\n      style=\\"font-size: 20px; color: blue; scale:1.5;\\"\\r\\n    >\\r\\n      <CircularProgress style=\\"height: 50px; width: 50px;\\" indeterminate />\\r\\n    </span>\\r\\n  </div>\\r\\n{/if}\\r\\n<div class=\\"top-app-bar-container flexor\\">\\r\\n  <TopAppBar bind:this={topAppBar} variant=\\"fixed\\">\\r\\n    <Row>\\r\\n      <Section align=\\"start\\">\\r\\n        {#if curSentence > 0}\\r\\n        <Icon\\r\\n          tag=\\"svg\\"\\r\\n          on:click={() => { navSentence('prev') }}\\r\\n          viewBox=\\"0 0 24 24\\"\\r\\n          style=\\"margin:10px 5px 10px 5px; scale:1.3; width:20px; visibility: {curSentence > 0 ? 'visible' : 'hidden'}\\"\\r\\n        >\\r\\n          <path fill=\\"white\\" stroke=\\"white\\" stroke-width=\\"1.5\\" stroke-linejoin=\\"round\\" d={mdiArrowLeft} />\\r\\n        </Icon>\\r\\n      {:else}\\r\\n        <Icon\\r\\n          tag=\\"svg\\"\\r\\n          viewBox=\\"0 0 24 24\\"\\r\\n\\r\\n          style=\\"margin:10px 5px 10px 5px; scale:1.3; width:20px; visibility: hidden;\\"\\r\\n        />\\r\\n      {/if}\\r\\n      </Section>\\r\\n      <Section align=\\"start\\"> \\r\\n\\r\\n          <div>\\r\\n            <IconButton\\r\\n              class=\\"material-icons\\"\\r\\n              aria-label=\\"Back\\"\\r\\n              on:click={onSTT}\\r\\n            >\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" style=\\"position:absolute; margin:10px 5px 10px 5px; scale:1.1;width:30px\\">\\r\\n                {#if isSTT}\\r\\n                  <path fill=\\"grey\\" d={mdiMicrophone} />\\r\\n                {:else}\\r\\n                  <path fill=\\"white\\" d={mdiMicrophoneOutline} />\\r\\n                {/if}\\r\\n              </Icon>\\r\\n            </IconButton>\\r\\n          </div>\\r\\n\\r\\n      </Section>\\r\\n      <Section align=\\"start\\">\\r\\n          {#if span_equal}\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" width=\\"30px\\" height=\\"30px\\" fill=\\"white\\"  \\r\\n          on:click={() => { span_equal = !span_equal; onToggleWord(); }} >\\r\\n            <!-- Верхняя полоска -->\\r\\n            <rect x=\\"2\\" y=\\"4\\" width=\\"8\\" height=\\"2\\" fill=\\"red\\" />\\r\\n            <rect x=\\"12\\" y=\\"4\\" width=\\"6\\" height=\\"2\\" />\\r\\n            <rect x=\\"18\\" y=\\"4\\" width=\\"4\\" height=\\"2\\" />\\r\\n          \\r\\n            <!-- Вторая полоска (разделенная на две части) -->\\r\\n            <rect x=\\"2\\" y=\\"8\\" width=\\"8\\" height=\\"2\\" />\\r\\n            <rect x=\\"12\\" y=\\"8\\" width=\\"10\\" height=\\"2\\" fill=\\"orange\\" />\\r\\n       \\r\\n          \\r\\n            <!-- Третья полоска -->\\r\\n            <rect x=\\"2\\" y=\\"12\\" width=\\"4\\" height=\\"2\\" />\\r\\n            <rect x=\\"8\\" y=\\"12\\" width=\\"10\\" height=\\"2\\" fill=\\"black\\" />\\r\\n            <rect x=\\"18\\" y=\\"12\\" width=\\"4\\" height=\\"2\\" />\\r\\n          \\r\\n            <!-- Четвертая полоска (разделенная на две части) -->\\r\\n            <rect x=\\"2\\" y=\\"16\\" width=\\"14\\" height=\\"2\\" fill=\\"green\\" />\\r\\n            <rect x=\\"18\\" y=\\"16\\" width=\\"4\\" height=\\"2\\" />\\r\\n          \\r\\n            <!-- Нижняя полоска -->\\r\\n            <rect x=\\"12\\" y=\\"20\\" width=\\"10\\" height=\\"2\\" fill=\\"magenta\\" />\\r\\n            <rect x=\\"2\\" y=\\"20\\" width=\\"8\\" height=\\"2\\" />\\r\\n          </Icon>\\r\\n    \\r\\n          {:else}\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" width=\\"30px\\" height=\\"30px\\"  fill=\\"white\\"  \\r\\n              on:click={()=>{span_equal = !span_equal; onToggleWord()}} >\\r\\n              <!-- Верхняя полоска -->\\r\\n              <rect x=\\"2\\" y=\\"4\\" width=\\"14\\" height=\\"2\\"/>\\r\\n              <rect x=\\"18\\" y=\\"4\\" width=\\"4\\" height=\\"2\\" />\\r\\n              <!-- Вторая полоска (разделенная на две части) -->\\r\\n              <rect x=\\"12\\" y=\\"8\\" width=\\"10\\" height=\\"2\\"/>\\r\\n              <rect x=\\"2\\" y=\\"8\\" width=\\"8\\" height=\\"2\\" />\\r\\n              <!-- Третья полоска -->\\r\\n              <rect x=\\"2\\" y=\\"12\\" width=\\"20\\" height=\\"2\\" />\\r\\n              <!-- Четвертая полоска (разделенная на две части) -->\\r\\n              <rect x=\\"2\\" y=\\"16\\" width=\\"14\\" height=\\"2\\"/>\\r\\n              <rect x=\\"18\\" y=\\"16\\" width=\\"4\\" height=\\"2\\"  />\\r\\n              <!-- Нижняя полоска -->\\r\\n              <rect x=\\"12\\" y=\\"20\\" width=\\"10\\" height=\\"2\\"/>\\r\\n              <rect x=\\"2\\" y=\\"20\\" width=\\"8\\" height=\\"2\\" />\\r\\n          </Icon>\\r\\n\\r\\n          {/if}\\r\\n\\r\\n      </Section>\\r\\n\\r\\n      <Section align=\\"end\\">\\r\\n        <div class=\\"counter\\">\\r\\n          <p>\\r\\n            <span class=\\"mdc-typography--overline\\" style=\\"position:relative\\"\\r\\n              >{1+curSentence}\\r\\n              <Badge\\r\\n                position=\\"middle\\"\\r\\n                align=\\"bottom-end - bottom-middle\\"\\r\\n                aria-label=\\"unread count\\"\\r\\n                style=\\"position:relative;top:-30px;right:-5px;scale:.8\\">{bricks_data?.text.length}</Badge\\r\\n              >\\r\\n            </span>\\r\\n          </p>\\r\\n        </div>\\r\\n      </Section>\\r\\n      <Section align=\\"end\\">\\r\\n        <div>\\r\\n        <IconButton on:click={()=>{ isPlayAuto = !isPlayAuto; PlayAutoContent()}} >\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" style=\\"visibility:hidden;display:absolute;margin:0px 10px 5px 10px ;scale:1.1;width:30px\\">\\r\\n            <path fill={playAutoColor} d={mdiEarHearing} />\\r\\n          </Icon>\\r\\n        </IconButton>\\r\\n      </div>\\r\\n      </Section>\\r\\n      <Section align=\\"end\\">\\r\\n        <Icon\\r\\n          tag=\\"svg\\"\\r\\n          viewBox=\\"0 0 24 24\\"\\r\\n          style=\\"margin:10px 5px 10px 5px; scale:1.1; width:25px\\"\\r\\n          on:click={ToggleTranslate}\\r\\n        >\\r\\n        {#if translate}\\r\\n          <path fill=\\"grey\\" d={mdiTranslateOff}/>\\r\\n        {:else}\\r\\n          <path fill=\\"white\\" d={mdiTranslate}/>\\r\\n        {/if}\\r\\n        </Icon>\\r\\n      </Section>\\r\\n\\r\\n      <Section align=\\"end\\">\\r\\n        <Icon\\r\\n          tag=\\"svg\\"\\r\\n          on:click={()=>{navSentence('next')}}\\r\\n          viewBox=\\"0 0 24 24\\"\\r\\n          style=\\"margin:10px 5px 10px 5px; scale:1.3; width:20px;\\"\\r\\n        >\\r\\n        <path fill=\\"white\\" stroke=\\"white\\" stroke-width=\\"1.5\\" stroke-linejoin=\\"round\\" d={mdiArrowRight} />\\r\\n      </Icon>\\r\\n      </Section>\\r\\n    </Row>\\r\\n  </TopAppBar>\\r\\n</div>\\r\\n\\r\\n{#if bricks_data?.html}\\r\\n  <span class=\\"bricks_name\\" on:click={() => (isCollapsed = !isCollapsed)}\\r\\n  \\r\\n  >{bricks_data?.name}</span\\r\\n  >\\r\\n  {#if !isCollapsed}\\r\\n      <div class=\\"collapsible\\" in:slide={{ duration: 300 }}>\\r\\n          <ConText data={bricks_data} {tts} />\\r\\n      </div>\\r\\n  {/if} \\r\\n{/if}\\r\\n\\r\\n<main>\\r\\n  <span class='article' on:click={toNextArticle}>{article_name}</span>\\r\\n  <div>\\r\\n    {#if translate}\\r\\n    <div class=\\"trans\\">\\r\\n      <!-- Исходное предложение -->\\r\\n      <!-- <p>{bricks_data.translate[curSentence]}</p> -->\\r\\n      {#await Translate(sentence.replace(/<[^>]*>/g, ''), $llang, $langs) then data}\\r\\n        <p>{data}</p>\\r\\n      {/await}\\r\\n    </div>\\r\\n    {/if}\\r\\n    <!-- Предложение с замененными словами -->\\r\\n    {#await Translate('Составить предложение', 'ru', $langs) then data}\\r\\n      <div class=\\"title\\">{data}:</div>\\r\\n    {/await}\\r\\n      <!-- {#await Translate('(используй подсказки слов в случае необходимости)', 'ru', $langs) then data_2}\\r\\n      <div class=\\"title title2\\">{data_2}:</div>\\r\\n      {/await} -->\\r\\n    <div class=\\"formatted-list\\">\\r\\n      {#each formattedSentence as item, index}\\r\\n        <span class={\`\${item.class} \${item.gr}\`}\\r\\n          tabindex=\\"0\\" \\r\\n          value={item.value.replace(/<[^>]*>/g, '')}\\r\\n          on:click={() => {item.word=item.value; handleFormatted(item, index)}}\\r\\n          on:focus={() => handleFocus(index)}>\\r\\n          {@html item.word || item.placeholder}\\r\\n        </span>\\r\\n      {/each}\\r\\n      <div class=\\"speaker-button\\" on:click={SpeakText}>\\r\\n        <IconButton>\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n            <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n          </Icon>\\r\\n        </IconButton>\\r\\n      </div> \\r\\n    </div>\\r\\n  </div>\\r\\n\\r\\n  <div>\\r\\n    <!-- Горизонтальный список слов -->\\r\\n    {#await Translate('используя набор слов', 'ru', $langs) then data}\\r\\n        <div class=\\"title\\">{data}:</div>\\r\\n    {/await}\\r\\n\\r\\n    <div class=\\"word-list\\">\\r\\n      {#each words as word, index}\\r\\n        <span class={word.gr} on:click={() => handleClick(words[index])}>{@html word.value}</span>\\r\\n      {/each}\\r\\n    </div>\\r\\n  </div>\\r\\n\\r\\n\\r\\n\\r\\n  {#if isSTT}\\r\\n  {#await Translate('Check a pronanciation', 'en', $langs) then data}\\r\\n    <div class=\\"title\\">{data}:</div>\\r\\n  {/await}\\r\\n      \\r\\n  <div class=\\"margins\\"\\r\\n    style=\\"text-align: center; display: flex; align-items: center; justify-content: space-between;\\">\\r\\n    <div>\\r\\n      <IconButton\\r\\n        class=\\"material-icons\\"\\r\\n        aria-label=\\"Back\\"\\r\\n        on:click={onClickMicrophone}\\r\\n      >\\r\\n        <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n          {#if isListening}\\r\\n            <path fill=\\"currentColor\\" d={mdiMicrophone} />\\r\\n          {:else}\\r\\n            <path fill=\\"currentColor\\" d={mdiMicrophoneOutline} />\\r\\n          {/if}\\r\\n        </Icon>\\r\\n      </IconButton>\\r\\n    </div>\\r\\n    <Stt\\r\\n      bind:this={stt}\\r\\n      {SttResult}\\r\\n      {StopListening}\\r\\n      bind:display_audio\\r\\n    ></Stt>\\r\\n  </div>\\r\\n  <div style=\\"text-align: center;  margin-top: 20px;\\">\\r\\n    <span style=\\"color: darkgreen;\\">\\r\\n      {@html stt_text}\\r\\n    </span>\\r\\n  </div>\\r\\n\\r\\n  {/if}\\r\\n\\r\\n  <div style=\\"height:100px\\"></div>\\r\\n\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n\\r\\n\\r\\n\\r\\n  :global(.mdc-top-app-bar__row){\\r\\n      height:48px\\r\\n  }\\r\\n\\r\\n  :global(.mdc-icon-button){\\r\\n    top:5px\\r\\n  }\\r\\n\\r\\n  .top-app-bar-container{\\r\\n    position: relative;\\r\\n    top:0px; \\r\\n    height: 45px;\\r\\n  /* transform: scale(1.2) translate(-4%,0%);\\r\\n  transform-origin: center ;  */\\r\\n  }\\r\\n  .hint-button {\\r\\n      border: 0px;\\r\\n      color: white;\\r\\n      background-color: #2196f3;\\r\\n      border-radius: 3px;\\r\\n      padding: 8px 10px;\\r\\n  }\\r\\n\\r\\n  .bricks_name{\\r\\n    position:relative;\\r\\n    margin: 10px;\\r\\n    width:80%;\\r\\n    color: black;\\r\\n    font-style: italic;\\r\\n    font-size: small;\\r\\n    font-family: serif;\\r\\n  }\\r\\n\\r\\n  .invisible{\\r\\n      color:transparent\\r\\n  }\\r\\n\\r\\n  .article{\\r\\n    display: flex;;\\r\\n    justify-content: center;\\r\\n    align-items: center;\\r\\n    height: 3vh;\\r\\n    color: #2196f3;\\r\\n    font-style: italic;\\r\\n    font-size: small;\\r\\n  }\\r\\n  .speaker-button {\\r\\n    display: inline-flex;\\r\\n    float: right;\\r\\n    font-size: large;\\r\\n    border-radius: 25px;\\r\\n    margin-right: 0px;\\r\\n    margin-left: 10px;\\r\\n    z-index: 0;\\r\\n  }\\r\\n\\r\\n  .counter {\\r\\n      position: relative;\\r\\n      background-color: #f0f0f0;\\r\\n      border-radius: 25px;\\r\\n      width: 30px;\\r\\n      height: 30px;\\r\\n      top: 0px;\\r\\n      left: -5px;\\r\\n      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\\r\\n      text-align: center;\\r\\n  }\\r\\n\\r\\n  .counter p {\\r\\n      margin: 0;\\r\\n      font-size: 15px;\\r\\n      color: #333;\\r\\n  }\\r\\n\\r\\n  .counter span {\\r\\n      font-weight: 700;\\r\\n      font-size: 15px;\\r\\n      color: #ff5733; /* цвет счетчика */\\r\\n  }\\r\\n  main{\\r\\n      overflow-y: auto;\\r\\n      height: calc(90vh - 56px);\\r\\n      margin: 0px 15px 0 15px;\\r\\n  }\\r\\n\\r\\n  .trans {\\r\\n      font-size: 0.8em;\\r\\n      flex-direction: column;\\r\\n      align-items: center;\\r\\n      margin-top: 10px;\\r\\n      text-align: center;\\r\\n      line-height: 1.2 !important;\\r\\n  }\\r\\n  .placeholder {\\r\\n    border-bottom: 1px dashed #000;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  .title {\\r\\n      width: fit-content;\\r\\n      margin: 5px auto; /* Центрирование второго элемента */\\r\\n      margin-top: 5px;\\r\\n      color: #9eb2cc;\\r\\n      line-height: normal;\\r\\n      text-align: center;\\r\\n      font-size: 0.9em;\\r\\n      background-color:transparent; \\r\\n  }\\r\\n  \\r\\n  .word-list {\\r\\n    display: flex;\\r\\n    text-align: center;\\r\\n    margin: 10px 2px 15px 2px;\\r\\n    gap: 10px;\\r\\n    font-weight: 500;\\r\\n    flex-wrap: wrap;\\r\\n    color: rgb(67, 65, 65);\\r\\n  }\\r\\n\\r\\n  .formatted-list {\\r\\n    display: flex;\\r\\n    text-align: center;\\r\\n    margin: 10px 2px 15px 2px;\\r\\n    gap: 10px;\\r\\n    font-weight: 700;\\r\\n    flex-wrap: wrap;\\r\\n    color: rgb(67, 65, 65);\\r\\n  }\\r\\n\\r\\n  .word-list span:not(.ver):not(.subj):not(.tijd):not(.plaats):not(.adv), \\r\\n  .formatted-list span:not(.ver):not(.subj):not(.tijd):not(.plaats):not(.adv) {\\r\\n    padding: 0px 6px;\\r\\n    border: 1px solid #ddd;\\r\\n    border-radius: 5px;\\r\\n    background: #f9f9f9;\\r\\n    cursor: pointer;\\r\\n    user-select: none;\\r\\n\\r\\n  }\\r\\n\\r\\n  .formatted-list span:focus {\\r\\n    outline: 2px solid transparent\\r\\n  }\\r\\n\\r\\n  .word-list span{\\r\\n      border-color: lightgray;\\r\\n  }\\r\\n\\r\\n  .incorrect{\\r\\n      color:red;\\r\\n      animation: color-blink 1s infinite;\\r\\n  }\\r\\n\\r\\n  .material-symbols-outlined {\\r\\n      font-size: 15px;\\r\\n      scale: 1.5;\\r\\n      font-variation-settings:\\r\\n      'FILL' 0,\\r\\n      'wght' 400,\\r\\n      'GRAD' 0,\\r\\n      'opsz' 24;\\r\\n  }\\r\\n\\r\\n\\r\\n .ver {\\r\\n    position: relative;\\r\\n    border:2px solid; \\r\\n    border-color: rgb(225, 111, 111);\\r\\n    --border-color: rgb(225, 111, 111); /* Красный для .ver */\\r\\n    border-radius: 5px;\\r\\n    /* background-color: lightcoral; */\\r\\n    padding: 0px 6px;\\r\\n  } \\r\\n\\r\\n  .word-list .ver,.formatted-list .ver:not(.invisible){\\r\\n    color: rgb(225, 111, 111); \\r\\n  }\\r\\n\\r\\n  .subj{\\r\\n    position: relative;\\r\\n    border:2px solid; \\r\\n    border-color: rgb(49, 49, 169); \\r\\n    --border-color: rgb(49, 49, 169); \\r\\n    border-radius: 7px;\\r\\n    /* background-color:lightskyblue; */\\r\\n    padding: 0px 6px;\\r\\n  } \\r\\n\\r\\n  .word-list .subj,.formatted-list .subj:not(.invisible){\\r\\n    color: rgb(49, 49, 169); \\r\\n  }\\r\\n\\r\\n  .tijd{\\r\\n    position: relative;\\r\\n    border:2px solid; \\r\\n    border-color: rgb(119, 201, 119); \\r\\n    --border-color: rgb(119, 201, 119); \\r\\n    border-radius: 5px;\\r\\n    /* background-color: lightgreen; */\\r\\n    padding: 0px 6px;\\r\\n  } \\r\\n\\r\\n\\r\\n  .word-list .tijd,.formatted-list .tijd:not(.invisible){\\r\\n    color: rgb(119, 201, 119);\\r\\n  }\\r\\n\\r\\n  .plaats{\\r\\n    position: relative;\\r\\n    border:2px solid; \\r\\n    border-color:  darkmagenta;\\r\\n    --border-color:  darkmagenta;\\r\\n    /* background-color: lightcyan ; */\\r\\n    border-radius: 5px;\\r\\n    padding: 0px 6px;\\r\\n  } \\r\\n  .word-list .plaats,.formatted-list .plaats:not(.invisible){\\r\\n    color:  darkmagenta\\r\\n  }\\r\\n\\r\\n  .adv{\\r\\n    position: relative;\\r\\n    border:2px solid; \\r\\n    border-color: darkmagenta;\\r\\n    --border-color: darkmagenta;\\r\\n    border-radius: 5px;\\r\\n    padding: 0px 6px;\\r\\n  }\\r\\n\\r\\n  .word-list .adv,.formatted-list .adv:not(.invisible){\\r\\n    color:  darkmagenta\\r\\n  }\\r\\n\\r\\n\\r\\n  /* Анимация мигания */\\r\\n  @keyframes color-blink {\\r\\n    0%, 100% {\\r\\n      color:red;\\r\\n\\r\\n    }\\r\\n    50% {\\r\\n      color:white;\\r\\n\\r\\n    }\\r\\n  }\\r\\n\\r\\n  @keyframes border-blink {\\r\\n    0%, 100% {\\r\\n\\r\\n      box-shadow: 0 0 0px 0 var(--border-color, rgb(124, 124, 139)); /* Без тени */\\r\\n  }\\r\\n  50% {\\r\\n\\r\\n      box-shadow: 0 0 10px 4px var(--border-color, rgb(124, 124, 139)); /* Тень цвета рамки */\\r\\n  }\\r\\n}\\r\\n\\r\\n   /* Эффект мигания при фокусе */\\r\\n   span:focus {\\r\\n      /*outline: none; /* Убираем стандартный outline браузера */\\r\\n      animation: border-blink 1s infinite; /* Запускает мигание */\\r\\n      border-width: 2px; /* Устанавливаем ширину рамки для чёткости */\\r\\n    }\\r\\n\\r\\n      /* Стили для мобильных устройств */\\r\\n  @media screen and (max-width: 767px) {\\r\\n      .trans {\\r\\n          font-size: 0.7em;\\r\\n      }\\r\\n      .word-list, .formatted-list {\\r\\n          font-size: 0.9em;\\r\\n          /* margin: 2px 10px; */\\r\\n          padding: 0 5px\\r\\n      }\\r\\n      .title{\\r\\n          font-size: small;\\r\\n      }\\r\\n  }\\r\\n</style>\\r\\n\\r\\n\\r\\n"],"names":[],"mappings":"AA24BU,qBAAsB,CAC1B,OAAO,IAAI;AACjB,EAAE,CAEQ,gBAAiB,CACvB,IAAI,GAAG;AACX,EAAE,CAEA,oDAAsB,CACpB,QAAQ,CAAE,QAAQ,CAClB,IAAI,GAAG,CACP,MAAM,CAAE,IAGV,CACA,0CAAa,CACT,MAAM,CAAE,GAAG,CACX,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,IACjB,CAEA,0CAAY,CACV,SAAS,QAAQ,CACjB,MAAM,CAAE,IAAI,CACZ,MAAM,GAAG,CACT,KAAK,CAAE,KAAK,CACZ,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,KAAK,CAChB,WAAW,CAAE,KACf,CAEA,wCAAU,CACN,MAAM,WAAW;AACvB,EAAE,CAEA,sCAAQ,CACN,OAAO,CAAE,IAAI,CAAC,CAAC,CACf,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,MAAM,CAAE,GAAG,CACX,KAAK,CAAE,OAAO,CACd,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,KACb,CACA,6CAAgB,CACd,OAAO,CAAE,WAAW,CACpB,KAAK,CAAE,KAAK,CACZ,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,IAAI,CACnB,YAAY,CAAE,GAAG,CACjB,WAAW,CAAE,IAAI,CACjB,OAAO,CAAE,CACX,CAEA,sCAAS,CACL,QAAQ,CAAE,QAAQ,CAClB,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,GAAG,CACR,IAAI,CAAE,IAAI,CACV,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CACxC,UAAU,CAAE,MAChB,CAEA,uBAAQ,CAAC,gBAAE,CACP,MAAM,CAAE,CAAC,CACT,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IACX,CAEA,uBAAQ,CAAC,mBAAK,CACV,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,OACX,CACA,kCAAI,CACA,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,IAAI,CAAC,CACzB,MAAM,CAAE,GAAG,CAAC,IAAI,CAAC,CAAC,CAAC,IACvB,CAEA,oCAAO,CACH,SAAS,CAAE,KAAK,CAChB,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,IAAI,CAChB,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,GAAG,CAAC,UACrB,CACA,0CAAa,CACX,aAAa,CAAE,GAAG,CAAC,MAAM,CAAC,IAAI,CAC9B,MAAM,CAAE,OACV,CAEA,oCAAO,CACH,KAAK,CAAE,WAAW,CAClB,MAAM,CAAE,GAAG,CAAC,IAAI,CAChB,UAAU,CAAE,GAAG,CACf,KAAK,CAAE,OAAO,CACd,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,KAAK,CAChB,iBAAiB,WACrB,CAEA,wCAAW,CACT,OAAO,CAAE,IAAI,CACb,UAAU,CAAE,MAAM,CAClB,MAAM,CAAE,IAAI,CAAC,GAAG,CAAC,IAAI,CAAC,GAAG,CACzB,GAAG,CAAE,IAAI,CACT,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IAAI,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,EAAE,CACvB,CAEA,6CAAgB,CACd,OAAO,CAAE,IAAI,CACb,UAAU,CAAE,MAAM,CAClB,MAAM,CAAE,IAAI,CAAC,GAAG,CAAC,IAAI,CAAC,GAAG,CACzB,GAAG,CAAE,IAAI,CACT,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IAAI,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,EAAE,CACvB,CAEA,yBAAU,CAAC,mBAAI,KAAK,IAAI,CAAC,KAAK,KAAK,CAAC,KAAK,KAAK,CAAC,KAAK,OAAO,CAAC,KAAK,IAAI,CAAC,CACtE,8BAAe,CAAC,mBAAI,KAAK,IAAI,CAAC,KAAK,KAAK,CAAC,KAAK,KAAK,CAAC,KAAK,OAAO,CAAC,KAAK,IAAI,CAAE,CAC1E,OAAO,CAAE,GAAG,CAAC,GAAG,CAChB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,OAAO,CACnB,MAAM,CAAE,OAAO,CACf,WAAW,CAAE,IAEf,CAEA,8BAAe,CAAC,mBAAI,MAAO,CACzB,OAAO,CAAE,GAAG,CAAC,KAAK,CAAC,WAAW;AAClC,EAAE,CAEA,yBAAU,CAAC,mBAAI,CACX,YAAY,CAAE,SAClB,CAEA,wCAAU,CACN,MAAM,GAAG,CACT,SAAS,CAAE,0BAAW,CAAC,EAAE,CAAC,QAC9B,CAEA,wDAA2B,CACvB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,GAAG,CACV,uBAAuB,CACvB,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,GAAG,CAAC;AACjB,MAAM,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,EACX,CAGD,kCAAK,CACF,QAAQ,CAAE,QAAQ,CAClB,OAAO,GAAG,CAAC,KAAK,CAChB,YAAY,CAAE,IAAI,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAAC,CAChC,cAAc,CAAE,kBAAkB,CAClC,aAAa,CAAE,GAAG,CAElB,OAAO,CAAE,GAAG,CAAC,GACf,CAEA,yBAAU,CAAC,mBAAI,CAAC,8BAAe,CAAC,mBAAI,KAAK,UAAU,CAAC,CAClD,KAAK,CAAE,IAAI,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAC1B,CAEA,mCAAK,CACH,QAAQ,CAAE,QAAQ,CAClB,OAAO,GAAG,CAAC,KAAK,CAChB,YAAY,CAAE,IAAI,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CAAC,CAC9B,cAAc,CAAE,gBAAgB,CAChC,aAAa,CAAE,GAAG,CAElB,OAAO,CAAE,GAAG,CAAC,GACf,CAEA,yBAAU,CAAC,oBAAK,CAAC,8BAAe,CAAC,oBAAK,KAAK,UAAU,CAAC,CACpD,KAAK,CAAE,IAAI,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CACxB,CAEA,mCAAK,CACH,QAAQ,CAAE,QAAQ,CAClB,OAAO,GAAG,CAAC,KAAK,CAChB,YAAY,CAAE,IAAI,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAAC,CAChC,cAAc,CAAE,kBAAkB,CAClC,aAAa,CAAE,GAAG,CAElB,OAAO,CAAE,GAAG,CAAC,GACf,CAGA,yBAAU,CAAC,oBAAK,CAAC,8BAAe,CAAC,oBAAK,KAAK,UAAU,CAAC,CACpD,KAAK,CAAE,IAAI,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAC1B,CAEA,qCAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,OAAO,GAAG,CAAC,KAAK,CAChB,YAAY,CAAG,WAAW,CAC1B,cAAc,CAAG,WAAW,CAE5B,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,GACf,CACA,yBAAU,CAAC,sBAAO,CAAC,8BAAe,CAAC,sBAAO,KAAK,UAAU,CAAC,CACxD,KAAK,CAAG,WAAW;AACvB,EAAE,CAEA,kCAAI,CACF,QAAQ,CAAE,QAAQ,CAClB,OAAO,GAAG,CAAC,KAAK,CAChB,YAAY,CAAE,WAAW,CACzB,cAAc,CAAE,WAAW,CAC3B,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,GACf,CAEA,yBAAU,CAAC,mBAAI,CAAC,8BAAe,CAAC,mBAAI,KAAK,UAAU,CAAC,CAClD,KAAK,CAAG,WAAW;AACvB,EAAE,CAIA,WAAW,0BAAY,CACrB,EAAE,CAAE,IAAK,CACP,MAAM,GAER,CACA,GAAI,CACF,MAAM,KAER,CACF,CAEA,WAAW,2BAAa,CACtB,EAAE,CAAE,IAAK,CAEP,UAAU,CAAE,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,IAAI,cAAc,CAAC,mBAAmB,CAChE,CACA,GAAI,CAEA,UAAU,CAAE,CAAC,CAAC,CAAC,CAAC,IAAI,CAAC,GAAG,CAAC,IAAI,cAAc,CAAC,mBAAmB,CACnE,CACF,CAGG,kCAAI,MAAO,CAER,SAAS,CAAE,2BAAY,CAAC,EAAE,CAAC,QAAQ,CACnC,YAAY,CAAE,GAChB,CAGF,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CACjC,oCAAO,CACH,SAAS,CAAE,KACf,CACA,wCAAU,CAAE,6CAAgB,CACxB,SAAS,CAAE,KAAK,CAEhB,OAAO,CAAE,CAAC,CAAC,GAAG;AACxB,MAAM,CACA,oCAAM,CACF,SAAS,CAAE,KACf,CACJ"}`
};
function extractTagName(tagString) {
  const match = tagString.match(/^<(\w+)/);
  return match ? match[1] : "";
}
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
const Bricks = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $$unsubscribe_llang;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_llang = subscribe(llang, (value) => value);
  let topAppBar;
  let playAutoColor = "currentColor";
  let article_name = "";
  let tts;
  let words = [];
  let formattedSentence = [];
  let bricks_data;
  let curSentence = 0;
  let keys = [];
  let { data } = $$props;
  const operator = getContext("operator");
  let sentence = "";
  fetch(`./lesson?bricks=${data.name}&theme=${data.theme}&owner=${operator.abonent}&level=${data.level}`).then((response) => response.json()).then(async (data2) => {
    bricks_data = data2.data;
    bricks_data.text = splitHtmlIntoSentencesWithInnerTags(data2.data.html.replaceAll('"', ""));
    InitData();
  }).catch((error) => {
    console.log(error);
    return [];
  });
  const InitData = async () => {
    if (!bricks_data?.text) return;
    try {
      const sentences = bricks_data.text;
      const cleanedSentences = sentences.map((sent_obj) => sent_obj.sentence.replace(/<[^>]*>/g, ""));
      const chunkArray = (arr, size) => arr.reduce(
        (chunks, _, i) => i % size === 0 ? [...chunks, arr.slice(i, i + size)] : chunks,
        []
      );
      if (typeof curSentence === "undefined" || !keys[curSentence]) {
        curSentence = 0;
      }
      const sentence2 = bricks_data.text[curSentence];
      article_name = sentence2.article || "     ";
      words = formatWords(sentence2);
      formattedSentence = formatWords(sentence2);
      MakeBricks();
    } catch (error) {
      console.error("Error in InitData:", error);
    }
  };
  const formatWords = (sent_obj) => sent_obj.sentence.trim().split(/[\s,:\.]+/).filter((word) => word).map((word) => ({
    gr: extractTagName(word),
    placeholder: "     ",
    value: word.trim()
  }));
  function MakeBricks() {
    const firstElement = document.querySelector(".formatted-list span");
    if (firstElement) {
      firstElement.focus();
    }
    onToggleWord();
  }
  function splitHtmlIntoSentencesWithInnerTags(html) {
    function removeEmojis(input) {
      const regex = emojiRegex();
      return input.replace(regex, "");
    }
    function formatTaggedText(input) {
      return input.replace(/<(\w+)>(.*?)<\/\1>/g, (match, tag, content) => {
        const words2 = content.match(/\S+|\s+/g) || [];
        return words2.map((word) => {
          if (word.trim()) return `<${tag}>${word}</${tag}>`;
          return word;
        }).join("");
      });
    }
    function shouldNotSplit(text, index) {
      const match = text.slice(Math.max(0, index - 10), index + 10);
      return /<(\w+)>([^<]*[A-Z]\.[A-Z]\.[^<]*)<\/\1>/i.test(match);
    }
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const articles = doc.querySelectorAll("article, aticle");
    const sentences = Array.from(articles).flatMap((article) => {
      const htmlContent = formatTaggedText(removeEmojis(article.innerHTML.trim()));
      const articleName = article.getAttribute("name") || "";
      return htmlContent.split(/(?<!\b(?:Dr|Mr|Ms|Mrs|St))(?<=[.!?])\s+(?=<|\w|<\/\w+>)/g).map((sentence2, index, arr) => {
        if (index > 0 && shouldNotSplit(arr[index - 1], arr[index - 1].length)) {
          return arr[index - 1] + " " + sentence2;
        }
        return sentence2;
      }).filter((sentence2) => sentence2.length > 0).map((sentence2) => ({
        sentence: sentence2,
        article: articleName
        // Добавляем название статьи вместо outerHTML
      }));
    });
    return sentences;
  }
  const onToggleWord = () => {
    const sent_obj = bricks_data.text[curSentence];
    sentence = sent_obj.sentence.trim();
    {
      formattedSentence = sentence.replace(/<[^>]*>/g, "").split(/[\s,:\.]+/).filter((word) => word).map(
        (word) => ({
          gr: extractTagName(word),
          placeholder: "     ",
          value: word.trim()
        })
      );
      formattedSentence.forEach((item) => {
        item.placeholder = "     ";
        item.class = "";
      });
      words = sentence.replace(/<[^>]*>/g, "").trim().split(/[\s,:\.]+/).filter((word) => word).map(
        (word) => ({
          gr: extractTagName(word),
          placeholder: "     ",
          value: word.trim()
        })
      );
    }
    words = shuffleArray(words);
    formattedSentence = formattedSentence;
  };
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$a);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      {
        playAutoColor = "currentColor";
      }
    }
    $$rendered = `${validate_component(Tts, "Tts").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${bricks_data?.length < 1 ? `<div style="text-align:center"><span class="material-symbols-outlined svelte-13nnokv" style="font-size: 20px; color: blue; scale:1.5;">${validate_component(CircularProgress, "CircularProgress").$$render(
      $$result,
      {
        style: "height: 50px; width: 50px;",
        indeterminate: true
      },
      {},
      {}
    )}</span></div>` : ``} <div class="top-app-bar-container flexor svelte-13nnokv">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      { variant: "fixed", this: topAppBar },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `${curSentence > 0 ? `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin:10px 5px 10px 5px; scale:1.3; width:20px; visibility: " + (curSentence > 0 ? "visible" : "hidden")
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white" stroke="white" stroke-width="1.5" stroke-linejoin="round"${add_attribute("d", mdiArrowLeft, 0)}></path>`;
                      }
                    }
                  )}` : `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin:10px 5px 10px 5px; scale:1.3; width:20px; visibility: hidden;"
                    },
                    {},
                    {}
                  )}`}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `<div>${validate_component(IconButton, "IconButton").$$render(
                    $$result,
                    {
                      class: "material-icons",
                      "aria-label": "Back"
                    },
                    {},
                    {
                      default: () => {
                        return `${validate_component(CommonIcon, "Icon").$$render(
                          $$result,
                          {
                            tag: "svg",
                            viewBox: "0 0 24 24",
                            style: "position:absolute; margin:10px 5px 10px 5px; scale:1.1;width:30px"
                          },
                          {},
                          {
                            default: () => {
                              return `${`<path fill="white"${add_attribute("d", mdiMicrophoneOutline, 0)}></path>`}`;
                            }
                          }
                        )}`;
                      }
                    }
                  )}</div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `${`${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      width: "30px",
                      height: "30px",
                      fill: "white"
                    },
                    {},
                    {
                      default: () => {
                        return ` <rect x="2" y="4" width="8" height="2" fill="red"></rect> <rect x="12" y="4" width="6" height="2"></rect> <rect x="18" y="4" width="4" height="2"></rect>  <rect x="2" y="8" width="8" height="2"></rect> <rect x="12" y="8" width="10" height="2" fill="orange"></rect>  <rect x="2" y="12" width="4" height="2"></rect> <rect x="8" y="12" width="10" height="2" fill="black"></rect> <rect x="18" y="12" width="4" height="2"></rect>  <rect x="2" y="16" width="14" height="2" fill="green"></rect> <rect x="18" y="16" width="4" height="2"></rect>  <rect x="12" y="20" width="10" height="2" fill="magenta"></rect> <rect x="2" y="20" width="8" height="2"></rect>`;
                      }
                    }
                  )}`}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<div class="counter svelte-13nnokv"><p class="svelte-13nnokv"><span class="mdc-typography--overline svelte-13nnokv" style="position:relative">${escape(1 + curSentence)} ${validate_component(Badge, "Badge").$$render(
                    $$result,
                    {
                      position: "middle",
                      align: "bottom-end - bottom-middle",
                      "aria-label": "unread count",
                      style: "position:relative;top:-30px;right:-5px;scale:.8"
                    },
                    {},
                    {
                      default: () => {
                        return `${escape(bricks_data?.text.length)}`;
                      }
                    }
                  )}</span></p></div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<div>${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
                    default: () => {
                      return `${validate_component(CommonIcon, "Icon").$$render(
                        $$result,
                        {
                          tag: "svg",
                          viewBox: "0 0 24 24",
                          style: "visibility:hidden;display:absolute;margin:0px 10px 5px 10px ;scale:1.1;width:30px"
                        },
                        {},
                        {
                          default: () => {
                            return `<path${add_attribute("fill", playAutoColor, 0)}${add_attribute("d", mdiEarHearing, 0)}></path>`;
                          }
                        }
                      )}`;
                    }
                  })}</div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin:10px 5px 10px 5px; scale:1.1; width:25px"
                    },
                    {},
                    {
                      default: () => {
                        return `${`<path fill="white"${add_attribute("d", mdiTranslate, 0)}></path>`}`;
                      }
                    }
                  )}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin:10px 5px 10px 5px; scale:1.3; width:20px;"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white" stroke="white" stroke-width="1.5" stroke-linejoin="round"${add_attribute("d", mdiArrowRight, 0)}></path>`;
                      }
                    }
                  )}`;
                }
              })}`;
            }
          })}`;
        }
      }
    )}</div> ${bricks_data?.html ? `<span class="bricks_name svelte-13nnokv">${escape(bricks_data?.name)}</span> ${``}` : ``} <main class="svelte-13nnokv"><span class="article svelte-13nnokv">${escape(article_name)}</span> <div>${``}  ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-13nnokv">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("Составить предложение", "ru", $langs))}  <div class="formatted-list svelte-13nnokv">${each(formattedSentence, (item, index) => {
      return `<span class="${escape(null_to_empty(`${item.class} ${item.gr}`), true) + " svelte-13nnokv"}" tabindex="0"${add_attribute("value", item.value.replace(/<[^>]*>/g, ""), 0)}><!-- HTML_TAG_START -->${item.word || item.placeholder}<!-- HTML_TAG_END --> </span>`;
    })} <div class="speaker-button svelte-13nnokv">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)}></path>`;
          }
        })}`;
      }
    })}</div></div></div> <div> ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-13nnokv">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("используя набор слов", "ru", $langs))} <div class="word-list svelte-13nnokv">${each(words, (word, index) => {
      return `<span class="${escape(null_to_empty(word.gr), true) + " svelte-13nnokv"}"><!-- HTML_TAG_START -->${word.value}<!-- HTML_TAG_END --></span>`;
    })}</div></div> ${``} <div style="height:100px"></div> </main>`;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_llang();
  return $$rendered;
});
const css$9 = {
  code: "main.svelte-7fmt0b.svelte-7fmt0b{text-align:center;margin-top:40px}.hint-button.svelte-7fmt0b.svelte-7fmt0b{display:inline-block;position:relative;top:4px;height:44px;color:white;background-color:#2196f3;border-radius:3px}button.svelte-7fmt0b.svelte-7fmt0b{margin-top:10px;padding:8px 16px;font-size:16px;cursor:pointer}.input.svelte-7fmt0b.svelte-7fmt0b{display:inline-block;padding:8px;width:50vw;font-size:24px;margin-top:10px;margin-left:auto;margin-right:auto}main.svelte-7fmt0b>div.svelte-7fmt0b{margin-bottom:20px}",
  map: '{"version":3,"file":"Listen.svelte","sources":["Listen.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy, getContext } from \\"svelte\\";\\nimport moment from \\"moment\\";\\nmoment.locale(\\"nl-be\\");\\nimport { DateTime } from \\"luxon\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport { mdiPagePreviousOutline, mdiArrowRight, mdiArrowLeft, mdiShareVariant, mdiShuffle } from \\"@mdi/js\\";\\nimport TTS from \\"../../../speech/tts/Tts.svelte\\";\\nlet tts;\\nimport { lesson, dc, dc_state, langs, llang, dicts } from \\"$lib/js/stores.js\\";\\nconst operator = getContext(\\"operator\\");\\nlet dict = $dicts;\\nlet share_mode = false;\\nlet share_button = false;\\nlet style_button_non_shared = `position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: white;\\n\\t\\tcolor: grey;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;`;\\nlet style_button_shared = `position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: #2196f3;\\n\\t\\tcolor: #fff;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;`;\\nlet style_button = style_button_non_shared;\\nexport let data;\\n$: if (data) {\\n  if (data.html) {\\n    style_button = style_button_shared;\\n    share_mode = true;\\n  }\\n}\\nif (data.func) {\\n  onChangeClick();\\n}\\n$: if ($dc_state) {\\n  switch ($dc_state) {\\n    case \\"open\\":\\n      share_button = true;\\n      break;\\n    case \\"closed\\":\\n      share_button = false;\\n      share_mode = false;\\n      style_button = style_button_non_shared;\\n      break;\\n  }\\n}\\n$: if ($dc_state) {\\n  share_button = true;\\n}\\nlet name = data.name;\\nlet generatedValue, generatedValueObj;\\nlet userTime = \\"\\";\\nlet userContent;\\nlet buttonName = \\"\\\\u0421\\\\u0442\\\\u0430\\\\u0440\\\\u0442\\";\\nlet isFirst = false;\\nlet inputStyle;\\nlet result = \\"\\";\\nlet isCorrect = null;\\nlet bottomAppBar;\\nlet change_button = false;\\nlet cur_html = 0;\\nlet q, a;\\nlet cnt = 0;\\nlet digit = 10;\\nlet div_input;\\nlet listen_data;\\nlet currentWord, currentWordIndex = 0;\\nonMount(async () => {\\n});\\n$: if (listen_data)\\n  currentWord = listen_data[currentWordIndex];\\nfetch(`./lesson?listen=${data.name}&owner=${operator.abonent}&lang=${$llang}`).then((response) => response.json()).then((res) => {\\n  listen_data = res.data.data;\\n}).catch((error) => {\\n  console.log(error);\\n  return [];\\n});\\nasync function SendToPartner() {\\n  if (share_mode && $dc) {\\n    await $dc.SendData({\\n      lesson: { quiz: \\"dialog.client\\" }\\n    }, () => {\\n      console.log();\\n    });\\n  }\\n}\\nfunction Generate() {\\n  buttonName = \\"\\\\u041F\\\\u043E\\\\u0432\\\\u0442\\\\u043E\\\\u0440\\\\u0438\\\\u0442\\\\u044C\\";\\n  isFirst = true;\\n  result = \\"\\";\\n  isCorrect = null;\\n  div_input.focus();\\n  speak(currentWord.original);\\n}\\nfunction checkInput() {\\n  userContent = userContent.replace(/&nbsp;/g, \\"\\").replace(/<\\\\/?[^>]+(>|$)/g, \\"\\");\\n  const trimmedUserContent = userContent.trim();\\n  isCorrect = trimmedUserContent.toLowerCase() === currentWord.example.toLowerCase();\\n  if (isCorrect) {\\n    inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n    setTimeout(() => {\\n      userContent = \\"\\";\\n      Generate();\\n    }, 1e3);\\n  } else {\\n    let i = 0;\\n    inputStyle = \\"\\";\\n    userContent = \\"\\";\\n    result = \\"\\";\\n    while (i < currentWord.example.length || i < trimmedUserContent.length) {\\n      if (!trimmedUserContent[i]) {\\n        result += `<span class=\\"empty_block\\" onchage=\\"onChangeUserContent\\" style=\\"display: inline-block; background-color:rgba(255, 240, 251, 0.9);border:1px solid rgba(255, 240, 251, 0.9); width:15px\\">&nbsp;</span>`;\\n      } else if (trimmedUserContent[i] === currentWord.example[i]) {\\n        result += `<span class=\\"correct\\">${currentWord.example[i]}</span>`;\\n      } else {\\n        result += `<span style=\\"color:red;  \\">${trimmedUserContent[i]}</span>`;\\n      }\\n      i++;\\n    }\\n    userContent = result;\\n    div_input.focus();\\n    repeat();\\n  }\\n}\\nfunction checkAnswer() {\\n  const parsedAnswer = parseInt(userAnswer, 10);\\n  isCorrect = !isNaN(parsedAnswer) && parsedAnswer === generatedValue;\\n  inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n  setTimeout(() => {\\n    generateNumber();\\n  }, 1500);\\n}\\nasync function speak(text) {\\n  tts.Speak($llang, text);\\n}\\nfunction repeat() {\\n  speak(currentWord.original);\\n  div_input.focus();\\n}\\nfunction handleBackClick() {\\n  $lesson.data = { quiz: \\"\\" };\\n}\\nfunction onChangeClick() {\\n  data = { question: q, answer: a, quiz: data.quiz };\\n  if (data.html)\\n    data.html = data.html[cur_html];\\n  data.quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  let client_quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  $dc?.SendData({ lesson: data }, () => {\\n    console.log();\\n  });\\n}\\nfunction handleUserInput(event) {\\n  const inputValue = event.target.innerHTML;\\n  if (!isNaN(inputValue)) {\\n    if (inputValue.length === 2 && event.data !== \\":\\") {\\n      event.target.innerHTML = inputValue + \\":\\";\\n    }\\n    if (inputValue.length > 4) {\\n      event.target.innerHTML = inputValue.slice(0, 4);\\n    }\\n    userContent = event.target.innerHTML;\\n    const range = document.createRange();\\n    const selection = window.getSelection();\\n    range.selectNodeContents(div_input);\\n    range.collapse(false);\\n    selection.removeAllRanges();\\n    selection.addRange(range);\\n  }\\n}\\nfunction showHint() {\\n  userContent = currentWord.example;\\n  setTimeout(() => {\\n    if (listen_data[currentWordIndex + 1])\\n      currentWordIndex++;\\n    else\\n      currentWordIndex = 0;\\n    checkInput();\\n  }, 1e3);\\n}\\nfunction onShare() {\\n  share_mode = !share_mode;\\n  style_button = share_mode ? style_button_shared : style_button_non_shared;\\n}\\nonDestroy(() => {\\n});\\n<\/script>\\r\\n\\r\\n<!-- <link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/> -->\\r\\n\\r\\n<TTS bind:this={tts}></TTS>\\r\\n<!-- <RV bind:this={rv}></RV> -->\\r\\n\\r\\n{#if share_button}\\r\\n  <IconButton class=\\"material-icons\\" on:click={onShare} style={style_button}>\\r\\n    <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n      <path fill=\\"currentColor\\" d={mdiShareVariant} /></Icon\\r\\n    >\\r\\n  </IconButton>\\r\\n{/if}\\r\\n<main>\\r\\n  <div>\\r\\n    <p>{dict[\'Послушай и напиши\'][$langs]}:</p>\\r\\n\\r\\n    {#if !isFirst}\\r\\n      <button on:click={Generate}>{dict[\'Старт\'][$langs]}</button>\\r\\n    {:else}\\r\\n      <button on:click={repeat}>{dict[\'Повторить\'][$langs]}</button>\\r\\n      <button on:click={checkInput}>{dict[\'Проверить\'][$langs]}</button>\\r\\n    {/if}\\r\\n  </div>\\r\\n\\r\\n  <div>\\r\\n    <!-- <label for=\\"userAnswer\\">Your Answer:</label> -->\\r\\n\\r\\n    <div\\r\\n      contenteditable=\\"true\\"\\r\\n      class=\\"input\\"\\r\\n      style={inputStyle}\\r\\n      on:input={handleUserInput}\\r\\n      bind:this={div_input}\\r\\n      bind:innerHTML={userContent}\\r\\n    />\\r\\n\\r\\n    {#if isFirst}\\r\\n      <button on:click={showHint} class=\\"hint-button\\">\\r\\n        <span class=\\"material-symbols-outlined\\"> question_mark </span>\\r\\n      </button>\\r\\n    {/if}\\r\\n\\r\\n    <!-- <input type=\\"text\\" id=\\"userAnswer\\" bind:value={userAnswer} style={inputStyle} /> -->\\r\\n  </div>\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    text-align: center;\\r\\n    margin-top: 40px;\\r\\n  }\\r\\n  .hint-button {\\r\\n    display: inline-block;\\r\\n    position: relative;\\r\\n    top: 4px;\\r\\n    height: 44px;\\r\\n    color: white;\\r\\n    background-color: #2196f3;\\r\\n    border-radius: 3px;\\r\\n  }\\r\\n\\r\\n  button {\\r\\n    margin-top: 10px;\\r\\n    padding: 8px 16px;\\r\\n    font-size: 16px;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  #userTime {\\r\\n    width: 80px;\\r\\n    font-size: x-large;\\r\\n    text-align: center;\\r\\n    border: 1px solid grey;\\r\\n    background-color: rgb(220, 228, 228);\\r\\n  }\\r\\n\\r\\n  .input {\\r\\n    display: inline-block;\\r\\n    padding: 8px;\\r\\n    width: 50vw;\\r\\n    font-size: 24px;\\r\\n    margin-top: 10px; /* Добавим отступ сверху для выравнивания */\\r\\n    margin-left: auto;\\r\\n    margin-right: auto;\\r\\n  }\\r\\n\\r\\n  label {\\r\\n    display: block;\\r\\n    font-size: 18px;\\r\\n    margin-top: 10px; /* Добавим отступ сверху для выравнивания */\\r\\n  }\\r\\n\\r\\n  main > div {\\r\\n    margin-bottom: 20px; /* Добавим отступ снизу для разделения блоков */\\r\\n  }\\r\\n\\r\\n  .share-button {\\r\\n    position: absolute;\\r\\n    top: 10px;\\r\\n    left: 10px;\\r\\n    padding: 10px;\\r\\n    font-size: 1.5em;\\r\\n    background-color: #2196f3;\\r\\n    color: #fff;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAoPE,gCAAK,CACH,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,IACd,CACA,wCAAa,CACX,OAAO,CAAE,YAAY,CACrB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,GACjB,CAEA,kCAAO,CACL,UAAU,CAAE,IAAI,CAChB,OAAO,CAAE,GAAG,CAAC,IAAI,CACjB,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,OACV,CAUA,kCAAO,CACL,OAAO,CAAE,YAAY,CACrB,OAAO,CAAE,GAAG,CACZ,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,IAAI,CAChB,WAAW,CAAE,IAAI,CACjB,YAAY,CAAE,IAChB,CAQA,kBAAI,CAAG,iBAAI,CACT,aAAa,CAAE,IACjB"}'
};
let cur_html$2 = 0;
const Listen = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dc, $$unsubscribe_dc;
  let $$unsubscribe_lesson;
  let $llang, $$unsubscribe_llang;
  let $dc_state, $$unsubscribe_dc_state;
  let $dicts, $$unsubscribe_dicts;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_dc_state = subscribe(dc_state, (value) => $dc_state = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  moment.locale("nl-be");
  let tts;
  const operator = getContext("operator");
  let dict = $dicts;
  let share_button = false;
  let style_button_non_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: white;
		color: grey;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: #2196f3;
		color: #fff;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button = style_button_non_shared;
  let { data } = $$props;
  if (data.func) {
    onChangeClick();
  }
  data.name;
  let userContent;
  let inputStyle;
  let q, a;
  let div_input;
  let listen_data;
  let currentWordIndex = 0;
  fetch(`./lesson?listen=${data.name}&owner=${operator.abonent}&lang=${$llang}`).then((response) => response.json()).then((res) => {
    listen_data = res.data.data;
  }).catch((error) => {
    console.log(error);
    return [];
  });
  function onChangeClick() {
    data = { question: q, answer: a, quiz: data.quiz };
    if (data.html) data.html = data.html[cur_html$2];
    data.quiz = data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    $dc?.SendData({ lesson: data }, () => {
      console.log();
    });
  }
  onDestroy(() => {
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$9);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (data) {
        if (data.html) {
          style_button = style_button_shared;
        }
      }
    }
    {
      if ($dc_state) {
        switch ($dc_state) {
          case "open":
            share_button = true;
            break;
          case "closed":
            share_button = false;
            style_button = style_button_non_shared;
            break;
        }
      }
    }
    {
      if ($dc_state) {
        share_button = true;
      }
    }
    {
      if (listen_data) listen_data[currentWordIndex];
    }
    $$rendered = ` ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )}  ${share_button ? `${validate_component(IconButton, "IconButton").$$render(
      $$result,
      {
        class: "material-icons",
        style: style_button
      },
      {},
      {
        default: () => {
          return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiShareVariant, 0)}></path>`;
            }
          })}`;
        }
      }
    )}` : ``} <main class="svelte-7fmt0b"><div class="svelte-7fmt0b"><p>${escape(dict["Послушай и напиши"][$langs])}:</p> ${`<button class="svelte-7fmt0b">${escape(dict["Старт"][$langs])}</button>`}</div> <div class="svelte-7fmt0b"> <div contenteditable="true" class="input svelte-7fmt0b"${add_attribute("style", inputStyle, 0)}${add_attribute("this", div_input, 0)}>${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(userContent)}</div> ${``} </div> </main>`;
  } while (!$$settled);
  $$unsubscribe_dc();
  $$unsubscribe_lesson();
  $$unsubscribe_llang();
  $$unsubscribe_dc_state();
  $$unsubscribe_dicts();
  $$unsubscribe_langs();
  return $$rendered;
});
const css$8 = {
  code: ".q.svelte-11aoiyk{color:gray;border:0;background-color:transparent;font:1.2em sans-serif}.toggleButton.svelte-11aoiyk{position:absolute;right:25px;top:170px}",
  map: `{"version":3,"file":"Speak.svelte","sources":["Speak.svelte"],"sourcesContent":["<script>\\r\\n\\timport { users } from '$lib/js/stores.js';\\r\\n\\r\\n\\timport { onMount, getContext } from 'svelte';\\r\\n\\timport BottomAppBar, { Section, AutoAdjust } from '@smui-extra/bottom-app-bar';\\r\\n\\timport IconButton, { Icon } from '@smui/icon-button';\\r\\n\\timport { mdiPagePreviousOutline } from '@mdi/js';\\r\\n\\r\\n\\timport { lesson } from '$lib/js/stores.js';\\r\\n\\timport { dc } from '$lib/js/stores.js';\\r\\n\\t$: if ($dc && $dc.dc) {\\r\\n\\t\\t$dc.dc.onmessage = (event) => {\\r\\n\\t\\t\\tconsole.log(event.data);\\r\\n\\t\\t};\\r\\n\\t}\\r\\n\\r\\n\\timport pkg from 'lodash';\\r\\n\\tconst { find, findKey, mapValues } = pkg;\\r\\n\\r\\n\\tlet bottomAppBar;\\r\\n\\r\\n\\t$: if (data.question) {\\r\\n\\t\\tq_visibility = 'hidden';\\r\\n\\t}\\r\\n\\r\\n\\t$: if (data.answer) {\\r\\n\\t\\ta_visibility = 'hidden';\\r\\n\\t}\\r\\n\\r\\n\\t$: {\\r\\n\\t\\tconsole.log($lesson.visible);\\r\\n\\t}\\r\\n\\t// import pair_data from './pair_data.json';\\r\\n\\texport let data;\\r\\n\\r\\n\\tlet q_visibility = 'hidden';\\r\\n\\tlet a_visibility = 'hidden';\\r\\n\\r\\n\\tlet containerWidth, containerHeight;\\r\\n\\r\\n\\tonMount(() => {\\r\\n\\t\\t// Получаем ширину родительского окна при загрузке компонента\\r\\n\\t\\tconst parentWidth = window.innerWidth; // Может потребоваться window.innerWidth - некоторое смещение, если у вас есть другие элементы на странице\\r\\n\\r\\n\\t\\t// Устанавливаем ширину контейнера равной ширине родительского окна\\r\\n\\t\\tcontainerWidth = parentWidth + 'px';\\r\\n\\r\\n\\t\\t// Получаем высоту родительского окна при загрузке компонента\\r\\n\\t\\tconst parentHeight = window.innerHeight; // Может потребоваться window.innerHeight - некоторое смещение, если у вас есть другие элементы на странице\\r\\n\\r\\n\\t\\t// Устанавливаем высоту контейнера равной высоте родительского окна\\r\\n\\t\\tcontainerHeight = parentHeight + 'px';\\r\\n\\t});\\r\\n\\tfunction handleBackClick() {\\r\\n\\t\\tlesson_display = true; // При клике на \\"Back\\" показываем компонент Lesson\\r\\n\\t}\\r\\n\\r\\n\\tfunction onClickQ() {\\r\\n\\t\\tif (a_visibility === 'visible') {\\r\\n\\t\\t\\tq_visibility = 'hidden';\\r\\n\\t\\t\\ta_visibility = 'hidden';\\r\\n\\t\\t} else {\\r\\n\\t\\t\\tif (q_visibility === 'visible') a_visibility = 'visible';\\r\\n\\t\\t\\tq_visibility = 'visible';\\r\\n\\t\\t}\\r\\n\\t}\\r\\n<\/script>\\r\\n\\r\\n<div style=\\"display: flex;\\">\\r\\n\\t<div style=\\"margin:0 auto\\">\\r\\n\\t\\t<div class=\\"q\\" id=\\"question\\" style=\\"visibility:{q_visibility}\\">\\r\\n\\t\\t\\t<div>{@html data.question}</div>\\r\\n\\t\\t</div>\\r\\n\\t\\t<div class=\\"q\\" id=\\"answer\\" style=\\"visibility:{a_visibility}\\">\\r\\n\\t\\t\\t<div>{@html data.answer}</div>\\r\\n\\t\\t</div>\\r\\n\\t\\t<button class=\\"toggleButton\\" on:click={onClickQ}> ? </button>\\r\\n\\t</div>\\r\\n</div>\\r\\n{#if data.html}\\r\\n\\t<div>{@html data.html}</div>\\r\\n{/if}\\r\\n\\r\\n<!-- <BottomAppBar bind:this={bottomAppBar}>\\r\\n\\t<Section>\\r\\n\\t\\t<IconButton class=\\"material-icons\\" aria-label=\\"Back\\" on:click={handleBackClick}>\\r\\n\\t\\t\\t<Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n\\t\\t\\t\\t<path fill=\\"currentColor\\" d={mdiPagePreviousOutline} />\\r\\n\\t\\t\\t</Icon>\\r\\n\\t\\t</IconButton>\\r\\n\\t</Section>\\r\\n\\t<Section>\\r\\n\\t\\t<IconButton class=\\"material-icons\\">change_circle</IconButton>\\r\\n\\t</Section>\\r\\n\\r\\n\\t<Section>\\r\\n\\t\\t<IconButton class=\\"material-icons\\" fill=\\"currentColor\\" aria-label=\\"More\\">more_vert</IconButton>\\r\\n\\t</Section>\\r\\n</BottomAppBar> -->\\r\\n\\r\\n<style>\\r\\n\\t.container {\\r\\n\\t\\tposition: absolute;\\r\\n\\t\\tline-height: 50px;\\r\\n\\t\\ttop: 50%;\\r\\n\\t\\tleft: 50%;\\r\\n\\t\\ttransform: translate(-50%, -50%);\\r\\n\\t\\t/* Дополнительные стили по вашему усмотрению */\\r\\n\\t\\tmargin: 0;\\r\\n\\t\\tpadding: 20px;\\r\\n\\t\\tborder: 1px solid #ccc;\\r\\n\\t\\tborder-radius: 5px;\\r\\n\\t}\\r\\n\\t.q {\\r\\n\\t\\tcolor: gray;\\r\\n\\t\\tborder: 0;\\r\\n\\t\\tbackground-color: transparent;\\r\\n\\t\\tfont: 1.2em sans-serif;\\r\\n\\t}\\r\\n\\t.toggleButton {\\r\\n\\t\\tposition: absolute;\\r\\n\\t\\tright: 25px;\\r\\n\\t\\ttop: 170px;\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAiHC,iBAAG,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,CAAC,CACT,gBAAgB,CAAE,WAAW,CAC7B,IAAI,CAAE,KAAK,CAAC,UACb,CACA,4BAAc,CACb,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,IAAI,CACX,GAAG,CAAE,KACN"}`
};
const Speak = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $lesson, $$unsubscribe_lesson;
  let $dc, $$unsubscribe_dc;
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  const { find, findKey, mapValues } = pkg;
  let { data } = $$props;
  let q_visibility = "hidden";
  let a_visibility = "hidden";
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$8);
  {
    if ($dc && $dc.dc) {
      set_store_value(
        dc,
        $dc.dc.onmessage = (event) => {
          console.log(event.data);
        },
        $dc
      );
    }
  }
  {
    if (data.question) {
      q_visibility = "hidden";
    }
  }
  {
    if (data.answer) {
      a_visibility = "hidden";
    }
  }
  {
    {
      console.log($lesson.visible);
    }
  }
  $$unsubscribe_lesson();
  $$unsubscribe_dc();
  return `<div style="display: flex;"><div style="margin:0 auto"><div class="q svelte-11aoiyk" id="question" style="${"visibility:" + escape(q_visibility, true)}"><div><!-- HTML_TAG_START -->${data.question}<!-- HTML_TAG_END --></div></div> <div class="q svelte-11aoiyk" id="answer" style="${"visibility:" + escape(a_visibility, true)}"><div><!-- HTML_TAG_START -->${data.answer}<!-- HTML_TAG_END --></div></div> <button class="toggleButton svelte-11aoiyk" data-svelte-h="svelte-15jvgde">?</button></div></div> ${data.html ? `<div><!-- HTML_TAG_START -->${data.html}<!-- HTML_TAG_END --></div>` : ``} `;
});
const css$7 = {
  code: "main.svelte-1v8zq4b{text-align:center;margin:40px auto;font-family:Arial, sans-serif;color:#333;width:60%;box-sizing:border-box}p.svelte-1v8zq4b{font-size:18px;margin-bottom:15px}.btn.svelte-1v8zq4b{margin-top:10px;padding:10px 20px;font-size:16px;border:none;border-radius:5px;cursor:pointer;transition:background-color 0.3s, transform 0.2s}.button-group.svelte-1v8zq4b{display:flex;justify-content:center;gap:10px;margin-top:20px}.btn.svelte-1v8zq4b{flex:none}.btn.svelte-1v8zq4b:hover{background-color:#1e88e5;transform:scale(1.05)}.start-btn.svelte-1v8zq4b{background-color:#4caf50;color:white}.repeat-btn.svelte-1v8zq4b{background-color:#ff9800;color:white}.check-btn.svelte-1v8zq4b{background-color:#9c27b0;color:white}.hint-btn.svelte-1v8zq4b{background-color:#2196f3;color:white;border:none;border-radius:50%;width:40px;height:40px;font-weight:700 26px;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 4px rgba(0, 0, 0, 0.2);transition:transform 0.2s}.hint-btn.svelte-1v8zq4b:hover{transform:scale(1.1);background-color:#7b1fa2}.input-group.svelte-1v8zq4b{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:20px}.input-field.svelte-1v8zq4b{flex:1;width:90%;padding:10px;font-size:18px;text-align:center;border:1px solid #ccc;border-radius:5px;background-color:#f9f9f9;box-shadow:0 2px 4px rgba(0, 0, 0, 0.1)}.input-field.svelte-1v8zq4b:focus{outline:none;border-color:#2196f3;box-shadow:0 0 8px rgba(33, 150, 243, 0.5)}#userTime.svelte-1v8zq4b{width:100px;font-size:x-large}@media(max-width: 768px){.button-group.svelte-1v8zq4b{flex-direction:column;gap:15px}}",
  map: `{"version":3,"file":"Numbers.svelte","sources":["Numbers.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy } from \\"svelte\\";\\nimport Speak from \\"./Speak.svelte\\";\\nimport { Translate } from \\"../../../translate/Transloc\\";\\nimport moment from \\"moment\\";\\nmoment.locale(\\"nl-be\\");\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport { mdiPagePreviousOutline, mdiArrowRight, mdiArrowLeft, mdiShareVariant, mdiShuffle } from \\"@mdi/js\\";\\nimport { NumberString, numberToDutchString } from \\"./Listen.numbers\\";\\nimport TTS from \\"../../../speech/tts/Tts.svelte\\";\\nlet tts;\\nimport { dicts, lesson, dc_state, dc, langs, llang } from \\"$lib/js/stores.js\\";\\nlet dict = $dicts;\\nlet share_mode = false;\\nlet share_button = false;\\nlet style_button_non_shared = \`position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: white;\\n\\t\\tcolor: grey;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;\`;\\nlet style_button_shared = \`position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: #2196f3;\\n\\t\\tcolor: #fff;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;\`;\\nlet style_button = style_button_non_shared;\\nexport let data;\\n$: if (data) {\\n  if (data.html) {\\n    style_button = style_button_shared;\\n    share_mode = true;\\n  }\\n}\\nif (data.func) {\\n  onChangeClick();\\n}\\n$: if ($dc_state) {\\n  switch ($dc_state) {\\n    case \\"open\\":\\n      share_button = true;\\n      break;\\n    case \\"closed\\":\\n      share_button = false;\\n      share_mode = false;\\n      style_button = style_button_non_shared;\\n      break;\\n  }\\n}\\n$: if ($dc_state) {\\n  share_button = true;\\n}\\nlet name = data.name;\\nlet generatedValue, generatedValueObj;\\nlet userTime = \\"\\";\\nlet userContent;\\nlet buttonName = \\"\\\\u0421\\\\u0442\\\\u0430\\\\u0440\\\\u0442\\";\\nlet isFirst = false;\\nlet inputStyle;\\nlet result = \\"\\";\\nlet isCorrect = null;\\nlet bottomAppBar;\\nlet change_button = false;\\nlet cur_html = 0;\\nlet q, a;\\nlet cnt = 0;\\nlet digit = 10;\\nlet div_input;\\nonMount(async () => {\\n});\\nasync function SendToPartner() {\\n  if (share_mode && dc) {\\n    await $dc.SendData({\\n      lesson: { quiz: \\"dialog.client\\" }\\n    }, () => {\\n      console.log();\\n    });\\n  }\\n}\\nfunction Generate() {\\n  generateNumber();\\n}\\nfunction generateAlphabet() {\\n  throw new Error(\\"Function not implemented.\\");\\n}\\nfunction generateNumber() {\\n  buttonName = \\"\\\\u041F\\\\u043E\\\\u0432\\\\u0442\\\\u043E\\\\u0440\\\\u0438\\\\u0442\\\\u044C\\";\\n  isFirst = true;\\n  if (cnt % 10 === 0) {\\n    digit *= 10;\\n  }\\n  const random = Math.floor(Math.random() * digit) + digit / 10;\\n  if (random === generatedValue)\\n    return generateNumber();\\n  generatedValue = random;\\n  cnt++;\\n  result = \\"\\";\\n  isCorrect = null;\\n  speak(numberToDutchString(generatedValue));\\n  div_input.focus();\\n}\\nfunction checkInput() {\\n  userContent = userContent.replace(/&nbsp;/g, \\"\\").replace(/<\\\\/?[^>]+(>|$)/g, \\"\\");\\n  const trimmedUserContent = userContent.trim();\\n  isCorrect = trimmedUserContent === generatedValue.toString();\\n  if (isCorrect) {\\n    inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n    setTimeout(() => {\\n      userContent = \\"\\";\\n      Generate();\\n    }, 1e3);\\n  } else {\\n    let i = 0;\\n    inputStyle = \\"\\";\\n    userContent = \\"\\";\\n    result = \\"\\";\\n    while (i < generatedValue.length || i < trimmedUserContent.length) {\\n      if (!trimmedUserContent[i]) {\\n        result += \`<span class=\\"empty_block\\" onchage=\\"onChangeUserContent\\" style=\\"display: inline-block; background-color:rgba(255, 240, 251, 0.9);border:1px solid rgba(255, 240, 251, 0.9); width:15px\\">&nbsp;</span>\`;\\n      } else if (trimmedUserContent[i] === generatedValue[i]) {\\n        result += \`<span class=\\"correct\\">\${generatedValue[i]}</span>\`;\\n      } else {\\n        result += \`<span style=\\"color:red;  \\">\${trimmedUserContent[i]}</span>\`;\\n      }\\n      i++;\\n    }\\n    userContent = result;\\n    div_input.focus();\\n    repeat();\\n  }\\n}\\nfunction checkAnswer() {\\n  const parsedAnswer = parseInt(userAnswer, 10);\\n  isCorrect = !isNaN(parsedAnswer) && parsedAnswer === generatedValue;\\n  inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n  setTimeout(() => {\\n    generateNumber();\\n  }, 1500);\\n}\\nasync function speak(text) {\\n  tts.Speak_server($llang, text);\\n}\\nfunction repeat() {\\n  speak(numberToDutchString(generatedValue));\\n  div_input.focus();\\n}\\nfunction handleBackClick() {\\n  $lesson.data = { quiz: \\"\\" };\\n}\\nfunction onChangeClick() {\\n  data = { question: q, answer: a, quiz: data.quiz };\\n  if (data.html)\\n    data.html = data.html[cur_html];\\n  data.quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  let client_quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  if ($dc)\\n    $dc.SendData({ lesson: data }, () => {\\n      console.log();\\n    });\\n}\\nfunction handleUserInput(event) {\\n  const inputValue = event.target.innerHTML;\\n  if (!isNaN(inputValue)) {\\n    if (inputValue.length === 2 && event.data !== \\":\\") {\\n      event.target.innerHTML = inputValue + \\":\\";\\n    }\\n    if (inputValue.length > 4) {\\n      event.target.innerHTML = inputValue.slice(0, 4);\\n    }\\n    userContent = event.target.innerHTML;\\n    const range = document.createRange();\\n    const selection = window.getSelection();\\n    range.selectNodeContents(div_input);\\n    range.collapse(false);\\n    selection.removeAllRanges();\\n    selection.addRange(range);\\n  }\\n}\\nfunction showHint() {\\n  userContent = generatedValue.toString();\\n  setTimeout(() => {\\n    checkInput();\\n  }, 1e3);\\n}\\nfunction onShare() {\\n  share_mode = !share_mode;\\n  style_button = share_mode ? style_button_shared : style_button_non_shared;\\n}\\nonDestroy(() => {\\n});\\n<\/script>\\r\\n\\r\\n<!-- <link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/> -->\\r\\n\\r\\n<TTS bind:this={tts}></TTS>\\r\\n<!-- <RV bind:this={voice}></RV> -->\\r\\n\\r\\n{#if share_button}\\r\\n  <IconButton class=\\"material-icons\\" on:click={onShare} style={style_button}>\\r\\n    <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n      <path fill=\\"currentColor\\" d={mdiShareVariant} /></Icon\\r\\n    >\\r\\n  </IconButton>\\r\\n{/if}\\r\\n\\r\\n<main>\\r\\n   {#if data.quiz == 'listen'}\\r\\n    <div>\\r\\n     <p>{#await Translate('Послушай и напиши','ru', $langs) then data} {data}: {/await}</p>\\r\\n  \\r\\n     <div class=\\"button-group\\">\\r\\n     {#if !isFirst}\\r\\n      <button on:click={Generate} class=\\"btn start-btn\\">{#await Translate('Старт','ru', $langs) then data} {data} {/await}</button>\\r\\n     {:else}\\r\\n      <button on:click={repeat} class=\\"btn repeat-btn\\">{#await Translate('Повторить','ru', $langs) then data} {data} {/await}</button>\\r\\n      <button on:click={checkInput} class=\\"btn check-btn\\">{#await Translate('Проверить','ru', $langs) then data} {data} {/await}</button>\\r\\n     {/if}\\r\\n    </div>\\r\\n  </div>\\r\\n  \\r\\n    <div class=\\"input-group\\">\\r\\n     {#if name === 'Nummers'}\\r\\n      <div\\r\\n       class=\\"input-field\\"\\r\\n       contenteditable=\\"true\\"\\r\\n       style={inputStyle}\\r\\n       bind:this={div_input}\\r\\n       bind:innerHTML={userContent}\\r\\n      >\\r\\n       {@html result}\\r\\n      </div>\\r\\n     {:else if name === 'Tijd'}\\r\\n      <div\\r\\n       contenteditable=\\"true\\"\\r\\n       id=\\"userTime\\"\\r\\n       class=\\"input-field\\"\\r\\n       placeholder=\\"hh:mm\\"\\r\\n       on:input={handleUserInput}\\r\\n       bind:this={div_input}\\r\\n       bind:innerHTML={userContent}\\r\\n      />\\r\\n     {:else if name === 'Alphabet'}\\r\\n      <div\\r\\n       contenteditable=\\"true\\"\\r\\n       id=\\"userTime\\"\\r\\n       class=\\"input-field\\"\\r\\n       on:input={handleUserInput}\\r\\n       bind:this={div_input}\\r\\n       bind:innerHTML={userContent}\\r\\n      />\\r\\n     {/if}\\r\\n     {#if isFirst}\\r\\n      <button on:click={showHint} class=\\"btn hint-btn\\">\\r\\n       <span class=\\"material-symbols-outlined\\"> ? </span>\\r\\n      </button>\\r\\n     {/if}\\r\\n    </div>\\r\\n   {:else if data.quiz == 'dialog.client'}\\r\\n    <Speak {data} />\\r\\n   {/if}\\r\\n  </main>\\r\\n  \\r\\n  <style>\\r\\n   /* Основной контейнер */\\r\\n   main {\\r\\n    text-align: center;\\r\\n    margin: 40px auto;\\r\\n    font-family: Arial, sans-serif;\\r\\n    color: #333;\\r\\n    width: 60%; /* Устанавливаем ширину 50% */\\r\\n    box-sizing: border-box; /* Учитываем padding в общей ширине */\\r\\n   }\\r\\n  \\r\\n   /* Блок с инструкциями */\\r\\n   p {\\r\\n    font-size: 18px;\\r\\n    margin-bottom: 15px;\\r\\n   }\\r\\n  \\r\\n   /* Кнопки */\\r\\n   .btn {\\r\\n    margin-top: 10px;\\r\\n    padding: 10px 20px;\\r\\n    font-size: 16px;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    transition: background-color 0.3s, transform 0.2s;\\r\\n   }\\r\\n\\r\\n   .button-group {\\r\\n    display: flex; /* Располагаем элементы в ряд */\\r\\n    justify-content: center; /* Центрируем кнопки по горизонтали */\\r\\n    gap: 10px; /* Добавляем расстояние между кнопками */\\r\\n    margin-top: 20px; /* Отступ сверху */\\r\\n  }\\r\\n\\r\\n  .btn {\\r\\n    flex: none; /* Убираем возможность растягиваться */\\r\\n  }\\r\\n\\r\\n  \\r\\n   .btn:hover {\\r\\n    background-color: #1e88e5;\\r\\n    transform: scale(1.05);\\r\\n   }\\r\\n  \\r\\n   .start-btn {\\r\\n    background-color: #4caf50;\\r\\n    color: white;\\r\\n   }\\r\\n  \\r\\n   .repeat-btn {\\r\\n    background-color: #ff9800;\\r\\n    color: white;\\r\\n   }\\r\\n  \\r\\n   .check-btn {\\r\\n    background-color: #9c27b0;\\r\\n    color: white;\\r\\n   }\\r\\n  \\r\\n   .hint-btn {\\r\\n    background-color: #2196f3;\\r\\n    color: white;\\r\\n    border: none;\\r\\n    border-radius: 50%;\\r\\n    width: 40px;\\r\\n    height: 40px;\\r\\n    font-weight: 700 26px;\\r\\n    cursor: pointer;\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n    justify-content: center;\\r\\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\\r\\n    transition: transform 0.2s;\\r\\n   }\\r\\n  \\r\\n   .hint-btn:hover {\\r\\n    transform: scale(1.1);\\r\\n    background-color: #7b1fa2;\\r\\n    \\r\\n   }\\r\\n  \\r\\n   /* Группа поля ввода и кнопки */\\r\\n   .input-group {\\r\\n    display: flex;\\r\\n    align-items: center; /* Центрирование по вертикали */\\r\\n    justify-content: center; /* Центрирование группы по горизонтали */\\r\\n    gap: 10px; /* Расстояние между input и кнопкой */\\r\\n    margin-top: 20px;\\r\\n   }\\r\\n  \\r\\n   /* Поле ввода */\\r\\n   .input-field {\\r\\n    flex: 1; /* Поле ввода занимает доступное пространство */\\r\\n    width:90%;\\r\\n    padding: 10px;\\r\\n    font-size: 18px;\\r\\n    text-align: center;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 5px;\\r\\n    background-color: #f9f9f9;\\r\\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\\r\\n   }\\r\\n  \\r\\n   .input-field:focus {\\r\\n    outline: none;\\r\\n    border-color: #2196f3;\\r\\n    box-shadow: 0 0 8px rgba(33, 150, 243, 0.5);\\r\\n   }\\r\\n  \\r\\n   #userTime {\\r\\n    width: 100px;\\r\\n    font-size: x-large;\\r\\n   }\\r\\n  \\r\\n   /* Адаптивность */\\r\\n   @media (max-width: 768px) {\\r\\n    .button-group {\\r\\n      flex-direction: column; /* Выравниваем кнопки вертикально */\\r\\n      gap: 15px; /* Увеличиваем расстояние между кнопками */\\r\\n    }\\r\\n  }\\r\\n\\r\\n  </style>\\r\\n  \\r\\n  \\r\\n "],"names":[],"mappings":"AA+QG,mBAAK,CACJ,UAAU,CAAE,MAAM,CAClB,MAAM,CAAE,IAAI,CAAC,IAAI,CACjB,WAAW,CAAE,KAAK,CAAC,CAAC,UAAU,CAC9B,KAAK,CAAE,IAAI,CACX,KAAK,CAAE,GAAG,CACV,UAAU,CAAE,UACb,CAGA,gBAAE,CACD,SAAS,CAAE,IAAI,CACf,aAAa,CAAE,IAChB,CAGA,mBAAK,CACJ,UAAU,CAAE,IAAI,CAChB,OAAO,CAAE,IAAI,CAAC,IAAI,CAClB,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OAAO,CACf,UAAU,CAAE,gBAAgB,CAAC,IAAI,CAAC,CAAC,SAAS,CAAC,IAC9C,CAEA,4BAAc,CACb,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,GAAG,CAAE,IAAI,CACT,UAAU,CAAE,IACd,CAEA,mBAAK,CACH,IAAI,CAAE,IACR,CAGC,mBAAI,MAAO,CACV,gBAAgB,CAAE,OAAO,CACzB,SAAS,CAAE,MAAM,IAAI,CACtB,CAEA,yBAAW,CACV,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KACR,CAEA,0BAAY,CACX,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KACR,CAEA,yBAAW,CACV,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KACR,CAEA,wBAAU,CACT,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,WAAW,CAAE,GAAG,CAAC,IAAI,CACrB,MAAM,CAAE,OAAO,CACf,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,eAAe,CAAE,MAAM,CACvB,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CACxC,UAAU,CAAE,SAAS,CAAC,IACvB,CAEA,wBAAS,MAAO,CACf,SAAS,CAAE,MAAM,GAAG,CAAC,CACrB,gBAAgB,CAAE,OAEnB,CAGA,2BAAa,CACZ,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,eAAe,CAAE,MAAM,CACvB,GAAG,CAAE,IAAI,CACT,UAAU,CAAE,IACb,CAGA,2BAAa,CACZ,IAAI,CAAE,CAAC,CACP,MAAM,GAAG,CACT,OAAO,CAAE,IAAI,CACb,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,MAAM,CAClB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,gBAAgB,CAAE,OAAO,CACzB,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CACxC,CAEA,2BAAY,MAAO,CAClB,OAAO,CAAE,IAAI,CACb,YAAY,CAAE,OAAO,CACrB,UAAU,CAAE,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,KAAK,EAAE,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAAC,CAAC,GAAG,CAC3C,CAEA,wBAAU,CACT,KAAK,CAAE,KAAK,CACZ,SAAS,CAAE,OACZ,CAGA,MAAO,YAAY,KAAK,CAAE,CACzB,4BAAc,CACZ,cAAc,CAAE,MAAM,CACtB,GAAG,CAAE,IACP,CACF"}`
};
let cur_html$1 = 0;
const Numbers = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dc, $$unsubscribe_dc;
  let $$unsubscribe_lesson;
  let $$unsubscribe_llang;
  let $dc_state, $$unsubscribe_dc_state;
  let $$unsubscribe_dicts;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => value);
  $$unsubscribe_llang = subscribe(llang, (value) => value);
  $$unsubscribe_dc_state = subscribe(dc_state, (value) => $dc_state = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  moment.locale("nl-be");
  let tts;
  let share_button = false;
  let style_button_non_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: white;
		color: grey;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: #2196f3;
		color: #fff;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button = style_button_non_shared;
  let { data } = $$props;
  if (data.func) {
    onChangeClick();
  }
  let name = data.name;
  let userContent;
  let inputStyle;
  let result = "";
  let q, a;
  let div_input;
  function onChangeClick() {
    data = { question: q, answer: a, quiz: data.quiz };
    if (data.html) data.html = data.html[cur_html$1];
    data.quiz = data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    if ($dc) $dc.SendData({ lesson: data }, () => {
      console.log();
    });
  }
  onDestroy(() => {
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$7);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (data) {
        if (data.html) {
          style_button = style_button_shared;
        }
      }
    }
    {
      if ($dc_state) {
        switch ($dc_state) {
          case "open":
            share_button = true;
            break;
          case "closed":
            share_button = false;
            style_button = style_button_non_shared;
            break;
        }
      }
    }
    {
      if ($dc_state) {
        share_button = true;
      }
    }
    $$rendered = ` ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )}  ${share_button ? `${validate_component(IconButton, "IconButton").$$render(
      $$result,
      {
        class: "material-icons",
        style: style_button
      },
      {},
      {
        default: () => {
          return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiShareVariant, 0)}></path>`;
            }
          })}`;
        }
      }
    )}` : ``} <main class="svelte-1v8zq4b">${data.quiz == "listen" ? `<div><p class="svelte-1v8zq4b">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)}: `;
      }(__value);
    }(Translate("Послушай и напиши", "ru", $langs))}</p> <div class="button-group svelte-1v8zq4b">${`<button class="btn start-btn svelte-1v8zq4b">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)} `;
      }(__value);
    }(Translate("Старт", "ru", $langs))}</button>`}</div></div> <div class="input-group svelte-1v8zq4b">${name === "Nummers" ? `<div class="input-field svelte-1v8zq4b" contenteditable="true"${add_attribute("style", inputStyle, 0)}${add_attribute("this", div_input, 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent)}</div>` : `${name === "Tijd" ? `<div contenteditable="true" id="userTime" class="input-field svelte-1v8zq4b" placeholder="hh:mm"${add_attribute("this", div_input, 0)}>${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(userContent)}</div>` : `${name === "Alphabet" ? `<div contenteditable="true" id="userTime" class="input-field svelte-1v8zq4b"${add_attribute("this", div_input, 0)}>${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(userContent)}</div>` : ``}`}`} ${``}</div>` : `${data.quiz == "dialog.client" ? `${validate_component(Speak, "Speak").$$render($$result, { data }, {}, {})}` : ``}`} </main>`;
  } while (!$$settled);
  $$unsubscribe_dc();
  $$unsubscribe_lesson();
  $$unsubscribe_llang();
  $$unsubscribe_dc_state();
  $$unsubscribe_dicts();
  $$unsubscribe_langs();
  return $$rendered;
});
const css$6 = {
  code: "main.svelte-1ehj1p{max-width:50%;margin:0 auto;text-align:center;margin-top:40px;font-family:Arial, sans-serif}.button-group.svelte-1ehj1p{display:flex;justify-content:center;align-items:center;gap:10px;margin-top:20px}.btn.svelte-1ehj1p{padding:10px 20px;font-size:16px;border:none;border-radius:5px;color:white;background-color:#ff9800;cursor:pointer;transition:background-color 0.3s ease}.btn.svelte-1ehj1p:hover{background-color:#45a049}.input-group.svelte-1ehj1p{display:flex;align-items:center;justify-content:center;margin-top:20px}.input-field.svelte-1ehj1p{flex:1;max-width:300px;padding:10px;font-size:18px;border:1px solid #ccc;border-radius:4px;background-color:#f9f9f9;text-align:center;margin-right:10px}.check-btn.svelte-1ehj1p{background-color:#9c27b0;color:white}.hint-button.svelte-1ehj1p{display:inline-block;height:44px;width:44px;border:none;border-radius:50%;color:white;background-color:#2196f3;font-size:18px;cursor:pointer;transition:background-color 0.3s ease}.hint-button.svelte-1ehj1p:hover{background-color:#1e88e5}@media(max-width: 768px){.button-group.svelte-1ehj1p{flex-direction:column;gap:15px}}",
  map: '{"version":3,"file":"Time.svelte","sources":["Time.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy } from \\"svelte\\";\\nimport { Translate } from \\"../../../translate/Transloc\\";\\nimport Speak from \\"./Speak.svelte\\";\\nimport moment from \\"moment\\";\\nmoment.locale(\\"nl-be\\");\\nimport { DateTime } from \\"luxon\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport { mdiPagePreviousOutline, mdiArrowRight, mdiArrowLeft, mdiShareVariant, mdiShuffle } from \\"@mdi/js\\";\\nimport { NumberString } from \\"./Listen.numbers\\";\\nimport TTS from \\"../../../speech/tts/Tts.svelte\\";\\nlet tts;\\nimport { lesson, dc, dc_state, langs, llang, dicts } from \\"$lib/js/stores.js\\";\\nlet dict = $dicts;\\nlet share_mode = false;\\nlet share_button = false;\\nlet style_button_non_shared = `position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: white;\\n\\t\\tcolor: grey;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;`;\\nlet style_button_shared = `position: relative;\\n\\t\\tpadding: 10px;\\n\\t\\tfont-size: 1.5em;\\n\\t\\tbackground-color: #2196f3;\\n\\t\\tcolor: #fff;\\n\\t\\tborder: none;\\n\\t\\tborder-radius: 5px;\\n\\t\\tcursor: pointer;`;\\nlet style_button = style_button_non_shared;\\nexport let data;\\n$: if (data) {\\n  if (data.html) {\\n    style_button = style_button_shared;\\n    share_mode = true;\\n  }\\n}\\nif (data.func) {\\n  onChangeClick();\\n}\\n$: if ($dc_state) {\\n  switch ($dc_state) {\\n    case \\"open\\":\\n      share_button = true;\\n      break;\\n    case \\"closed\\":\\n      share_button = false;\\n      share_mode = false;\\n      style_button = style_button_non_shared;\\n      break;\\n  }\\n}\\n$: if ($dc_state) {\\n  share_button = true;\\n}\\nlet name = data.name;\\nlet generatedValue, generatedValueObj;\\nlet userTime = \\"\\";\\nlet userContent;\\nlet buttonName = \\"\\\\u0421\\\\u0442\\\\u0430\\\\u0440\\\\u0442\\";\\nlet isFirst = false;\\nlet inputStyle;\\nlet result = \\"\\";\\nlet isCorrect = null;\\nlet bottomAppBar;\\nlet change_button = false;\\nlet cur_html = 0;\\nlet q, a;\\nlet cnt = 0;\\nlet digit = 10;\\nlet div_input;\\nonMount(async () => {\\n});\\nasync function SendToPartner() {\\n  if (share_mode && $dc) {\\n    await $dc.SendData({\\n      lesson: { quiz: \\"dialog.client\\" }\\n    }, () => {\\n      console.log();\\n    });\\n  }\\n}\\nfunction convertToWords(num) {\\n  if (num < 10)\\n    return ones[num];\\n  if (num < 20)\\n    return teens[num - 10];\\n  const ten = Math.floor(num / 10);\\n  const rest = num % 10;\\n  return rest === 0 ? tens[ten] : ones[rest] + \\"en\\" + tens[ten];\\n}\\nfunction convertGroup(num, unit) {\\n  const hundred = Math.floor(num / 100);\\n  const rest = num % 100;\\n  let result2 = \\"\\";\\n  if (hundred > 0) {\\n    result2 += ones[hundred] + \\"honderd\\";\\n    if (rest > 0)\\n      result2 += \\"en\\";\\n  }\\n  if (rest > 0) {\\n    result2 += convertToWords(rest);\\n  }\\n  if (unit) {\\n    result2 += unit;\\n  }\\n  return result2;\\n  if (number === 0)\\n    return \\"nul\\";\\n  let unitIndex = 0;\\n  while (number > 0) {\\n    const group = number % 1e3;\\n    if (group > 0) {\\n      const groupResult = convertGroup(group, unitIndex === 1 ? \\"duizend\\" : \\"\\");\\n      result2 = groupResult + (result2 ? \\"en\\" : \\"\\") + result2;\\n    }\\n    number = Math.floor(number / 1e3);\\n    unitIndex++;\\n  }\\n  return result2.trim();\\n}\\nfunction Generate() {\\n  if (name === \\"Tijd\\") {\\n    generateTime();\\n  } else if (name === \\"Nummers\\") {\\n    generateNumber();\\n  } else if (name === \\"Alphabet\\") {\\n    generateAlphabet();\\n  }\\n}\\nfunction generateAlphabet() {\\n  throw new Error(\\"Function not implemented.\\");\\n}\\nfunction generateNumber() {\\n  buttonName = \\"\\\\u041F\\\\u043E\\\\u0432\\\\u0442\\\\u043E\\\\u0440\\\\u0438\\\\u0442\\\\u044C\\";\\n  isFirst = true;\\n  if (cnt % 10 === 0) {\\n    digit *= 10;\\n  }\\n  const random = Math.floor(Math.random() * digit) + digit / 10;\\n  if (random === generatedValue)\\n    return generateNumber();\\n  generatedValue = random;\\n  cnt++;\\n  result = \\"\\";\\n  isCorrect = null;\\n  speak(NumberString($llang, generatedValue));\\n  div_input.focus();\\n}\\nfunction generateTime() {\\n  isFirst = true;\\n  let hours = Math.floor(Math.random() * 24) + 1;\\n  if (hours >= 13)\\n    hours = parseInt(hours - 12);\\n  const minutes = Math.floor(Math.random() * 12) * 5;\\n  generatedValue = DateTime.local().set({ hours, minutes }).toLocaleString(DateTime.TIME_24_SIMPLE);\\n  generatedValueObj = { hours, minutes };\\n  speak(formatTime($llang, generatedValueObj));\\n  div_input.focus();\\n  cnt++;\\n}\\nfunction formatTime(lang, time) {\\n  const hours = time.hours;\\n  const minutes = time.minutes;\\n  switch (lang) {\\n    case \\"nl\\":\\n      if (minutes === 0) {\\n        return `${hours} uur`;\\n      } else if (minutes < 15) {\\n        return `${minutes} over ${hours}`;\\n      } else if (minutes === 15) {\\n        return `kwart over ${hours}`;\\n      } else if (minutes > 15 && minutes < 30) {\\n        return `${30 - minutes} voor half ${hours + 1}`;\\n      } else if (minutes === 30) {\\n        return `half ${hours === 1 ? \\"twee\\" : hours + 1}`;\\n      } else if (minutes > 30 && minutes < 45) {\\n        return `${minutes - 30} over half ${hours + 1}`;\\n      } else if (minutes === 45) {\\n        return `kwart voor ${hours === 1 ? \\"tien\\" : hours + 1}`;\\n      } else if (minutes > 45) {\\n        return `${60 - minutes} voor  ${hours + 1}`;\\n      } else {\\n        return `${minutes} minuten over ${hours}`;\\n      }\\n      break;\\n    case \\"en\\":\\n      if (minutes === 0) {\\n        return `${hours} o\'clock`;\\n      } else if (minutes < 15) {\\n        return `${minutes} past ${hours}`;\\n      } else if (minutes === 15) {\\n        return `quarter past ${hours}`;\\n      } else if (minutes < 30) {\\n        return `${30 - minutes} minutes past ${hours}`;\\n      } else if (minutes === 30) {\\n        return `half past ${hours}`;\\n      } else if (minutes < 45) {\\n        return `${minutes - 30} minutes to ${hours + 1}`;\\n      } else if (minutes === 45) {\\n        return `quarter to ${hours + 1}`;\\n      } else {\\n        return `${60 - minutes} minutes to ${hours + 1}`;\\n      }\\n      break;\\n    case \\"fr\\":\\n      if (minutes === 0) {\\n        return `${hours} heure${hours > 1 ? \\"s\\" : \\"\\"}`;\\n      } else if (minutes < 15) {\\n        return `${minutes} minute${minutes > 1 ? \\"s\\" : \\"\\"} apr\\\\xE8s ${hours} heure${hours > 1 ? \\"s\\" : \\"\\"}`;\\n      } else if (minutes === 15) {\\n        return `quart apr\\\\xE8s ${hours} heure${hours > 1 ? \\"s\\" : \\"\\"}`;\\n      } else if (minutes < 30) {\\n        return `${30 - minutes} minute${30 - minutes > 1 ? \\"s\\" : \\"\\"} avant la demi de ${hours + 1} heure`;\\n      } else if (minutes === 30) {\\n        return `demie apr\\\\xE8s ${hours} heure`;\\n      } else if (minutes < 45) {\\n        return `${minutes - 30} minute${minutes - 30 > 1 ? \\"s\\" : \\"\\"} apr\\\\xE8s la demi de ${hours + 1} heure`;\\n      } else if (minutes === 45) {\\n        return `quart avant ${hours + 1} heure`;\\n      } else {\\n        return `${60 - minutes} minute${60 - minutes > 1 ? \\"s\\" : \\"\\"} avant ${hours + 1} heure`;\\n      }\\n      break;\\n    case \\"de\\":\\n      if (minutes === 0) {\\n        return `${hours} Uhr`;\\n      } else if (minutes < 15) {\\n        return `${minutes} nach ${hours}`;\\n      } else if (minutes === 15) {\\n        return `Viertel nach ${hours}`;\\n      } else if (minutes > 15 && minutes < 30) {\\n        return `${30 - minutes} vor halb ${hours + 1}`;\\n      } else if (minutes === 30) {\\n        return `halb ${hours + 1}`;\\n      } else if (minutes > 30 && minutes < 45) {\\n        return `${minutes - 30} nach halb ${hours + 1}`;\\n      } else if (minutes === 45) {\\n        return `Viertel vor ${hours + 1}`;\\n      } else if (minutes > 45) {\\n        return `${60 - minutes} vor ${hours + 1}`;\\n      } else {\\n        return `${minutes} Minuten nach ${hours}`;\\n      }\\n    case \\"es\\":\\n      if (minutes === 0) {\\n        return `${hours === 1 ? \\"La una\\" : hours} en punto`;\\n      } else if (minutes === 15) {\\n        return `Son las ${hours} y cuarto`;\\n      } else if (minutes === 30) {\\n        return `Son las ${hours} y media`;\\n      } else if (minutes === 45) {\\n        return `Son las ${hours + 1} menos cuarto`;\\n      } else if (minutes < 30) {\\n        return `Son las ${hours} y ${minutes} minutos`;\\n      } else {\\n        return `Son las ${hours + 1} menos ${60 - minutes} minutos`;\\n      }\\n      break;\\n    case \\"it\\":\\n      if (minutes === 0) {\\n        return `${hours} ${hours === 1 ? \\"ora\\" : \\"ore\\"}`;\\n      } else if (minutes < 15) {\\n        return `${minutes} minuti dopo l\'ora ${hours}`;\\n      } else if (minutes === 15) {\\n        return `un quarto dopo l\'ora ${hours}`;\\n      } else if (minutes < 30) {\\n        return `${30 - minutes} minuti prima della mezz\'ora ${hours + 1}`;\\n      } else if (minutes === 30) {\\n        return `mezz\'ora ${hours + 1}`;\\n      } else if (minutes < 45) {\\n        return `${minutes - 30} minuti dopo la mezz\'ora ${hours + 1}`;\\n      } else if (minutes === 45) {\\n        return `un quarto prima dell\'ora ${hours + 1}`;\\n      } else {\\n        return `${60 - minutes} minuti prima dell\'ora ${hours + 1}`;\\n      }\\n      break;\\n  }\\n}\\nfunction checkInput() {\\n  userContent = userContent.replace(/&nbsp;/g, \\"\\").replace(/<\\\\/?[^>]+(>|$)/g, \\"\\");\\n  const trimmedUserContent = userContent.trim();\\n  isCorrect = trimmedUserContent === generatedValue.toString();\\n  if (isCorrect) {\\n    inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n    setTimeout(() => {\\n      userContent = \\"\\";\\n      Generate();\\n    }, 1e3);\\n  } else {\\n    let i = 0;\\n    inputStyle = \\"\\";\\n    userContent = \\"\\";\\n    result = \\"\\";\\n    while (i < generatedValue.length || i < trimmedUserContent.length) {\\n      if (!trimmedUserContent[i]) {\\n        result += `<span class=\\"empty_block\\" onchage=\\"onChangeUserContent\\" style=\\"display: inline-block; background-color:rgba(255, 240, 251, 0.9);border:1px solid rgba(255, 240, 251, 0.9); width:15px\\">&nbsp;</span>`;\\n      } else if (trimmedUserContent[i] === generatedValue[i]) {\\n        result += `<span class=\\"correct\\">${generatedValue[i]}</span>`;\\n      } else {\\n        result += `<span style=\\"color:red;  \\">${trimmedUserContent[i]}</span>`;\\n      }\\n      i++;\\n    }\\n    userContent = result;\\n    div_input.focus();\\n    repeat();\\n  }\\n}\\nfunction checkAnswer() {\\n  const parsedAnswer = parseInt(userAnswer, 10);\\n  isCorrect = !isNaN(parsedAnswer) && parsedAnswer === generatedValue;\\n  inputStyle = isCorrect ? \\"color: green;\\" : \\"color: red; \\";\\n  setTimeout(() => {\\n    generateNumber();\\n  }, 1500);\\n}\\nasync function speak(text) {\\n  tts.Speak_server($llang, text);\\n}\\nfunction repeat() {\\n  speak(formatTime($llang, generatedValueObj));\\n  div_input.focus();\\n}\\nfunction handleBackClick() {\\n  $lesson.data = { quiz: \\"\\" };\\n}\\nfunction onChangeClick() {\\n  data = { question: q, answer: a, quiz: data.quiz };\\n  if (data.html)\\n    data.html = data.html[cur_html];\\n  data.quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  let client_quiz = data.quiz === \\"dialog.client\\" ? \\"dialog\\" : \\"dialog.client\\";\\n  $dc?.SendData({ lesson: data }, () => {\\n    console.log();\\n  });\\n}\\nfunction handleUserInput(event) {\\n  const inputValue = event.target.innerHTML;\\n  if (!isNaN(inputValue)) {\\n    if (inputValue.length === 2 && event.data !== \\":\\") {\\n      event.target.innerHTML = inputValue + \\":\\";\\n    }\\n    if (inputValue.length > 4) {\\n      event.target.innerHTML = inputValue.slice(0, 4);\\n    }\\n    userContent = event.target.innerHTML;\\n    const range = document.createRange();\\n    const selection = window.getSelection();\\n    range.selectNodeContents(div_input);\\n    range.collapse(false);\\n    selection.removeAllRanges();\\n    selection.addRange(range);\\n  }\\n}\\nfunction showHint() {\\n  userContent = generatedValue.toString();\\n  setTimeout(() => {\\n    checkInput();\\n  }, 1e3);\\n}\\nfunction onShare() {\\n  share_mode = !share_mode;\\n  style_button = share_mode ? style_button_shared : style_button_non_shared;\\n}\\nonDestroy(() => {\\n});\\n<\/script>\\r\\n\\r\\n<!-- <link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/> -->\\r\\n\\r\\n<TTS bind:this={tts}></TTS>\\r\\n<!-- <RV bind:this={voice}></RV> -->\\r\\n\\r\\n{#if share_button}\\r\\n  <IconButton class=\\"material-icons\\" on:click={onShare} style={style_button}>\\r\\n    <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n      <path fill=\\"currentColor\\" d={mdiShareVariant} /></Icon\\r\\n    >\\r\\n  </IconButton>\\r\\n{/if}\\r\\n<main>\\r\\n  {#if data.quiz == \'listen\'}\\r\\n\\r\\n      <p>{#await Translate(\'Послушай и напиши\',\'ru\', $langs) then data} {data}: {/await}</p>\\r\\n\\r\\n\\r\\n    <div class=\\"button-group\\">\\r\\n      {#if !isFirst}\\r\\n        <button on:click={Generate} class=\\"btn action-btn\\">{#await Translate(\'Старт\',\'ru\', $langs) then data}  {data} {/await}</button>\\r\\n      {:else}\\r\\n        <button on:click={repeat} class=\\"btn repeat-btn\\">{#await Translate(\'Повторить\',\'ru\', $langs) then data} {data} {/await}</button>\\r\\n        <button on:click={checkInput} class=\\"btn check-btn\\">{#await Translate(\'Проверить\',\'ru\', $langs) then data} {data} {/await}</button>\\r\\n      {/if}\\r\\n    </div>\\r\\n\\r\\n    <div class=\\"input-group\\">\\r\\n      {#if name === \'Nummers\'}\\r\\n        <div\\r\\n          class=\\"input-field\\"\\r\\n          contenteditable=\\"true\\"\\r\\n          style={inputStyle}\\r\\n          bind:this={div_input}\\r\\n          bind:innerHTML={userContent}\\r\\n        >\\r\\n          {@html result}\\r\\n        </div>\\r\\n      {:else if name === \'Tijd\'}\\r\\n        <div\\r\\n          contenteditable=\\"true\\"\\r\\n          id=\\"userTime\\"\\r\\n          class=\\"input-field\\"\\r\\n          placeholder=\\"hh:mm\\"\\r\\n          on:input={handleUserInput}\\r\\n          bind:this={div_input}\\r\\n          bind:innerHTML={userContent}\\r\\n        />\\r\\n      {:else if name === \'Alphabet\'}\\r\\n        <div\\r\\n          contenteditable=\\"true\\"\\r\\n          id=\\"userTime\\"\\r\\n          class=\\"input-field\\"\\r\\n          on:input={handleUserInput}\\r\\n          bind:this={div_input}\\r\\n          bind:innerHTML={userContent}\\r\\n        />\\r\\n      {/if}\\r\\n      {#if isFirst}\\r\\n        <button on:click={showHint} class=\\"hint-button\\">\\r\\n          <span class=\\"material-symbols-outlined\\"> ? </span>\\r\\n        </button>\\r\\n      {/if}\\r\\n    </div>\\r\\n  {:else if data.quiz == \'dialog.client\'}\\r\\n    <Speak {data} />\\r\\n  {/if}\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    max-width: 50%;\\r\\n    margin: 0 auto;\\r\\n    text-align: center;\\r\\n    margin-top: 40px;\\r\\n    font-family: Arial, sans-serif;\\r\\n  }\\r\\n\\r\\n  .quiz-header p {\\r\\n    font-size: 20px;\\r\\n    margin-bottom: 15px;\\r\\n  }\\r\\n\\r\\n  /* Flexbox для кнопок */\\r\\n  .button-group {\\r\\n    display: flex;\\r\\n    justify-content: center;\\r\\n    align-items: center;\\r\\n    gap: 10px; /* Отступ между кнопками */\\r\\n    margin-top: 20px;\\r\\n  }\\r\\n\\r\\n  .btn {\\r\\n    padding: 10px 20px;\\r\\n    font-size: 16px;\\r\\n    border: none;\\r\\n    border-radius: 5px;\\r\\n    color: white;\\r\\n    background-color: #ff9800;\\r\\n    cursor: pointer;\\r\\n    transition: background-color 0.3s ease;\\r\\n  }\\r\\n\\r\\n  .btn:hover {\\r\\n    background-color: #45a049;\\r\\n  }\\r\\n\\r\\n  .input-group {\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n    justify-content: center;\\r\\n    margin-top: 20px;\\r\\n  }\\r\\n\\r\\n  .input-field {\\r\\n    flex: 1;\\r\\n    max-width: 300px;\\r\\n    padding: 10px;\\r\\n    font-size: 18px;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 4px;\\r\\n    background-color: #f9f9f9;\\r\\n    text-align: center;\\r\\n    margin-right: 10px;\\r\\n  }\\r\\n\\r\\n\\r\\n  .check-btn {\\r\\n    background-color: #9c27b0;\\r\\n    color: white;\\r\\n   }\\r\\n\\r\\n  .hint-button {\\r\\n    display: inline-block;\\r\\n    height: 44px;\\r\\n    width: 44px;\\r\\n    border: none;\\r\\n    border-radius: 50%;\\r\\n    color: white;\\r\\n    background-color: #2196f3;\\r\\n    font-size: 18px;\\r\\n    cursor: pointer;\\r\\n    transition: background-color 0.3s ease;\\r\\n  }\\r\\n\\r\\n  .hint-button:hover {\\r\\n    background-color: #1e88e5;\\r\\n  }\\r\\n\\r\\n   /* Адаптивность */\\r\\n   @media (max-width: 768px) {\\r\\n    .button-group {\\r\\n      flex-direction: column; /* Выравниваем кнопки вертикально */\\r\\n      gap: 15px; /* Увеличиваем расстояние между кнопками */\\r\\n    }\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA6bE,kBAAK,CACH,SAAS,CAAE,GAAG,CACd,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,IAAI,CAChB,WAAW,CAAE,KAAK,CAAC,CAAC,UACtB,CAQA,2BAAc,CACZ,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,GAAG,CAAE,IAAI,CACT,UAAU,CAAE,IACd,CAEA,kBAAK,CACH,OAAO,CAAE,IAAI,CAAC,IAAI,CAClB,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,MAAM,CAAE,OAAO,CACf,UAAU,CAAE,gBAAgB,CAAC,IAAI,CAAC,IACpC,CAEA,kBAAI,MAAO,CACT,gBAAgB,CAAE,OACpB,CAEA,0BAAa,CACX,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,eAAe,CAAE,MAAM,CACvB,UAAU,CAAE,IACd,CAEA,0BAAa,CACX,IAAI,CAAE,CAAC,CACP,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,IAAI,CACb,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,gBAAgB,CAAE,OAAO,CACzB,UAAU,CAAE,MAAM,CAClB,YAAY,CAAE,IAChB,CAGA,wBAAW,CACT,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,KACR,CAED,0BAAa,CACX,OAAO,CAAE,YAAY,CACrB,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,OAAO,CACf,UAAU,CAAE,gBAAgB,CAAC,IAAI,CAAC,IACpC,CAEA,0BAAY,MAAO,CACjB,gBAAgB,CAAE,OACpB,CAGC,MAAO,YAAY,KAAK,CAAE,CACzB,2BAAc,CACZ,cAAc,CAAE,MAAM,CACtB,GAAG,CAAE,IACP,CACF"}'
};
let cur_html = 0;
const Time = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dc, $$unsubscribe_dc;
  let $$unsubscribe_lesson;
  let $$unsubscribe_llang;
  let $dc_state, $$unsubscribe_dc_state;
  let $$unsubscribe_dicts;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => value);
  $$unsubscribe_llang = subscribe(llang, (value) => value);
  $$unsubscribe_dc_state = subscribe(dc_state, (value) => $dc_state = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  moment.locale("nl-be");
  let tts;
  let share_button = false;
  let style_button_non_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: white;
		color: grey;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button_shared = `position: relative;
		padding: 10px;
		font-size: 1.5em;
		background-color: #2196f3;
		color: #fff;
		border: none;
		border-radius: 5px;
		cursor: pointer;`;
  let style_button = style_button_non_shared;
  let { data } = $$props;
  if (data.func) {
    onChangeClick();
  }
  let name = data.name;
  let userContent;
  let inputStyle;
  let result = "";
  let q, a;
  let div_input;
  function onChangeClick() {
    data = { question: q, answer: a, quiz: data.quiz };
    if (data.html) data.html = data.html[cur_html];
    data.quiz = data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    data.quiz === "dialog.client" ? "dialog" : "dialog.client";
    $dc?.SendData({ lesson: data }, () => {
      console.log();
    });
  }
  onDestroy(() => {
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css$6);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if (data) {
        if (data.html) {
          style_button = style_button_shared;
        }
      }
    }
    {
      if ($dc_state) {
        switch ($dc_state) {
          case "open":
            share_button = true;
            break;
          case "closed":
            share_button = false;
            style_button = style_button_non_shared;
            break;
        }
      }
    }
    {
      if ($dc_state) {
        share_button = true;
      }
    }
    $$rendered = ` ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )}  ${share_button ? `${validate_component(IconButton, "IconButton").$$render(
      $$result,
      {
        class: "material-icons",
        style: style_button
      },
      {},
      {
        default: () => {
          return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiShareVariant, 0)}></path>`;
            }
          })}`;
        }
      }
    )}` : ``} <main class="svelte-1ehj1p">${data.quiz == "listen" ? `<p>${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)}: `;
      }(__value);
    }(Translate("Послушай и напиши", "ru", $langs))}</p> <div class="button-group svelte-1ehj1p">${`<button class="btn action-btn svelte-1ehj1p">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` ${escape(data2)} `;
      }(__value);
    }(Translate("Старт", "ru", $langs))}</button>`}</div> <div class="input-group svelte-1ehj1p">${name === "Nummers" ? `<div class="input-field svelte-1ehj1p" contenteditable="true"${add_attribute("style", inputStyle, 0)}${add_attribute("this", div_input, 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent)}</div>` : `${name === "Tijd" ? `<div contenteditable="true" id="userTime" class="input-field svelte-1ehj1p" placeholder="hh:mm"${add_attribute("this", div_input, 0)}>${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(userContent)}</div>` : `${name === "Alphabet" ? `<div contenteditable="true" id="userTime" class="input-field svelte-1ehj1p"${add_attribute("this", div_input, 0)}>${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(userContent)}</div>` : ``}`}`} ${``}</div>` : `${data.quiz == "dialog.client" ? `${validate_component(Speak, "Speak").$$render($$result, { data }, {}, {})}` : ``}`} </main>`;
  } while (!$$settled);
  $$unsubscribe_dc();
  $$unsubscribe_lesson();
  $$unsubscribe_llang();
  $$unsubscribe_dc_state();
  $$unsubscribe_dicts();
  $$unsubscribe_langs();
  return $$rendered;
});
const css$5 = {
  code: ".top-app-bar-container.svelte-zekd1d.svelte-zekd1d{position:relative;top:0px;height:60px}.div_word.svelte-zekd1d.svelte-zekd1d{position:relative;display:inline-grid;transition:transform 0.3s ease-in-out;margin:0 auto;transition:transform 0.5s}.title.svelte-zekd1d.svelte-zekd1d{font-size:medium;color:lightgrey;position:relative;text-align:center;margin-top:10px}.hint_button.svelte-zekd1d.svelte-zekd1d{display:inline-block;border:solid 0.1em #80777791;border-radius:5px;text-align:center;width:auto;padding-left:8px;margin:5px;color:#2196e6;background-color:transparent}.word.svelte-zekd1d.svelte-zekd1d{font-size:0.8em;flex-direction:column;align-items:center;margin-top:10px;text-align:center;line-height:17px}p.svelte-zekd1d.svelte-zekd1d{position:relative;transition:opacity 0.5s ease;text-align:center;font-size:xx-large;margin:0}.speaker-button.svelte-zekd1d.svelte-zekd1d{display:inline-flex;position:relative;float:right;margin-right:10px;font-size:large;border-radius:25px;transform:translate(50%, 0%);font-size:large;z-index:2 !important}.input-container.svelte-zekd1d.svelte-zekd1d{display:inline-block;font-size:large;position:relative;color:#2196f3;width:95vw;margin:10px auto;text-align:center}.words_div.svelte-zekd1d.svelte-zekd1d{position:relative;text-align:center;overflow-y:hidden;height:70vh}.input.svelte-zekd1d.svelte-zekd1d{position:relative;height:18px;display:inline-table;outline:none;border:1px solid lightblue;border-radius:4px;background:beige;text-align:center;padding-left:5px;padding-right:5px}.input.svelte-zekd1d.svelte-zekd1d:focus{outline:none}.material-symbols-outlined.svelte-zekd1d.svelte-zekd1d{font-size:15px;scale:1.5;font-variation-settings:'FILL' 0,\r\n      'wght' 400,\r\n      'GRAD' 0,\r\n      'opsz' 24}.counter.svelte-zekd1d.svelte-zekd1d{background-color:#f0f0f0;padding:0px;border-radius:25px;width:30px;height:30px;top:-10px;left:-6px;box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);text-align:center}.counter.svelte-zekd1d p.svelte-zekd1d{margin:0;font-size:15px;color:#333}.counter.svelte-zekd1d span.svelte-zekd1d{font-weight:700;font-size:15px;color:#ff5733}@media screen and (min-width: 768px){}",
  map: `{"version":3,"file":"Word.svelte","sources":["Word.svelte"],"sourcesContent":["<script>\\r\\n  // @ts-nocheck\\r\\n\\r\\n  import { onMount, onDestroy, getContext } from 'svelte';\\r\\n  import TopAppBar, { Row, Title, Section } from '@smui/top-app-bar';\\r\\n  import Badge from '@smui-extra/badge';\\r\\n  import Accordion, { Panel, Header, Content } from '@smui-extra/accordion';\\r\\n  import IconButton, { Icon } from '@smui/icon-button';\\r\\n  import {\\r\\n    mdiArrowRight,\\r\\n    mdiArrowLeft,\\r\\n    mdiShuffle,\\r\\n    mdiPagePreviousOutline,\\r\\n    mdiChevronDownCircleOutline,\\r\\n    mdiHelp,\\r\\n    mdiTextBoxCheckOutline,\\r\\n    mdiPlay,\\r\\n    mdiEarHearing,\\r\\n    mdiTranslateVariant,\\r\\n    mdiTranslate,\\r\\n    mdiTranslateOff\\r\\n  } from '@mdi/js';\\r\\n\\r\\n  // import words from './80.json';\\r\\n  import { Translate } from '../../../translate/Transloc';\\r\\n  // translate.engine = 'google';\\r\\n  // translate.from = $llang;\\r\\n\\r\\n  import {\\r\\n    llang,\\r\\n    langs,\\r\\n    dicts,\\r\\n    lesson,\\r\\n    showBottomAppBar,\\r\\n    dc,\\r\\n\\r\\n  } from '$lib/js/stores.js';\\r\\n\\r\\n  import langs_list from '$lib/dict/learn_langs_list.json';\\r\\n\\r\\n  let lang_menu = false;\\r\\n\\r\\n  let isPlayAuto = false;\\r\\n  let playAutoColor = 'currentColor';\\r\\n\\r\\n  $: if (isPlayAuto) {\\r\\n    playAutoColor = 'green';\\r\\n  } else {\\r\\n    playAutoColor = 'currentColor';\\r\\n  }\\r\\n\\r\\n  import ISO6391 from 'iso-google-locales';\\r\\n\\r\\n  import CircularProgress from '@smui/circular-progress';\\r\\n\\r\\n  import TTS from '../../../speech/tts/Tts.svelte';\\r\\n  let tts;\\r\\n\\r\\n  let dict = $dicts;\\r\\n\\r\\n  export let data;\\r\\n\\r\\n  const abonent = getContext('abonent');\\r\\n\\r\\n  let words = [],\\r\\n    word,\\r\\n    example,\\r\\n    example_lang = $langs;\\r\\n  let translate = true;\\r\\n  let shuffleWords;\\r\\n  let hints;\\r\\n  let currentWordIndex = 0;\\r\\n  let currentWord;\\r\\n  let hl_words = data.highlight ? data.highlight.split(',') : [];\\r\\n  let _llang = $llang;\\r\\n  let value = $llang;\\r\\n  let arrayOfArrays;\\r\\n  let userContent = [];\\r\\n  let div_input = [];\\r\\n  let result = '&nbsp;';\\r\\n  let resultElement;\\r\\n  let hintIndex = 0;\\r\\n  let errorIndex = 0;\\r\\n  let showCheckMark = false;\\r\\n  let showNextButton = false;\\r\\n  let resultElementWidth = [];\\r\\n  let showSpeakerButton = false;\\r\\n  let focus_pos = 0;\\r\\n  let speak_text = '';\\r\\n\\r\\n  // defineWordsArray();\\r\\n\\r\\n  let counter = 0;\\r\\n  let isVisible = false;\\r\\n\\r\\n  let names = data.name?.split(',');\\r\\n\\r\\n  // Создаем массив промисов для каждого запроса\\r\\n\\r\\n  fetch(\\r\\n    \`./lesson?words=theme&theme=\${data.theme}&name=\${data.name}&owner=\${abonent}&level=\${data.level}\`\\r\\n  )\\r\\n    .then((response) => response.json())\\r\\n    .then((data) => {\\r\\n      words = data.data.data;\\r\\n      if (!words[0]) return;\\r\\n\\r\\n      currentWord = words[currentWordIndex];\\r\\n      makeExample();\\r\\n    })\\r\\n    .catch((error) => {\\r\\n      console.log(error);\\r\\n      return [];\\r\\n    });\\r\\n\\r\\n  $: if ($langs) {\\r\\n    example_lang = $langs;\\r\\n    makeExample();\\r\\n  }\\r\\n\\r\\n  let topAppBar;\\r\\n  let sentence_span;\\r\\n\\r\\n  export function extractWords(text) {\\r\\n    // Регулярное выражение для поиска слов в угловых скобках\\r\\n    const regex = /<<(.*?)>>/g;\\r\\n    // Массив для хранения найденных слов\\r\\n    let result = [];\\r\\n    let match;\\r\\n\\r\\n    // Поиск всех совпадений и добавление их в массив\\r\\n    while ((match = regex.exec(text)) !== null) {\\r\\n      result.push(match[1]);\\r\\n    }\\r\\n\\r\\n    return result;\\r\\n  }\\r\\n\\r\\n  function similarity(s1, s2) {\\r\\n    let longer = s1;\\r\\n    let shorter = s2;\\r\\n    if (s1.length < s2.length) {\\r\\n      longer = s2;\\r\\n      shorter = s1;\\r\\n    }\\r\\n    const longerLength = longer.length;\\r\\n    if (longerLength === 0) {\\r\\n      return 1.0;\\r\\n    }\\r\\n    return (\\r\\n      (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength)\\r\\n    );\\r\\n  }\\r\\n\\r\\n  function editDistance(s1, s2) {\\r\\n    s1 = s1.toLowerCase();\\r\\n    s2 = s2.toLowerCase();\\r\\n\\r\\n    const costs = [];\\r\\n    for (let i = 0; i <= s1.length; i++) {\\r\\n      let lastValue = i;\\r\\n      for (let j = 0; j <= s2.length; j++) {\\r\\n        if (i === 0) costs[j] = j;\\r\\n        else {\\r\\n          if (j > 0) {\\r\\n            let newValue = costs[j - 1];\\r\\n            if (s1.charAt(i - 1) !== s2.charAt(j - 1))\\r\\n              newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;\\r\\n            costs[j - 1] = lastValue;\\r\\n            lastValue = newValue;\\r\\n          }\\r\\n        }\\r\\n      }\\r\\n      if (i > 0) costs[s2.length] = lastValue;\\r\\n    }\\r\\n    return costs[s2.length];\\r\\n  }\\r\\n\\r\\n  function replaceWordWithInput(text, targetWord) {\\r\\n    const threshold = 0.8; // 90% порог\\r\\n\\r\\n    return text.replace(\\r\\n      /<<([^>]*)>>/g,\\r\\n      \`<span  value=\\"$1\\" class=\\"sentence_span\\" style=\\"position: relative;width:20px;  left: 0px;\\" ></span>\`\\r\\n    );\\r\\n  }\\r\\n\\r\\n  function makeExample() {\\r\\n    \\r\\n    if (!currentWord) return;\\r\\n\\r\\n    return new Promise(async (resolve, reject) => {\\r\\n\\r\\n      // if (currentWord?.example[example_lang]) {\\r\\n      //   example = await currentWord.example[example_lang];\\r\\n      // } else if (currentWord.example[$llang]) {\\r\\n      //   example = await Translate(currentWord.example[$llang], $llang, $langs);\\r\\n      // }\\r\\n\\r\\n      // currentWord.example[$langs] = example;\\r\\n      example = currentWord.example[$llang];\\r\\n\\r\\n      const regex = /(<<\\\\w+>>)\\\\s+(<<\\\\w+>>)/;\\r\\n      const match = currentWord?.example[$llang]\\r\\n        ? currentWord?.example[$llang].match(regex)\\r\\n        : '';\\r\\n      let original = '';\\r\\n      if (match) {\\r\\n        original = \`\${match[0]} \${match[1]}\`;\\r\\n      }\\r\\n      // else original = \`\${currentWord.original}\`;\\r\\n\\r\\n      resultElement = replaceWordWithInput(\\r\\n        (speak_text = currentWord?.example[$llang]\\r\\n          ? currentWord?.example[$llang]\\r\\n          : (currentWord.example[$llang] = await Translate(\\r\\n              currentWord.example['ru'],\\r\\n              'ru',\\r\\n              $llang\\r\\n            ))),\\r\\n        \`\${original}\`\\r\\n      );\\r\\n\\r\\n      if (example.includes('<<') && example.includes('>>')) {\\r\\n        example = example?.replace(\\r\\n          /<<([^<>]+)>>/gu,\\r\\n          !data.level.includes('C1')\\r\\n            ? '<span style=\\"color:green\\" ><b>$1</b></span>'\\r\\n            : '$1'\\r\\n        );\\r\\n      } else if (example.includes('\\"')) {\\r\\n        example = example?.replace(\\r\\n          /\\"([^\\"]+)\\"/gu,\\r\\n          !data.level.includes('C1')\\r\\n            ? '<span style=\\"color:green\\" ><b>$1</b></span>'\\r\\n            : '$1'\\r\\n        );\\r\\n      }\\r\\n\\r\\n      setTimeout(() => {\\r\\n        const wAr = extractWords(currentWord?.example[$llang]);\\r\\n        const spanElements = document.querySelectorAll('.sentence_span');\\r\\n        spanElements.forEach((spanElement, i) => {\\r\\n          if (div_input) div_input[i].style.display = '';\\r\\n          spanElement.appendChild(div_input[i]); // Используем cloneNode, чтобы не удалить div_input из DOM\\r\\n          // spanElement.style.width = \\"50px\\";\\r\\n          resultElementWidth[i] = getTextWidth(wAr[i], '20px Arial');\\r\\n        });\\r\\n      }, 0);\\r\\n\\r\\n      function getSubArray(arr, index) {\\r\\n        const totalElements = 10;\\r\\n        const halfRange = Math.floor(totalElements / 2);\\r\\n\\r\\n        let startIndex = index - halfRange;\\r\\n        let endIndex = index + halfRange;\\r\\n\\r\\n        // Корректировка начала массива, если оно меньше 0\\r\\n        if (startIndex < 0) {\\r\\n          endIndex += Math.abs(startIndex);\\r\\n          startIndex = 0;\\r\\n        }\\r\\n\\r\\n        // Корректировка конца массива, если он больше длины массива\\r\\n        if (endIndex >= arr.length) {\\r\\n          startIndex -= endIndex - arr.length + 1;\\r\\n          endIndex = arr.length - 1;\\r\\n        }\\r\\n\\r\\n        // Убедиться, что начало не ушло ниже нуля после корректировки конца\\r\\n        startIndex = Math.max(startIndex, 0);\\r\\n\\r\\n        return arr.slice(startIndex, endIndex + 1); // Включить элемент с endIndex\\r\\n      }\\r\\n\\r\\n      hints = getSubArray([...words], currentWordIndex);\\r\\n      shuffle(hints);\\r\\n\\r\\n      resolve();\\r\\n\\r\\n      // Устанавливаем фокус в конец строки\\r\\n      // setFocus();\\r\\n    });\\r\\n  }\\r\\n\\r\\n  function getTextWidth(text, font) {\\r\\n    // Создаем элемент canvas\\r\\n    const canvas = document.createElement('canvas');\\r\\n    const context = canvas.getContext('2d');\\r\\n\\r\\n    // Устанавливаем шрифт\\r\\n    context.font = font;\\r\\n\\r\\n    // Измеряем длину текста\\r\\n    const metrics = context.measureText(text);\\r\\n    return metrics.width + 5;\\r\\n  }\\r\\n\\r\\n  function OnClickHint(word) {\\r\\n    div_input.forEach((di) => {\\r\\n      di.style.color = '';\\r\\n    });\\r\\n    // word=word.split(' '); \\r\\n    const span_cnt = countWordOccurrences(resultElement, '<span');\\r\\n    function extractSpans(htmlString) {\\r\\n      // Создаем новый DOMParser\\r\\n      const parser = new DOMParser();\\r\\n      // Парсим HTML-строку в документ\\r\\n      const doc = parser.parseFromString(htmlString, 'text/html');\\r\\n      // Находим все элементы <span> в документе\\r\\n      const spans = doc.querySelectorAll('span');\\r\\n      // Преобразуем NodeList в массив\\r\\n      return Array.from(spans);\\r\\n    }\\r\\n\\r\\n    const arSpan = extractSpans(resultElement);\\r\\n    const words = arSpan.length > 1 ? arSpan.map((span)=>{\\r\\n      return span.getAttribute('value');\\r\\n    }): [word];\\r\\n\\r\\n    div_input[0].style.width = '';\\r\\n    div_input[1].style.width = '';\\r\\n\\r\\n\\r\\n    userContent.forEach((uc, i) => {\\r\\n      if (word.includes(words[i])) {\\r\\n        userContent[i] = words[i];\\r\\n      } else {\\r\\n        userContent[i] =  '';\\r\\n      }\\r\\n    });\\r\\n\\r\\n    checkInput();\\r\\n  }\\r\\n\\r\\n  onMount(async () => {\\r\\n     window.scrollTo({ top: 0, behavior: 'smooth' });\\r\\n    setTimeout(() => {\\r\\n      //  $showBottomAppBar = false;//test\\r\\n    }, 3000);\\r\\n  });\\r\\n\\r\\n  function handleBackClick() {\\r\\n    $lesson.data = { quiz: '' }; // При клике на \\"Back\\" показываем компонент Lesson\\r\\n  }\\r\\n\\r\\n  function shuffle(array) {\\r\\n    for (let i = array.length - 1; i > 0; i--) {\\r\\n      const j = Math.floor(Math.random() * (i + 1));\\r\\n      [array[i], array[j]] = [array[j], array[i]];\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function onShuffleWords(ev) {\\r\\n    shuffle(words);\\r\\n    currentWordIndex = 0;\\r\\n    currentWord = words[currentWordIndex];\\r\\n    makeExample();\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    result = '&nbsp;';\\r\\n  }\\r\\n\\r\\n  function jumpNext10() {\\r\\n    const nextIndex = (parseInt(currentWordIndex / 10) + 1) * 10;\\r\\n    currentWordIndex = nextIndex;\\r\\n    currentWord = words[currentWordIndex];\\r\\n    makeExample();\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    hintIndex = 0;\\r\\n    result = '';\\r\\n    showCheckMark = false;\\r\\n    showSpeakerButton = false;\\r\\n  }\\r\\n\\r\\n  function defineWordsArray() {\\r\\n    const originalArray = words;\\r\\n\\r\\n    // Определение длины массива\\r\\n    const arrayLength = originalArray.length;\\r\\n\\r\\n    // Определение количества подмассивов\\r\\n    const chunkSize = 10;\\r\\n    const numberOfChunks = Math.ceil(arrayLength / chunkSize);\\r\\n\\r\\n    // Разбиваем массив на подмассивы по 10 элементов\\r\\n    arrayOfArrays = [];\\r\\n\\r\\n    for (let i = 0; i < numberOfChunks; i++) {\\r\\n      const start = i * chunkSize;\\r\\n      const end = (i + 1) * chunkSize;\\r\\n      const chunk = originalArray.slice(start, end);\\r\\n      arrayOfArrays.push(chunk);\\r\\n    }\\r\\n\\r\\n    // console.log(arrayOfArrays);\\r\\n  }\\r\\n\\r\\n  function setFocus() {\\r\\n    setTimeout(() => {\\r\\n      const range = document.createRange();\\r\\n      const selection = window.getSelection();\\r\\n      range.selectNodeContents(div_input[0]);\\r\\n      range.collapse(false);\\r\\n      selection.removeAllRanges();\\r\\n      selection.addRange(range);\\r\\n    }, 100);\\r\\n  }\\r\\n\\r\\n  function checkInput() {\\r\\n    if (userContent.length < 1 || !userContent[0].replace(/&nbsp;/g, ''))\\r\\n      return;\\r\\n\\r\\n    let thisErrorIndex = 0;\\r\\n\\r\\n    const targetWords = extractWords(currentWord.example[$llang]);\\r\\n\\r\\n    let correctCount = 0;\\r\\n    result = '';\\r\\n\\r\\n    userContent.forEach((userInput, i) => {\\r\\n      // userContent[i] = '';\\r\\n      if (!userInput) userInput = userContent[0];\\r\\n      userInput = userInput\\r\\n        .replace(/&nbsp;/g, '')\\r\\n        .replace(/<\\\\/?![^>]+(>|$)/g, '')\\r\\n        .trim();\\r\\n\\r\\n      if (targetWords[i] && userInput)\\r\\n        if (\\r\\n          userInput?.toLowerCase() ===\\r\\n          targetWords[i].toLowerCase().replace('_', ' ')\\r\\n        ) {\\r\\n          // result[i] = \`<span class=\\"correct\\">\${targetWords[i]}</span>\`;\\r\\n          if (div_input[i]) div_input[i].style.color = 'green';\\r\\n          correctCount++;\\r\\n        } else {\\r\\n          if (div_input[i]) div_input[i].style.color = 'red';\\r\\n          thisErrorIndex++;\\r\\n          errorIndex++;\\r\\n        }\\r\\n    });\\r\\n\\r\\n    const addClone = function () {\\r\\n      const currentWordClone = JSON.parse(JSON.stringify(currentWord));\\r\\n\\r\\n      if (currentWordIndex + 10 < words.length) {\\r\\n        words.splice(currentWordIndex + 10, 0, currentWordClone);\\r\\n      } else {\\r\\n        if (currentWordIndex + words.length / 2 < words.length)\\r\\n          words.splice(\\r\\n            currentWordIndex + words.length / 2,\\r\\n            0,\\r\\n            currentWordClone\\r\\n          );\\r\\n        else words.push(currentWordClone);\\r\\n      }\\r\\n\\r\\n      words = words;\\r\\n    };\\r\\n\\r\\n    // console.log(targetWords.length)\\r\\n\\r\\n    if (hintIndex > 0 || (errorIndex > 0 && thisErrorIndex < 1)) {\\r\\n      addClone();\\r\\n    }\\r\\n\\r\\n    if (thisErrorIndex < 1) {\\r\\n      showCheckMark = true; // Показываем галочку\\r\\n      showNextButton = true;\\r\\n      speak(speak_text);\\r\\n      currentWordIndex = currentWordIndex + 1;\\r\\n      hintIndex = 0;\\r\\n      errorIndex = 0;\\r\\n    }\\r\\n\\r\\n    showCheckMark = false;\\r\\n    focus_pos = 0;\\r\\n    setFocus();\\r\\n  }\\r\\n\\r\\n  function onChangeUserContent(ev) {\\r\\n    let ar = document.getElementsByClassName('empty_block');\\r\\n    if (ar.length > 0) {\\r\\n      // console.log(ar.length);\\r\\n      ar[0].remove();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function showHint() {\\r\\n    const words = extractWords(currentWord.example[$llang]).join(' ');\\r\\n\\r\\n    let i = 0,\\r\\n      w = 0;\\r\\n\\r\\n    if (hintIndex == 0) {\\r\\n      userContent[0] = '&nbsp;';\\r\\n      userContent[1] = '&nbsp;';\\r\\n      div_input[0].style.color = '#2196f3';\\r\\n      div_input[1].style.color = '#2196f3';\\r\\n      // div_input[0].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n      // div_input[1].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n    }\\r\\n\\r\\n    for (let char of words) {\\r\\n      // word = word.replace(/[.,\\\\/#!?$%\\\\^&\\\\*;:{}=_\`~()]/g, '');\\r\\n\\r\\n      if (char == ' ' && div_input[1].style.display !== 'none') {\\r\\n        w++;\\r\\n        //  div_input[1].style.display = 'inline-table'\\r\\n        if (userContent[w] === '&nbsp;') userContent[w] = '';\\r\\n        continue;\\r\\n      }\\r\\n\\r\\n      if (i === hintIndex) {\\r\\n        userContent[w] += char;\\r\\n\\r\\n        result = ''; // Очистим результат при каждой новой подсказке\\r\\n        showSpeakerButton = true; // Устанавливаем видимость кнопки\\r\\n        setFocus();\\r\\n\\r\\n        hintIndex++;\\r\\n        break;\\r\\n      }\\r\\n\\r\\n      i++;\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function showHintAuto() {\\r\\n    const words = extractWords(currentWord.example[$llang]).join(' ');\\r\\n\\r\\n    if (hintIndex == 0) {\\r\\n      userContent[0] = '&nbsp;';\\r\\n      userContent[1] = '&nbsp;';\\r\\n\\r\\n      div_input[0].style.color = '#2196f3';\\r\\n      div_input[1].style.color = '#2196f3';\\r\\n      div_input[0].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n      div_input[1].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n    }\\r\\n\\r\\n    const splited = words.split(' ');\\r\\n\\r\\n    if (div_input[1] && div_input[1].style.display === '')\\r\\n      [userContent[0], userContent[1]] = splited;\\r\\n    else userContent[0] = words;\\r\\n  }\\r\\n\\r\\n  async function nextWord() {\\r\\n    if (currentWordIndex >= words.length) currentWordIndex = 0;\\r\\n    example_lang = $langs;\\r\\n    currentWord = words[currentWordIndex];\\r\\n    await makeExample();\\r\\n\\r\\n    hints = hints;\\r\\n\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    hintIndex = 0;\\r\\n    result = '&nbsp;';\\r\\n    showCheckMark = false;\\r\\n    showNextButton = false;\\r\\n    showSpeakerButton = false;\\r\\n  }\\r\\n\\r\\n  function onPrev() {\\r\\n    if (currentWordIndex <= 0) return;\\r\\n    currentWord = words[--currentWordIndex];\\r\\n    makeExample();\\r\\n\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    hintIndex = 0;\\r\\n    result = '';\\r\\n    showCheckMark = false;\\r\\n    showNextButton = false;\\r\\n    showSpeakerButton = false;\\r\\n  }\\r\\n\\r\\n  function onSpeach() {\\r\\n    speak(\\r\\n      !showNextButton\\r\\n        ? extractWords(currentWord.example[$llang]).join()\\r\\n        : currentWord.example[$llang]\\r\\n    );\\r\\n\\r\\n    if (!showNextButton) hintIndex++;\\r\\n  }\\r\\n\\r\\n  function speak(text) {\\r\\n    text = text.replace(/<<|>>/g, '');\\r\\n    text = text.replace(/_/g, ' ');\\r\\n    // Speak(text);\\r\\n    tts.Speak_server($llang, text, data.name,()=>{\\r\\n      nextWord()\\r\\n    });\\r\\n\\r\\n    // setFocus();\\r\\n  }\\r\\n\\r\\n  function countWordOccurrences(sentence, word) {\\r\\n    // Приводим предложение и слово к нижнему регистру для нечувствительности к регистру\\r\\n    const lowerSentence = sentence.toLowerCase();\\r\\n    const lowerWord = word.toLowerCase();\\r\\n\\r\\n    // Разбиваем предложение на массив слов\\r\\n    const words = lowerSentence.split(/\\\\s+/);\\r\\n\\r\\n    // Считаем количество вхождений слова\\r\\n    let count = 0;\\r\\n    words.forEach(function (w) {\\r\\n      if (w === lowerWord) {\\r\\n        count++;\\r\\n      }\\r\\n    });\\r\\n\\r\\n    return count;\\r\\n  }\\r\\n\\r\\n  // function OnClickInput(el) {\\r\\n  //   // div_input[0].innerHTML = \\"    \\"\\r\\n  //   div_input[0].focus();\\r\\n  //   // setFocus()\\r\\n  // }\\r\\n\\r\\n  function setLang(ev) {\\r\\n    let lang = ev.currentTarget.outerText;\\r\\n    let code = ISO6391.getCode(lang);\\r\\n    if (code !== 'English') {\\r\\n      $llang = code;\\r\\n    }\\r\\n    // console.log($langs);\\r\\n    lang_menu = false;\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    makeExample();\\r\\n  }\\r\\n\\r\\n  function PlayAutoContent() {\\r\\n    isPlayAuto = !isPlayAuto;\\r\\n    if (!isPlayAuto) return;\\r\\n\\r\\n    async function onEndSpeak() {\\r\\n      if (!isPlayAuto) return;\\r\\n\\r\\n      if (active === currentWord.example[$langs].replace(/<<|>>/g, '')) {\\r\\n        active = currentWord.example[$llang].replace(/<<|>>/g, '');\\r\\n        tts.Speak_server($llang, active, data.name, onEndSpeak);\\r\\n      } else if (active === currentWord.example[$llang].replace(/<<|>>/g, '')) {\\r\\n        currentWordIndex++;\\r\\n        await nextWord();\\r\\n        setTimeout(() => {\\r\\n          showHintAuto();\\r\\n        }, 100);\\r\\n\\r\\n        active = currentWord.example[$langs].replace(/<<|>>/g, '');\\r\\n        tts.Speak_server($langs, active, data.name, onEndSpeak);\\r\\n      }\\r\\n    }\\r\\n\\r\\n    div_input[0].style.color = '#2196f3';\\r\\n    div_input[1].style.color = '#2196f3';\\r\\n    setTimeout(() => {\\r\\n      showHintAuto();\\r\\n    }, 100);\\r\\n    let active = currentWord.example[$langs].replace(/<<|>>/g, ''); //currentWord.example[$langs];\\r\\n    tts.Speak_server($langs, active, data.name,onEndSpeak);\\r\\n  }\\r\\n\\r\\n  function OnClickLBL(){\\r\\n    return\\r\\n    if(currentWord?.example[\`lbl.\${$langs}\`]){\\r\\n      example_lang =\`lbl.\${$langs}\`;\\r\\n      makeExample()\\r\\n\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function ToggleTranslate(){\\r\\n    translate = !translate\\r\\n  }\\r\\n\\r\\n  onDestroy(() => {\\r\\n    // Очищаем интервал при размонтировании компонента\\r\\n    $llang = _llang;\\r\\n    $lesson.data = { quiz: '' };\\r\\n  });\\r\\n<\/script>\\r\\n\\r\\n<!-- <link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/> -->\\r\\n\\r\\n<TTS bind:this={tts}></TTS>\\r\\n\\r\\n{#if words?.length < 1}\\r\\n  <div style=\\"text-align:center\\">\\r\\n    <span\\r\\n      class=\\"material-symbols-outlined\\"\\r\\n      style=\\"font-size: 20px; color: blue; scale:1.5;\\"\\r\\n    >\\r\\n      <CircularProgress style=\\"height: 50px; width: 50px;\\" indeterminate />\\r\\n    </span>\\r\\n  </div>\\r\\n{/if}\\r\\n\\r\\n{#if words}\\r\\n\\r\\n    <div class=\\"top-app-bar-container flexor\\">\\r\\n      <TopAppBar bind:this={topAppBar} variant=\\"fixed\\">\\r\\n        <Row>\\r\\n          <Section align=\\"start\\">\\r\\n            {#if currentWordIndex > 0}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={onPrev}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"margin:10px 5px 10px 5px; scale:.5; width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"white\\" d={mdiArrowLeft} />\\r\\n              </Icon>\\r\\n            {/if}\\r\\n          </Section>\\r\\n          <Section align=\\"start\\">\\r\\n\\r\\n          </Section>\\r\\n          <Section>\\r\\n            {#if !$dc}\\r\\n              <IconButton on:click={PlayAutoContent}>\\r\\n                <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill={playAutoColor} d={mdiEarHearing} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            {/if}\\r\\n          </Section>\\r\\n\\r\\n          <Section align=\\"end\\">\\r\\n            <div class=\\"counter\\">\\r\\n              <p>\\r\\n                <span class=\\"mdc-typography--overline\\" style=\\"position:relative\\"\\r\\n                  >{currentWordIndex}\\r\\n                  <Badge\\r\\n                    position=\\"middle\\"\\r\\n                    align=\\"bottom-end - bottom-middle\\"\\r\\n                    aria-label=\\"unread count\\"\\r\\n                    style=\\"margin-right:-10px;scale:.8\\">{words.length}</Badge\\r\\n                  >\\r\\n                </span>\\r\\n              </p>\\r\\n            </div>\\r\\n          </Section>\\r\\n          <Section align=\\"end\\">\\r\\n            {#if true || words.length <= 20}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={onShuffleWords}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"margin-top:0px; scale:.5; width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"white\\" d={mdiShuffle} />\\r\\n              </Icon>\\r\\n            {:else}\\r\\n              <div on:click={jumpNext10}>+10</div>\\r\\n            {/if}\\r\\n          </Section>\\r\\n          <Section align=\\"end\\">\\r\\n            <Icon\\r\\n              tag=\\"svg\\"\\r\\n              viewBox=\\"0 0 24 24\\"\\r\\n              style=\\"margin:10px 5px 10px 5px; scale:1.2; width:20px\\"\\r\\n              on:click={ToggleTranslate}\\r\\n            >\\r\\n            {#if translate}\\r\\n              <path fill=\\"white\\" d={mdiTranslateOff}/>\\r\\n            {:else}\\r\\n              <path fill=\\"grey\\" d={mdiTranslate}/>\\r\\n            {/if}\\r\\n            </Icon>\\r\\n          </Section>\\r\\n\\r\\n          <Section align=\\"end\\">\\r\\n            {#if showNextButton}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={nextWord}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"margin:10px 5px 10px 5px; scale:.5; width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"green\\" d={mdiArrowRight} />\\r\\n              </Icon>\\r\\n            {:else}\\r\\n              <Icon\\r\\n                tag=\\"svg\\"\\r\\n                on:click={checkInput}\\r\\n                viewBox=\\"0 0 24 24\\"\\r\\n                style=\\"visibility:hidden;margin-top:0px; scale:.5; width:50px\\"\\r\\n              >\\r\\n                <path fill=\\"white\\" d={mdiTextBoxCheckOutline} />\\r\\n              </Icon>\\r\\n            {/if}\\r\\n          </Section>\\r\\n        </Row>\\r\\n      </TopAppBar>\\r\\n    </div>\\r\\n\\r\\n    <div class=\\"div_word\\">\\r\\n    <span\\r\\n      style=\\"display:block;position:relative;top: 0px;left:5px;color: lightgray;font-style: italic;font-size:smaller;font-family: serif;\\"\\r\\n      >{data.name}</span\\r\\n    >\\r\\n\\r\\n    <div style=\\"border:1px solid lightgrey;border-radius:5px;padding:-10px\\">\\r\\n\\r\\n      {#await Translate('Заполнить пропуски', 'ru', $langs) then data}\\r\\n        <div class=\\"title\\">{data}:</div>\\r\\n      {/await}\\r\\n\\r\\n      {#if translate}\\r\\n        <div class=\\"word\\" >\\r\\n\\r\\n              {#await Translate(currentWord?.example[$llang], $llang, $langs) then data}\\r\\n                {@html data}\\r\\n              {/await}\\r\\n      \\r\\n      \\r\\n        </div>\\r\\n      {/if}\\r\\n\\r\\n    <div class=\\"input-container\\">\\r\\n      {#if resultElement}\\r\\n        {@html resultElement}\\r\\n      {/if}\\r\\n\\r\\n      <div\\r\\n        class=\\"input\\"\\r\\n        contenteditable=\\"true\\"\\r\\n        on:click={showHint}\\r\\n        bind:this={div_input[0]}\\r\\n        bind:innerHTML={userContent[0]}\\r\\n        style=\\"display:none;width: {resultElementWidth[0]}px\\"\\r\\n      >\\r\\n        {@html result}\\r\\n      </div>\\r\\n      <div\\r\\n        class=\\"input\\"\\r\\n        contenteditable=\\"true\\"\\r\\n        on:click={showHint}\\r\\n        bind:this={div_input[1]}\\r\\n        bind:innerHTML={userContent[1]}\\r\\n        style=\\"display:none;width: {resultElementWidth[1]}px\\"\\r\\n      >\\r\\n        {@html result}\\r\\n      </div>\\r\\n      <div class=\\"speaker-button\\" on:click={onSpeach}>\\r\\n        <IconButton>\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n            <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n          </Icon>\\r\\n        </IconButton>\\r\\n      </div>\\r\\n    </div>\\r\\n  </div>\\r\\n\\r\\n    <!-- <br /> -->\\r\\n    <!-- {#if hintIndex != 0} -->\\r\\n    <div class=\\"words_div accordion-container\\">\\r\\n      {#if hints?.length > 0}\\r\\n        <Content style=\\"line-height: 2.0; overflow-y:auto;\\">\\r\\n          {#each hints as hint, i}\\r\\n            {#if hint?.example[$llang]}\\r\\n              <span\\r\\n                class=\\"hint_button\\"\\r\\n                on:click={() => {\\r\\n                  OnClickHint(extractWords(hint?.example[$llang]).join(' '), i);\\r\\n                }}\\r\\n              >\\r\\n                {@html extractWords(hint?.example[$llang]).join(' ') +\\r\\n                  '&nbsp;' +\\r\\n                  '&nbsp;'}\\r\\n              </span>\\r\\n            {:else}\\r\\n              {#await Translate(hint?.example['ru'], 'ru', $llang) then data}\\r\\n                <span\\r\\n                  class=\\"hint_button\\"\\r\\n                  on:click={() => {\\r\\n                    OnClickHint(extractWords(data).join(' '));\\r\\n                  }}\\r\\n                >\\r\\n                  {@html extractWords(data).join(' ') + '&nbsp;' + '&nbsp;'}\\r\\n                </span>\\r\\n              {/await}\\r\\n            {/if}\\r\\n          {/each}\\r\\n          <div style=\\"height:80px\\"></div>\\r\\n        </Content>\\r\\n      {/if}\\r\\n    </div>\\r\\n     <div style=\\"height:300px\\"/>\\r\\n    </div>\\r\\n{/if}\\r\\n\\r\\n<style>\\r\\n    .top-app-bar-container{\\r\\n      position: relative;\\r\\n      top:0px; \\r\\n      height: 60px;\\r\\n    /* transform: scale(1.2) translate(-4%,0%);\\r\\n    transform-origin: center ;  */\\r\\n    }\\r\\n  .div_word {\\r\\n    position: relative;\\r\\n    display: inline-grid;\\r\\n    /* background-color: #fff; */\\r\\n    transition: transform 0.3s ease-in-out;\\r\\n    /* width: 98%; */\\r\\n    margin: 0 auto;\\r\\n    /* transform-style: preserve-3d; */\\r\\n    transition: transform 0.5s;\\r\\n    /* height: 80vh; */\\r\\n    /* top: 10px; */\\r\\n  }\\r\\n  .title {\\r\\n    font-size: medium;\\r\\n    color: lightgrey;\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  .hint_button {\\r\\n    display: inline-block;\\r\\n    border: solid 0.1em #80777791;\\r\\n    border-radius: 5px;\\r\\n    text-align: center;\\r\\n    width: auto;\\r\\n    padding-left: 8px;\\r\\n    margin: 5px;\\r\\n    color: #2196e6;\\r\\n    background-color: transparent;\\r\\n  }\\r\\n\\r\\n  /* Стилизуйте компонент по вашему усмотению */\\r\\n  .word {\\r\\n    font-size: 0.8em;\\r\\n    flex-direction: column;\\r\\n    align-items: center;\\r\\n    margin-top: 10px;\\r\\n    text-align: center;\\r\\n    line-height: 17px;\\r\\n  }\\r\\n\\r\\n  .example {\\r\\n    color: #2196f3;\\r\\n  }\\r\\n\\r\\n  h1 {\\r\\n    margin-bottom: 20px;\\r\\n  }\\r\\n\\r\\n  .hidden {\\r\\n    opacity: 0;\\r\\n    pointer-events: none;\\r\\n  }\\r\\n\\r\\n  p {\\r\\n    position: relative;\\r\\n    transition: opacity 0.5s ease;\\r\\n    text-align: center;\\r\\n    font-size: xx-large;\\r\\n    margin: 0;\\r\\n  }\\r\\n\\r\\n  .speaker-button {\\r\\n    display: inline-flex;\\r\\n    position: relative;\\r\\n    float: right;\\r\\n    margin-right: 10px;\\r\\n    font-size: large;\\r\\n    border-radius: 25px;\\r\\n    transform: translate(50%, 0%);\\r\\n    font-size: large;\\r\\n    z-index: 2 !important;\\r\\n  }\\r\\n\\r\\n  .input-container {\\r\\n    display: inline-block;\\r\\n    font-size: large;\\r\\n    position: relative;\\r\\n    color: #2196f3;\\r\\n    width: 95vw;\\r\\n    margin: 10px auto;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .words_div {\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    overflow-y: hidden;\\r\\n    height: 70vh;\\r\\n  }\\r\\n\\r\\n  .input {\\r\\n    position: relative;\\r\\n    height: 18px;\\r\\n    display: inline-table;\\r\\n    outline: none;\\r\\n    border: 1px solid lightblue;\\r\\n    border-radius: 4px;\\r\\n    background: beige;\\r\\n    text-align: center;\\r\\n    padding-left: 5px;\\r\\n    padding-right: 5px;\\r\\n  }\\r\\n\\r\\n  .input:focus {\\r\\n    outline: none;\\r\\n  }\\r\\n\\r\\n  .next10-button,\\r\\n  .shuffle-button,\\r\\n  .prev-button,\\r\\n  .check-button,\\r\\n  .next-button {\\r\\n    /* margin-top: 10px; */\\r\\n    padding: 8px 10px;\\r\\n    font-size: 16px;\\r\\n    font-weight: 500;\\r\\n    border-color: #2196f3;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    color: #2196f3;\\r\\n  }\\r\\n\\r\\n  .material-symbols-outlined {\\r\\n    font-size: 15px;\\r\\n    scale: 1.5;\\r\\n    font-variation-settings:\\r\\n      'FILL' 0,\\r\\n      'wght' 400,\\r\\n      'GRAD' 0,\\r\\n      'opsz' 24;\\r\\n  }\\r\\n\\r\\n  .hint-button {\\r\\n    border: 0px;\\r\\n    color: white;\\r\\n    background-color: #2196f3;\\r\\n    border-radius: 3px;\\r\\n    padding: 8px 10px;\\r\\n  }\\r\\n  .counter {\\r\\n    /* position: absolute; */\\r\\n    background-color: #f0f0f0;\\r\\n    padding: 0px;\\r\\n    border-radius: 25px;\\r\\n    width: 30px;\\r\\n    height: 30px;\\r\\n    top: -10px;\\r\\n    left: -6px;\\r\\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .counter p {\\r\\n    margin: 0;\\r\\n    font-size: 15px;\\r\\n    color: #333;\\r\\n  }\\r\\n\\r\\n  .counter span {\\r\\n    font-weight: 700;\\r\\n    font-size: 15px;\\r\\n    color: #ff5733; /* цвет счетчика */\\r\\n  }\\r\\n\\r\\n  .lang_span {\\r\\n    visibility: hidden;\\r\\n    font-size: large;\\r\\n  }\\r\\n\\r\\n  .lang_list {\\r\\n    position: absolute;\\r\\n    top: 50px;\\r\\n    height: 80vh;\\r\\n    overflow: hidden;\\r\\n    justify-content: center; /* Выравниваем содержимое по центру вертикально */\\r\\n    align-items: center; /* Выравниваем содержимое по центру горизонтально */\\r\\n    background-color: white;\\r\\n    /* opacity: 50%; */\\r\\n  }\\r\\n\\r\\n  @media screen and (min-width: 768px) {\\r\\n\\t\\t/* Ваши стили для более крупных экранов здесь */\\r\\n\\r\\n\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAy4BI,kDAAsB,CACpB,QAAQ,CAAE,QAAQ,CAClB,IAAI,GAAG,CACP,MAAM,CAAE,IAGV,CACF,qCAAU,CACR,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,WAAW,CAEpB,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,WAAW,CAEtC,MAAM,CAAE,CAAC,CAAC,IAAI,CAEd,UAAU,CAAE,SAAS,CAAC,IAGxB,CACA,kCAAO,CACL,SAAS,CAAE,MAAM,CACjB,KAAK,CAAE,SAAS,CAChB,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,IACd,CAEA,wCAAa,CACX,OAAO,CAAE,YAAY,CACrB,MAAM,CAAE,KAAK,CAAC,KAAK,CAAC,SAAS,CAC7B,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,GAAG,CACjB,MAAM,CAAE,GAAG,CACX,KAAK,CAAE,OAAO,CACd,gBAAgB,CAAE,WACpB,CAGA,iCAAM,CACJ,SAAS,CAAE,KAAK,CAChB,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,IAAI,CAChB,UAAU,CAAE,MAAM,CAClB,WAAW,CAAE,IACf,CAeA,6BAAE,CACA,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,OAAO,CAAC,IAAI,CAAC,IAAI,CAC7B,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,QAAQ,CACnB,MAAM,CAAE,CACV,CAEA,2CAAgB,CACd,OAAO,CAAE,WAAW,CACpB,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,KAAK,CACZ,YAAY,CAAE,IAAI,CAClB,SAAS,CAAE,KAAK,CAChB,aAAa,CAAE,IAAI,CACnB,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,EAAE,CAAC,CAC7B,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,CAAC,CAAC,UACb,CAEA,4CAAiB,CACf,OAAO,CAAE,YAAY,CACrB,SAAS,CAAE,KAAK,CAChB,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,OAAO,CACd,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CAAC,IAAI,CACjB,UAAU,CAAE,MACd,CAEA,sCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,MAAM,CAClB,MAAM,CAAE,IACV,CAEA,kCAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,YAAY,CACrB,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,SAAS,CAC3B,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,KAAK,CACjB,UAAU,CAAE,MAAM,CAClB,YAAY,CAAE,GAAG,CACjB,aAAa,CAAE,GACjB,CAEA,kCAAM,MAAO,CACX,OAAO,CAAE,IACX,CAiBA,sDAA2B,CACzB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,GAAG,CACV,uBAAuB,CACrB,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,GAAG,CAAC;AACjB,MAAM,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,EACX,CASA,oCAAS,CAEP,gBAAgB,CAAE,OAAO,CACzB,OAAO,CAAE,GAAG,CACZ,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,KAAK,CACV,IAAI,CAAE,IAAI,CACV,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CACxC,UAAU,CAAE,MACd,CAEA,sBAAQ,CAAC,eAAE,CACT,MAAM,CAAE,CAAC,CACT,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IACT,CAEA,sBAAQ,CAAC,kBAAK,CACZ,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,OACT,CAkBA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAItC"}`
};
function extractWords$1(text) {
  const regex = /<<(.*?)>>/g;
  let result = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[1]);
  }
  return result;
}
function replaceWordWithInput$1(text, targetWord) {
  return text.replace(/<<([^>]*)>>/g, `<span  value="$1" class="sentence_span" style="position: relative;width:20px;  left: 0px;" ></span>`);
}
function getTextWidth$1(text, font) {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  context.font = font;
  const metrics = context.measureText(text);
  return metrics.width + 5;
}
function shuffle$1(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
const Word = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $lesson, $$unsubscribe_lesson;
  let $llang, $$unsubscribe_llang;
  let $langs, $$unsubscribe_langs;
  let $$unsubscribe_dicts;
  let $dc, $$unsubscribe_dc;
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => value);
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  let playAutoColor = "currentColor";
  let tts;
  let { data } = $$props;
  const abonent = getContext("abonent");
  let words = [], example;
  let hints;
  let currentWordIndex = 0;
  let currentWord;
  data.highlight ? data.highlight.split(",") : [];
  let _llang = $llang;
  let userContent = [];
  let div_input = [];
  let result = "&nbsp;";
  let resultElement;
  let resultElementWidth = [];
  data.name?.split(",");
  fetch(`./lesson?words=theme&theme=${data.theme}&name=${data.name}&owner=${abonent}&level=${data.level}`).then((response) => response.json()).then((data2) => {
    words = data2.data.data;
    if (!words[0]) return;
    currentWord = words[currentWordIndex];
    makeExample();
  }).catch((error) => {
    console.log(error);
    return [];
  });
  let topAppBar;
  function makeExample() {
    if (!currentWord) return;
    return new Promise(async (resolve, reject) => {
      example = currentWord.example[$llang];
      const regex = /(<<\w+>>)\s+(<<\w+>>)/;
      const match = currentWord?.example[$llang] ? currentWord?.example[$llang].match(regex) : "";
      if (match) {
        `${match[0]} ${match[1]}`;
      }
      resultElement = replaceWordWithInput$1(
        currentWord?.example[$llang] ? currentWord?.example[$llang] : currentWord.example[$llang] = await Translate(currentWord.example["ru"], "ru", $llang)
      );
      if (example.includes("<<") && example.includes(">>")) {
        example = example?.replace(/<<([^<>]+)>>/gu, !data.level.includes("C1") ? '<span style="color:green" ><b>$1</b></span>' : "$1");
      } else if (example.includes('"')) {
        example = example?.replace(/"([^"]+)"/gu, !data.level.includes("C1") ? '<span style="color:green" ><b>$1</b></span>' : "$1");
      }
      setTimeout(
        () => {
          const wAr = extractWords$1(currentWord?.example[$llang]);
          const spanElements = document.querySelectorAll(".sentence_span");
          spanElements.forEach((spanElement, i) => {
            if (div_input) div_input[i].style.display = "";
            spanElement.appendChild(div_input[i]);
            resultElementWidth[i] = getTextWidth$1(wAr[i], "20px Arial");
          });
        },
        0
      );
      function getSubArray(arr, index) {
        const totalElements = 10;
        const halfRange = Math.floor(totalElements / 2);
        let startIndex = index - halfRange;
        let endIndex = index + halfRange;
        if (startIndex < 0) {
          endIndex += Math.abs(startIndex);
          startIndex = 0;
        }
        if (endIndex >= arr.length) {
          startIndex -= endIndex - arr.length + 1;
          endIndex = arr.length - 1;
        }
        startIndex = Math.max(startIndex, 0);
        return arr.slice(startIndex, endIndex + 1);
      }
      hints = getSubArray([...words], currentWordIndex);
      shuffle$1(hints);
      resolve();
    });
  }
  onDestroy(() => {
    set_store_value(llang, $llang = _llang, $llang);
    set_store_value(lesson, $lesson.data = { quiz: "" }, $lesson);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.extractWords === void 0 && $$bindings.extractWords && extractWords$1 !== void 0) $$bindings.extractWords(extractWords$1);
  $$result.css.add(css$5);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      {
        playAutoColor = "currentColor";
      }
    }
    {
      if ($langs) {
        makeExample();
      }
    }
    $$rendered = ` ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${words?.length < 1 ? `<div style="text-align:center"><span class="material-symbols-outlined svelte-zekd1d" style="font-size: 20px; color: blue; scale:1.5;">${validate_component(CircularProgress, "CircularProgress").$$render(
      $$result,
      {
        style: "height: 50px; width: 50px;",
        indeterminate: true
      },
      {},
      {}
    )}</span></div>` : ``} ${words ? `<div class="top-app-bar-container flexor svelte-zekd1d">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      { variant: "fixed", this: topAppBar },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {
                default: () => {
                  return `${``}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "start" }, {}, {})} ${validate_component(Section$1, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return `${!$dc ? `${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
                    default: () => {
                      return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
                        default: () => {
                          return `<path${add_attribute("fill", playAutoColor, 0)}${add_attribute("d", mdiEarHearing, 0)}></path>`;
                        }
                      })}`;
                    }
                  })}` : ``}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<div class="counter svelte-zekd1d"><p class="svelte-zekd1d"><span class="mdc-typography--overline svelte-zekd1d" style="position:relative">${escape(currentWordIndex)} ${validate_component(Badge, "Badge").$$render(
                    $$result,
                    {
                      position: "middle",
                      align: "bottom-end - bottom-middle",
                      "aria-label": "unread count",
                      style: "margin-right:-10px;scale:.8"
                    },
                    {},
                    {
                      default: () => {
                        return `${escape(words.length)}`;
                      }
                    }
                  )}</span></p></div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${`${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin-top:0px; scale:.5; width:50px"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white"${add_attribute("d", mdiShuffle, 0)}></path>`;
                      }
                    }
                  )}`}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "margin:10px 5px 10px 5px; scale:1.2; width:20px"
                    },
                    {},
                    {
                      default: () => {
                        return `${`<path fill="white"${add_attribute("d", mdiTranslateOff, 0)}></path>`}`;
                      }
                    }
                  )}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${`${validate_component(CommonIcon, "Icon").$$render(
                    $$result,
                    {
                      tag: "svg",
                      viewBox: "0 0 24 24",
                      style: "visibility:hidden;margin-top:0px; scale:.5; width:50px"
                    },
                    {},
                    {
                      default: () => {
                        return `<path fill="white"${add_attribute("d", mdiTextBoxCheckOutline, 0)}></path>`;
                      }
                    }
                  )}`}`;
                }
              })}`;
            }
          })}`;
        }
      }
    )}</div> <div class="div_word svelte-zekd1d"><span style="display:block;position:relative;top: 0px;left:5px;color: lightgray;font-style: italic;font-size:smaller;font-family: serif;">${escape(data.name)}</span> <div style="border:1px solid lightgrey;border-radius:5px;padding:-10px">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-zekd1d">${escape(data2)}:</div> `;
      }(__value);
    }(Translate("Заполнить пропуски", "ru", $langs))} ${`<div class="word svelte-zekd1d">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <!-- HTML_TAG_START -->${data2}<!-- HTML_TAG_END --> `;
      }(__value);
    }(Translate(currentWord?.example[$llang], $llang, $langs))}</div>`} <div class="input-container svelte-zekd1d">${resultElement ? `<!-- HTML_TAG_START -->${resultElement}<!-- HTML_TAG_END -->` : ``} <div class="input svelte-zekd1d" contenteditable="true" style="${"display:none;width: " + escape(resultElementWidth[0], true) + "px"}"${add_attribute("this", div_input[0], 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent[0])}</div> <div class="input svelte-zekd1d" contenteditable="true" style="${"display:none;width: " + escape(resultElementWidth[1], true) + "px"}"${add_attribute("this", div_input[1], 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent[1])}</div> <div class="speaker-button svelte-zekd1d">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)}></path>`;
          }
        })}`;
      }
    })}</div></div></div>   <div class="words_div accordion-container svelte-zekd1d">${hints?.length > 0 ? `${validate_component(Content, "Content").$$render(
      $$result,
      {
        style: "line-height: 2.0; overflow-y:auto;"
      },
      {},
      {
        default: () => {
          return `${each(hints, (hint, i) => {
            return `${hint?.example[$llang] ? `<span class="hint_button svelte-zekd1d"><!-- HTML_TAG_START -->${extractWords$1(hint?.example[$llang]).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --> </span>` : `${function(__value) {
              if (is_promise(__value)) {
                __value.then(null, noop);
                return ``;
              }
              return function(data2) {
                return ` <span class="hint_button svelte-zekd1d"><!-- HTML_TAG_START -->${extractWords$1(data2).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --></span> `;
              }(__value);
            }(Translate(hint?.example["ru"], "ru", $llang))}`}`;
          })} <div style="height:80px"></div>`;
        }
      }
    )}` : ``}</div> <div style="height:300px"></div></div>` : ``}`;
  } while (!$$settled);
  $$unsubscribe_lesson();
  $$unsubscribe_llang();
  $$unsubscribe_langs();
  $$unsubscribe_dicts();
  $$unsubscribe_dc();
  return $$rendered;
});
const css$4 = {
  code: "main.svelte-7qx74n.svelte-7qx74n{margin:0 auto;position:relative;transition:transform 0.5s;top:0px}.flexor.svelte-7qx74n.svelte-7qx74n{position:relative}.title.svelte-7qx74n.svelte-7qx74n{color:coral;position:relative;text-align:center;margin-top:0px;top:70px;font-size:medium}.hint_button.svelte-7qx74n.svelte-7qx74n{display:inline-block;border:solid 0.1em #9f3f3f;border-radius:5px;text-align:center;width:auto;padding-left:8px;margin:5px;background-color:transparent}.hint_example.svelte-7qx74n.svelte-7qx74n{position:relative;top:60px;border-radius:5px;text-align:center;width:auto;padding-left:5px;margin:5px;background-color:transparent}.disabled.svelte-7qx74n.svelte-7qx74n{visibility:hidden}.word.svelte-7qx74n.svelte-7qx74n{position:relative;top:60px;font-size:large;flex-direction:column;align-items:center;margin:2px;text-align:center}.example.svelte-7qx74n.svelte-7qx74n{color:#2196f3}.hidden.svelte-7qx74n.svelte-7qx74n{opacity:0;pointer-events:none}p.svelte-7qx74n.svelte-7qx74n{position:relative;transition:opacity 0.5s ease;text-align:center;font-size:xx-large;margin:0}.speaker-button.svelte-7qx74n.svelte-7qx74n{position:relative;top:0px;right:10px;transform:translate(50%, 0%);font-size:large;z-index:1}.input-container.svelte-7qx74n.svelte-7qx74n{display:inline-block;top:60px;font-size:large;font-weight:700;position:relative;color:#2196f3;width:95vw;margin:0 auto;text-align:center}.words_div.svelte-7qx74n.svelte-7qx74n{position:relative;text-align:center;overflow-y:auto;top:80px}.input.svelte-7qx74n.svelte-7qx74n{position:relative;height:18px;display:inline-table;outline:none;border:none;background:rgba(0, 0, 0, 0.12);text-align:center}.input.svelte-7qx74n.svelte-7qx74n:focus{outline:none}.next10-button.svelte-7qx74n.svelte-7qx74n,.shuffle-button.svelte-7qx74n.svelte-7qx74n,.prev-button.svelte-7qx74n.svelte-7qx74n,.check-button.svelte-7qx74n.svelte-7qx74n,.next-button.svelte-7qx74n.svelte-7qx74n{padding:8px 10px;font-size:16px;font-weight:500;border-color:#2196f3;border-radius:5px;cursor:pointer;color:#2196f3}.material-symbols-outlined.svelte-7qx74n.svelte-7qx74n{font-size:15px;scale:1.5;font-variation-settings:'FILL' 0,\r\n      'wght' 400,\r\n      'GRAD' 0,\r\n      'opsz' 24}.hint-button.svelte-7qx74n.svelte-7qx74n{border:0px;color:white;background-color:#2196f3;border-radius:3px;padding:8px 10px}.counter.svelte-7qx74n.svelte-7qx74n{background-color:#f0f0f0;padding:0px;border-radius:25px;width:50px;height:30px;top:-10px;left:-6px;box-shadow:0 2px 4px rgba(0, 0, 0, 0.1);text-align:center}.counter.svelte-7qx74n p.svelte-7qx74n{margin:0;font-size:15px;color:#333}.counter.svelte-7qx74n span.svelte-7qx74n{font-weight:700;font-size:15px;color:#ff5733}.lang_span.svelte-7qx74n.svelte-7qx74n{font-size:large}.lang_list.svelte-7qx74n.svelte-7qx74n{position:absolute;top:50px;height:80vh;overflow:auto;justify-content:center;align-items:center;background-color:white}.selected.svelte-7qx74n.svelte-7qx74n{background-color:coral}",
  map: `{"version":3,"file":"WordGame.svelte","sources":["WordGame.svelte"],"sourcesContent":["<script>\\r\\n  // @ts-nocheck\\r\\n\\r\\n  import { onMount, onDestroy, getContext } from 'svelte';\\r\\n  import TopAppBar, { Row, Title, Section } from '@smui/top-app-bar';\\r\\n  import Badge from '@smui-extra/badge';\\r\\n  import Select, { Option } from '@smui/select';\\r\\n\\r\\n  // import words from './80.json';\\r\\n  import { Translate } from '../../../translate/Transloc';\\r\\n  // translate.engine = 'google';\\r\\n  // translate.from = $llang;\\r\\n\\r\\n  import { langs } from '$lib/js/stores.js';\\r\\n\\r\\n  import langs_list from '$lib/dict/learn_langs_list.json';\\r\\n\\r\\n  let lang_menu = false;\\r\\n\\r\\n  import ISO6391 from 'iso-google-locales';\\r\\n\\r\\n  import CircularProgress from '@smui/circular-progress';\\r\\n\\r\\n  import TTS from '../../../speech/tts/Tts.svelte';\\r\\n  let tts;\\r\\n\\r\\n  import Accordion, { Panel, Header, Content } from '@smui-extra/accordion';\\r\\n  import IconButton, { Icon } from '@smui/icon-button';\\r\\n  import {\\r\\n    mdiShareVariant,\\r\\n    mdiPagePreviousOutline,\\r\\n    mdiChevronDownCircleOutline,\\r\\n    mdiHelp,\\r\\n    mdiVolumeHigh,\\r\\n  } from '@mdi/js';\\r\\n\\r\\n  import {\\r\\n    lesson,\\r\\n    llang,\\r\\n    view,\\r\\n    dicts,\\r\\n    dc,\\r\\n    dc_state,\\r\\n    msg,\\r\\n    call_but_status,\\r\\n    showBottomAppBar,\\r\\n    OnCheckQU,\\r\\n  } from '$lib/js/stores.js';\\r\\n\\r\\n  let dict = $dicts;\\r\\n\\r\\n  export let data;\\r\\n\\r\\n  const abonent = getContext('abonent');\\r\\n\\r\\n  let words = [],\\r\\n    word,\\r\\n    example = '&nbsp;';\\r\\n  let shuffleWords;\\r\\n  let hints = {};\\r\\n  let currentWordIndex = 0;\\r\\n  let currentWord;\\r\\n  let doneWords = 0;\\r\\n  let doneWords_2 = 0;\\r\\n  let arrayOfArrays;\\r\\n  let userContent = [];\\r\\n  let div_input = [];\\r\\n  let result = '&nbsp;';\\r\\n  let resultElement;\\r\\n  let hintIndex = 0;\\r\\n  let showHints = {};\\r\\n  let errorIndex = 0;\\r\\n  let _llang = $llang;\\r\\n  let value = $llang;\\r\\n  let showNextButton = false;\\r\\n  let showCheckButton = false;\\r\\n  let resultElementWidth = [];\\r\\n  let showSpeakerButton = false;\\r\\n  let focus_pos = 0;\\r\\n  let level = data.level;\\r\\n  let share_button = false;\\r\\n  let share_button_class = 'button_shared_false';\\r\\n  let share_mode = false;\\r\\n  let isFlipped = false;\\r\\n  let hint_example = '';\\r\\n  let label = {};\\r\\n  label[true] = 'Ожидай вопрос';\\r\\n  label[false] = 'Выбери слово';\\r\\n\\r\\n  $: switch ($call_but_status) {\\r\\n    case 'talk':\\r\\n      break;\\r\\n    default:\\r\\n      share_mode = false;\\r\\n\\r\\n      break;\\r\\n  }\\r\\n\\r\\n  // defineWordsArray();\\r\\n\\r\\n  let counter = 0;\\r\\n  let isVisible = false;\\r\\n\\r\\n  let names = data.name?.split(',');\\r\\n\\r\\n  // Создаем массив промисов для каждого запроса\\r\\n\\r\\n  if (data.theme && data.name && level)\\r\\n    fetch(\\r\\n      \`./lesson?words=theme&theme=\${data.theme}&name=\${data.name}&owner=\${abonent}&level=\${level}\`\\r\\n    )\\r\\n      .then((response) => response.json())\\r\\n      .then((data) => {\\r\\n        words = data.data.data || [];\\r\\n        if (!words[0]) return;\\r\\n\\r\\n        hints[false] = JSON.parse(JSON.stringify(words));\\r\\n        hints[true] = JSON.parse(JSON.stringify(words));\\r\\n\\r\\n        showHints[isFlipped] = true;\\r\\n\\r\\n        if ($call_but_status !== 'active' && !isFlipped) {\\r\\n          onShare();\\r\\n        }\\r\\n\\r\\n        //   shuffle(hints);\\r\\n      })\\r\\n      .catch((error) => {\\r\\n        console.log(error);\\r\\n        return [];\\r\\n      });\\r\\n\\r\\n  $: if ($langs) {\\r\\n    makeExample();\\r\\n  }\\r\\n\\r\\n  $: if ($llang) {\\r\\n    makeExample();\\r\\n  }\\r\\n\\r\\n  $: if ($msg?.lesson?.quiz === 'word' && !$msg.lesson.isFlipped) {\\r\\n    try {\\r\\n      if ($msg.lesson.words_data) {\\r\\n        words = $msg.lesson.words_data;\\r\\n        hints[false] = JSON.parse(JSON.stringify(words));\\r\\n        hints[true] = JSON.parse(JSON.stringify(words));\\r\\n        isFlipped = !$msg.lesson.isFlipped;\\r\\n        level = $msg.lesson.level;\\r\\n        share_mode = true;\\r\\n        showHints[isFlipped] = false;\\r\\n        $OnCheckQU(null, 'word', $msg.lesson.name);\\r\\n      } else if (\\r\\n        ($msg.lesson.word_correct || $msg.lesson.word_correct == 0) &&\\r\\n        hints\\r\\n      ) {\\r\\n        hints[isFlipped][$msg.lesson.word_correct].disabled = 'disabled';\\r\\n        hint_example = '';\\r\\n        doneWords_2 = $msg.lesson.done_words;\\r\\n      } else if (\\r\\n        ($msg.lesson.word_error || $msg.lesson.word_error == 0) &&\\r\\n        hints\\r\\n      ) {\\r\\n        // hints[isFlipped][$msg.lesson.word_correct].disabled = 'disabled';\\r\\n        hint_example = '';\\r\\n      } else if ($msg.lesson.word_index || $msg.lesson.word_index == 0) {\\r\\n        currentWord = words[$msg.lesson.word_index];\\r\\n        currentWordIndex = $msg.lesson.word_index;\\r\\n        showHints[isFlipped] = true;\\r\\n        label[true] = 'Заполни пропуски';\\r\\n        label[false] = 'Твой ход. Выбери слово';\\r\\n        level = $msg.lesson.level;\\r\\n        makeExample();\\r\\n        setTimeout(()=>{\\r\\n         $msg = '';\\r\\n        },10)\\r\\n    \\r\\n      } else if ($msg?.lesson.word_flip) {\\r\\n        isFlipped = $msg.lesson.word_flip;\\r\\n        $msg.lesson.word_flip = null;\\r\\n        hints[isFlipped] = hints[isFlipped];\\r\\n        showHints[isFlipped] = false;\\r\\n        label[true] = 'Ожидай вопрос';\\r\\n        resultElement = '';\\r\\n        result = '';\\r\\n        hint_example = '';\\r\\n        example = '';\\r\\n      }\\r\\n    } catch (ex) {\\r\\n      console.log(ex);\\r\\n    }\\r\\n  }\\r\\n\\r\\n  $: if ($msg?.lesson?.quiz === 'word' && $msg.lesson.isFlipped) {\\r\\n    if ($msg.lesson.word_index || $msg.lesson.word_index == 0) {\\r\\n      currentWord = words[$msg.lesson.word_index];\\r\\n      currentWordIndex = $msg.lesson.word_index;\\r\\n      label[true] = 'Заполни пропуски';\\r\\n      label[false] = 'Твой ход. Выбери слово';\\r\\n      showHints[isFlipped] = true;\\r\\n      level = $msg.lesson.level;\\r\\n      makeExample();\\r\\n    } else if ($msg?.lesson.words_data) {\\r\\n      words = $msg.lesson.words_data;\\r\\n      hints[false] = JSON.parse(JSON.stringify(words));\\r\\n      hints[true] = JSON.parse(JSON.stringify(words));\\r\\n      level = $msg.lesson.level;\\r\\n      share_mode = true;\\r\\n      isFlipped = !$msg.lesson.isFlipped;\\r\\n      showHints[isFlipped] = false;\\r\\n\\r\\n      $OnCheckQU(null, 'word', $msg.lesson.name);\\r\\n    } else if (\\r\\n      ($msg.lesson.word_correct || $msg.lesson.word_correct == 0) &&\\r\\n      hints\\r\\n    ) {\\r\\n      hints[isFlipped][$msg.lesson.word_correct].disabled = 'disabled';\\r\\n      hint_example = '';\\r\\n      doneWords_2 = $msg.lesson.done_words;\\r\\n    } else if (\\r\\n      ($msg.lesson.word_error || $msg.lesson.word_error == 0) &&\\r\\n      hints\\r\\n    ) {\\r\\n      // hints[isFlipped][$msg.lesson.word_correct].disabled = 'disabled';\\r\\n      hint_example = '';\\r\\n    } else if ($msg.lesson.word_flip) {\\r\\n      isFlipped = $msg.lesson.word_flip;\\r\\n      hints[isFlipped] = hints[isFlipped];\\r\\n      $msg.lesson.word_flip = null;\\r\\n      showHints[isFlipped] = false;\\r\\n      label[true] = 'Ожидай вопрос';\\r\\n      resultElement = '';\\r\\n      result = '';\\r\\n      hint_example = '';\\r\\n      example = '';\\r\\n    }\\r\\n  }\\r\\n\\r\\n  $: if ($msg?.msg) {\\r\\n    (async () => {\\r\\n      alert(await Translate($msg?.msg, 'ru', $langs));\\r\\n      if ($msg) $msg.msg = '';\\r\\n    })();\\r\\n  }\\r\\n\\r\\n  onMount(async () => {});\\r\\n\\r\\n  function onShare() {\\r\\n    // Обработчик нажатия на кнопку \\"share\\"\\r\\n    share_mode = true;\\r\\n    share_button_class = \`button_shared_\${share_mode}\`;\\r\\n    const lesson = {\\r\\n      lesson: {\\r\\n        quiz: 'word',\\r\\n        name: data.name,\\r\\n        llang: $llang,\\r\\n        level: level,\\r\\n        words_data: words,\\r\\n        isFlipped: isFlipped,\\r\\n      },\\r\\n    };\\r\\n    // isFlipped = !isFlipped;\\r\\n    // currentWord = words[currentWordIndex];\\r\\n    // makeExample();\\r\\n    SendData(lesson);\\r\\n    // $OnCheckQU($dc?.rtc.oper_uid, 'word', data.name);\\r\\n  }\\r\\n\\r\\n  let topAppBar;\\r\\n  let sentence_span;\\r\\n\\r\\n  export function extractWords(text) {\\r\\n    // Регулярное выражение для поиска слов в угловых скобках\\r\\n    const regex = /<<(.*?)>>/g;\\r\\n    // Массив для хранения найденных слов\\r\\n    let result = [];\\r\\n    let match;\\r\\n\\r\\n    // Поиск всех совпадений и добавление их в массив\\r\\n    while ((match = regex.exec(text)) !== null) {\\r\\n      result.push(match[1]);\\r\\n    }\\r\\n\\r\\n    return result;\\r\\n  }\\r\\n\\r\\n  function similarity(s1, s2) {\\r\\n    let longer = s1;\\r\\n    let shorter = s2;\\r\\n    if (s1.length < s2.length) {\\r\\n      longer = s2;\\r\\n      shorter = s1;\\r\\n    }\\r\\n    const longerLength = longer.length;\\r\\n    if (longerLength === 0) {\\r\\n      return 1.0;\\r\\n    }\\r\\n    return (\\r\\n      (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength)\\r\\n    );\\r\\n  }\\r\\n\\r\\n  function editDistance(s1, s2) {\\r\\n    s1 = s1.toLowerCase();\\r\\n    s2 = s2.toLowerCase();\\r\\n\\r\\n    const costs = [];\\r\\n    for (let i = 0; i <= s1.length; i++) {\\r\\n      let lastValue = i;\\r\\n      for (let j = 0; j <= s2.length; j++) {\\r\\n        if (i === 0) costs[j] = j;\\r\\n        else {\\r\\n          if (j > 0) {\\r\\n            let newValue = costs[j - 1];\\r\\n            if (s1.charAt(i - 1) !== s2.charAt(j - 1))\\r\\n              newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;\\r\\n            costs[j - 1] = lastValue;\\r\\n            lastValue = newValue;\\r\\n          }\\r\\n        }\\r\\n      }\\r\\n      if (i > 0) costs[s2.length] = lastValue;\\r\\n    }\\r\\n    return costs[s2.length];\\r\\n  }\\r\\n\\r\\n  function replaceWordWithInput(text, targetWord) {\\r\\n    const threshold = 0.8; // 90% порог\\r\\n\\r\\n    return text.replace(\\r\\n      /<<([^>]*)>>/g,\\r\\n      \`<span  value=\\"$1\\" class=\\"sentence_span\\" style=\\"position: relative;width:20px;  left: 0px; color:green; font-weight:bold\\"  onclick=OnClickInput></span>\`\\r\\n    );\\r\\n  }\\r\\n\\r\\n  function replaceWord(text, targetWord) {\\r\\n    const threshold = 0.8; // 90% порог\\r\\n\\r\\n    if (text)\\r\\n      return text.replace(\\r\\n        /<<([^>]*)>>/g,\\r\\n        \`<span  value=\\"$1\\" class=\\"sentence_span\\" style=\\"position: relative;width:20px;  left: 0px; color:green; font-weight:bold\\">$1</span>\`\\r\\n      );\\r\\n  }\\r\\n\\r\\n  async function makeExample() {\\r\\n    if (!currentWord) return;\\r\\n\\r\\n    resultElement = '';\\r\\n    example = '';\\r\\n\\r\\n    if (currentWord.example[$langs]) {\\r\\n      example = currentWord['example'][$langs];\\r\\n    } else if (currentWord.example[$llang]) {\\r\\n      example = await Translate(currentWord['example'][$llang], $llang, $langs);\\r\\n    }\\r\\n\\r\\n    const regex = /(<<\\\\w+>>)\\\\s+(<<\\\\w+>>)/;\\r\\n    const match = example.match(regex);\\r\\n    let original = '';\\r\\n    if (match) {\\r\\n      original = \`\${match[0]} \${match[1]}\`;\\r\\n    }\\r\\n    // else original = \`\${currentWord.original}\`;\\r\\n\\r\\n    resultElement = replaceWordWithInput(\\r\\n      currentWord?.example[$llang]\\r\\n        ? currentWord?.example[$llang]\\r\\n        : await Translate(currentWord.example['ru'], 'ru', $llang),\\r\\n      \`\${original}\`\\r\\n    );\\r\\n\\r\\n    if (example.includes('<<') && example.includes('>>')) {\\r\\n      example = example?.replace(\\r\\n        /<<([^<>]+)>>/gu,\\r\\n        level.includes('A1')\\r\\n          ? '<span style=\\"color:green\\" onclick=OnClickInput><b>$1</b></span>'\\r\\n          : '$1'\\r\\n      );\\r\\n    } else if (example.includes('\\"')) {\\r\\n      example = example?.replace(\\r\\n        /\\"([^\\"]+)\\"/gu,\\r\\n        level.includes('A1')\\r\\n          ? '<span style=\\"color:green\\" onclick=OnClickInput><b>$1</b></span>'\\r\\n          : '$1'\\r\\n      );\\r\\n    }\\r\\n\\r\\n    setTimeout(() => {\\r\\n      const wAr = extractWords(currentWord?.example[$llang]);\\r\\n      const spanElements = document.querySelectorAll('.sentence_span');\\r\\n      spanElements.forEach((spanElement, i) => {\\r\\n        div_input[i].style.display = '';\\r\\n        spanElement.appendChild(div_input[i]); // Используем cloneNode, чтобы не удалить div_input из DOM\\r\\n        // spanElement.style.width = \\"50px\\";\\r\\n        resultElementWidth[i] = getTextWidth(wAr[i], '20px Arial');\\r\\n      });\\r\\n    }, 100);\\r\\n\\r\\n    function getSubArray(arr, index) {\\r\\n      const totalElements = 10;\\r\\n      const halfRange = Math.floor(totalElements / 2);\\r\\n\\r\\n      let startIndex = index - halfRange;\\r\\n      let endIndex = index + halfRange;\\r\\n\\r\\n      // Корректировка начала массива, если оно меньше 0\\r\\n      if (startIndex < 0) {\\r\\n        endIndex += Math.abs(startIndex);\\r\\n        startIndex = 0;\\r\\n      }\\r\\n\\r\\n      // Корректировка конца массива, если он больше длины массива\\r\\n      if (endIndex >= arr.length) {\\r\\n        startIndex -= endIndex - arr.length + 1;\\r\\n        endIndex = arr.length - 1;\\r\\n      }\\r\\n\\r\\n      // Убедиться, что начало не ушло ниже нуля после корректировки конца\\r\\n      startIndex = Math.max(startIndex, 0);\\r\\n\\r\\n      return arr.slice(startIndex, endIndex + 1); // Включить элемент с endIndex\\r\\n    }\\r\\n\\r\\n    if (isFlipped) {\\r\\n      hints[isFlipped] = getSubArray([...words], currentWordIndex);\\r\\n      shuffle(hints[isFlipped]);\\r\\n    }\\r\\n\\r\\n    // word = currentWord['original'].replace(/(de|het)\\\\s*/gi, '');\\r\\n    // let filteredExample = currentWord['example'].replace(\\r\\n    //    new RegExp(\`\\\\\\\\b(de |het )?(?=\\\\\\\\b\${word}\\\\\\\\b)\`, 'gi'), '');\\r\\n    // resultElement = filteredExample.split(new RegExp(word, 'i'));\\r\\n    // console.log(resultElement)\\r\\n\\r\\n    // Устанавливаем фокус в конец строки\\r\\n    // setFocus();\\r\\n  }\\r\\n\\r\\n  function getTextWidth(text, font) {\\r\\n    // Создаем элемент canvas\\r\\n    const canvas = document.createElement('canvas');\\r\\n    const context = canvas.getContext('2d');\\r\\n\\r\\n    // Устанавливаем шрифт\\r\\n    context.font = font;\\r\\n\\r\\n    // Измеряем длину текста\\r\\n    const metrics = context.measureText(text);\\r\\n    return metrics.width + 20;\\r\\n  }\\r\\n\\r\\n  function OnClickHint(ev, word, i) {\\r\\n    if (!share_mode) onShare();\\r\\n\\r\\n    if (!isFlipped) {\\r\\n      const data = {\\r\\n        lesson: {\\r\\n          quiz: 'word',\\r\\n          level: level,\\r\\n          word_index: i,\\r\\n          isFlipped: isFlipped,\\r\\n        },\\r\\n      };\\r\\n      SendData(data);\\r\\n      showHints[isFlipped] = false;\\r\\n      ev.target.classList.add('selected');\\r\\n      label[false] = 'Ожидай вопрос';\\r\\n    } else {\\r\\n      showCheckButton = true;\\r\\n      div_input.forEach((di) => {\\r\\n        di.style.color = '';\\r\\n      });\\r\\n      const span_cnt = countWordOccurrences(resultElement, '<span');\\r\\n      function extractSpans(htmlString) {\\r\\n        // Создаем новый DOMParser\\r\\n        const parser = new DOMParser();\\r\\n        // Парсим HTML-строку в документ\\r\\n        const doc = parser.parseFromString(htmlString, 'text/html');\\r\\n        // Находим все элементы <span> в документе\\r\\n        const spans = doc.querySelectorAll('span');\\r\\n        // Преобразуем NodeList в массив\\r\\n        return Array.from(spans);\\r\\n      }\\r\\n\\r\\n      const arSpan = extractSpans(resultElement);\\r\\n      const words = arSpan.length > 1 ? word.split(' ') : [word];\\r\\n\\r\\n      div_input[0].style.width = '';\\r\\n\\r\\n      arSpan.forEach((el, i) => {\\r\\n        if (word.includes(el.attributes.value.nodeValue.toLowerCase())) {\\r\\n          userContent[i] = el.attributes.value.nodeValue;\\r\\n          el.style.width = getTextWidth(userContent[i], '20px Arial');\\r\\n        } else {\\r\\n          userContent[i] = words[i] ? words[i] : '';\\r\\n        }\\r\\n      });\\r\\n    }\\r\\n\\r\\n    hint_example = replaceWord(words[i].example[$langs]);\\r\\n    \\r\\n    checkInput();\\r\\n  }\\r\\n\\r\\n  async function SendData(data) {\\r\\n    if (share_mode && $dc) {\\r\\n      //  words.content[cur_qa].user2['a_shfl'] = a_shfl;\\r\\n      await $dc?.SendData(data, (ex) => {\\r\\n        console.log(ex);\\r\\n      });\\r\\n    }\\r\\n  }\\r\\n\\r\\n  // function handleBackClick() {\\r\\n  //   $lesson.data = { quiz: '' }; // При клике на \\"Back\\" показываем компонент Lesson\\r\\n  // }\\r\\n\\r\\n  function shuffle(array) {\\r\\n    for (let i = array.length - 1; i > 0; i--) {\\r\\n      const j = Math.floor(Math.random() * (i + 1));\\r\\n      [array[i], array[j]] = [array[j], array[i]];\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function onShuffleWords(ev) {\\r\\n    shuffle(words);\\r\\n    currentWordIndex = 0;\\r\\n    currentWord = words[currentWordIndex];\\r\\n    makeExample();\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    result = '&nbsp;';\\r\\n  }\\r\\n\\r\\n  function jumpNext10() {\\r\\n    const nextIndex = (parseInt(currentWordIndex / 10) + 1) * 10;\\r\\n    currentWordIndex = nextIndex;\\r\\n    currentWord = words[currentWordIndex];\\r\\n    makeExample();\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n    hintIndex = 0;\\r\\n    result = '';\\r\\n\\r\\n    showSpeakerButton = false;\\r\\n  }\\r\\n\\r\\n  function defineWordsArray() {\\r\\n    const originalArray = words;\\r\\n\\r\\n    // Определение длины массива\\r\\n    const arrayLength = originalArray.length;\\r\\n\\r\\n    // Определение количества подмассивов\\r\\n    const chunkSize = 10;\\r\\n    const numberOfChunks = Math.ceil(arrayLength / chunkSize);\\r\\n\\r\\n    // Разбиваем массив на подмассивы по 10 элементов\\r\\n    arrayOfArrays = [];\\r\\n\\r\\n    for (let i = 0; i < numberOfChunks; i++) {\\r\\n      const start = i * chunkSize;\\r\\n      const end = (i + 1) * chunkSize;\\r\\n      const chunk = originalArray.slice(start, end);\\r\\n      arrayOfArrays.push(chunk);\\r\\n    }\\r\\n\\r\\n    // console.log(arrayOfArrays);\\r\\n  }\\r\\n\\r\\n  function setFocus() {\\r\\n    setTimeout(() => {\\r\\n      const range = document.createRange();\\r\\n      const selection = window.getSelection();\\r\\n      range.selectNodeContents(div_input[0]);\\r\\n      range.collapse(false);\\r\\n      selection.removeAllRanges();\\r\\n      selection.addRange(range);\\r\\n    }, 100);\\r\\n  }\\r\\n\\r\\n  function checkInput() {\\r\\n    if (userContent.length < 1 || !userContent[0].replace(/&nbsp;/g, ''))\\r\\n      return;\\r\\n\\r\\n    let thisErrorIndex = 0;\\r\\n    const targetWords = extractWords(currentWord.example[$llang]);\\r\\n\\r\\n    let correctCount = 0;\\r\\n    result = '';\\r\\n\\r\\n    userContent.forEach((userInput, i) => {\\r\\n      // userContent[i] = '';\\r\\n      if (!userInput) userInput = userContent[0];\\r\\n      userInput = userInput\\r\\n        .replace(/&nbsp;/g, '')\\r\\n        .replace(/<\\\\/?![^>]+(>|$)/g, '')\\r\\n        .trim();\\r\\n\\r\\n      if (targetWords[i] && userInput)\\r\\n        if (\\r\\n          userInput?.toLowerCase() ===\\r\\n          targetWords[i].toLowerCase().replace('_', ' ')\\r\\n        ) {\\r\\n          // result[i] = \`<span class=\\"correct\\">\${targetWords[i]}</span>\`;\\r\\n          if (div_input[i]) div_input[i].style.color = 'green';\\r\\n          correctCount++;\\r\\n        } else {\\r\\n          if (div_input[i]) div_input[i].style.color = 'red';\\r\\n          thisErrorIndex++;\\r\\n          errorIndex++;\\r\\n        }\\r\\n    });\\r\\n\\r\\n    if (thisErrorIndex < 1) {\\r\\n      if (errorIndex < 1 && hintIndex < 1) doneWords++;\\r\\n\\r\\n      const data = {\\r\\n        lesson: {\\r\\n          quiz: 'word',\\r\\n          word_correct: currentWordIndex,\\r\\n          done_words: doneWords,\\r\\n        },\\r\\n      };\\r\\n      SendData(data);\\r\\n\\r\\n      errorIndex = 0;\\r\\n      hintIndex = 0;\\r\\n      label[true] = 'Нажми \\"Вперед\\"';\\r\\n      // speak(currentWord.example[$llang]);TODO: для fr\\r\\n      showHints[isFlipped] = false;\\r\\n      showNextButton = true;\\r\\n    } else {\\r\\n      errorIndex++;\\r\\n      errorIndex = 0;\\r\\n      label[true] = 'Исправь ошибку';\\r\\n    }\\r\\n    // console.log(targetWords.length)\\r\\n  }\\r\\n\\r\\n  function onChangeUserContent(ev) {\\r\\n    let ar = document.getElementsByClassName('empty_block');\\r\\n    if (ar.length > 0) {\\r\\n      // console.log(ar.length);\\r\\n      ar[0].remove();\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function showHint() {\\r\\n    showCheckButton = true;\\r\\n    const words = extractWords(currentWord.example[$llang]).join(' ');\\r\\n\\r\\n    let i = 0,\\r\\n      w = 0;\\r\\n\\r\\n    if (hintIndex == 0) {\\r\\n      userContent[0] = '&nbsp;';\\r\\n      userContent[1] = '&nbsp;';\\r\\n      div_input[0].style.color = '#2196f3';\\r\\n      div_input[1].style.color = '#2196f3';\\r\\n      div_input[0].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n      div_input[1].style.width = getTextWidth(words, '20px Arial') + 'px';\\r\\n    }\\r\\n\\r\\n    for (let char of words) {\\r\\n      // word = word.replace(/[.,\\\\/#!?$%\\\\^&\\\\*;:{}=_\`~()]/g, '');\\r\\n      if (char == ' ') {\\r\\n        w++;\\r\\n        if (userContent[w] === '&nbsp;') userContent[w] = '';\\r\\n        continue;\\r\\n      }\\r\\n\\r\\n      if (i === hintIndex) {\\r\\n        console.log(char);\\r\\n        userContent[w] += char;\\r\\n\\r\\n        result = ''; // Очистим результат при каждой новой подсказке\\r\\n        showSpeakerButton = true; // Устанавливаем видимость кнопки\\r\\n        setFocus();\\r\\n\\r\\n        hintIndex++;\\r\\n        break;\\r\\n      }\\r\\n\\r\\n      i++;\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function nextWord() {\\r\\n    // currentWordIndex = currentWordIndex + 1;\\r\\n    // if (currentWordIndex >= words.length) currentWordIndex = 0;\\r\\n    // currentWord = words[currentWordIndex];\\r\\n    // makeExample();\\r\\n\\r\\n    userContent[0] = '&nbsp;';\\r\\n    userContent[1] = '&nbsp;';\\r\\n\\r\\n    errorIndex = 0;\\r\\n\\r\\n    label[isFlipped] = 'Выбери слово';\\r\\n\\r\\n    resultElement = '';\\r\\n    result = '';\\r\\n    hint_example = '';\\r\\n    example = '';\\r\\n\\r\\n    hintIndex = 0;\\r\\n\\r\\n    showHints[isFlipped] = false;\\r\\n    // result = '&nbsp;';\\r\\n\\r\\n    showNextButton = false;\\r\\n    showCheckButton = false;\\r\\n    showSpeakerButton = false;\\r\\n\\r\\n    const data = {\\r\\n      lesson: {\\r\\n        quiz: 'word',\\r\\n        word_flip: isFlipped,\\r\\n      },\\r\\n    };\\r\\n    SendData(data);\\r\\n    console.log(isFlipped);\\r\\n    isFlipped = !isFlipped;\\r\\n  }\\r\\n\\r\\n  function onSpeach() {\\r\\n    speak(\\r\\n      !showNextButton\\r\\n        ? extractWords(currentWord.example[$llang]).join()\\r\\n        : currentWord.example[$llang]\\r\\n    );\\r\\n    // hintIndex++;\\r\\n    const currentWordClone = { ...currentWord };\\r\\n\\r\\n    if (currentWordIndex + 10 < words.length) {\\r\\n      words.splice(currentWordIndex + 10, 0, currentWordClone);\\r\\n    } else {\\r\\n      words.push(currentWordClone);\\r\\n    }\\r\\n  }\\r\\n\\r\\n  function speak(text) {\\r\\n    text = text.replace(/<<|>>/g, '');\\r\\n    text = text.replace(/_/g, ' ');\\r\\n    // Speak(text);\\r\\n    tts.Speak($llang, text);\\r\\n\\r\\n    // setFocus();\\r\\n  }\\r\\n\\r\\n  function countWordOccurrences(sentence, word) {\\r\\n    // Приводим предложение и слово к нижнему регистру для нечувствительности к регистру\\r\\n    const lowerSentence = sentence.toLowerCase();\\r\\n    const lowerWord = word.toLowerCase();\\r\\n\\r\\n    // Разбиваем предложение на массив слов\\r\\n    const words = lowerSentence.split(/\\\\s+/);\\r\\n\\r\\n    // Считаем количество вхождений слова\\r\\n    let count = 0;\\r\\n    words.forEach(function (w) {\\r\\n      if (w === lowerWord) {\\r\\n        count++;\\r\\n      }\\r\\n    });\\r\\n\\r\\n    return count;\\r\\n  }\\r\\n\\r\\n  function OnClickInput(el) {\\r\\n    // div_input[0].innerHTML = \\"    \\"\\r\\n    div_input[0].focus();\\r\\n    // setFocus()\\r\\n  }\\r\\n\\r\\n  function setLang(ev) {\\r\\n    let lang = ev.currentTarget.outerText;\\r\\n    let code = ISO6391.getCode(lang);\\r\\n    if (code !== 'English') {\\r\\n      $llang = code;\\r\\n    }\\r\\n    // console.log($langs);\\r\\n    lang_menu = false;\\r\\n  }\\r\\n  onDestroy(() => {\\r\\n    // Очищаем интервал при размонтировании компонента\\r\\n    $llang = _llang;\\r\\n\\r\\n    // $view = 'lesson';\\r\\n    $lesson.data.quiz = '';\\r\\n\\r\\n    $showBottomAppBar = true;\\r\\n  });\\r\\n<\/script>\\r\\n\\r\\n<!-- <link\\r\\n  rel=\\"stylesheet\\"\\r\\n  href=\\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0\\"\\r\\n/> -->\\r\\n\\r\\n<TTS bind:this={tts}></TTS>\\r\\n\\r\\n{#if words.length === 0}\\r\\n  <div style=\\"text-align:center\\">\\r\\n    <span\\r\\n      class=\\"material-symbols-outlined\\"\\r\\n      style=\\"font-size: 20px; color: blue; scale:1.5;\\"\\r\\n    >\\r\\n      <CircularProgress style=\\"height: 50px; width: 50px;\\" indeterminate />\\r\\n    </span>\\r\\n  </div>\\r\\n{:else}\\r\\n  <main>\\r\\n    <div class=\\"top-app-bar-container flexor\\">\\r\\n      <TopAppBar bind:this={topAppBar} variant=\\"fixed\\">\\r\\n        <Row>\\r\\n          <Section></Section>\\r\\n          <Section>\\r\\n            <!-- {#if share_button && $call_but_status === 'talk'} -->\\r\\n\\r\\n            <!-- <div class={share_button_class} on:click={onShare}>\\r\\n              <IconButton>\\r\\n                <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                  <path fill=\\"currentColor\\" d={mdiShareVariant} />\\r\\n                </Icon>\\r\\n              </IconButton>\\r\\n            </div> -->\\r\\n          </Section>\\r\\n\\r\\n          <Section>\\r\\n            <button class=\\"hint-button\\" on:click={showHint}>\\r\\n              <span class=\\"material-symbols-outlined\\">?</span>\\r\\n            </button>\\r\\n          </Section>\\r\\n\\r\\n          <Section>\\r\\n            <div class=\\"counter\\" style=\\"display:inline\\">\\r\\n              <p>\\r\\n                <span class=\\"mdc-typography--overline\\" style=\\"position:relative\\"\\r\\n                  >{doneWords}:{doneWords_2}\\r\\n                  <Badge\\r\\n                    position=\\"middle\\"\\r\\n                    align=\\"bottom-end - bottom-middle\\"\\r\\n                    aria-label=\\"unread count\\"\\r\\n                    style=\\"margin-right:-15px;scale:.8\\">{words.length}</Badge\\r\\n                  >\\r\\n                </span>\\r\\n              </p>\\r\\n            </div>\\r\\n          </Section>\\r\\n          <Section align=\\"end\\">\\r\\n            <span\\r\\n              class=\\"lang_span\\"\\r\\n              on:click={() => {\\r\\n                lang_menu = !lang_menu;\\r\\n              }}\\r\\n              >{(() => {\\r\\n                return $llang;\\r\\n              })()}</span\\r\\n            >\\r\\n            {#if lang_menu}\\r\\n              <div class=\\"lang_list\\">\\r\\n                {#each langs_list as lang}\\r\\n                  <div\\r\\n                    style=\\"color:black; margin:10px;font-size:smaller\\"\\r\\n                    on:click={setLang}\\r\\n                  >\\r\\n                    {lang}\\r\\n                  </div>\\r\\n                {/each}\\r\\n              </div>\\r\\n            {/if}\\r\\n          </Section>\\r\\n\\r\\n          <Section align=\\"end\\">\\r\\n            {#if isFlipped}\\r\\n              {#if showNextButton}\\r\\n                <button on:click={nextWord} class=\\"next-button\\"\\r\\n                  >{#await Translate('Вперед', 'ru', $langs) then data}\\r\\n                    {data}\\r\\n                  {/await}</button\\r\\n                >\\r\\n              {:else if showCheckButton}\\r\\n                <button on:click={checkInput} class=\\"check-button\\">\\r\\n                  {#await Translate('Проверить', 'ru', $langs) then data}\\r\\n                    {data}\\r\\n                  {/await}\\r\\n                </button>\\r\\n              {/if}\\r\\n            {/if}\\r\\n          </Section>\\r\\n        </Row>\\r\\n      </TopAppBar>\\r\\n    </div>\\r\\n\\r\\n    {#if isFlipped}\\r\\n      <div class=\\"word\\">\\r\\n        {@html example}\\r\\n      </div>\\r\\n\\r\\n      <div class=\\"input-container\\">\\r\\n        {#if resultElement}\\r\\n          {@html resultElement}\\r\\n        {/if}\\r\\n\\r\\n        <div\\r\\n          class=\\"input\\"\\r\\n          contenteditable=\\"true\\"\\r\\n          on:click={OnClickInput}\\r\\n          on:input={onChangeUserContent}\\r\\n          bind:this={div_input[0]}\\r\\n          bind:innerHTML={userContent[0]}\\r\\n          style=\\"display:none;width: {resultElementWidth[0]}px\\"\\r\\n        >\\r\\n          {@html result}\\r\\n        </div>\\r\\n        <div\\r\\n          class=\\"input\\"\\r\\n          contenteditable=\\"true\\"\\r\\n          on:input={onChangeUserContent}\\r\\n          bind:this={div_input[1]}\\r\\n          bind:innerHTML={userContent[1]}\\r\\n          style=\\"display:none;width: {resultElementWidth[1]}px\\"\\r\\n        >\\r\\n          {@html result}\\r\\n        </div>\\r\\n      </div>\\r\\n\\r\\n      <!-- {#if showSpeakerButton}\\r\\n        <div class=\\"speaker-button\\">\\r\\n          <IconButton on:click={onSpeach}>\\r\\n            <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n              <path fill=\\"currentColor\\" d={mdiVolumeHigh} />\\r\\n            </Icon>\\r\\n          </IconButton>\\r\\n        </div>\\r\\n      {/if} -->\\r\\n\\r\\n      {#await Translate(label[isFlipped], 'ru', $langs) then data}\\r\\n        <div class=\\"title\\">{data}</div>\\r\\n      {/await}\\r\\n    {:else}\\r\\n      {#await Translate(label[isFlipped], 'ru', $langs) then data}\\r\\n        <div class=\\"title\\">{data}:</div>\\r\\n      {/await}\\r\\n      {#if showHints[isFlipped]}\\r\\n        <div class=\\"hint_example\\">\\r\\n          {@html hint_example}\\r\\n        </div>\\r\\n      {/if}\\r\\n    {/if}\\r\\n\\r\\n    <div class=\\"words_div accordion-container\\">\\r\\n      {#if isFlipped}\\r\\n        {#if hints[isFlipped]?.length > 0 && showHints[isFlipped]}\\r\\n          <Content style=\\"line-height: 2.0; overflow-y:auto; height:70vh\\">\\r\\n            {#each hints[isFlipped] as hint, i}\\r\\n              <!-- {@debug isFlipped} -->\\r\\n              {#if hint?.example[$llang]}\\r\\n                <!--  -->\\r\\n                <span\\r\\n                  class=\\"hint_button {hint.disabled}\\"\\r\\n                  on:click={() => {\\r\\n                    OnClickHint(\\r\\n                      this,\\r\\n                      extractWords(hint.example[$llang]).join(' '),\\r\\n                      i\\r\\n                    );\\r\\n                  }}\\r\\n                >\\r\\n                  {@html extractWords(hint.example[$llang]).join(' ') +\\r\\n                    '&nbsp;' +\\r\\n                    '&nbsp;'}\\r\\n                </span>\\r\\n                <!-- {/if} -->\\r\\n              {:else}\\r\\n                {#await Translate(hint?.example['ru'], 'ru', $llang) then data}\\r\\n                  <span\\r\\n                    class=\\"hint_button {hint.disabled}\\"\\r\\n                    on:click={(ev) => {\\r\\n                      OnClickHint(ev, extractWords(data).join(' '), i);\\r\\n                    }}\\r\\n                  >\\r\\n                    {@html extractWords(data).join(' ') + '&nbsp;' + '&nbsp;'}\\r\\n                  </span>\\r\\n                {/await}\\r\\n              {/if}\\r\\n            {/each}\\r\\n\\r\\n            <div style=\\"height:50px\\"></div>\\r\\n          </Content>\\r\\n        {/if}\\r\\n      {:else if hints[isFlipped]?.length > 0}\\r\\n        <Content style=\\"line-height: 2.0; overflow-y:auto; height:70vh\\">\\r\\n          {#each hints[isFlipped] as hint, i}\\r\\n            <!-- {@debug isFlipped} -->\\r\\n            {#if hint?.example[$langs]}\\r\\n              <!--  -->\\r\\n              <span\\r\\n                class=\\"hint_button {hint.disabled}\\"\\r\\n                on:click={(ev) => {\\r\\n                  OnClickHint(\\r\\n                    ev,\\r\\n                    extractWords(\\r\\n                      hint?.example[isFlipped ? $llang : $langs]\\r\\n                    ).join(' '),\\r\\n                    i\\r\\n                  );\\r\\n                }}\\r\\n              >\\r\\n                {@html extractWords(hint?.example[$langs]).join(' ') +\\r\\n                  '&nbsp;' +\\r\\n                  '&nbsp;'}\\r\\n              </span>\\r\\n              <!-- {/if} -->\\r\\n            {:else}\\r\\n              {#await Translate(hint?.example['ru'], 'ru', $langs) then data}\\r\\n                <span\\r\\n                  class=\\"hint_button {hint.disabled}\\"\\r\\n                  on:click={(ev) => {\\r\\n                    OnClickHint(ev, extractWords(data).join(' '), i);\\r\\n                  }}\\r\\n                >\\r\\n                  {@html extractWords(data).join(' ') + '&nbsp;' + '&nbsp;'}\\r\\n                </span>\\r\\n              {/await}\\r\\n            {/if}\\r\\n          {/each}\\r\\n\\r\\n          <div style=\\"height:50px\\"></div>\\r\\n        </Content>\\r\\n      {/if}\\r\\n    </div>\\r\\n  </main>\\r\\n{/if}\\r\\n\\r\\n<style>\\r\\n  main {\\r\\n    /* display: inline-grid; */\\r\\n    /* transition: transform 0.3s ease-in-out; */\\r\\n    margin: 0 auto;\\r\\n    position: relative;\\r\\n    transition: transform 0.5s;\\r\\n    /* height: 80vh; */\\r\\n    top: 0px;\\r\\n  }\\r\\n\\r\\n  .flexor {\\r\\n    position: relative;\\r\\n    /* top: 30px; */\\r\\n  }\\r\\n  .title {\\r\\n    color: coral;\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    margin-top: 0px;\\r\\n    top: 70px;\\r\\n    font-size: medium;\\r\\n  }\\r\\n\\r\\n  .hint_button {\\r\\n    display: inline-block;\\r\\n    border: solid 0.1em #9f3f3f;\\r\\n    border-radius: 5px;\\r\\n    text-align: center;\\r\\n    width: auto;\\r\\n    padding-left: 8px;\\r\\n    margin: 5px;\\r\\n    background-color: transparent;\\r\\n  }\\r\\n\\r\\n  .hint_example {\\r\\n    position: relative;\\r\\n    top: 60px;\\r\\n    /* border: solid 0.1em #9f3f3f; */\\r\\n    border-radius: 5px;\\r\\n    text-align: center;\\r\\n    width: auto;\\r\\n    padding-left: 5px;\\r\\n    margin: 5px;\\r\\n    background-color: transparent;\\r\\n  }\\r\\n\\r\\n  .disabled {\\r\\n    visibility: hidden;\\r\\n  }\\r\\n\\r\\n  /* Стилизуйте компонент по вашему усмотрению */\\r\\n  .word {\\r\\n    position: relative;\\r\\n    top: 60px;\\r\\n    font-size: large;\\r\\n    flex-direction: column;\\r\\n    align-items: center;\\r\\n    margin: 2px;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .example {\\r\\n    color: #2196f3;\\r\\n  }\\r\\n\\r\\n  h1 {\\r\\n    margin-bottom: 20px;\\r\\n  }\\r\\n\\r\\n  .hidden {\\r\\n    opacity: 0;\\r\\n    pointer-events: none;\\r\\n  }\\r\\n\\r\\n  p {\\r\\n    position: relative;\\r\\n    transition: opacity 0.5s ease;\\r\\n    text-align: center;\\r\\n    font-size: xx-large;\\r\\n    margin: 0;\\r\\n  }\\r\\n\\r\\n  .speaker-button {\\r\\n    position: relative;\\r\\n    /* flex: auto; */\\r\\n    top: 0px;\\r\\n    right: 10px;\\r\\n    transform: translate(50%, 0%);\\r\\n    font-size: large;\\r\\n    z-index: 1;\\r\\n  }\\r\\n\\r\\n  .input-container {\\r\\n    display: inline-block;\\r\\n    top: 60px;\\r\\n    font-size: large;\\r\\n    font-weight: 700;\\r\\n    position: relative;\\r\\n    color: #2196f3;\\r\\n    width: 95vw;\\r\\n    margin: 0 auto;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .words_div {\\r\\n    position: relative;\\r\\n    text-align: center;\\r\\n    overflow-y: auto;\\r\\n    top: 80px;\\r\\n  }\\r\\n\\r\\n  .input {\\r\\n    position: relative;\\r\\n    /* top:3px; */\\r\\n    height: 18px;\\r\\n    display: inline-table;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    background: rgba(0, 0, 0, 0.12);\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .input:focus {\\r\\n    outline: none;\\r\\n  }\\r\\n\\r\\n  .next10-button,\\r\\n  .shuffle-button,\\r\\n  .prev-button,\\r\\n  .check-button,\\r\\n  .next-button {\\r\\n    /* margin-top: 10px; */\\r\\n    padding: 8px 10px;\\r\\n    font-size: 16px;\\r\\n    font-weight: 500;\\r\\n    border-color: #2196f3;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    color: #2196f3;\\r\\n  }\\r\\n\\r\\n  .material-symbols-outlined {\\r\\n    font-size: 15px;\\r\\n    scale: 1.5;\\r\\n    font-variation-settings:\\r\\n      'FILL' 0,\\r\\n      'wght' 400,\\r\\n      'GRAD' 0,\\r\\n      'opsz' 24;\\r\\n  }\\r\\n\\r\\n  .hint-button {\\r\\n    border: 0px;\\r\\n    color: white;\\r\\n    background-color: #2196f3;\\r\\n    border-radius: 3px;\\r\\n    padding: 8px 10px;\\r\\n  }\\r\\n  .counter {\\r\\n    /* position: absolute; */\\r\\n    background-color: #f0f0f0;\\r\\n    padding: 0px;\\r\\n    border-radius: 25px;\\r\\n    width: 50px;\\r\\n    height: 30px;\\r\\n    top: -10px;\\r\\n    left: -6px;\\r\\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .counter p {\\r\\n    margin: 0;\\r\\n    font-size: 15px;\\r\\n    color: #333;\\r\\n  }\\r\\n\\r\\n  .counter span {\\r\\n    font-weight: 700;\\r\\n    font-size: 15px;\\r\\n    color: #ff5733; /* цвет счетчика */\\r\\n  }\\r\\n\\r\\n  .lang_span {\\r\\n    font-size: large;\\r\\n  }\\r\\n\\r\\n  .lang_list {\\r\\n    position: absolute;\\r\\n    top: 50px;\\r\\n    height: 80vh;\\r\\n    overflow: auto;\\r\\n    justify-content: center; /* Выравниваем содержимое по центру вертикально */\\r\\n    align-items: center; /* Выравниваем содержимое по центру горизонтально */\\r\\n    background-color: white;\\r\\n    /* opacity: 50%; */\\r\\n  }\\r\\n\\r\\n  .selected {\\r\\n    background-color: coral;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA8gCE,gCAAK,CAGH,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,SAAS,CAAC,IAAI,CAE1B,GAAG,CAAE,GACP,CAEA,mCAAQ,CACN,QAAQ,CAAE,QAEZ,CACA,kCAAO,CACL,KAAK,CAAE,KAAK,CACZ,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,GAAG,CACf,GAAG,CAAE,IAAI,CACT,SAAS,CAAE,MACb,CAEA,wCAAa,CACX,OAAO,CAAE,YAAY,CACrB,MAAM,CAAE,KAAK,CAAC,KAAK,CAAC,OAAO,CAC3B,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,GAAG,CACjB,MAAM,CAAE,GAAG,CACX,gBAAgB,CAAE,WACpB,CAEA,yCAAc,CACZ,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CAET,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,MAAM,CAClB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,GAAG,CACjB,MAAM,CAAE,GAAG,CACX,gBAAgB,CAAE,WACpB,CAEA,qCAAU,CACR,UAAU,CAAE,MACd,CAGA,iCAAM,CACJ,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CACT,SAAS,CAAE,KAAK,CAChB,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,MAAM,CAAE,GAAG,CACX,UAAU,CAAE,MACd,CAEA,oCAAS,CACP,KAAK,CAAE,OACT,CAMA,mCAAQ,CACN,OAAO,CAAE,CAAC,CACV,cAAc,CAAE,IAClB,CAEA,6BAAE,CACA,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,OAAO,CAAC,IAAI,CAAC,IAAI,CAC7B,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,QAAQ,CACnB,MAAM,CAAE,CACV,CAEA,2CAAgB,CACd,QAAQ,CAAE,QAAQ,CAElB,GAAG,CAAE,GAAG,CACR,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,UAAU,GAAG,CAAC,CAAC,EAAE,CAAC,CAC7B,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,CACX,CAEA,4CAAiB,CACf,OAAO,CAAE,YAAY,CACrB,GAAG,CAAE,IAAI,CACT,SAAS,CAAE,KAAK,CAChB,WAAW,CAAE,GAAG,CAChB,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,OAAO,CACd,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,UAAU,CAAE,MACd,CAEA,sCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,UAAU,CAAE,MAAM,CAClB,UAAU,CAAE,IAAI,CAChB,GAAG,CAAE,IACP,CAEA,kCAAO,CACL,QAAQ,CAAE,QAAQ,CAElB,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,YAAY,CACrB,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,IAAI,CAAC,CAC/B,UAAU,CAAE,MACd,CAEA,kCAAM,MAAO,CACX,OAAO,CAAE,IACX,CAEA,0CAAc,CACd,2CAAe,CACf,wCAAY,CACZ,yCAAa,CACb,wCAAa,CAEX,OAAO,CAAE,GAAG,CAAC,IAAI,CACjB,SAAS,CAAE,IAAI,CACf,WAAW,CAAE,GAAG,CAChB,YAAY,CAAE,OAAO,CACrB,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OAAO,CACf,KAAK,CAAE,OACT,CAEA,sDAA2B,CACzB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,GAAG,CACV,uBAAuB,CACrB,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,GAAG,CAAC;AACjB,MAAM,MAAM,CAAC,CAAC,CAAC;AACf,MAAM,MAAM,CAAC,EACX,CAEA,wCAAa,CACX,MAAM,CAAE,GAAG,CACX,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,IACf,CACA,oCAAS,CAEP,gBAAgB,CAAE,OAAO,CACzB,OAAO,CAAE,GAAG,CACZ,aAAa,CAAE,IAAI,CACnB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,KAAK,CACV,IAAI,CAAE,IAAI,CACV,UAAU,CAAE,CAAC,CAAC,GAAG,CAAC,GAAG,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CACxC,UAAU,CAAE,MACd,CAEA,sBAAQ,CAAC,eAAE,CACT,MAAM,CAAE,CAAC,CACT,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,IACT,CAEA,sBAAQ,CAAC,kBAAK,CACZ,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,KAAK,CAAE,OACT,CAEA,sCAAW,CACT,SAAS,CAAE,KACb,CAEA,sCAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,IAAI,CACT,MAAM,CAAE,IAAI,CACZ,QAAQ,CAAE,IAAI,CACd,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,gBAAgB,CAAE,KAEpB,CAEA,qCAAU,CACR,gBAAgB,CAAE,KACpB"}`
};
function extractWords(text) {
  const regex = /<<(.*?)>>/g;
  let result = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[1]);
  }
  return result;
}
function replaceWordWithInput(text, targetWord) {
  return text.replace(/<<([^>]*)>>/g, `<span  value="$1" class="sentence_span" style="position: relative;width:20px;  left: 0px; color:green; font-weight:bold"  onclick=OnClickInput></span>`);
}
function getTextWidth(text, font) {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  context.font = font;
  const metrics = context.measureText(text);
  return metrics.width + 20;
}
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
const WordGame = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $showBottomAppBar, $$unsubscribe_showBottomAppBar;
  let $lesson, $$unsubscribe_lesson;
  let $llang, $$unsubscribe_llang;
  let $dc, $$unsubscribe_dc;
  let $langs, $$unsubscribe_langs;
  let $msg, $$unsubscribe_msg;
  let $OnCheckQU, $$unsubscribe_OnCheckQU;
  let $call_but_status, $$unsubscribe_call_but_status;
  let $$unsubscribe_dicts;
  $$unsubscribe_showBottomAppBar = subscribe(showBottomAppBar, (value) => $showBottomAppBar = value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  $$unsubscribe_OnCheckQU = subscribe(OnCheckQU, (value) => $OnCheckQU = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => value);
  let tts;
  let { data } = $$props;
  const abonent = getContext("abonent");
  let words = [], example = "&nbsp;";
  let hints = {};
  let currentWordIndex = 0;
  let currentWord;
  let doneWords = 0;
  let doneWords_2 = 0;
  let userContent = [];
  let div_input = [];
  let result = "&nbsp;";
  let resultElement;
  let showHints = {};
  let _llang = $llang;
  let resultElementWidth = [];
  let level = data.level;
  let share_mode = false;
  let isFlipped = false;
  let hint_example = "";
  let label = {};
  label[true] = "Ожидай вопрос";
  label[false] = "Выбери слово";
  data.name?.split(",");
  if (data.theme && data.name && level) fetch(`./lesson?words=theme&theme=${data.theme}&name=${data.name}&owner=${abonent}&level=${level}`).then((response) => response.json()).then((data2) => {
    words = data2.data.data || [];
    if (!words[0]) return;
    hints[false] = JSON.parse(JSON.stringify(words));
    hints[true] = JSON.parse(JSON.stringify(words));
    showHints[isFlipped] = true;
    if ($call_but_status !== "active" && !isFlipped) {
      onShare();
    }
  }).catch(
    (error) => {
      console.log(error);
      return [];
    }
  );
  function onShare() {
    share_mode = true;
    const lesson2 = {
      lesson: {
        quiz: "word",
        name: data.name,
        llang: $llang,
        level,
        words_data: words,
        isFlipped
      }
    };
    SendData(lesson2);
  }
  let topAppBar;
  async function makeExample() {
    if (!currentWord) return;
    resultElement = "";
    example = "";
    if (currentWord.example[$langs]) {
      example = currentWord["example"][$langs];
    } else if (currentWord.example[$llang]) {
      example = await Translate(currentWord["example"][$llang], $llang, $langs);
    }
    const regex = /(<<\w+>>)\s+(<<\w+>>)/;
    const match = example.match(regex);
    if (match) {
      `${match[0]} ${match[1]}`;
    }
    resultElement = replaceWordWithInput(
      currentWord?.example[$llang] ? currentWord?.example[$llang] : await Translate(currentWord.example["ru"], "ru", $llang)
    );
    if (example.includes("<<") && example.includes(">>")) {
      example = example?.replace(/<<([^<>]+)>>/gu, level.includes("A1") ? '<span style="color:green" onclick=OnClickInput><b>$1</b></span>' : "$1");
    } else if (example.includes('"')) {
      example = example?.replace(/"([^"]+)"/gu, level.includes("A1") ? '<span style="color:green" onclick=OnClickInput><b>$1</b></span>' : "$1");
    }
    setTimeout(
      () => {
        const wAr = extractWords(currentWord?.example[$llang]);
        const spanElements = document.querySelectorAll(".sentence_span");
        spanElements.forEach((spanElement, i) => {
          div_input[i].style.display = "";
          spanElement.appendChild(div_input[i]);
          resultElementWidth[i] = getTextWidth(wAr[i], "20px Arial");
        });
      },
      100
    );
    function getSubArray(arr, index) {
      const totalElements = 10;
      const halfRange = Math.floor(totalElements / 2);
      let startIndex = index - halfRange;
      let endIndex = index + halfRange;
      if (startIndex < 0) {
        endIndex += Math.abs(startIndex);
        startIndex = 0;
      }
      if (endIndex >= arr.length) {
        startIndex -= endIndex - arr.length + 1;
        endIndex = arr.length - 1;
      }
      startIndex = Math.max(startIndex, 0);
      return arr.slice(startIndex, endIndex + 1);
    }
    if (isFlipped) {
      hints[isFlipped] = getSubArray([...words], currentWordIndex);
      shuffle(hints[isFlipped]);
    }
  }
  async function SendData(data2) {
    if (share_mode && $dc) {
      await $dc?.SendData(data2, (ex) => {
        console.log(ex);
      });
    }
  }
  onDestroy(() => {
    set_store_value(llang, $llang = _llang, $llang);
    set_store_value(lesson, $lesson.data.quiz = "", $lesson);
    set_store_value(showBottomAppBar, $showBottomAppBar = true, $showBottomAppBar);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.extractWords === void 0 && $$bindings.extractWords && extractWords !== void 0) $$bindings.extractWords(extractWords);
  $$result.css.add(css$4);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      switch ($call_but_status) {
        case "talk":
          break;
        default:
          share_mode = false;
          break;
      }
    }
    {
      if ($langs) {
        makeExample();
      }
    }
    {
      if ($llang) {
        makeExample();
      }
    }
    {
      if ($msg?.lesson?.quiz === "word" && !$msg.lesson.isFlipped) {
        try {
          if ($msg.lesson.words_data) {
            words = $msg.lesson.words_data;
            hints[false] = JSON.parse(JSON.stringify(words));
            hints[true] = JSON.parse(JSON.stringify(words));
            isFlipped = !$msg.lesson.isFlipped;
            level = $msg.lesson.level;
            share_mode = true;
            showHints[isFlipped] = false;
            $OnCheckQU(null, "word", $msg.lesson.name);
          } else if (($msg.lesson.word_correct || $msg.lesson.word_correct == 0) && hints) {
            hints[isFlipped][$msg.lesson.word_correct].disabled = "disabled";
            hint_example = "";
            doneWords_2 = $msg.lesson.done_words;
          } else if (($msg.lesson.word_error || $msg.lesson.word_error == 0) && hints) {
            hint_example = "";
          } else if ($msg.lesson.word_index || $msg.lesson.word_index == 0) {
            currentWord = words[$msg.lesson.word_index];
            currentWordIndex = $msg.lesson.word_index;
            showHints[isFlipped] = true;
            label[true] = "Заполни пропуски";
            label[false] = "Твой ход. Выбери слово";
            level = $msg.lesson.level;
            makeExample();
            setTimeout(
              () => {
                set_store_value(msg, $msg = "", $msg);
              },
              10
            );
          } else if ($msg?.lesson.word_flip) {
            isFlipped = $msg.lesson.word_flip;
            set_store_value(msg, $msg.lesson.word_flip = null, $msg);
            hints[isFlipped] = hints[isFlipped];
            showHints[isFlipped] = false;
            label[true] = "Ожидай вопрос";
            resultElement = "";
            result = "";
            hint_example = "";
            example = "";
          }
        } catch (ex) {
          console.log(ex);
        }
      }
    }
    {
      if ($msg?.lesson?.quiz === "word" && $msg.lesson.isFlipped) {
        if ($msg.lesson.word_index || $msg.lesson.word_index == 0) {
          currentWord = words[$msg.lesson.word_index];
          currentWordIndex = $msg.lesson.word_index;
          label[true] = "Заполни пропуски";
          label[false] = "Твой ход. Выбери слово";
          showHints[isFlipped] = true;
          level = $msg.lesson.level;
          makeExample();
        } else if ($msg?.lesson.words_data) {
          words = $msg.lesson.words_data;
          hints[false] = JSON.parse(JSON.stringify(words));
          hints[true] = JSON.parse(JSON.stringify(words));
          level = $msg.lesson.level;
          share_mode = true;
          isFlipped = !$msg.lesson.isFlipped;
          showHints[isFlipped] = false;
          $OnCheckQU(null, "word", $msg.lesson.name);
        } else if (($msg.lesson.word_correct || $msg.lesson.word_correct == 0) && hints) {
          hints[isFlipped][$msg.lesson.word_correct].disabled = "disabled";
          hint_example = "";
          doneWords_2 = $msg.lesson.done_words;
        } else if (($msg.lesson.word_error || $msg.lesson.word_error == 0) && hints) {
          hint_example = "";
        } else if ($msg.lesson.word_flip) {
          isFlipped = $msg.lesson.word_flip;
          hints[isFlipped] = hints[isFlipped];
          set_store_value(msg, $msg.lesson.word_flip = null, $msg);
          showHints[isFlipped] = false;
          label[true] = "Ожидай вопрос";
          resultElement = "";
          result = "";
          hint_example = "";
          example = "";
        }
      }
    }
    {
      if ($msg?.msg) {
        (async () => {
          alert(await Translate($msg?.msg, "ru", $langs));
          if ($msg) set_store_value(msg, $msg.msg = "", $msg);
        })();
      }
    }
    $$rendered = ` ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${words.length === 0 ? `<div style="text-align:center"><span class="material-symbols-outlined svelte-7qx74n" style="font-size: 20px; color: blue; scale:1.5;">${validate_component(CircularProgress, "CircularProgress").$$render(
      $$result,
      {
        style: "height: 50px; width: 50px;",
        indeterminate: true
      },
      {},
      {}
    )}</span></div>` : `<main class="svelte-7qx74n"><div class="top-app-bar-container flexor svelte-7qx74n">${validate_component(TopAppBar, "TopAppBar").$$render(
      $$result,
      { variant: "fixed", this: topAppBar },
      {
        this: ($$value) => {
          topAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Row, "Row").$$render($$result, {}, {}, {
            default: () => {
              return `${validate_component(Section$1, "Section").$$render($$result, {}, {}, {})} ${validate_component(Section$1, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return ` `;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return `<button class="hint-button svelte-7qx74n" data-svelte-h="svelte-197iwd0"><span class="material-symbols-outlined svelte-7qx74n">?</span></button>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, {}, {}, {
                default: () => {
                  return `<div class="counter svelte-7qx74n" style="display:inline"><p class="svelte-7qx74n"><span class="mdc-typography--overline svelte-7qx74n" style="position:relative">${escape(doneWords)}:${escape(doneWords_2)} ${validate_component(Badge, "Badge").$$render(
                    $$result,
                    {
                      position: "middle",
                      align: "bottom-end - bottom-middle",
                      "aria-label": "unread count",
                      style: "margin-right:-15px;scale:.8"
                    },
                    {},
                    {
                      default: () => {
                        return `${escape(words.length)}`;
                      }
                    }
                  )}</span></p></div>`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `<span class="lang_span svelte-7qx74n">${escape(/* @__PURE__ */ (() => {
                    return $llang;
                  })())}</span> ${``}`;
                }
              })} ${validate_component(Section$1, "Section").$$render($$result, { align: "end" }, {}, {
                default: () => {
                  return `${isFlipped ? `${`${``}`}` : ``}`;
                }
              })}`;
            }
          })}`;
        }
      }
    )}</div> ${isFlipped ? `<div class="word svelte-7qx74n"><!-- HTML_TAG_START -->${example}<!-- HTML_TAG_END --></div> <div class="input-container svelte-7qx74n">${resultElement ? `<!-- HTML_TAG_START -->${resultElement}<!-- HTML_TAG_END -->` : ``} <div class="input svelte-7qx74n" contenteditable="true" style="${"display:none;width: " + escape(resultElementWidth[0], true) + "px"}"${add_attribute("this", div_input[0], 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent[0])}</div> <div class="input svelte-7qx74n" contenteditable="true" style="${"display:none;width: " + escape(resultElementWidth[1], true) + "px"}"${add_attribute("this", div_input[1], 0)}>${(($$value) => $$value === void 0 ? `<!-- HTML_TAG_START -->${result}<!-- HTML_TAG_END -->` : $$value)(userContent[1])}</div></div>  ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-7qx74n">${escape(data2)}</div> `;
      }(__value);
    }(Translate(label[isFlipped], "ru", $langs))}` : `${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data2) {
        return ` <div class="title svelte-7qx74n">${escape(data2)}:</div> `;
      }(__value);
    }(Translate(label[isFlipped], "ru", $langs))} ${showHints[isFlipped] ? `<div class="hint_example svelte-7qx74n"><!-- HTML_TAG_START -->${hint_example}<!-- HTML_TAG_END --></div>` : ``}`} <div class="words_div accordion-container svelte-7qx74n">${isFlipped ? `${hints[isFlipped]?.length > 0 && showHints[isFlipped] ? `${validate_component(Content, "Content").$$render(
      $$result,
      {
        style: "line-height: 2.0; overflow-y:auto; height:70vh"
      },
      {},
      {
        default: () => {
          return `${each(hints[isFlipped], (hint, i) => {
            return ` ${hint?.example[$llang] ? ` <span class="${"hint_button " + escape(hint.disabled, true) + " svelte-7qx74n"}"><!-- HTML_TAG_START -->${extractWords(hint.example[$llang]).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --></span> ` : `${function(__value) {
              if (is_promise(__value)) {
                __value.then(null, noop);
                return ``;
              }
              return function(data2) {
                return ` <span class="${"hint_button " + escape(hint.disabled, true) + " svelte-7qx74n"}"><!-- HTML_TAG_START -->${extractWords(data2).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --></span> `;
              }(__value);
            }(Translate(hint?.example["ru"], "ru", $llang))}`}`;
          })} <div style="height:50px"></div>`;
        }
      }
    )}` : ``}` : `${hints[isFlipped]?.length > 0 ? `${validate_component(Content, "Content").$$render(
      $$result,
      {
        style: "line-height: 2.0; overflow-y:auto; height:70vh"
      },
      {},
      {
        default: () => {
          return `${each(hints[isFlipped], (hint, i) => {
            return ` ${hint?.example[$langs] ? ` <span class="${"hint_button " + escape(hint.disabled, true) + " svelte-7qx74n"}"><!-- HTML_TAG_START -->${extractWords(hint?.example[$langs]).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --></span> ` : `${function(__value) {
              if (is_promise(__value)) {
                __value.then(null, noop);
                return ``;
              }
              return function(data2) {
                return ` <span class="${"hint_button " + escape(hint.disabled, true) + " svelte-7qx74n"}"><!-- HTML_TAG_START -->${extractWords(data2).join(" ") + "&nbsp;&nbsp;"}<!-- HTML_TAG_END --></span> `;
              }(__value);
            }(Translate(hint?.example["ru"], "ru", $langs))}`}`;
          })} <div style="height:50px"></div>`;
        }
      }
    )}` : ``}`}</div></main>`}`;
  } while (!$$settled);
  $$unsubscribe_showBottomAppBar();
  $$unsubscribe_lesson();
  $$unsubscribe_llang();
  $$unsubscribe_dc();
  $$unsubscribe_langs();
  $$unsubscribe_msg();
  $$unsubscribe_OnCheckQU();
  $$unsubscribe_call_but_status();
  $$unsubscribe_dicts();
  return $$rendered;
});
const Quiz = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $call_but_status, $$unsubscribe_call_but_status;
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  let { data } = $$props;
  let quiz = data.quiz;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe_call_but_status();
  return `<div></div>  ${quiz ? `${quiz.includes("dialog") ? `${validate_component(Dialog_1, "Dialog").$$render($$result, { data }, {}, {})}` : `${quiz.includes("bricks") ? `${validate_component(Bricks, "Bricks").$$render($$result, { data }, {}, {})}` : `${quiz.includes("listen") ? `${data.name === "Nummers" ? `${validate_component(Numbers, "Numbers").$$render($$result, { data }, {}, {})}` : `${data.name === "Tijd" ? `${validate_component(Time, "Time").$$render($$result, { data }, {}, {})}` : `${validate_component(Listen, "Listen").$$render($$result, { data }, {}, {})}`}`}` : `${quiz === "word" ? `${$call_but_status === "talk" ? `${validate_component(WordGame, "WordGame").$$render($$result, { data }, {}, {})}` : `${$call_but_status === "inactive" || $call_but_status === "active" ? `${validate_component(Word, "Word").$$render($$result, { data }, {}, {})}` : `<div style="text-align:center"><span class="material-symbols-outlined" style="position: relative;font-size: 20px; top:20vh; color: blue; scale:1.5;">${validate_component(CircularProgress, "CircularProgress").$$render(
    $$result,
    {
      style: "height: 50px; width: 50px;",
      indeterminate: true
    },
    {},
    {}
  )}</span></div>`}`}` : ``}`}`}`}` : ``}`;
});
const css$3 = {
  code: ":root{--accent-color:rgba(225, 55, 55, 0.8)}.mdc-typography--subtitle2{font-size:large}.icon-wrapper.svelte-rasag7{position:relative;display:inline-block;width:20px;height:20px;left:-5px}.new-badge.svelte-rasag7{position:absolute;color:red;font-size:10px;top:-12px;left:-5px;background-color:transparent;border-radius:3px;padding:1px 1px;z-index:1}main.svelte-rasag7{position:fixed;top:50px;left:0;height:100vh;overflow-y:auto;width:100vw;margin:0 auto;background-color:#fff;font-size:large}.user-cards.svelte-rasag7{display:flex;justify-content:flex-start;margin-left:20px;border:#80808047  solid 0px;border-radius:5px;width:88vw;overflow-x:auto}.quiz-container.svelte-rasag7{display:flex;position:relative;justify-content:start;align-items:center;padding:5px;margin-top:10px}.grammar.svelte-rasag7{margin-left:30px;font-style:italic;font-size:small;font-weight:400}.form-field-container.svelte-rasag7{position:absolute;top:0;right:40px;z-index:2}@media screen and (min-width: 768px){.mdc-typography--subtitle2.svelte-rasag7{font-size:1.2em}a.svelte-rasag7{font-size:1.4em}}",
  map: `{"version":3,"file":"Module.svelte","sources":["Module.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy, setContext, getContext } from \\"svelte\\";\\nimport moment from \\"moment\\";\\nmoment.locale(\\"nl-be\\");\\nimport { Translate } from \\"../translate/Transloc.js\\";\\nimport pkg from \\"lodash\\";\\nconst { find, findIndex, remove } = pkg;\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport Badge from \\"@smui-extra/badge\\";\\nimport Card, { PrimaryAction, Media, MediaContent } from \\"@smui/card\\";\\nimport { mdiAccountMultiple, mdiTextBoxOutline, mdiCardTextOutline, mdiEarHearing, mdiFileWordBoxOutline } from \\"@mdi/js\\";\\nimport Accordion, { Panel, Header, Content } from \\"@smui-extra/accordion\\";\\nimport Textfield from \\"@smui/textfield\\";\\nimport Autocomplete from \\"@smui-extra/autocomplete\\";\\nimport Checkbox from \\"@smui/checkbox\\";\\nimport Quiz from \\"./quiz/Quiz.svelte\\";\\nconst bricks_icon = \`<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 24 24\\" fill=\\"currentColor\\">\\n  <rect x=\\"3\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\n  <rect x=\\"13\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\n  <rect x=\\"3\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\n  <rect x=\\"9\\" y=\\"8\\" width=\\"6\\" height=\\"3\\" />\\n  <rect x=\\"17\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\n  <rect x=\\"3\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\n  <rect x=\\"13\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\n  <rect x=\\"3\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\n  <rect x=\\"9\\" y=\\"18\\" width=\\"6\\" height=\\"3\\" />\\n  <rect x=\\"17\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\n</svg>\`;\\nimport { signal, users, langs, llang, msg, dc, call_but_status, showBottomAppBar, OnCheckQU } from \\"$lib/js/stores.js\\";\\nlet lesson_data;\\nexport let group;\\nlet gr_field = \\"\\";\\nconst operator = getContext(\\"operator\\");\\nfunction findPic(operator2) {\\n  const oper = find(group, { operator: operator2 });\\n  return oper.picture || \\"/assets/operator.svg\\";\\n}\\nimport tutor_src from \\"$lib/images/tutor.png\\";\\nimport { view } from \\"$lib/js/stores.js\\";\\nimport { lesson } from \\"$lib/js/stores.js\\";\\nlet disabled = [\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true,\\n  true\\n];\\nexport let data;\\nconst icons = {\\n  dialog: mdiAccountMultiple,\\n  text: mdiTextBoxOutline,\\n  word: mdiFileWordBoxOutline,\\n  listen: mdiEarHearing\\n};\\n$: if ($lesson.data) {\\n  if ($lesson.data.quiz == \\"\\" && data.quiz) {\\n    SendDataDC({ msg: \\"\\\\u0421\\\\u043E\\\\u0431\\\\u0435\\\\u0441\\\\u0435\\\\u0434\\\\u043D\\\\u0438\\\\u043A \\\\u0432\\\\u044B\\\\u0448\\\\u0435\\\\u043B \\\\u0438\\\\u0437 \\\\u0443\\\\u043F\\\\u0440\\\\u0430\\\\u0436\\\\u043D\\\\u0435\\\\u043D\\\\u0438\\\\u044F\\" });\\n    data = $lesson.data;\\n  }\\n  data = $lesson.data;\\n}\\nlet module, main;\\nlet panel_disabled = true;\\nlet checked = { dialog: {}, word: {} };\\nlet quiz_users = { dialog: {}, word: {} };\\n$: if (Array.isArray($msg)) {\\n  try {\\n    $msg.map((el) => {\\n      if (el.add && $users[el.add]) {\\n        BuildQuizUsers(el.quiz, el.add, el.type);\\n        $msg = \\"\\";\\n      } else if (el.rem) {\\n        RemoveQuizUser(el.rem, el.type, el.quiz);\\n      }\\n    });\\n  } catch (ex) {\\n  }\\n}\\nexport async function fetchLesson(owner, operator2) {\\n  try {\\n    const response = await fetch(\`./lesson?lesson=\${operator2}&owner=\${owner}\`);\\n    if (!response.ok) {\\n      throw new Error(\\"Failed to fetch data\\");\\n    }\\n    const data2 = await response.json();\\n    return data2;\\n  } catch (error) {\\n    console.error(error);\\n    return [];\\n  }\\n}\\nonMount(async () => {\\n  const lessonData = await fetchLesson(operator.abonent, operator.operator);\\n  lesson_data = lessonData.data;\\n  module = lesson_data.module;\\n  $llang = lesson_data.lang;\\n  $showBottomAppBar = true;\\n});\\nfunction onClickQuiz(type, level, theme, name) {\\n  try {\\n    data.theme = theme.name[$llang];\\n    lesson_data?.module.themes.map((theme2) => {\\n      theme2.new_cnt = 0;\\n    });\\n    data.name = name;\\n    data.llang = $llang;\\n    data.level = level;\\n    data.quiz = type;\\n    main.scrollTo(0, -200);\\n  } catch (ex) {\\n    console.log(ex);\\n  }\\n}\\nfunction disablePanel(node) {\\n  try {\\n    let t = node.attributes[\\"t\\"].value;\\n    disabled[parseInt(t)] = false;\\n  } catch (ex) {\\n  }\\n}\\n$OnCheckQU = function(node, type_, name_) {\\n  const name = name_ || node.currentTarget.attributes[\\"name\\"].value;\\n  const type = type_ || node.currentTarget.attributes[\\"type\\"].value;\\n  let par = {};\\n  par.proj = \\"kolmit\\";\\n  par.func = \\"quiz_users\\";\\n  par.abonent = operator.abonent;\\n  par.quiz = name;\\n  par.type = type;\\n  if (checked[type][name] === false || checked[type][name] === null) {\\n    par.add = operator.operator;\\n  } else {\\n    par.rem = operator.operator;\\n  }\\n  $signal.SendMessage(par, (data2) => {\\n    console.log(data2.resp);\\n  });\\n};\\nlet RemoveQuizUser = function(user, type, quiz) {\\n  try {\\n    let obj = find(quiz_users[type][quiz], { operator: user });\\n    obj.type = $msg.type;\\n    remove(quiz_users[type][quiz], obj);\\n    quiz_users = quiz_users;\\n    $msg.rem = \\"\\";\\n  } catch (ex) {\\n  }\\n};\\nfunction BuildQuizUsers(quiz, user, type) {\\n  let usersPic = group.map((item) => ({\\n    operator: item.operator,\\n    src: findPic(item.operator),\\n    name: item.name,\\n    status: item.status\\n  }));\\n  let obj = find(usersPic, { operator: user });\\n  if (obj)\\n    obj.type = type;\\n  if (obj && !find(quiz_users[type][quiz], obj)) {\\n    quiz_users[type][quiz].push(obj);\\n    quiz_users[type][quiz] = quiz_users[type][quiz];\\n    quiz_users = quiz_users;\\n  }\\n}\\nfunction GetSubscribers(node, msg2) {\\n  let par = {};\\n  par.proj = \\"kolmit\\";\\n  par.func = \\"get_subscribers\\";\\n  par.abonent = operator.abonent || msg2.abonent;\\n  par.quiz = node?.attributes[\\"name\\"].value || msg2.quiz;\\n  par.level = lesson_data.level;\\n  par.type = node?.attributes[\\"type\\"].value || msg2.type;\\n  if (!checked[par.type])\\n    return;\\n  checked[par.type][par.quiz] = false;\\n  if (!quiz_users[par.type][par.quiz])\\n    quiz_users[par.type][par.quiz] = [];\\n  $signal.SendMessage(par, (data2) => {\\n    if (data2 && data2.resp) {\\n      const key = Object.keys(data2.resp)[0];\\n      data2.resp[key].subscribers.map((user) => {\\n        const quiz = data2.resp.word?.quiz || data2.resp.dialog?.quiz;\\n        const key2 = Object.keys(data2.resp)[0];\\n        BuildQuizUsers(quiz, user, key2);\\n        if (user === operator.operator) {\\n          checked[key2][data2.resp[key2].quiz] = true;\\n          return;\\n        }\\n      });\\n      if (data2.resp[key].operators)\\n        console.log(data2.resp[key].operators);\\n    }\\n  });\\n}\\nasync function OnClickUserCard(user, theme, module2, quiz) {\\n  await new Promise((resolve) => {\\n    $users[user][\\"OnClickCallButton\\"](resolve);\\n  }).catch((error) => console.error(\\"\\\\u041E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430:\\", error));\\n  onClickQuiz(quiz.type, lesson_data.level, theme, quiz.name[$llang]);\\n}\\nfunction SendDataDC(data2, cb) {\\n  if ($dc?.dc.readyState === \\"open\\") {\\n    $dc.SendData(data2, (res) => {\\n      if (cb)\\n        cb(res);\\n    });\\n  }\\n}\\nonDestroy(() => {\\n  data = \\"\\";\\n  lesson_data = \\"\\";\\n  module = \\"\\";\\n  quiz_users = \\"\\";\\n});\\nasync function OnThemeNameInput(theme) {\\n  theme.name = await Translate(theme.name[$llang], $llang, $langs);\\n  module = module;\\n}\\nfunction isNew(publishedDate, theme) {\\n  if (Date.now() - new Date(publishedDate).getTime() < 5 * 24 * 60 * 60 * 1e3) {\\n    if (!theme.new_cnt)\\n      theme.new_cnt = 0;\\n    theme.new_cnt++;\\n    return true;\\n  }\\n  return false;\\n}\\n<\/script>\\r\\n\\r\\n<main bind:this={main}>\\r\\n  {#if data.quiz}\\r\\n    <!-- {@debug data} -->\\r\\n    <Quiz {data} />\\r\\n  {:else if module}\\r\\n\\r\\n\\r\\n      {#each module.themes as theme, t}\\r\\n        <br />\\r\\n        <div class=\\"accordion-container\\">\\r\\n          <Accordion multiple>\\r\\n            <Panel class=\\"panel\\" disabled={disabled[parseInt(t)]}>\\r\\n              {#await Translate(theme.name[$llang], $llang, $langs) then data}\\r\\n                <Header\\r\\n                  :use={theme.name[$llang]\\r\\n                    ? theme.name[$llang]\\r\\n                    : (() => {\\r\\n                        OnThemeNameInput(theme);\\r\\n                      })()}\\r\\n                  ><div class=\\"mdc-typography--subtitle2\\">\\r\\n                    {theme.name[$llang]}\\r\\n                    {#if theme.new_cnt>0}\\r\\n                    <span style=\\"color:red\\">({theme.new_cnt})</span>\\r\\n                    {/if}<br />\\r\\n\\r\\n                  </div>\\r\\n                  </Header\\r\\n                >{/await} \\r\\n              <Content>\\r\\n\\r\\n                  {#if theme.grammar}  \\r\\n                   <div>\\r\\n                      <Autocomplete  label=\\"grammatica\\" style=\\"pointer-events: none;font-size:small;margin-left:30px\\"/>                \\r\\n                      \\r\\n                        {#each theme.grammar as theme}          \\r\\n                          <div class=\\"grammar\\">{theme}</div>\\r\\n                        {/each}\\r\\n                      \\r\\n                    </div>  \\r\\n                  {/if}\\r\\n\\r\\n                {#if theme.lessons}\\r\\n                  {#each theme.lessons as lesson}\\r\\n                    {#if lesson.quizes}\\r\\n                      {#each lesson.quizes as quiz}\\r\\n                        {#if quiz.name[$llang] && quiz.published}\\r\\n                          <div\\r\\n                            class=\\"quiz-container mdc-typography--caption\\"\\r\\n                            type={quiz.type}\\r\\n                            use:GetSubscribers\\r\\n                            name={quiz.name[$llang]}\\r\\n                          >\\r\\n                          <div class=\\"icon-wrapper\\">\\r\\n                            <div>\\r\\n                              {#if isNew(quiz.published, theme)}\\r\\n                              {#await Translate('новый', 'ru', $llang) then data}\\r\\n                                <span  class=\\"new-badge\\">{data}</span>\\r\\n                                {/await}\\r\\n                              {/if}\\r\\n                            </div>\\r\\n                      \\r\\n                          \\r\\n                            {#if quiz.type==='bricks'}\\r\\n                              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" width=\\"20px\\" height=\\"20px\\"  fill=\\"grey\\" scale='.5'>\\r\\n                                <rect x=\\"3\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                <rect x=\\"13\\" y=\\"3\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                <rect x=\\"3\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                <rect x=\\"9\\" y=\\"8\\" width=\\"6\\" height=\\"3\\" />\\r\\n                                <rect x=\\"17\\" y=\\"8\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                <rect x=\\"3\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                <rect x=\\"13\\" y=\\"13\\" width=\\"8\\" height=\\"3\\" />\\r\\n                                <rect x=\\"3\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\r\\n                                <rect x=\\"9\\" y=\\"18\\" width=\\"6\\" height=\\"3\\" />\\r\\n                                <rect x=\\"17\\" y=\\"18\\" width=\\"4\\" height=\\"3\\" />\\r\\n                              </Icon>\\r\\n\\r\\n                            {:else if icons[quiz.type]}\\r\\n                              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\" width=\\"20px\\" height=\\"20px\\">\\r\\n                                <path fill=\\"grey\\" d={icons[quiz.type]} />\\r\\n                              </Icon>\\r\\n                            {/if}\\r\\n                          </div>                        \\r\\n                            <a\\r\\n                              href=\\"#\\"\\r\\n                              use:disablePanel\\r\\n                              on:click={() => {\\r\\n                                onClickQuiz(\\r\\n                                  quiz.type,\\r\\n                                  lesson_data.level,\\r\\n                                  theme,\\r\\n                                  quiz.name[$llang]\\r\\n                                );\\r\\n             \\r\\n                              }}\\r\\n                              style=\\"width:100%;font-size:medium;\\"\\r\\n                              {t}\\r\\n                              type={quiz.type}\\r\\n                              name={quiz.name[$llang]}\\r\\n                              level={module.level}\\r\\n                              theme={theme.name[$llang]}\\r\\n                              title={quiz.title}\\r\\n                              highlight={quiz.highlight || ''}\\r\\n                              >{quiz.name[$llang]}\\r\\n                            </a><span />\\r\\n\\r\\n                            {#if $call_but_status!=='inactive' && (quiz.type === 'dialog' || quiz.type === 'word')}\\r\\n \\r\\n                              <div class=\\"form-field-container\\">\\r\\n                         \\r\\n                                  <Checkbox\\r\\n                                    on:click={$OnCheckQU}\\r\\n                                    name={quiz.name[$llang]}\\r\\n                                    type={quiz.type}\\r\\n                                    bind:checked={checked[quiz.type][\\r\\n                                      quiz.name[$llang]\\r\\n                                    ]}\\r\\n                                    touch\\r\\n                                  ></Checkbox>\\r\\n                       \\r\\n                              </div>\\r\\n                            {/if}\\r\\n                          </div>\\r\\n\\r\\n                          {#if $call_but_status !== 'inactive' && quiz_users[quiz.type] && quiz_users[quiz.type][quiz.name[$llang]]}\\r\\n                            <div class=\\"user-cards\\">\\r\\n                              {#each quiz_users[quiz.type][quiz.name[$llang]] as qu, q}\\r\\n                                {#if qu.operator !== operator.operator && find( group, { operator: qu.operator } )}\\r\\n                                  <div\\r\\n                                    on:click={() => {\\r\\n                                      OnClickUserCard(\\r\\n                                        qu.operator,\\r\\n                                        theme,\\r\\n                                        module,\\r\\n                                        quiz\\r\\n                                      );\\r\\n                                    }}\\r\\n                                    operator={qu.operator}\\r\\n                                    {t}\\r\\n                                  >\\r\\n                                    <Card\\r\\n                                      style=\\"width:30px;  margin-right:15px\\"\\r\\n                                    >\\r\\n                                      <Media\\r\\n                                        class=\\"card-media-square\\"\\r\\n                                        aspectRatio=\\"square\\"\\r\\n                                      >\\r\\n                                        <MediaContent>\\r\\n                                          <img\\r\\n                                            src={qu.src}\\r\\n                                            alt=\\"\\"\\r\\n                                            width=\\"22px\\"\\r\\n                                            style=\\"position:relative; left:3px\\"\\r\\n                                          />\\r\\n                                        </MediaContent>\\r\\n                                      </Media>\\r\\n                                      <!-- <Content style=\\"color: #888; font-size:smaller\\">{name}</Content> -->\\r\\n                                      <h3\\r\\n                                        class=\\"mdc-typography--subtitle2\\"\\r\\n                                        style=\\"margin: -7px; color: #888;font-size:x-small;text-align:center;z-index:1\\"\\r\\n                                      >\\r\\n                                        {#if qu.name}\\r\\n                                          {qu.name.slice(0, 8)}\\r\\n                                        {:else}\\r\\n                                          {qu.operator.slice(0, 8)}\\r\\n                                        {/if}\\r\\n                                      </h3>\\r\\n                                    </Card>\\r\\n                                  </div>\\r\\n                                {/if}\\r\\n                              {/each}\\r\\n                            </div>\\r\\n                          {/if}\\r\\n                        {/if}\\r\\n                      {/each}\\r\\n                      <div  style=\\"height:150px\\"></div>\\r\\n                    {/if}\\r\\n                  {/each}\\r\\n                {/if}\\r\\n              </Content>\\r\\n            </Panel>\\r\\n          </Accordion>\\r\\n        </div>\\r\\n      {/each}\\r\\n\\r\\n    <div style=\\"height:50px\\"></div>\\r\\n  {/if}\\r\\n</main>\\r\\n\\r\\n<style>\\r\\n  :root {\\r\\n    --accent-color: rgba(225, 55, 55, 0.8);\\r\\n  }\\r\\n\\r\\n  :global(.mdc-typography--subtitle2){\\r\\n    font-size: large;\\r\\n  }\\r\\n\\r\\n  \\r\\n  .icon-wrapper {\\r\\n    position: relative;\\r\\n    display: inline-block; /* Позволяет корректно позиционировать вложенные элементы */\\r\\n    width: 20px;\\r\\n    height: 20px;\\r\\n    left:-5px;\\r\\n  }\\r\\n\\r\\n  .new-badge {\\r\\n    position: absolute;\\r\\n    color: red;\\r\\n    font-size: 10px; /* Подбирайте размер шрифта для лучшей читаемости */\\r\\n    top: -12px; /* Расположение над иконкой */\\r\\n    left: -5px; /* Расположение справа */\\r\\n    background-color: transparent; /* Для контраста, опционально */\\r\\n    border-radius: 3px; /* Слегка закругляем для стилистики */\\r\\n    padding: 1px 1px; /* Отступы для лучшего внешнего вида */\\r\\n    z-index: 1; /* Чтобы текст отображался поверх иконки */\\r\\n  }\\r\\n  main {\\r\\n    position: fixed;\\r\\n    top: 50px;\\r\\n    left: 0;\\r\\n    height: 100vh;\\r\\n    overflow-y: auto;\\r\\n    width: 100vw;\\r\\n    margin: 0 auto;\\r\\n    background-color: #fff;\\r\\n    font-size: large;\\r\\n    /*transition: transform 0.3s ease-in-out;\\r\\n\\r\\n    position: relative;\\r\\n    transform-style: preserve-3d;\\r\\n    transition: transform 0.5s; */\\r\\n\\r\\n    /* margin-top: 40px; */\\r\\n  }\\r\\n  .module_level {\\r\\n    position: fixed;\\r\\n    color: white;\\r\\n    background-color: var(--accent-color);\\r\\n    top: 60px;\\r\\n    left: 20px;\\r\\n    transform: translate(-50%, -50%);\\r\\n    z-index: 1;\\r\\n  }\\r\\n\\r\\n  .user-cards {\\r\\n    display: flex;\\r\\n    justify-content: flex-start;\\r\\n    margin-left: 20px;\\r\\n    border: #80808047  solid 0px;\\r\\n    border-radius: 5px;\\r\\n    width: 88vw;\\r\\n    overflow-x: auto;\\r\\n  }\\r\\n  \\r\\n\\r\\n  .lesson-container {\\r\\n    /* height: 120vh; */\\r\\n\\r\\n    overflow-y: auto;\\r\\n    overflow-x: hidden;\\r\\n    max-width: 100%;\\r\\n    padding-top: 10px;\\r\\n    height: 120vh;\\r\\n    scrollbar-width: none;\\r\\n    -ms-overflow-style: none;\\r\\n  }\\r\\n  .quiz-container {\\r\\n    display: flex;\\r\\n    position: relative;\\r\\n    justify-content: start;\\r\\n    align-items: center;\\r\\n    padding: 5px; /* Установите желаемый отступ вокруг элемента */\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  .grammar{\\r\\n    margin-left:30px;\\r\\n    font-style: italic;\\r\\n    font-size: small;\\r\\n    font-weight: 400;\\r\\n  }\\r\\n\\r\\n\\r\\n  .form-field-container {\\r\\n    position: absolute; /* Отключает влияние на другие элементы */\\r\\n    top: 0; /* Настраивайте по месту в зависимости от дизайна */\\r\\n    right: 40px; /* Закрепляет к правому краю */\\r\\n    z-index: 2; /* Позволяет перекрывать другие элементы, если требуется */\\r\\n  }\\r\\n\\r\\n  @media screen and (min-width: 768px) {\\r\\n\\t\\t/* Ваши стили для более крупных экранов здесь */\\r\\n    .mdc-typography--subtitle2 {\\r\\n     font-size: 1.2em;\\r\\n    }\\r\\n    a{\\r\\n      font-size: 1.4em;\\r\\n    }\\r\\n\\t}\\r\\n\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAyaE,KAAM,CACJ,cAAc,CAAE,sBAClB,CAEQ,0BAA2B,CACjC,SAAS,CAAE,KACb,CAGA,2BAAc,CACZ,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,YAAY,CACrB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,KAAK,IACP,CAEA,wBAAW,CACT,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,GAAG,CACV,SAAS,CAAE,IAAI,CACf,GAAG,CAAE,KAAK,CACV,IAAI,CAAE,IAAI,CACV,gBAAgB,CAAE,WAAW,CAC7B,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,GAAG,CAChB,OAAO,CAAE,CACX,CACA,kBAAK,CACH,QAAQ,CAAE,KAAK,CACf,GAAG,CAAE,IAAI,CACT,IAAI,CAAE,CAAC,CACP,MAAM,CAAE,KAAK,CACb,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,gBAAgB,CAAE,IAAI,CACtB,SAAS,CAAE,KAQb,CAWA,yBAAY,CACV,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,UAAU,CAC3B,WAAW,CAAE,IAAI,CACjB,MAAM,CAAE,SAAS,EAAE,KAAK,CAAC,GAAG,CAC5B,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,IAAI,CACX,UAAU,CAAE,IACd,CAcA,6BAAgB,CACd,OAAO,CAAE,IAAI,CACb,QAAQ,CAAE,QAAQ,CAClB,eAAe,CAAE,KAAK,CACtB,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,GAAG,CACZ,UAAU,CAAE,IACd,CAEA,sBAAQ,CACN,YAAY,IAAI,CAChB,UAAU,CAAE,MAAM,CAClB,SAAS,CAAE,KAAK,CAChB,WAAW,CAAE,GACf,CAGA,mCAAsB,CACpB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,CAAC,CACN,KAAK,CAAE,IAAI,CACX,OAAO,CAAE,CACX,CAEA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAEnC,wCAA2B,CAC1B,SAAS,CAAE,KACZ,CACA,eAAC,CACC,SAAS,CAAE,KACb,CACH"}`
};
async function fetchLesson(owner, operator2) {
  try {
    const response = await fetch(`./lesson?lesson=${operator2}&owner=${owner}`);
    if (!response.ok) {
      throw new Error("Failed to fetch data");
    }
    const data2 = await response.json();
    return data2;
  } catch (error) {
    console.error(error);
    return [];
  }
}
function isNew(publishedDate, theme) {
  if (Date.now() - new Date(publishedDate).getTime() < 5 * 24 * 60 * 60 * 1e3) {
    if (!theme.new_cnt) theme.new_cnt = 0;
    theme.new_cnt++;
    return true;
  }
  return false;
}
const Module = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $llang, $$unsubscribe_llang;
  let $dc, $$unsubscribe_dc;
  let $users, $$unsubscribe_users;
  let $signal, $$unsubscribe_signal;
  let $msg, $$unsubscribe_msg;
  let $OnCheckQU, $$unsubscribe_OnCheckQU;
  let $$unsubscribe_showBottomAppBar;
  let $lesson, $$unsubscribe_lesson;
  let $call_but_status, $$unsubscribe_call_but_status;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_users = subscribe(users, (value) => $users = value);
  $$unsubscribe_signal = subscribe(signal, (value) => $signal = value);
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  $$unsubscribe_OnCheckQU = subscribe(OnCheckQU, (value) => $OnCheckQU = value);
  $$unsubscribe_showBottomAppBar = subscribe(showBottomAppBar, (value) => value);
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  moment.locale("nl-be");
  const { find, findIndex, remove } = pkg;
  let { group } = $$props;
  const operator = getContext("operator");
  function findPic(operator2) {
    const oper = find(group, { operator: operator2 });
    return oper.picture || "/assets/operator.svg";
  }
  let disabled = [true, true, true, true, true, true, true, true, true, true, true, true, true];
  let { data } = $$props;
  const icons = {
    dialog: mdiAccountMultiple,
    text: mdiTextBoxOutline,
    word: mdiFileWordBoxOutline,
    listen: mdiEarHearing
  };
  let module, main;
  let checked = { dialog: {}, word: {} };
  let quiz_users = { dialog: {}, word: {} };
  set_store_value(
    OnCheckQU,
    $OnCheckQU = function(node, type_, name_) {
      const name = name_ || node.currentTarget.attributes["name"].value;
      const type = type_ || node.currentTarget.attributes["type"].value;
      let par = {};
      par.proj = "kolmit";
      par.func = "quiz_users";
      par.abonent = operator.abonent;
      par.quiz = name;
      par.type = type;
      if (checked[type][name] === false || checked[type][name] === null) {
        par.add = operator.operator;
      } else {
        par.rem = operator.operator;
      }
      $signal.SendMessage(par, (data2) => {
        console.log(data2.resp);
      });
    },
    $OnCheckQU
  );
  let RemoveQuizUser = function(user, type, quiz) {
    try {
      let obj = find(quiz_users[type][quiz], { operator: user });
      obj.type = $msg.type;
      remove(quiz_users[type][quiz], obj);
      quiz_users = quiz_users;
      set_store_value(msg, $msg.rem = "", $msg);
    } catch (ex) {
    }
  };
  function BuildQuizUsers(quiz, user, type) {
    let usersPic = group.map((item) => ({
      operator: item.operator,
      src: findPic(item.operator),
      name: item.name,
      status: item.status
    }));
    let obj = find(usersPic, { operator: user });
    if (obj) obj.type = type;
    if (obj && !find(quiz_users[type][quiz], obj)) {
      quiz_users[type][quiz].push(obj);
      quiz_users[type][quiz] = quiz_users[type][quiz];
      quiz_users = quiz_users;
    }
  }
  function SendDataDC(data2, cb) {
    if ($dc?.dc.readyState === "open") {
      $dc.SendData(data2, (res) => {
      });
    }
  }
  onDestroy(() => {
    data = "";
    module = "";
    quiz_users = "";
  });
  async function OnThemeNameInput(theme) {
    theme.name = await Translate(theme.name[$llang], $llang, $langs);
    module = module;
  }
  if ($$props.group === void 0 && $$bindings.group && group !== void 0) $$bindings.group(group);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.fetchLesson === void 0 && $$bindings.fetchLesson && fetchLesson !== void 0) $$bindings.fetchLesson(fetchLesson);
  $$result.css.add(css$3);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($lesson.data) {
        if ($lesson.data.quiz == "" && data.quiz) {
          SendDataDC({
            msg: "Собеседник вышел из упражнения"
          });
          data = $lesson.data;
        }
        data = $lesson.data;
      }
    }
    {
      if (Array.isArray($msg)) {
        try {
          $msg.map((el) => {
            if (el.add && $users[el.add]) {
              BuildQuizUsers(el.quiz, el.add, el.type);
              set_store_value(msg, $msg = "", $msg);
            } else if (el.rem) {
              RemoveQuizUser(el.rem, el.type, el.quiz);
            }
          });
        } catch (ex) {
        }
      }
    }
    $$rendered = `<main class="svelte-rasag7"${add_attribute("this", main, 0)}>${data.quiz ? ` ${validate_component(Quiz, "Quiz").$$render($$result, { data }, {}, {})}` : `${module ? `${each(module.themes, (theme, t) => {
      return `<br> <div class="accordion-container">${validate_component(Accordion, "Accordion").$$render($$result, { multiple: true }, {}, {
        default: () => {
          return `${validate_component(Panel, "Panel").$$render(
            $$result,
            {
              class: "panel",
              disabled: disabled[parseInt(t)]
            },
            {},
            {
              default: () => {
                return `${function(__value) {
                  if (is_promise(__value)) {
                    __value.then(null, noop);
                    return ``;
                  }
                  return function(data2) {
                    return ` ${validate_component(Header$1, "Header").$$render(
                      $$result,
                      {
                        ":use": theme.name[$llang] ? theme.name[$llang] : (() => {
                          OnThemeNameInput(theme);
                        })()
                      },
                      {},
                      {
                        default: () => {
                          return `<div class="mdc-typography--subtitle2 svelte-rasag7">${escape(theme.name[$llang])} ${theme.new_cnt > 0 ? `<span style="color:red">(${escape(theme.new_cnt)})</span> ` : ``}<br></div> `;
                        }
                      }
                    )}`;
                  }();
                }(Translate(theme.name[$llang], $llang, $langs))} ${validate_component(Content, "Content").$$render($$result, {}, {}, {
                  default: () => {
                    return `${theme.grammar ? `<div>${validate_component(Autocomplete, "Autocomplete").$$render(
                      $$result,
                      {
                        label: "grammatica",
                        style: "pointer-events: none;font-size:small;margin-left:30px"
                      },
                      {},
                      {}
                    )} ${each(theme.grammar, (theme2) => {
                      return `<div class="grammar svelte-rasag7">${escape(theme2)}</div>`;
                    })} </div>` : ``} ${theme.lessons ? `${each(theme.lessons, (lesson2) => {
                      return `${lesson2.quizes ? `${each(lesson2.quizes, (quiz) => {
                        return `${quiz.name[$llang] && quiz.published ? `<div class="quiz-container mdc-typography--caption svelte-rasag7"${add_attribute("type", quiz.type, 0)}${add_attribute("name", quiz.name[$llang], 0)}><div class="icon-wrapper svelte-rasag7"><div>${isNew(quiz.published, theme) ? `${function(__value) {
                          if (is_promise(__value)) {
                            __value.then(null, noop);
                            return ``;
                          }
                          return function(data2) {
                            return ` <span class="new-badge svelte-rasag7">${escape(data2)}</span> `;
                          }(__value);
                        }(Translate("новый", "ru", $llang))}` : ``}</div> ${quiz.type === "bricks" ? `${validate_component(CommonIcon, "Icon").$$render(
                          $$result,
                          {
                            tag: "svg",
                            viewBox: "0 0 24 24",
                            width: "20px",
                            height: "20px",
                            fill: "grey",
                            scale: ".5"
                          },
                          {},
                          {
                            default: () => {
                              return `<rect x="3" y="3" width="8" height="3"></rect> <rect x="13" y="3" width="8" height="3"></rect> <rect x="3" y="8" width="4" height="3"></rect> <rect x="9" y="8" width="6" height="3"></rect> <rect x="17" y="8" width="4" height="3"></rect> <rect x="3" y="13" width="8" height="3"></rect> <rect x="13" y="13" width="8" height="3"></rect> <rect x="3" y="18" width="4" height="3"></rect> <rect x="9" y="18" width="6" height="3"></rect> <rect x="17" y="18" width="4" height="3"></rect> `;
                            }
                          }
                        )}` : `${icons[quiz.type] ? `${validate_component(CommonIcon, "Icon").$$render(
                          $$result,
                          {
                            tag: "svg",
                            viewBox: "0 0 24 24",
                            width: "20px",
                            height: "20px"
                          },
                          {},
                          {
                            default: () => {
                              return `<path fill="grey"${add_attribute("d", icons[quiz.type], 0)}></path> `;
                            }
                          }
                        )}` : ``}`}</div> <a href="#" style="width:100%;font-size:medium;"${add_attribute("t", t, 0)}${add_attribute("type", quiz.type, 0)}${add_attribute("name", quiz.name[$llang], 0)}${add_attribute("level", module.level, 0)}${add_attribute("theme", theme.name[$llang], 0)}${add_attribute("title", quiz.title, 0)}${add_attribute("highlight", quiz.highlight || "", 0)} class="svelte-rasag7">${escape(quiz.name[$llang])} </a><span></span> ${$call_but_status !== "inactive" && (quiz.type === "dialog" || quiz.type === "word") ? `<div class="form-field-container svelte-rasag7">${validate_component(Checkbox, "Checkbox").$$render(
                          $$result,
                          {
                            name: quiz.name[$llang],
                            type: quiz.type,
                            touch: true,
                            checked: checked[quiz.type][quiz.name[$llang]]
                          },
                          {
                            checked: ($$value) => {
                              checked[quiz.type][quiz.name[$llang]] = $$value;
                              $$settled = false;
                            }
                          },
                          {}
                        )} </div>` : ``}</div> ${$call_but_status !== "inactive" && quiz_users[quiz.type] && quiz_users[quiz.type][quiz.name[$llang]] ? `<div class="user-cards svelte-rasag7">${each(quiz_users[quiz.type][quiz.name[$llang]], (qu, q) => {
                          return `${qu.operator !== operator.operator && find(group, { operator: qu.operator }) ? `<div${add_attribute("operator", qu.operator, 0)}${add_attribute("t", t, 0)}>${validate_component(Card, "Card").$$render($$result, { style: "width:30px;  margin-right:15px" }, {}, {
                            default: () => {
                              return `${validate_component(Media, "Media").$$render(
                                $$result,
                                {
                                  class: "card-media-square",
                                  aspectRatio: "square"
                                },
                                {},
                                {
                                  default: () => {
                                    return `${validate_component(MediaContent, "MediaContent").$$render($$result, {}, {}, {
                                      default: () => {
                                        return `<img${add_attribute("src", qu.src, 0)} alt="" width="22px" style="position:relative; left:3px"> `;
                                      }
                                    })} `;
                                  }
                                }
                              )}  <h3 class="mdc-typography--subtitle2 svelte-rasag7" style="margin: -7px; color: #888;font-size:x-small;text-align:center;z-index:1">${qu.name ? `${escape(qu.name.slice(0, 8))}` : `${escape(qu.operator.slice(0, 8))}`}</h3> `;
                            }
                          })} </div>` : ``}`;
                        })} </div>` : ``}` : ``}`;
                      })} <div style="height:150px"></div>` : ``}`;
                    })}` : ``} `;
                  }
                })} `;
              }
            }
          )} `;
        }
      })} </div>`;
    })} <div style="height:50px"></div>` : ``}`} </main>`;
  } while (!$$settled);
  $$unsubscribe_langs();
  $$unsubscribe_llang();
  $$unsubscribe_dc();
  $$unsubscribe_users();
  $$unsubscribe_signal();
  $$unsubscribe_msg();
  $$unsubscribe_OnCheckQU();
  $$unsubscribe_showBottomAppBar();
  $$unsubscribe_lesson();
  $$unsubscribe_call_but_status();
  return $$rendered;
});
const css$2 = {
  code: ".chat-container.svelte-8yelu5{display:flex;flex-direction:column-reverse;position:absolute;width:100dvw;height:70vh;background-color:#f4f4f8;border-radius:10px;box-shadow:0 0 10px rgba(0, 0, 0, 0.1)}.userMessage.svelte-8yelu5{margin:5px;padding:5px;border-radius:5px;user-select:text;-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text}.userMessage.question.svelte-8yelu5{width:88%;background-color:#cce5ff;float:left}.userMessage.answer.svelte-8yelu5{width:88%;background-color:#e0e0e0;float:right}.input-container.svelte-8yelu5{display:flex;position:fixed;flex-direction:row;justify-content:space-between;bottom:60px;padding:0 10px;width:95vw}.speaker-button.svelte-8yelu5{position:relative;top:5px}.original.svelte-8yelu5{font-size:x-small;color:rgb(40, 72, 113)}button.svelte-8yelu5{position:relative;bottom:0px}.textarea-container.svelte-8yelu5{position:relative;display:inline-block;width:96vw;margin-left:2vw;bottom:-3px}.mic-button.svelte-8yelu5{position:absolute;top:50%;right:10px;transform:translateY(-50%);background:transparent;border:none;font-size:20px;cursor:pointer}.hint-button.svelte-8yelu5{color:white;background-color:#2196f3;border-radius:3px;padding:8px 20px}",
  map: `{"version":3,"file":"Сhat.svelte","sources":["Сhat.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount } from \\"svelte\\";\\nimport { Translate } from \\"../../translate/Transloc.ts\\";\\nimport { langs, llang, dc, msg } from \\"$lib/js/stores.js\\";\\n$llang = \\"nl\\";\\nimport { mdiPagePreviousOutline, mdiArrowRight, mdiArrowLeft, mdiShareVariant, mdiMicrophone, mdiMicrophoneOutline, mdiAccountConvertOutline, mdiVolumeHigh, mdiPlay, mdiHelp } from \\"@mdi/js\\";\\nimport Button, { Label } from \\"@smui/button\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport Stt from \\"../../speech/stt/Stt.svelte\\";\\nlet stt;\\nimport TTS from \\"../../speech/tts/Tts.svelte\\";\\nlet tts;\\nlet userInput = {};\\nlet messages = [];\\nlet isListening = false;\\nlet display_audio = \\"none\\";\\nlet variant = \\"outlined\\";\\nlet showHint;\\nlet to;\\n$: if ($msg || $msg) {\\n  const msg2 = $msg || $msg;\\n  if (msg2.func === \\"chat\\") {\\n    messages.unshift({ text: msg2.text, isQuestion: \\"answer\\" });\\n    messages = messages;\\n  }\\n}\\nasync function callChat(text) {\\n  try {\\n    if (to)\\n      clearTimeout(to);\\n    let question = { text, lang: $langs, llang: $llang };\\n    const response = await fetch(\`./operator/chat\`, {\\n      method: \\"POST\\",\\n      body: JSON.stringify({ question }),\\n      headers: { \\"Content-Type\\": \\"application/json\\" }\\n    });\\n    if (!response.ok) {\\n      throw new Error(\`HTTP error! Status: \${response.status}\`);\\n    }\\n    const data = await response.json();\\n    messages.unshift({ text: data.res, isQuestion: \\"answer\\" });\\n    messages = messages;\\n    to = setTimeout(() => {\\n    }, 2e4);\\n  } catch (error) {\\n    console.error(\\"\\\\u041F\\\\u0440\\\\u043E\\\\u0438\\\\u0437\\\\u043E\\\\u0448\\\\u043B\\\\u0430 \\\\u043E\\\\u0448\\\\u0438\\\\u0431\\\\u043A\\\\u0430 \\\\u043F\\\\u0440\\\\u0438 \\\\u043E\\\\u0431\\\\u0440\\\\u0430\\\\u0449\\\\u0435\\\\u043D\\\\u0438\\\\u0438 \\\\u043A \\\\u0441\\\\u0435\\\\u0440\\\\u0432\\\\u0435\\\\u0440\\\\u0443:\\", error);\\n  }\\n}\\nfunction handleKeyDown(event) {\\n  if (event.key === \\"Enter\\" && !event.shiftKey) {\\n    event.preventDefault();\\n    callChat();\\n    SendDC(\\"\\");\\n  }\\n}\\nonMount(() => {\\n  SendDC(\\"Hallo\\");\\n});\\nasync function speak(text) {\\n  if (text)\\n    tts.Speak_server($llang, text, \\"chat\\");\\n}\\nfunction micClicked() {\\n  if (!isListening) {\\n    isListening = true;\\n    if (dc) {\\n      stt.startAudioMonitoring($langs, $llang);\\n    } else {\\n      stt.startAudioMonitoring($llang, $langs);\\n    }\\n  } else {\\n    stt.MediaRecorderStop();\\n    isListening = false;\\n  }\\n}\\nfunction StopListening() {\\n  isListening = false;\\n  display_audio = false;\\n}\\nfunction SttResult(data) {\\n  if (data[$llang])\\n    userInput = data;\\n  userInput[$llang] = userInput[$llang].slice(0, 500);\\n  messages.unshift({ text: userInput, isQuestion: \\"question\\" });\\n  messages = messages;\\n  isListening = false;\\n}\\nfunction SendDC(text) {\\n  if ($dc) {\\n    $dc.SendData({\\n      func: \\"chat\\",\\n      lang: $llang,\\n      text: text ? text : \\"test\\"\\n    }, () => {\\n      console.log();\\n    });\\n  } else {\\n  }\\n}\\nfunction SendRepeat() {\\n  variant = \\"unelevated\\";\\n  setTimeout(() => {\\n    variant = \\"outlined\\";\\n  }, 1e3);\\n  if ($dc) {\\n    $dc.SendData({\\n      command: \\"repeat\\"\\n    }, () => {\\n      console.log();\\n    });\\n  }\\n}\\nfunction ShowHint(index) {\\n  showHint = index;\\n}\\n<\/script>\\r\\n\\r\\n<div class=\\"chat-container\\" style=\\"overflow-y: auto;\\">\\r\\n  {#each messages as { text, isQuestion }, index (index)}\\r\\n    <div style=\\"display:inline-flex\\">\\r\\n      <div class=\\"userMessage {isQuestion}\\" key={index}>\\r\\n        {text[$llang]}\\r\\n        {#if text[$langs] && showHint===index}\\r\\n          {#await Translate(text[$llang], $llang, $langs) then data}\\r\\n            <div class=\\"original\\">{data}</div>\\r\\n          {/await} \\r\\n\\r\\n          {:else}\\r\\n            <button class=\\"hint-button\\" on:click={()=>{ShowHint(index)}}>\\r\\n              <span class=\\"material-symbols-outlined\\"> ? </span>\\r\\n              <!-- <IconButton class=\\"material-icons\\" on:click={()=>{}}>\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                <path fill=\\"currentColor\\" d={mdiHelp} />\\r\\n              </Icon>\\r\\n            </IconButton> -->\\r\\n            </button>\\r\\n        {/if}\\r\\n      </div>\\r\\n      <div class=\\"speaker-button\\">\\r\\n        <IconButton on:click={speak(text[$llang])}>\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n            <path fill=\\"currentColor\\" d={mdiPlay} />\\r\\n          </Icon>\\r\\n        </IconButton>\\r\\n      </div>\\r\\n    </div>\\r\\n  {/each}\\r\\n</div>\\r\\n<br />\\r\\n\\r\\n<!-- <div\\r\\n  class=\\"margins\\"\\r\\n  style=\\"text-align: center; display: flex; align-items: center; justify-content: space-between;\\"\\r\\n> -->\\r\\n<div class=\\"input-container\\">\\r\\n     <span style=\\"position: absolute;\\r\\n    font-weight: bold;\\r\\n    top: 8px;\\r\\n    left: 26px;\\r\\n    font-size: x-small\\">{dc?$langs:$llang}</span>\\r\\n  <IconButton on:click={micClicked}>\\r\\n    <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n      {#if isListening}\\r\\n        <path fill=\\"currentColor\\" d={mdiMicrophone} />\\r\\n      {:else}\\r\\n        <path fill=\\"currentColor\\" d={mdiMicrophoneOutline} />\\r\\n      {/if}\\r\\n    </Icon>   \\r\\n  </IconButton>\\r\\n\\r\\n  <Stt bind:this={stt} bind:display_audio {SttResult} {StopListening}></Stt>\\r\\n\\r\\n  <TTS bind:this={tts}></TTS>\\r\\n\\r\\n  {#if $dc}\\r\\n\\r\\n    {#await Translate('Отправить', 'ru', $langs) then data}\\r\\n      <Button\\r\\n        on:click={() => {\\r\\n          // stt.SendRecognition()\\r\\n          SendDC(userInput[$llang]);\\r\\n        }}><Label>{data}</Label></Button\\r\\n      >\\r\\n    {/await}\\r\\n\\r\\n\\r\\n    <div class=\\"repeat_but\\">\\r\\n      {#await Translate('Повторить', 'ru', $langs) then data}\\r\\n        <Button on:click={() => SendRepeat()} {variant}>\\r\\n          <Label>{data}</Label>\\r\\n        </Button>\\r\\n      {/await}\\r\\n    </div>\\r\\n  {/if}\\r\\n</div>\\r\\n\\r\\n<!-- </div> -->\\r\\n\\r\\n<!-- <div class=\\"input-container\\">\\r\\n\\r\\n  <div class=\\"mic-button\\">\\r\\n    <IconButton on:click={micClicked}>\\r\\n      <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n        {#if isListening}\\r\\n          <path fill=\\"currentColor\\" d={mdiMicrophone} />\\r\\n        {:else}\\r\\n          <path fill=\\"currentColor\\" d={mdiMicrophoneOutline} />\\r\\n        {/if}\\r\\n      </Icon>\\r\\n    </IconButton>\\r\\n  </div>\\r\\n</div> -->\\r\\n\\r\\n<!-- <div class=\\"textarea-container\\">\\r\\n  <textarea\\r\\n    id=\\"myTextarea\\"\\r\\n    maxlength=\\"500\\"\\r\\n    bind:value={userInput[$langs]}\\r\\n    on:keydown={handleKeyDown}\\r\\n    placeholder=\\"Задайте вопрос...\\"\\r\\n  ></textarea>\\r\\n</div> -->\\r\\n\\r\\n<style>\\r\\n  .chat-container {\\r\\n    display: flex;\\r\\n    flex-direction: column-reverse;\\r\\n    position: absolute;\\r\\n    width: 100dvw;\\r\\n    height: 70vh;\\r\\n    background-color: #f4f4f8;\\r\\n    border-radius: 10px;\\r\\n    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\\r\\n    /* padding-bottom: 6px;  */\\r\\n  }\\r\\n\\r\\n  .userMessage {\\r\\n    margin: 5px;\\r\\n    padding: 5px;\\r\\n    border-radius: 5px;\\r\\n    user-select: text;\\r\\n    -webkit-user-select: text; /* для совместимости с Safari */\\r\\n    -moz-user-select: text; /* для совместимости с Firefox */\\r\\n    -ms-user-select: text; /* для совместимости с IE10+ */\\r\\n  }\\r\\n\\r\\n  .userMessage.question {\\r\\n    width: 88%;\\r\\n    background-color: #cce5ff;\\r\\n    float: left;\\r\\n  }\\r\\n\\r\\n  .userMessage.answer {\\r\\n    width: 88%;\\r\\n    background-color: #e0e0e0;\\r\\n    /* margin-left: 60px; */\\r\\n    float: right;\\r\\n  }\\r\\n\\r\\n  .input-container {\\r\\n    display: flex;\\r\\n    position: fixed;\\r\\n    flex-direction: row;\\r\\n    justify-content: space-between;\\r\\n    bottom: 60px;\\r\\n    padding: 0 10px; /* Добавляем отступы */\\r\\n    width: 95vw;\\r\\n  }\\r\\n\\r\\n  .speaker-button {\\r\\n    position: relative;\\r\\n    top: 5px;\\r\\n  }\\r\\n\\r\\n  .original {\\r\\n    font-size: x-small;\\r\\n    color: rgb(40, 72, 113);\\r\\n  }\\r\\n\\r\\n  button {\\r\\n    position: relative;\\r\\n    bottom: 0px; /* Кнопка выше нижней границы на 30px */\\r\\n  }\\r\\n\\r\\n  .textarea-container {\\r\\n    position: relative;\\r\\n    display: inline-block;\\r\\n    width: 96vw;\\r\\n    margin-left: 2vw;\\r\\n    bottom: -3px;\\r\\n  }\\r\\n\\r\\n  .textarea-container textarea {\\r\\n    height: 10vh;\\r\\n    position: relative;\\r\\n    bottom: 0;\\r\\n    width: 98%;\\r\\n  }\\r\\n\\r\\n  .mic-button {\\r\\n    position: absolute;\\r\\n    top: 50%;\\r\\n    right: 10px; /* Отступ от правого края контейнера */\\r\\n    transform: translateY(-50%); /* Центрирование по вертикали */\\r\\n    background: transparent;\\r\\n    border: none;\\r\\n    font-size: 20px; /* Размер иконки */\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n    .hint-button {\\r\\n    color: white;\\r\\n    background-color: #2196f3;\\r\\n    border-radius: 3px;\\r\\n    padding: 8px 20px;\\r\\n  }\\r\\n\\r\\n  /* Стилизация textarea и кнопки по желанию */\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA+NE,6BAAgB,CACd,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,cAAc,CAC9B,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,MAAM,CACb,MAAM,CAAE,IAAI,CACZ,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,IAAI,CACnB,UAAU,CAAE,CAAC,CAAC,CAAC,CAAC,IAAI,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAExC,CAEA,0BAAa,CACX,MAAM,CAAE,GAAG,CACX,OAAO,CAAE,GAAG,CACZ,aAAa,CAAE,GAAG,CAClB,WAAW,CAAE,IAAI,CACjB,mBAAmB,CAAE,IAAI,CACzB,gBAAgB,CAAE,IAAI,CACtB,eAAe,CAAE,IACnB,CAEA,YAAY,uBAAU,CACpB,KAAK,CAAE,GAAG,CACV,gBAAgB,CAAE,OAAO,CACzB,KAAK,CAAE,IACT,CAEA,YAAY,qBAAQ,CAClB,KAAK,CAAE,GAAG,CACV,gBAAgB,CAAE,OAAO,CAEzB,KAAK,CAAE,KACT,CAEA,8BAAiB,CACf,OAAO,CAAE,IAAI,CACb,QAAQ,CAAE,KAAK,CACf,cAAc,CAAE,GAAG,CACnB,eAAe,CAAE,aAAa,CAC9B,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,CAAC,CAAC,IAAI,CACf,KAAK,CAAE,IACT,CAEA,6BAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GACP,CAEA,uBAAU,CACR,SAAS,CAAE,OAAO,CAClB,KAAK,CAAE,IAAI,EAAE,CAAC,CAAC,EAAE,CAAC,CAAC,GAAG,CACxB,CAEA,oBAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,GACV,CAEA,iCAAoB,CAClB,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,YAAY,CACrB,KAAK,CAAE,IAAI,CACX,WAAW,CAAE,GAAG,CAChB,MAAM,CAAE,IACV,CASA,yBAAY,CACV,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,WAAW,IAAI,CAAC,CAC3B,UAAU,CAAE,WAAW,CACvB,MAAM,CAAE,IAAI,CACZ,SAAS,CAAE,IAAI,CACf,MAAM,CAAE,OACV,CAEE,0BAAa,CACb,KAAK,CAAE,KAAK,CACZ,gBAAgB,CAAE,OAAO,CACzB,aAAa,CAAE,GAAG,CAClB,OAAO,CAAE,GAAG,CAAC,IACf"}`
};
const UD0uA1hat = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dc, $$unsubscribe_dc;
  let $llang, $$unsubscribe_llang;
  let $langs, $$unsubscribe_langs;
  let $msg, $$unsubscribe_msg;
  $$unsubscribe_dc = subscribe(dc, (value) => $dc = value);
  $$unsubscribe_llang = subscribe(llang, (value) => $llang = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  set_store_value(llang, $llang = "nl", $llang);
  let stt;
  let tts;
  let userInput = {};
  let messages = [];
  let isListening = false;
  let display_audio = "none";
  let variant = "outlined";
  let showHint;
  function StopListening() {
    isListening = false;
    display_audio = false;
  }
  function SttResult(data) {
    if (data[$llang]) userInput = data;
    userInput[$llang] = userInput[$llang].slice(0, 500);
    messages.unshift({ text: userInput, isQuestion: "question" });
    messages = messages;
    isListening = false;
  }
  $$result.css.add(css$2);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($msg || $msg) {
        const msg2 = $msg || $msg;
        if (msg2.func === "chat") {
          messages.unshift({ text: msg2.text, isQuestion: "answer" });
          messages = messages;
        }
      }
    }
    $$rendered = `<div class="chat-container svelte-8yelu5" style="overflow-y: auto;">${each(messages, ({ text, isQuestion }, index) => {
      return `<div style="display:inline-flex"><div class="${"userMessage " + escape(isQuestion, true) + " svelte-8yelu5"}"${add_attribute("key", index, 0)}>${escape(text[$llang])} ${text[$langs] && showHint === index ? `${function(__value) {
        if (is_promise(__value)) {
          __value.then(null, noop);
          return ``;
        }
        return function(data) {
          return ` <div class="original svelte-8yelu5">${escape(data)}</div> `;
        }(__value);
      }(Translate(text[$llang], $llang, $langs))}` : `<button class="hint-button svelte-8yelu5" data-svelte-h="svelte-1cd2e1n"><span class="material-symbols-outlined">?</span>  </button>`}</div> <div class="speaker-button svelte-8yelu5">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
        default: () => {
          return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
            default: () => {
              return `<path fill="currentColor"${add_attribute("d", mdiPlay, 0)}></path> `;
            }
          })} `;
        }
      })}</div> </div>`;
    })}</div> <br>  <div class="input-container svelte-8yelu5"><span style="position: absolute; font-weight: bold; top: 8px; left: 26px; font-size: x-small">${escape(dc ? $langs : $llang)}</span> ${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
          default: () => {
            return `${isListening ? `<path fill="currentColor"${add_attribute("d", mdiMicrophone, 0)}></path>` : `<path fill="currentColor"${add_attribute("d", mdiMicrophoneOutline, 0)}></path>`}`;
          }
        })}`;
      }
    })} ${validate_component(Stt, "Stt").$$render(
      $$result,
      {
        SttResult,
        StopListening,
        this: stt,
        display_audio
      },
      {
        this: ($$value) => {
          stt = $$value;
          $$settled = false;
        },
        display_audio: ($$value) => {
          display_audio = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${validate_component(Tts, "TTS").$$render(
      $$result,
      { this: tts },
      {
        this: ($$value) => {
          tts = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${$dc ? `${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Button, "Button").$$render($$result, {}, {}, {
          default: () => {
            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
              default: () => {
                return `${escape(data)}`;
              }
            })}`;
          }
        })} `;
      }(__value);
    }(Translate("Отправить", "ru", $langs))} <div class="repeat_but">${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Button, "Button").$$render($$result, { variant }, {}, {
          default: () => {
            return `${validate_component(CommonLabel, "Label").$$render($$result, {}, {}, {
              default: () => {
                return `${escape(data)}`;
              }
            })}`;
          }
        })} `;
      }(__value);
    }(Translate("Повторить", "ru", $langs))}</div>` : ``}</div>   `;
  } while (!$$settled);
  $$unsubscribe_dc();
  $$unsubscribe_llang();
  $$unsubscribe_langs();
  $$unsubscribe_msg();
  return $$rendered;
});
const css$1 = {
  code: '@charset "UTF-8";.bottom-app-bar-wrapper.svelte-s4wswc{position:fixed;bottom:0;width:100%;transform:translateY(0);transition:transform 0.7s ease}.hide.svelte-s4wswc{transform:translateY(100px);transition:transform 0.7s ease}.dialog.svelte-s4wswc{position:fixed;background-color:aliceblue;top:40px;width:100vw;height:90vh;right:0vw;margin:0px auto;z-index:2}.remote_msg.svelte-s4wswc{position:relative;font-size:0.7em;white-space:nowrap;color:black;margin:auto;text-align:center;top:-10px;z-index:1}.user_placeholder.svelte-s4wswc{position:relative;bottom:30px;scale:0.8;left:-20px}.speaker-button.svelte-s4wswc{position:absolute;left:83px;bottom:20px;color:black}.video.svelte-s4wswc{position:relative;top:5px;margin:auto;max-height:50px}.videolocal_div.svelte-s4wswc{position:relative;width:45px;bottom:10px}@media screen and (max-width: 400px){.video.svelte-s4wswc{top:0px}}@media screen and (min-width: 768px){}',
  map: `{"version":3,"file":"Operator.svelte","sources":["Operator.svelte"],"sourcesContent":["<script lang=\\"ts\\">import { onMount, onDestroy, getContext, setContext } from \\"svelte\\";\\nimport { createEventDispatcher } from \\"svelte\\";\\nimport \\"../assets/icofont/icofont.min.css\\";\\nimport BottomAppBar, { Section, AutoAdjust } from \\"@smui-extra/bottom-app-bar\\";\\nimport IconButton, { Icon } from \\"@smui/icon-button\\";\\nimport TopAppBar, { Row, Title } from \\"@smui/top-app-bar\\";\\nimport { mdiAccountBox, mdiVolumeHigh, mdiVolumeOff } from \\"@mdi/js\\";\\nimport { users, view, posterst, lesson, signal, click_call_func, dc_state, call_but_status, dicts, langs, showBottomAppBar } from \\"$lib/js/stores.js\\";\\nimport CircularProgress from \\"@smui/circular-progress\\";\\nimport Group from \\"./Group.svelte\\";\\nlet group_data = getContext(\\"group_data\\");\\nlet group = [];\\nimport { RTCOperator } from \\"./rtc/RTCOperator\\";\\nimport CallButton from \\"./callbutton/CallButtonOperator.svelte\\";\\nimport VideoLocal from \\"./Video.local.svelte\\";\\nimport VideoRemote from \\"./Video.remote.svelte\\";\\nimport Download from \\"./Download.svelte\\";\\nimport AudioLocal from \\"./Audio.local.svelte\\";\\nimport AudioRemote from \\"./Audio.remote.svelte\\";\\nimport RecordedVideo from \\"./RecordedVideo.svelte\\";\\nimport Module from \\"../lesson/Module.svelte\\";\\nimport Chat from \\"./chat/\\\\u0421hat.svelte\\";\\nimport pkg from \\"lodash\\";\\nconst { find } = pkg;\\nimport { msg } from \\"$lib/js/stores.js\\";\\n$: if ($msg) {\\n  OnMessage($msg, null);\\n}\\nlet dlg_display = \\"none\\";\\nfunction SetDlgDisplay() {\\n  $view = \\"chat\\";\\n}\\nsetContext(\\"SetDlgDisplay\\", SetDlgDisplay);\\n$: if ($view === \\"chat\\")\\n  dlg_display = \\"block\\";\\nelse\\n  dlg_display = \\"none\\";\\n$posterst = \\"assets/operator.svg\\";\\nlet rtc;\\nlet topAppBar;\\nlet bottomAppBar;\\nlet selected;\\nlet call_cnt, inter;\\nlet video_button_display = false;\\nlet video_progress = false;\\nlet edited_display = false;\\nlet synthesis;\\nlet isRemoteAudioMute = false;\\nlet commandsList;\\nlet rtcSupportText = \\"\\";\\nlet debug_div;\\n$call_but_status = \\"inactive\\";\\nimport { editable } from \\"$lib/js/stores.js\\";\\nimport { Translate } from \\"../translate/Transloc\\";\\n$: if ($editable) {\\n  edited_display = $editable;\\n}\\nlet operator = getContext(\\"operator\\");\\noperator.type = \\"operator\\";\\nconst abonent = operator.abonent;\\nconst name = operator.name;\\nconst uid = operator.operator;\\nlet container;\\nconst headers = {\\n  \\"Content-Type\\": \\"application/json\\"\\n};\\nlet isHidden = false;\\nfunction handleVisibilityChange() {\\n  isHidden = document.hidden;\\n  if (isHidden) {\\n    console.log(\\"\\\\u0421\\\\u0442\\\\u0440\\\\u0430\\\\u043D\\\\u0438\\\\u0446\\\\u0430 \\\\u0443\\\\u0448\\\\u043B\\\\u0430 \\\\u0432 \\\\u0444\\\\u043E\\\\u043D\\\\u043E\\\\u0432\\\\u044B\\\\u0439 \\\\u0440\\\\u0435\\\\u0436\\\\u0438\\\\u043C\\");\\n    location.reload();\\n  } else {\\n    console.log(\\"\\\\u0421\\\\u0442\\\\u0440\\\\u0430\\\\u043D\\\\u0438\\\\u0446\\\\u0430 \\\\u0430\\\\u043A\\\\u0442\\\\u0438\\\\u0432\\\\u043D\\\\u0430\\");\\n  }\\n}\\nlet isMobile = false;\\nfunction detectDevice() {\\n  const userAgent = navigator.userAgent || navigator.vendor || window.opera;\\n  if (/android/i.test(userAgent)) {\\n    isMobile = true;\\n  } else if (/iPhone|iPad|iPod/i.test(userAgent)) {\\n    isMobile = true;\\n  } else {\\n    isMobile = false;\\n  }\\n}\\nfunction checkWebRTCSupport() {\\n  const isWebRTCSupported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.RTCPeerConnection && window.RTCDataChannel);\\n  if (!isWebRTCSupported) {\\n    rtcSupportText = \\"WebRTC \\\\u043D\\\\u0435 \\\\u043F\\\\u043E\\\\u0434\\\\u0434\\\\u0435\\\\u0440\\\\u0436\\\\u0438\\\\u0432\\\\u0430\\\\u0435\\\\u0442\\\\u0441\\\\u044F \\\\u0432\\\\u0430\\\\u0448\\\\u0438\\\\u043C \\\\u0431\\\\u0440\\\\u0430\\\\u0443\\\\u0437\\\\u0435\\\\u0440\\\\u043E\\\\u043C\\";\\n  } else {\\n    rtcSupportText = \\" \\";\\n  }\\n}\\nonMount(async () => {\\n  checkWebRTCSupport();\\n  try {\\n    rtc = new RTCOperator(operator, name, $signal);\\n    initRTC();\\n  } catch (ex) {\\n    console.log();\\n  }\\n  try {\\n  } catch (ex) {\\n    console.log(\\"Web Audio API is not supported in this browser\\");\\n  }\\n  if (detectDevice())\\n    document.addEventListener(\\"visibilitychange\\", handleVisibilityChange);\\n  if (group_data.length <= 1)\\n    $view = \\"lesson\\";\\n});\\nlet progress = {\\n  display: \\"block\\",\\n  value: 0\\n};\\nlet local = {\\n  video: {\\n    display: \\"none\\",\\n    srcObject: \\"\\",\\n    poster: \\"\\"\\n  },\\n  audio: {\\n    paused: true,\\n    src: \\"\\"\\n  }\\n};\\nlet remote = {\\n  text: {\\n    display: \\"none\\",\\n    msg: \\"\\",\\n    name: \\"\\",\\n    email: \\"\\"\\n  },\\n  video: {\\n    display: \\"none\\",\\n    srcObject: \\"\\",\\n    poster: \\"/assets/operator.svg\\"\\n  }\\n};\\nlet profile = {\\n  display: \\"none\\"\\n};\\nif (operator.operator === abonent) {\\n  operator.role = \\"admin\\";\\n} else {\\n  operator.role = \\"user\\";\\n}\\nfunction onTransFile(params) {\\n  let event = new MouseEvent(\\"click\\", {\\n    bubbles: true,\\n    cancelable: true,\\n    view: window\\n  });\\n  document.getElementById(\\"files\\").dispatchEvent(event);\\n}\\n$: if (selected)\\n  switch (selected) {\\n    case 1:\\n      break;\\n    case 2:\\n      edited_display = true;\\n      break;\\n    case 10:\\n      break;\\n  }\\nfunction initRTC() {\\n  rtc.PlayCallCnt = () => {\\n    local.audio.paused = false;\\n    call_cnt = 10;\\n    inter = setInterval(function() {\\n      call_cnt--;\\n      if (call_cnt === 0) {\\n        clearInterval(inter);\\n        call_cnt = 10;\\n        local.audio.paused = true;\\n        return;\\n      }\\n    }, 2e3);\\n    return;\\n  };\\n  rtc.GetRemoteVideo = () => {\\n    return remote.video.srcObject;\\n  };\\n  rtc.SetLocalVideo = (src) => {\\n    if (src)\\n      local.video.srcObject = src;\\n  };\\n  rtc.SetRemoteVideo = (src) => {\\n    remote.video.poster = $posterst;\\n    remote.video.srcObject = src;\\n    remote.video.display = \\"block\\";\\n  };\\n}\\nfunction OnLongPress() {\\n  selected.display = true;\\n}\\nfunction OnClickCallButton() {\\n  console.log(\\"OnClickCallButton\\");\\n  switch ($call_but_status) {\\n    case \\"inactive\\":\\n      try {\\n        if (detectDevice())\\n          document.addEventListener(\\"visibilitychange\\", handleVisibilityChange);\\n      } catch (ex) {\\n        console.log();\\n      }\\n      rtc.Offer();\\n      $call_but_status = \\"active\\";\\n      break;\\n    case \\"active\\":\\n      $call_but_status = \\"inactive\\";\\n      rtc.OnInactive();\\n      break;\\n    case \\"call\\":\\n      if ($dc_state && !$click_call_func) {\\n        $call_but_status = \\"talk\\";\\n        isRemoteAudioMute = false;\\n        rtc.OnTalk();\\n        video_button_display = true;\\n        remote.text.display = \\"none\\";\\n      } else {\\n        $call_but_status = \\"inactive\\";\\n      }\\n      local.audio.paused = true;\\n      clearInterval(inter);\\n      call_cnt = 10;\\n      break;\\n    case \\"talk\\":\\n      local.video.display = \\"none\\";\\n      local.audio.paused = true;\\n      video_button_display = false;\\n      remote.video.display = \\"none\\";\\n      remote.video.srcObject = \\"\\";\\n      remote.video.poster = \\"\\";\\n      remote.text.display = \\"none\\";\\n      remote.text.name = \\"\\";\\n      remote.text.email = \\"\\";\\n      $call_but_status = \\"inactive\\";\\n      rtc.DC.SendDCClose();\\n      rtc.DC.CloseDC();\\n      rtc.OnInactive();\\n      $users = $users;\\n      break;\\n    default:\\n      return;\\n  }\\n}\\n$: if ($click_call_func) {\\n  console.log();\\n}\\n$: if ($call_but_status) {\\n  console.log($call_but_status);\\n}\\nfunction openProfile(id) {\\n  profile.display = \\"block\\";\\n}\\nfunction OnClickVideoButton() {\\n  $call_but_status = \\"talk\\";\\n  local.audio.paused = true;\\n  local.video.display = \\"block\\";\\n  video_button_display = false;\\n  video_progress = true;\\n  if (rtc.DC.dc.readyState === \\"open\\") {\\n    rtc.GetUserMedia({ audio: 1, video: 1 }, function() {\\n      rtc.SendVideoOffer(rtc.main_pc);\\n    });\\n  }\\n}\\nfunction OnPlayVideo() {\\n  video_progress = false;\\n}\\n$: switch ($dc_state) {\\n  case \\"open\\":\\n    $call_but_status = \\"call\\";\\n    local.audio.paused = false;\\n    break;\\n}\\nfunction OnMessage(data, resolve) {\\n  if (data.func === \\"close\\") {\\n    $call_but_status = \\"inactive\\";\\n    rtc.DC.CloseDC();\\n    remote.video.display = \\"none\\";\\n    local.audio.paused = true;\\n  }\\n  if (data.call || data.func === \\"call\\") {\\n    $showBottomAppBar = true;\\n    $call_but_status = \\"call\\";\\n    remote.text.display = \\"block\\";\\n    video_button_display = false;\\n    local.audio.paused = false;\\n    if (data.profile) {\\n      if (data.profile.img)\\n        remote.video.display = \\"block\\";\\n      remote.text.name = data.profile.name;\\n      remote.text.email = data.profile.email;\\n    }\\n    if ($click_call_func)\\n      rtc.OnCall();\\n  }\\n  if (data.func === \\"talk\\") {\\n    $call_but_status = \\"talk\\";\\n    local.audio.paused = true;\\n    video_button_display = true;\\n    remote.text.display = \\"none\\";\\n  }\\n  if (data.camera) {\\n    local.video.src = that.localStream;\\n  }\\n  if (data.lesson) {\\n    $view = \\"lesson\\";\\n    $lesson.data = data.lesson;\\n  }\\n}\\nfunction toggle_remote_audio() {\\n  isRemoteAudioMute = !isRemoteAudioMute;\\n}\\nonDestroy(() => {\\n  group = \\"\\";\\n  document.removeEventListener(\\"visibilitychange\\", handleVisibilityChange);\\n});\\n<\/script>\\r\\n\\r\\n<!-- {@debug $view} -->\\r\\n\\r\\n\\r\\n<!-- {#if $view === 'group'} -->\\r\\n<Group  {rtc} bind:group={group}/>\\r\\n\\r\\n{#if $view === 'lesson'}\\r\\n  <Module data={group_data} bind:group={group}/>\\r\\n{/if}\\r\\n\\r\\n<div class=\\"dialog\\" style=\\"display: {dlg_display};\\">\\r\\n  <Chat></Chat>\\r\\n</div>\\r\\n\\r\\n<div class=\\"bottom-app-bar-wrapper\\" class:hide={!$showBottomAppBar}>\\r\\n  <BottomAppBar variant=\\"static\\" slot=\\"oper\\" bind:this={bottomAppBar}>\\r\\n    <Section>\\r\\n      <div class=\\"remote_div\\">\\r\\n        <div class=\\"user_placeholder\\"></div>\\r\\n\\r\\n        <VideoRemote\\r\\n          {...remote.video}\\r\\n          name={remote.text.name}\\r\\n          operator={operator.operator}\\r\\n          on:click={OnClickCallButton}\\r\\n          on:mute\\r\\n          bind:isRemoteAudioMute\\r\\n        ></VideoRemote>\\r\\n        {#if $call_but_status === 'talk'}\\r\\n          <div class=\\"speaker-button\\">\\r\\n            <IconButton on:click={toggle_remote_audio}>\\r\\n              <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n                {#if !isRemoteAudioMute}\\r\\n                  <path fill=\\"currentColor\\" d={mdiVolumeHigh} />\\r\\n                {:else}\\r\\n                  <path fill=\\"currentColor\\" d={mdiVolumeOff} />\\r\\n                {/if}\\r\\n              </Icon>\\r\\n            </IconButton>\\r\\n          </div>\\r\\n        {/if}\\r\\n      </div>\\r\\n    </Section>\\r\\n    <Section>\\r\\n      {#if remote.text.display && remote.text.name}\\r\\n        <div class=\\"remote_text_display\\" style=\\"display:{remote.text.display};\\">\\r\\n          {#await Translate('Тебя вызывает - ', 'ru', $langs) then data}\\r\\n            <p class=\\"remote_msg\\">\\r\\n              {data}\\r\\n              {remote.text.name}\\r\\n            </p>\\r\\n          {/await}\\r\\n        </div>\\r\\n      {/if}\\r\\n    </Section>\\r\\n    <Section>\\r\\n\\r\\n    </Section>\\r\\n    <Section align=\\"end\\">\\r\\n      <CallButton on:click={OnClickCallButton}>\\r\\n        <b\\r\\n          class=\\"call_cnt\\"\\r\\n          style=\\"display:none;position: relative;left:22px;top:10px;color:#0e0cff;font-size: 12px;\\"\\r\\n          >100</b\\r\\n        >\\r\\n        <span\\r\\n          class=\\"badge badge-primary badge-pill call-queue\\"\\r\\n          style=\\"display:none;position: relative;right:0px;bottom:0px;color:#0e0cff;font-size: 12px;opacity:1\\"\\r\\n          >0</span\\r\\n        >\\r\\n      </CallButton>\\r\\n      <div\\r\\n        class=\\"video\\"\\r\\n        on:click={OnClickVideoButton}\\r\\n        on:loadstart={OnPlayVideo}\\r\\n      >\\r\\n        {#if video_button_display}\\r\\n          <Icon tag=\\"svg\\" viewBox=\\"0 0 24 24\\">\\r\\n            <path fill=\\"currentColor\\" style=\\"color:grey\\" d={mdiAccountBox} />\\r\\n          </Icon>\\r\\n          <!-- <i class=\\"video icofont-ui-video-chat\\"  on:click = {OnClickVideoButton}\\r\\n                        style=\\"position: absolute; right: 0; top: 0; stroke:black; stroke-width: 2px; color: lightgrey; font-size: 30px; z-index: 20;\\"></i>  -->\\r\\n        {/if}\\r\\n\\r\\n        {#if video_progress}\\r\\n          <div style=\\"position: absolute; top: -10px;\\">\\r\\n            <CircularProgress\\r\\n              style=\\"height: 30px; width: 30px;\\"\\r\\n              indeterminate\\r\\n            />\\r\\n          </div>\\r\\n        {/if}\\r\\n      </div>\\r\\n\\r\\n      <div class=\\"videolocal_div\\">\\r\\n        <VideoLocal {...local.video}>\\r\\n          <svelte:fragment slot=\\"footer\\">\\r\\n            <div bind:this={container} />\\r\\n          </svelte:fragment>\\r\\n        </VideoLocal>\\r\\n      </div>\\r\\n    </Section>\\r\\n  </BottomAppBar>\\r\\n\\r\\n  {#await Translate(rtcSupportText, 'ru', $langs) then data}\\r\\n    <span style=\\"position:fixed;bottom:0;font-size:smaller;color:red\\"\\r\\n      >{data}</span\\r\\n    >\\r\\n  {/await}\\r\\n\\r\\n  <!-- <VideoLocal {...local.video} /> -->\\r\\n  <AudioLocal {...local.audio} bind:paused={local.audio.paused} />\\r\\n  <!-- {@debug $call_but_status} -->\\r\\n</div>\\r\\n\\r\\n\\r\\n\\r\\n<style lang=\\"scss\\">@charset \\"UTF-8\\";\\n/* Variables and mixins declared here will be available in all other SCSS files */\\n/* Hide everything above this component. */\\n.bottom-app-bar-wrapper {\\n  position: fixed;\\n  bottom: 0;\\n  width: 100%;\\n  transform: translateY(0);\\n  transition: transform 0.7s ease;\\n}\\n\\n.hide {\\n  transform: translateY(100px);\\n  transition: transform 0.7s ease;\\n}\\n\\n/* Если не скрыт, панель остается на месте */\\n.dialog {\\n  position: fixed;\\n  background-color: aliceblue;\\n  top: 40px;\\n  width: 100vw;\\n  height: 90vh;\\n  right: 0vw;\\n  margin: 0px auto;\\n  z-index: 2;\\n}\\n\\n.remote_msg {\\n  position: relative;\\n  font-size: 0.7em;\\n  white-space: nowrap;\\n  color: black;\\n  margin: auto;\\n  text-align: center;\\n  top: -10px;\\n  /* background-color: rgba(125, 125, 125, 0.7); */\\n  z-index: 1;\\n}\\n\\n.user_placeholder {\\n  position: relative;\\n  bottom: 30px;\\n  scale: 0.8;\\n  left: -20px;\\n}\\n\\n.speaker-button {\\n  position: absolute;\\n  left: 83px;\\n  bottom: 20px;\\n  color: black;\\n}\\n\\n.video {\\n  position: relative;\\n  top: 5px;\\n  margin: auto;\\n  max-height: 50px;\\n}\\n\\n.videolocal_div {\\n  position: relative;\\n  width: 45px;\\n  bottom: 10px;\\n}\\n\\n@media screen and (max-width: 400px) {\\n  .video {\\n    top: 0px;\\n  }\\n}\\n@media screen and (min-width: 768px) {\\n  /* Ваши стили для более крупных экранов здесь */\\n}</style>\\r\\n"],"names":[],"mappings":"AAwbmB,SAAS,OAAO,CAGnC,qCAAwB,CACtB,QAAQ,CAAE,KAAK,CACf,MAAM,CAAE,CAAC,CACT,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,WAAW,CAAC,CAAC,CACxB,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,IAC7B,CAEA,mBAAM,CACJ,SAAS,CAAE,WAAW,KAAK,CAAC,CAC5B,UAAU,CAAE,SAAS,CAAC,IAAI,CAAC,IAC7B,CAGA,qBAAQ,CACN,QAAQ,CAAE,KAAK,CACf,gBAAgB,CAAE,SAAS,CAC3B,GAAG,CAAE,IAAI,CACT,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,GAAG,CACV,MAAM,CAAE,GAAG,CAAC,IAAI,CAChB,OAAO,CAAE,CACX,CAEA,yBAAY,CACV,QAAQ,CAAE,QAAQ,CAClB,SAAS,CAAE,KAAK,CAChB,WAAW,CAAE,MAAM,CACnB,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,MAAM,CAClB,GAAG,CAAE,KAAK,CAEV,OAAO,CAAE,CACX,CAEA,+BAAkB,CAChB,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,GAAG,CACV,IAAI,CAAE,KACR,CAEA,6BAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,IAAI,CAAE,IAAI,CACV,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,KACT,CAEA,oBAAO,CACL,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IACd,CAEA,6BAAgB,CACd,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IACV,CAEA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CACnC,oBAAO,CACL,GAAG,CAAE,GACP,CACF,CACA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAErC"}`
};
const Operator = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $lesson, $$unsubscribe_lesson;
  let $view, $$unsubscribe_view;
  let $call_but_status, $$unsubscribe_call_but_status;
  let $click_call_func, $$unsubscribe_click_call_func;
  let $showBottomAppBar, $$unsubscribe_showBottomAppBar;
  let $dc_state, $$unsubscribe_dc_state;
  let $$unsubscribe_users;
  let $posterst, $$unsubscribe_posterst;
  let $$unsubscribe_signal;
  let $$unsubscribe_editable;
  let $msg, $$unsubscribe_msg;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_lesson = subscribe(lesson, (value) => $lesson = value);
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  $$unsubscribe_call_but_status = subscribe(call_but_status, (value) => $call_but_status = value);
  $$unsubscribe_click_call_func = subscribe(click_call_func, (value) => $click_call_func = value);
  $$unsubscribe_showBottomAppBar = subscribe(showBottomAppBar, (value) => $showBottomAppBar = value);
  $$unsubscribe_dc_state = subscribe(dc_state, (value) => $dc_state = value);
  $$unsubscribe_users = subscribe(users, (value) => value);
  $$unsubscribe_posterst = subscribe(posterst, (value) => $posterst = value);
  $$unsubscribe_signal = subscribe(signal, (value) => value);
  $$unsubscribe_editable = subscribe(editable, (value) => value);
  $$unsubscribe_msg = subscribe(msg, (value) => $msg = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  let group_data = getContext("group_data");
  let group = [];
  const { find } = pkg;
  let dlg_display = "none";
  function SetDlgDisplay() {
    set_store_value(view, $view = "chat", $view);
  }
  setContext("SetDlgDisplay", SetDlgDisplay);
  set_store_value(posterst, $posterst = "assets/operator.svg", $posterst);
  let rtc;
  let bottomAppBar;
  let video_button_display = false;
  let isRemoteAudioMute = false;
  let rtcSupportText = "";
  set_store_value(call_but_status, $call_but_status = "inactive", $call_but_status);
  let operator = getContext("operator");
  operator.type = "operator";
  const abonent = operator.abonent;
  operator.name;
  operator.operator;
  let container;
  let isHidden = false;
  function handleVisibilityChange() {
    isHidden = document.hidden;
    if (isHidden) {
      console.log("Страница ушла в фоновый режим");
      location.reload();
    } else {
      console.log("Страница активна");
    }
  }
  let local = {
    video: {
      display: "none",
      srcObject: "",
      poster: ""
    },
    audio: { paused: true, src: "" }
  };
  let remote = {
    text: {
      display: "none",
      name: "",
      email: ""
    },
    video: {
      display: "none",
      srcObject: "",
      poster: "/assets/operator.svg"
    }
  };
  if (operator.operator === abonent) {
    operator.role = "admin";
  } else {
    operator.role = "user";
  }
  function OnMessage(data, resolve) {
    if (data.func === "close") {
      set_store_value(call_but_status, $call_but_status = "inactive", $call_but_status);
      rtc.DC.CloseDC();
      remote.video.display = "none";
      local.audio.paused = true;
    }
    if (data.call || data.func === "call") {
      set_store_value(showBottomAppBar, $showBottomAppBar = true, $showBottomAppBar);
      set_store_value(call_but_status, $call_but_status = "call", $call_but_status);
      remote.text.display = "block";
      video_button_display = false;
      local.audio.paused = false;
      if (data.profile) {
        if (data.profile.img) remote.video.display = "block";
        remote.text.name = data.profile.name;
        remote.text.email = data.profile.email;
      }
      if ($click_call_func) rtc.OnCall();
    }
    if (data.func === "talk") {
      set_store_value(call_but_status, $call_but_status = "talk", $call_but_status);
      local.audio.paused = true;
      video_button_display = true;
      remote.text.display = "none";
    }
    if (data.camera) {
      local.video.src = that.localStream;
    }
    if (data.lesson) {
      set_store_value(view, $view = "lesson", $view);
      set_store_value(lesson, $lesson.data = data.lesson, $lesson);
    }
  }
  onDestroy(() => {
    group = "";
    document.removeEventListener("visibilitychange", handleVisibilityChange);
  });
  $$result.css.add(css$1);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      if ($msg) {
        OnMessage($msg);
      }
    }
    {
      if ($view === "chat") dlg_display = "block";
      else dlg_display = "none";
    }
    {
      if ($click_call_func) {
        console.log();
      }
    }
    {
      switch ($dc_state) {
        case "open":
          set_store_value(call_but_status, $call_but_status = "call", $call_but_status);
          local.audio.paused = false;
          break;
      }
    }
    {
      if ($call_but_status) {
        console.log($call_but_status);
      }
    }
    $$rendered = `  ${validate_component(Group, "Group").$$render(
      $$result,
      { rtc, group },
      {
        group: ($$value) => {
          group = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${$view === "lesson" ? `${validate_component(Module, "Module").$$render(
      $$result,
      { data: group_data, group },
      {
        group: ($$value) => {
          group = $$value;
          $$settled = false;
        }
      },
      {}
    )}` : ``} <div class="dialog svelte-s4wswc" style="${"display: " + escape(dlg_display, true) + ";"}">${validate_component(UD0uA1hat, "Chat").$$render($$result, {}, {}, {})}</div> <div class="${["bottom-app-bar-wrapper svelte-s4wswc", !$showBottomAppBar ? "hide" : ""].join(" ").trim()}">${validate_component(BottomAppBar, "BottomAppBar").$$render(
      $$result,
      {
        variant: "static",
        slot: "oper",
        this: bottomAppBar
      },
      {
        this: ($$value) => {
          bottomAppBar = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${validate_component(Section, "Section").$$render($$result, {}, {}, {
            default: () => {
              return `<div class="remote_div"><div class="user_placeholder svelte-s4wswc"></div> ${validate_component(Video_remote, "VideoRemote").$$render(
                $$result,
                Object.assign({}, remote.video, { name: remote.text.name }, { operator: operator.operator }, { isRemoteAudioMute }),
                {
                  isRemoteAudioMute: ($$value) => {
                    isRemoteAudioMute = $$value;
                    $$settled = false;
                  }
                },
                {}
              )} ${$call_but_status === "talk" ? `<div class="speaker-button svelte-s4wswc">${validate_component(IconButton, "IconButton").$$render($$result, {}, {}, {
                default: () => {
                  return `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
                    default: () => {
                      return `${!isRemoteAudioMute ? `<path fill="currentColor"${add_attribute("d", mdiVolumeHigh, 0)}></path>` : `<path fill="currentColor"${add_attribute("d", mdiVolumeOff, 0)}></path>`}`;
                    }
                  })}`;
                }
              })}</div>` : ``}</div>`;
            }
          })} ${validate_component(Section, "Section").$$render($$result, {}, {}, {
            default: () => {
              return `${remote.text.display && remote.text.name ? `<div class="remote_text_display" style="${"display:" + escape(remote.text.display, true) + ";"}">${function(__value) {
                if (is_promise(__value)) {
                  __value.then(null, noop);
                  return ``;
                }
                return function(data) {
                  return ` <p class="remote_msg svelte-s4wswc">${escape(data)} ${escape(remote.text.name)}</p> `;
                }(__value);
              }(Translate("Тебя вызывает - ", "ru", $langs))}</div>` : ``}`;
            }
          })} ${validate_component(Section, "Section").$$render($$result, {}, {}, {})} ${validate_component(Section, "Section").$$render($$result, { align: "end" }, {}, {
            default: () => {
              return `${validate_component(CallButtonOperator, "CallButton").$$render($$result, {}, {}, {
                default: () => {
                  return `<b class="call_cnt" style="display:none;position: relative;left:22px;top:10px;color:#0e0cff;font-size: 12px;" data-svelte-h="svelte-1iw71ga">100</b> <span class="badge badge-primary badge-pill call-queue" style="display:none;position: relative;right:0px;bottom:0px;color:#0e0cff;font-size: 12px;opacity:1" data-svelte-h="svelte-ecfdsv">0</span>`;
                }
              })} <div class="video svelte-s4wswc">${video_button_display ? `${validate_component(CommonIcon, "Icon").$$render($$result, { tag: "svg", viewBox: "0 0 24 24" }, {}, {
                default: () => {
                  return `<path fill="currentColor" style="color:grey"${add_attribute("d", mdiAccountBox, 0)}></path>`;
                }
              })} ` : ``} ${``}</div> <div class="videolocal_div svelte-s4wswc">${validate_component(Video_local, "VideoLocal").$$render($$result, Object.assign({}, local.video), {}, {
                footer: () => {
                  return `<div${add_attribute("this", container, 0)}></div>`;
                }
              })}</div>`;
            }
          })}`;
        }
      }
    )} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` <span style="position:fixed;bottom:0;font-size:smaller;color:red">${escape(data)}</span> `;
      }(__value);
    }(Translate(rtcSupportText, "ru", $langs))}  ${validate_component(Audio_local, "AudioLocal").$$render(
      $$result,
      Object.assign({}, local.audio, { paused: local.audio.paused }),
      {
        paused: ($$value) => {
          local.audio.paused = $$value;
          $$settled = false;
        }
      },
      {}
    )}  </div>`;
  } while (!$$settled);
  $$unsubscribe_lesson();
  $$unsubscribe_view();
  $$unsubscribe_call_but_status();
  $$unsubscribe_click_call_func();
  $$unsubscribe_showBottomAppBar();
  $$unsubscribe_dc_state();
  $$unsubscribe_users();
  $$unsubscribe_posterst();
  $$unsubscribe_signal();
  $$unsubscribe_editable();
  $$unsubscribe_msg();
  $$unsubscribe_langs();
  return $$rendered;
});
const css = {
  code: ".container.svelte-11ki6a9{display:flex;justify-content:center;align-items:center;min-height:100vh}form.svelte-11ki6a9{display:flex;flex-direction:column;align-items:center;width:100%;max-width:500px;padding:20px;border:0px solid #ccc;border-radius:8px;background-color:transparent}.mdc-text-field{width:80% !important}.mdc-text-field__input{width:80% !important;box-sizing:border-box;font-size:16px;padding:10px}img.svelte-11ki6a9{width:120px;height:120px;border-radius:50%;cursor:pointer;margin:10px 0}@media screen and (max-width: 768px){form.svelte-11ki6a9{padding:15px}}",
  map: `{"version":3,"file":"Login.svelte","sources":["Login.svelte"],"sourcesContent":["<script>\\r\\n\\timport { onMount } from 'svelte';\\r\\n\\timport { dicts } from '$lib/js/stores.js';\\r\\n\\timport Button from '@smui/button';\\r\\n\\timport Textfield from '@smui/textfield';\\r\\n\\timport loadImage from 'blueimp-load-image/js/load-image.js';\\r\\n\\timport 'blueimp-load-image/js/load-image-scale.js';\\r\\n\\timport { Translate } from '../translate/Transloc.ts';\\r\\n\\r\\n\\timport {\\r\\n\\t\\tlangs\\r\\n\\t} from '$lib/js/stores.js';\\r\\n\\r\\n\\tlet formData = {\\r\\n\\t\\tname: '',\\r\\n\\t\\temail: '',\\r\\n\\t\\tpsw: '',\\r\\n\\t\\tconfirmPassword: '',\\r\\n\\t\\tpicture: '/assets/operator.svg',\\r\\n\\t\\tlang: 'en',\\r\\n\\t};\\r\\n\\r\\n\\tlet abonent, lvl, lang = 'en';\\r\\n\\tlet passwordMatch = true;\\r\\n\\r\\n\\t$: formData.lang = lang;\\r\\n\\r\\n\\tonMount(() => {\\r\\n\\t\\tlet url = new URL(window.location.href);\\r\\n\\t\\tabonent = url.searchParams.get('abonent');\\r\\n\\t\\tlvl = url.searchParams.get('lvl');\\r\\n\\t\\tformData.email = url.searchParams.get('user');\\r\\n\\t});\\r\\n\\r\\n\\tfunction uploadImage(event) {\\r\\n\\t\\tconst file = event.target.files[0];\\r\\n\\t\\tif (file) {\\r\\n\\t\\t\\tloadImage(\\r\\n\\t\\t\\t\\tfile,\\r\\n\\t\\t\\t\\t(img) => {\\r\\n\\t\\t\\t\\t\\tif (img.type === 'error') {\\r\\n\\t\\t\\t\\t\\t\\tconsole.error($dicts['Ошибка загрузки изображения'][lang]);\\r\\n\\t\\t\\t\\t\\t} else {\\r\\n\\t\\t\\t\\t\\t\\tformData.picture = img.toDataURL();\\r\\n\\t\\t\\t\\t\\t}\\r\\n\\t\\t\\t\\t},\\r\\n\\t\\t\\t\\t{ orientation: true, maxWidth: 100, maxHeight: 100, canvas: true }\\r\\n\\t\\t\\t);\\r\\n\\t\\t}\\r\\n\\t}\\r\\n\\r\\n\\tasync function handleSubmit() {\\r\\n\\t\\t// Здесь вы можете обработать данные формы\\r\\n\\t\\tlet par = formData;\\r\\n\\t\\tpar.email = par.email.trim();\\r\\n\\t\\tpasswordMatch = par.confirmPassword === par.psw;\\r\\n\\t\\tif (!passwordMatch) return;\\r\\n\\t\\tpar.func = 'operator';\\r\\n\\t\\tpar.lvl = lvl;\\r\\n\\t\\tpar.abonent = abonent;\\r\\n\\t\\tconst headers = {\\r\\n\\t\\t\\t'Content-Type': 'application/json'\\r\\n\\t\\t\\t// Authorization: \`Bearer \${token}\`\\r\\n\\t\\t};\\r\\n\\t\\tlet res = await fetch(\`/\`, {\\r\\n\\t\\t\\tmethod: 'POST',\\r\\n\\t\\t\\t// mode: 'no-cors',\\r\\n\\t\\t\\tbody: JSON.stringify({ par }),\\r\\n\\t\\t\\theaders: headers\\r\\n\\t\\t});\\r\\n\\t\\r\\n\\t\\tlocation.reload();\\r\\n\\t}\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"container\\">\\r\\n\\t<form on:submit|preventDefault={handleSubmit}>\\r\\n\\t\\t<Textfield\\r\\n\\t\\t\\tname=\\"email\\"\\r\\n\\t\\t\\tbind:value={formData.email}\\r\\n\\t\\t\\tlabel=\\"{$dicts['Email'][lang]}:\\"\\r\\n\\t\\t\\trequired\\r\\n\\t\\t/>\\r\\n\\t\\t{#await Translate('Имя', 'ru', $langs) then data}\\r\\n\\t\\t<Textfield\\r\\n\\t\\t\\tname=\\"name\\"\\r\\n\\t\\t\\tbind:value={formData.name}\\r\\n\\t\\t\\tlabel=\\"{data}:\\"\\r\\n\\t\\t\\trequired\\r\\n\\t\\t/>\\r\\n\\t\\t{/await}\\r\\n\\t\\t{#await Translate('Пароль', 'ru', $langs) then data}\\r\\n\\t\\t<Textfield\\r\\n\\t\\t\\ttype=\\"password\\"\\r\\n\\t\\t\\tname=\\"psw\\"\\r\\n\\t\\t\\tbind:value={formData.psw}\\r\\n\\t\\t\\tlabel=\\"{data}:\\"\\r\\n\\t\\t\\trequired\\r\\n\\t\\t/>\\r\\n\\t\\t{/await}\\r\\n\\t\\t{#await Translate('Повторить пароль', 'ru', $langs) then data}\\r\\n\\t\\t<Textfield\\r\\n\\t\\t\\ttype=\\"password\\"\\r\\n\\t\\t\\tname=\\"confirmPassword\\"\\r\\n\\t\\t\\tbind:value={formData.confirmPassword}\\r\\n\\t\\t\\tlabel=\\"{data}:\\"\\r\\n\\t\\t\\trequired\\r\\n\\t\\t/>\\r\\n\\t\\t{/await}\\r\\n\\t\\t{#if !passwordMatch}\\r\\n\\t\\t\\t{#await Translate('Пароли не совпадают', 'ru', $langs) then data}\\r\\n\\t\\t\\t\\t<p style=\\"color: red;\\">{data}</p>\\t\\r\\n\\t\\t\\t{/await}\\r\\n\\t\\t{/if}\\r\\n\\t\\t<div>\\r\\n\\t\\t\\t<input type=\\"file\\" id=\\"pic\\" on:change={uploadImage} accept=\\"image/png, image/jpeg\\" hidden />\\r\\n\\t\\t\\t<img src={formData.picture} alt=\\"Avatar\\" on:click={() => document.getElementById('pic').click()} />\\r\\n\\t\\t</div>\\r\\n\\t\\t{#await Translate('Зарегистрироваться', 'ru', $langs) then data}\\r\\n\\t\\t\\t<Button type=\\"submit\\" disabled={!passwordMatch}>\\r\\n\\t\\t\\t\\t{data}\\r\\n\\t\\t\\t</Button>\\r\\n\\t\\t{/await}\\r\\n\\t</form>\\r\\n\\r\\n\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n\\t.container {\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tjustify-content: center;\\r\\n\\t\\talign-items: center;\\r\\n\\t\\tmin-height: 100vh;\\r\\n\\t}\\r\\n\\r\\n\\tform {\\r\\n\\t\\tdisplay: flex;\\r\\n\\t\\tflex-direction: column;\\r\\n\\t\\talign-items: center;\\r\\n\\t\\twidth: 100%;\\r\\n\\t\\tmax-width: 500px; /* Широкая форма */\\r\\n\\t\\tpadding: 20px;\\r\\n\\t\\tborder: 0px solid #ccc;\\r\\n\\t\\tborder-radius: 8px;\\r\\n\\t\\tbackground-color: transparent;\\r\\n\\t\\t/* box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); */\\r\\n\\t}\\r\\n\\r\\n\\t.field {\\r\\n\\t\\tmargin-bottom: 15px;\\r\\n\\t\\twidth: 80%;\\r\\n\\t}\\r\\n\\r\\n\\t/* Принудительное расширение полей для SMUI */\\r\\n\\t:global(.mdc-text-field) {\\r\\n\\t\\twidth: 80% !important;\\r\\n\\t}\\r\\n\\r\\n\\t:global(.mdc-text-field__input) {\\r\\n\\t\\twidth: 80% !important;\\r\\n\\t\\tbox-sizing: border-box;\\r\\n\\t\\tfont-size: 16px;\\r\\n\\t\\tpadding: 10px;\\r\\n\\t}\\r\\n\\r\\n\\timg {\\r\\n\\t\\twidth: 120px;\\r\\n\\t\\theight: 120px;\\r\\n\\t\\tborder-radius: 50%;\\r\\n\\t\\tcursor: pointer;\\r\\n\\t\\tmargin: 10px 0;\\r\\n\\t}\\r\\n\\r\\n\\t.upload-button {\\r\\n\\t\\tmargin-top: 15px;\\r\\n\\t\\tpadding: 10px 20px;\\r\\n\\t\\tfont-size: 16px;\\r\\n\\t}\\r\\n\\r\\n\\t/* Адаптивность для мобильных устройств */\\r\\n\\t@media screen and (max-width: 768px) {\\r\\n\\t\\tform {\\r\\n\\t\\t\\tpadding: 15px;\\r\\n\\t\\t}\\r\\n\\t}\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAiIC,yBAAW,CACV,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,KACb,CAEA,mBAAK,CACJ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,gBAAgB,CAAE,WAEnB,CAQQ,eAAiB,CACxB,KAAK,CAAE,GAAG,CAAC,UACZ,CAEQ,sBAAwB,CAC/B,KAAK,CAAE,GAAG,CAAC,UAAU,CACrB,UAAU,CAAE,UAAU,CACtB,SAAS,CAAE,IAAI,CACf,OAAO,CAAE,IACV,CAEA,kBAAI,CACH,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,KAAK,CACb,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OAAO,CACf,MAAM,CAAE,IAAI,CAAC,CACd,CASA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CACpC,mBAAK,CACJ,OAAO,CAAE,IACV,CACD"}`
};
const Login = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dicts, $$unsubscribe_dicts;
  let $langs, $$unsubscribe_langs;
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  let formData = {
    name: "",
    email: "",
    psw: "",
    confirmPassword: "",
    picture: "/assets/operator.svg",
    lang: "en"
  };
  let lang = "en";
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    formData.lang = lang;
    $$rendered = `<div class="container svelte-11ki6a9"><form class="svelte-11ki6a9">${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        name: "email",
        label: $dicts["Email"][lang] + ":",
        required: true,
        value: formData.email
      },
      {
        value: ($$value) => {
          formData.email = $$value;
          $$settled = false;
        }
      },
      {}
    )} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Textfield, "Textfield").$$render(
          $$result,
          {
            name: "name",
            label: data + ":",
            required: true,
            value: formData.name
          },
          {
            value: ($$value) => {
              formData.name = $$value;
              $$settled = false;
            }
          },
          {}
        )} `;
      }(__value);
    }(Translate("Имя", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Textfield, "Textfield").$$render(
          $$result,
          {
            type: "password",
            name: "psw",
            label: data + ":",
            required: true,
            value: formData.psw
          },
          {
            value: ($$value) => {
              formData.psw = $$value;
              $$settled = false;
            }
          },
          {}
        )} `;
      }(__value);
    }(Translate("Пароль", "ru", $langs))} ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Textfield, "Textfield").$$render(
          $$result,
          {
            type: "password",
            name: "confirmPassword",
            label: data + ":",
            required: true,
            value: formData.confirmPassword
          },
          {
            value: ($$value) => {
              formData.confirmPassword = $$value;
              $$settled = false;
            }
          },
          {}
        )} `;
      }(__value);
    }(Translate("Повторить пароль", "ru", $langs))} ${``} <div><input type="file" id="pic" accept="image/png, image/jpeg" hidden> <img${add_attribute("src", formData.picture, 0)} alt="Avatar" class="svelte-11ki6a9"></div> ${function(__value) {
      if (is_promise(__value)) {
        __value.then(null, noop);
        return ``;
      }
      return function(data) {
        return ` ${validate_component(Button, "Button").$$render($$result, { type: "submit", disabled: false }, {}, {
          default: () => {
            return `${escape(data)}`;
          }
        })} `;
      }(__value);
    }(Translate("Зарегистрироваться", "ru", $langs))}</form> </div>`;
  } while (!$$settled);
  $$unsubscribe_dicts();
  $$unsubscribe_langs();
  return $$rendered;
});
class SignalingChannel {
  constructor(operator) {
    this.msg = msg;
    this.operator = operator;
    this.isOpen = false;
    this.socketUrl = "";
    this.socketUrl = "wss://kolmit-server.onrender.com";
    this.socket = null;
    this.messageQueue = [];
    this.heartbeatInterval = null;
    this.initializeWebSocket();
    this.status = "inactive";
  }
  initializeWebSocket(reconnectAttempt = 1) {
    this.socket = new WebSocket(this.socketUrl);
    this.status = "inactive";
    this.socket.onopen = () => {
      console.log("WebSocket соединение установлено");
      this.isOpen = true;
      reconnectAttempt = 1;
      this.processQueue();
    };
    this.socket.onmessage = (event) => {
      console.log("Получено сообщение:", event.data);
      const data = JSON.parse(event.data);
      if (this.callback) this.callback(data);
      setTimeout(() => {
        this.msg.set(data);
      }, 10);
    };
    this.socket.onclose = () => {
      console.log("WebSocket соединение закрыто");
      this.isOpen = false;
      this.stopHeartbeat();
      const delay = Math.min(1e3 * reconnectAttempt, 3e4);
      setTimeout(() => this.initializeWebSocket(reconnectAttempt + 1), delay);
    };
    this.socket.onerror = (error) => {
      console.error("WebSocket ошибка:", error);
    };
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatInterval = setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify({ type: "ping", operator: this.operator, status: this.status }));
        console.log("Пинг отправлен на сервер");
      }
    }, 5e3);
  }
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }
  SendMessage(par, cb) {
    this.callback = cb;
    this.status = par.status;
    try {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify({ par }));
      } else {
        console.log("Соединение с WebSocket не установлено, добавление сообщения в очередь");
        this.messageQueue.push(par);
        if (!this.socket || this.socket.readyState >= WebSocket.CLOSING) {
          this.initializeWebSocket();
        }
      }
      if (par.status === "close") {
        this.closeConnection();
      } else if (par.status === "open" && !this.isOpen) {
        this.initializeWebSocket();
      }
    } catch (error) {
      console.error("Ошибка при отправке сообщения:", error);
    }
  }
  closeConnection() {
    this.isOpen = false;
    this.stopHeartbeat();
    if (this.socket && this.socket.readyState !== 0) {
      this.socket.close();
    }
  }
  processQueue() {
    while (this.messageQueue.length > 0 && this.socket && this.socket.readyState === WebSocket.OPEN) {
      const par = this.messageQueue.shift();
      this.socket.send(JSON.stringify({ par }));
    }
  }
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $view, $$unsubscribe_view;
  let $ice_conf, $$unsubscribe_ice_conf;
  let $langs, $$unsubscribe_langs;
  let $signal, $$unsubscribe_signal;
  let $dicts, $$unsubscribe_dicts;
  $$unsubscribe_view = subscribe(view, (value) => $view = value);
  $$unsubscribe_ice_conf = subscribe(ice_conf, (value) => $ice_conf = value);
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_signal = subscribe(signal, (value) => $signal = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  let { data } = $$props;
  let operator, abonent, name, user_pic;
  set_store_value(dicts, $dicts = data.dict[0], $dicts);
  function Init() {
    setContext("group_data", data.group);
    setContext("lvl", data.group[0].group);
    setContext("operator", data.operator[0]);
    setContext("abonent", data.abonent);
    operator = data.operator[0].operator, abonent = data.operator[0].abonent, name = data.operator[0].name, user_pic = data.operator ? data.operator[0].picture : "";
    set_store_value(signal, $signal = new SignalingChannel(operator), $signal);
    set_store_value(
      langs,
      $langs = data.cookies ? JSON.parse(data.cookies).lang : data.operator[0].lang,
      $langs
    );
    set_store_value(ice_conf, $ice_conf = data.ice_conf, $ice_conf);
  }
  if (data.operator && data.group.length > 0) {
    Init();
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe_view();
  $$unsubscribe_ice_conf();
  $$unsubscribe_langs();
  $$unsubscribe_signal();
  $$unsubscribe_dicts();
  return `${validate_component(Header, "Header").$$render($$result, {}, {}, {})} ${operator && data?.group?.length > 0 ? `${validate_component(Operator, "Operator").$$render($$result, { operator, abonent, name }, {}, {})}` : `${$view === "login" ? `${validate_component(Login, "Login").$$render($$result, { operator, abonent, user_pic }, {}, {})}` : ``}`}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-5vTtzJze.js.map
