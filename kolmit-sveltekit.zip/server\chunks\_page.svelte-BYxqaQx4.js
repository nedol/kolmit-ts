import { s as subscribe, a as set_store_value } from './utils-DaVwj2Zu.js';
import { c as create_ssr_component, v as validate_component, a as add_attribute, e as escape } from './ssr2-CjWPy-sK.js';
import './client-QR49yHlf.js';
import { T as Textfield, B as Button } from './Textfield-CFaEN1yp.js';
import 'blueimp-load-image/js/load-image.js';
import 'blueimp-load-image/js/load-image-scale.js';
import { l as langs, d as dicts } from './stores-9atq2JWj.js';
import './exports-DVe6os7E.js';
import './index2-Iz8xeDhy.js';

const css = {
  code: "@media screen and (min-width: 768px){input.svelte-1oy5700{padding:8px;font-size:14px}}@media screen and (max-width: 767px){input.svelte-1oy5700{padding:8px;font-size:14px}}form.svelte-1oy5700{display:flex;flex-direction:column;align-items:center;max-width:400px;margin:0 auto;padding:20px;border:1px solid #ccc;border-radius:5px;background-color:#fff}img.svelte-1oy5700{display:block;margin-left:auto;margin-right:auto}input[type='file'].svelte-1oy5700{display:none}#oper_pic.svelte-1oy5700{max-width:100px;max-height:100px;border-radius:50%;cursor:pointer}",
  map: `{"version":3,"file":"Login.svelte","sources":["Login.svelte"],"sourcesContent":["<script>\\r\\n  import { onMount } from 'svelte';\\r\\n  import { applyAction, deserialize } from '$app/forms';\\r\\n\\r\\n  import Button from '@smui/button';\\r\\n  import Textfield from '@smui/textfield';\\r\\n  import loadImage from 'blueimp-load-image/js/load-image.js';\\r\\n  import 'blueimp-load-image/js/load-image-scale.js';\\r\\n  // import SelectMenu from './SelectMenu.svelte';\\r\\n  import { dicts } from '$lib/js/stores.js';\\r\\n\\r\\n  // let operator_svg =\\r\\n  // \\t'https://kolmit-service.onrender.com/_app/immutable/assets/operator.7238a518.svg';\\r\\n\\r\\n  let width, height, value, abonent;\\r\\n  let formData = {\\r\\n    name: '', //'WH',//\\r\\n    email: 'email', //,'white@house.usa'\\r\\n    psw: '', //'test',\\r\\n    confirmPassword: '', //'test',\\r\\n    picture: '',\\r\\n    lang: 'ru', //'en'\\r\\n  };\\r\\n\\r\\n  if (!formData.picture) {\\r\\n    formData.picture = '/assets/operator.svg';\\r\\n  }\\r\\n\\r\\n  let lang = 'en';\\r\\n  $: if (lang) {\\r\\n    formData.lang = lang;\\r\\n  }\\r\\n\\r\\n  let psw;\\r\\n  let confirmPassword; // Поле для повторного ввода пароля\\r\\n  let passwordMatch = true; // Переменная для проверки совпадения паролей\\r\\n\\r\\n  onMount(async () => {\\r\\n    let url = new URL(window.location.href);\\r\\n    abonent = url.searchParams.get('abonent');\\r\\n    // formData.email = url.searchParams.get('user');\\r\\n    // console.log(abonent);\\r\\n    // if (url.searchParams.get('psw')) {\\r\\n    // \\tformData.name = url.searchParams.get('name');\\r\\n    // \\tformData.psw = url.searchParams.get('psw');\\r\\n    // \\tformData.email = url.searchParams.get('email');\\r\\n    // \\tformData.lang = url.searchParams.get('lang');\\r\\n    // \\thandleSubmit();\\r\\n    // }\\r\\n  });\\r\\n\\r\\n  function uploadImage(event) {\\r\\n    const file = event.target.files[0];\\r\\n    if (file) {\\r\\n      loadImage(\\r\\n        file,\\r\\n        function (img, data) {\\r\\n          if (img.type === 'error') {\\r\\n            console.error($dicts['Ошибка загрузки изображения'][lang]);\\r\\n          } else {\\r\\n            width = img.width;\\r\\n            height = img.height;\\r\\n            formData.picture = img.toDataURL();\\r\\n          }\\r\\n        },\\r\\n        {\\r\\n          orientation: true,\\r\\n          maxWidth: 100,\\r\\n          maxHeight: 100,\\r\\n          canvas: true,\\r\\n        }\\r\\n      );\\r\\n    }\\r\\n  }\\r\\n\\r\\n  async function handleSubmit() {\\r\\n    // Здесь вы можете обработать данные формы\\r\\n    let par = formData;\\r\\n    par.email = par.email.trim();\\r\\n    passwordMatch = par.confirmPassword === par.psw;\\r\\n    if (!passwordMatch) return;\\r\\n    par.func = 'operator';\\r\\n    par.abonent = 'public';\\r\\n    const headers = {\\r\\n      'Content-Type': 'application/json',\\r\\n      // Authorization: \`Bearer \${token}\`\\r\\n    };\\r\\n    let res = await fetch(\`/\`, {\\r\\n      method: 'POST',\\r\\n      // mode: 'no-cors',\\r\\n      body: JSON.stringify({ par }),\\r\\n      headers: headers,\\r\\n    });\\r\\n\\r\\n    location.reload();\\r\\n  }\\r\\n<\/script>\\r\\n\\r\\n<form on:submit|preventDefault={handleSubmit}>\\r\\n  <div class=\\"columns margins\\">\\r\\n    <input name=\\"lang\\" value={formData.lang} hidden />\\r\\n    <div>\\r\\n      <Textfield\\r\\n        name=\\"email\\"\\r\\n        bind:value={formData.email}\\r\\n        label=\\"{$dicts['Email'][lang]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"text\\"\\r\\n        name=\\"name\\"\\r\\n        bind:value={formData.name}\\r\\n        label=\\"{$dicts['Имя'][lang]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"password\\"\\r\\n        name=\\"psw\\"\\r\\n        bind:value={formData.psw}\\r\\n        label=\\"{$dicts['Пароль'][lang]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Textfield\\r\\n        type=\\"password\\"\\r\\n        name=\\"confirmPassword\\"\\r\\n        bind:value={formData.confirmPassword}\\r\\n        label=\\"{$dicts['Повторить пароль'][lang]}:\\"\\r\\n        required\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div style=\\"padding-top: 20px\\">\\r\\n      <input\\r\\n        type=\\"file\\"\\r\\n        id=\\"pic\\"\\r\\n        on:change={uploadImage}\\r\\n        accept=\\"image/png, image/jpeg\\"\\r\\n      />\\r\\n\\r\\n      <img\\r\\n        type=\\"image\\"\\r\\n        id=\\"oper_pic\\"\\r\\n        src={formData.picture}\\r\\n        on:click={() => document.getElementById('pic').click()}\\r\\n      />\\r\\n    </div>\\r\\n\\r\\n    <div>\\r\\n      <Button class=\\"upload-button\\">{$dicts['Зарегистрироваться'][lang]}</Button\\r\\n      >\\r\\n    </div>\\r\\n  </div>\\r\\n</form>\\r\\n<!-- <SelectMenu bind:lang /> -->\\r\\n\\r\\n{#if !passwordMatch}\\r\\n  <p style=\\"color: red;\\">{$dicts['Пароли не совпадают'][lang]}</p>\\r\\n{/if}\\r\\n\\r\\n<figure>\\r\\n  <img\\r\\n    src=\\"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSEhIVFRUVFRUVFRUVFRUVEhUVFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABIEAACAQMCBAQDBwMDBQAAAAAAAQIDBBEFEiExQRMiUWFxgZGhBhShwTJCUrHBFiMkYoKSotEjJTM0Q1Nys9Hw/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/EACwRAAICAgEDAwMEAwAAAAAAAAABAhEDIQQSMUFRE2FxkaEGIjKRobHB0fDx/9oADAMBAAIRAxEAPwD5iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\\"\\r\\n  />\\r\\n</figure>\\r\\n\\r\\n<style>\\r\\n  /* Стили для мобильных устройств */\\r\\n\\r\\n  /* Стили для более крупных экранов */\\r\\n  @media screen and (min-width: 768px) {\\r\\n    /* Ваши стили для более крупных экранов здесь */\\r\\n    button {\\r\\n      padding: 6px 10px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n\\r\\n    input {\\r\\n      padding: 8px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n  }\\r\\n  /* Стили для мобильных устройств */\\r\\n  @media screen and (max-width: 767px) {\\r\\n    button {\\r\\n      padding: 6px 10px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n\\r\\n    input {\\r\\n      padding: 8px;\\r\\n      font-size: 14px;\\r\\n    }\\r\\n  }\\r\\n\\r\\n  /* CSS стили для формы регистрации */\\r\\n  form {\\r\\n    display: flex;\\r\\n    flex-direction: column;\\r\\n    align-items: center;\\r\\n    max-width: 400px;\\r\\n    margin: 0 auto;\\r\\n    padding: 20px;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 5px;\\r\\n    background-color: #fff;\\r\\n  }\\r\\n\\r\\n  img {\\r\\n    display: block;\\r\\n    margin-left: auto;\\r\\n    margin-right: auto;\\r\\n  }\\r\\n\\r\\n  label {\\r\\n    font-weight: bold;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  input[type='email'],\\r\\n  input[type='text'],\\r\\n  input[type='psw'] {\\r\\n    width: 100%;\\r\\n    padding: 10px;\\r\\n    margin: 5px 0;\\r\\n    border: 1px solid #ccc;\\r\\n    border-radius: 5px;\\r\\n  }\\r\\n\\r\\n  input[type='file'] {\\r\\n    display: none;\\r\\n  }\\r\\n\\r\\n  .container {\\r\\n    text-align: center;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n\\r\\n  #oper_pic {\\r\\n    max-width: 100px;\\r\\n    max-height: 100px;\\r\\n    border-radius: 50%;\\r\\n    cursor: pointer;\\r\\n  }\\r\\n\\r\\n  .upload-button {\\r\\n    background-color: #0078d4;\\r\\n    color: #fff;\\r\\n    border: none;\\r\\n    padding: 10px 20px;\\r\\n    border-radius: 5px;\\r\\n    cursor: pointer;\\r\\n    margin-top: 10px;\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAkLE,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAOnC,oBAAM,CACJ,OAAO,CAAE,GAAG,CACZ,SAAS,CAAE,IACb,CACF,CAEA,OAAO,MAAM,CAAC,GAAG,CAAC,YAAY,KAAK,CAAE,CAMnC,oBAAM,CACJ,OAAO,CAAE,GAAG,CACZ,SAAS,CAAE,IACb,CACF,CAGA,mBAAK,CACH,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,SAAS,CAAE,KAAK,CAChB,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,IAAI,CACtB,aAAa,CAAE,GAAG,CAClB,gBAAgB,CAAE,IACpB,CAEA,kBAAI,CACF,OAAO,CAAE,KAAK,CACd,WAAW,CAAE,IAAI,CACjB,YAAY,CAAE,IAChB,CAiBA,KAAK,CAAC,IAAI,CAAC,MAAM,gBAAE,CACjB,OAAO,CAAE,IACX,CAOA,wBAAU,CACR,SAAS,CAAE,KAAK,CAChB,UAAU,CAAE,KAAK,CACjB,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,OACV"}`
};
let lang = "en";
const Login = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $dicts, $$unsubscribe_dicts;
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  let formData = {
    name: "",
    //'WH',//
    email: "email",
    //,'white@house.usa'
    psw: "",
    //'test',
    confirmPassword: "",
    //'test',
    picture: "",
    lang: "ru"
    //'en'
  };
  if (!formData.picture) {
    formData.picture = "/assets/operator.svg";
  }
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    {
      {
        formData.lang = lang;
      }
    }
    $$rendered = `<form class="svelte-1oy5700"><div class="columns margins"><input name="lang"${add_attribute("value", formData.lang, 0)} hidden class="svelte-1oy5700"> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        name: "email",
        label: $dicts["Email"][lang] + ":",
        required: true,
        value: formData.email
      },
      {
        value: ($$value) => {
          formData.email = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "text",
        name: "name",
        label: $dicts["Имя"][lang] + ":",
        required: true,
        value: formData.name
      },
      {
        value: ($$value) => {
          formData.name = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "password",
        name: "psw",
        label: $dicts["Пароль"][lang] + ":",
        required: true,
        value: formData.psw
      },
      {
        value: ($$value) => {
          formData.psw = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div>${validate_component(Textfield, "Textfield").$$render(
      $$result,
      {
        type: "password",
        name: "confirmPassword",
        label: $dicts["Повторить пароль"][lang] + ":",
        required: true,
        value: formData.confirmPassword
      },
      {
        value: ($$value) => {
          formData.confirmPassword = $$value;
          $$settled = false;
        }
      },
      {}
    )}</div> <div style="padding-top: 20px"><input type="file" id="pic" accept="image/png, image/jpeg" class="svelte-1oy5700"> <img type="image" id="oper_pic"${add_attribute("src", formData.picture, 0)} class="svelte-1oy5700"></div> <div>${validate_component(Button, "Button").$$render($$result, { class: "upload-button" }, {}, {
      default: () => {
        return `${escape($dicts["Зарегистрироваться"][lang])}`;
      }
    })}</div></div></form>  ${``} <figure data-svelte-h="svelte-1abp56j"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSEhIVFRUVFRUVFRUVFRUVEhUVFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABIEAACAQMCBAQDBwMDBQAAAAAAAQIDBBEFEiExQRMiUWFxgZGhBhShwTJCUrHBFiMkYoKSotEjJTM0Q1Nys9Hw/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/EACwRAAICAgEDAwMEAwAAAAAAAAABAhEDIQQSMUFRE2FxkaEGIjKRobHB0fDx/9oADAMBAAIRAxEAPwD5iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" class="svelte-1oy5700"> </figure>`;
  } while (!$$settled);
  $$unsubscribe_dicts();
  return $$rendered;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $langs, $$unsubscribe_langs;
  let $dicts, $$unsubscribe_dicts;
  $$unsubscribe_langs = subscribe(langs, (value) => $langs = value);
  $$unsubscribe_dicts = subscribe(dicts, (value) => $dicts = value);
  let { data } = $$props;
  let operator = data.operator, abonent = data.abonent;
  data.name;
  if (data.lang) set_store_value(langs, $langs = data.lang, $langs);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    if (data.dict[0]) {
      set_store_value(dicts, $dicts = data.dict[0], $dicts);
    }
  }
  $$unsubscribe_langs();
  $$unsubscribe_dicts();
  return `${validate_component(Login, "Login").$$render($$result, { operator, abonent }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BYxqaQx4.js.map
