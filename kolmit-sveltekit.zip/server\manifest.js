const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/audio/Dialoog op restaurant.mp3","assets/audio/Een recept.mp3","assets/audio/Gezonde of ongezonde snacks.mp3","assets/audio/Het opsporingsbericht.mp3","assets/audio/Het opspringsbericht.2.mp3","assets/audio/online.dialog.2.mp4","assets/audio/Petra in de kledingwinkel.mp3","assets/audio/radionieuws_11.11.24.mp3","assets/audio/radionieuws_17.11.24.mp3","assets/audio/untitle.mp3","assets/audio/Wim Slabbinck.mp3","assets/audio/word.1.mp3","assets/audio/word.2.mp3","assets/content_ru.json","assets/img/check_quiz.png","assets/img/counter.png","assets/img/demo.png","assets/img/dialog.png","assets/img/lesson.png","assets/img/lesson.quizes.png","assets/img/lesson.theme","assets/img/login.png","assets/img/main.png","assets/img/phone.active.png","assets/img/phone.call.png","assets/img/phone.inactive.png","assets/img/phone.talk.png","assets/img/registry.png","assets/img/word.png","assets/operator.svg","assets/video/dialog.mp4","assets/video/lang.mp4","assets/video/online.dialog.2.mp4","assets/video/online.dialog.mp4","assets/video/online.word.mp4","assets/video/registry.mp4","assets/video/themes.mp4","assets/video/words.mp4","docs/Kolmit.txt","favicon.png","html/howto.html","html/howto.ru.html","html/howto.uk.html","test.html"]),
	mimeTypes: {".mp3":"audio/mpeg",".mp4":"video/mp4",".json":"application/json",".png":"image/png",".svg":"image/svg+xml",".txt":"text/plain",".html":"text/html"},
	_: {
		client: {start:"_app/immutable/entry/start.cjD_4uJJ.js",app:"_app/immutable/entry/app.tUm00ZaY.js",imports:["_app/immutable/entry/start.cjD_4uJJ.js","_app/immutable/chunks/CjtaZ3kr.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/entry/app.tUm00ZaY.js","_app/immutable/chunks/BFS4dl8i.js","_app/immutable/chunks/B2NxKjp4.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-CeMV52Jh.js')),
			__memo(() => import('./chunks/1-BgKJlv9T.js')),
			__memo(() => import('./chunks/2-wrRxY3Nd.js')),
			__memo(() => import('./chunks/3-C0Vme7Cj.js')),
			__memo(() => import('./chunks/4-BlllniKb.js')),
			__memo(() => import('./chunks/5-BKQqXQJb.js')),
			__memo(() => import('./chunks/6-DX18sFrP.js')),
			__memo(() => import('./chunks/7-ByV8a7M5.js')),
			__memo(() => import('./chunks/8-B6Rdxdfz.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: __memo(() => import('./chunks/_server-CxMg-Iuu.js'))
			},
			{
				id: "/admin",
				pattern: /^\/admin\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: __memo(() => import('./chunks/_server.ts-xCNL1BbG.js'))
			},
			{
				id: "/admin/group",
				pattern: /^\/admin\/group\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-UWau1V19.js'))
			},
			{
				id: "/admin/login",
				pattern: /^\/admin\/login\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-BfYtzkJY.js'))
			},
			{
				id: "/admin/module",
				pattern: /^\/admin\/module\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-UpMOZ27J.js'))
			},
			{
				id: "/admin/quiz/dialog",
				pattern: /^\/admin\/quiz\/dialog\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server.ts-DDYGFsiK.js'))
			},
			{
				id: "/lesson",
				pattern: /^\/lesson\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: __memo(() => import('./chunks/_server-CWXP8ofz.js'))
			},
			{
				id: "/operator",
				pattern: /^\/operator\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-CzHK98vu.js'))
			},
			{
				id: "/operator/chat",
				pattern: /^\/operator\/chat\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Bk4cZD5p.js'))
			},
			{
				id: "/public",
				pattern: /^\/public\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/site",
				pattern: /^\/site\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/site/about",
				pattern: /^\/site\/about\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/speech/stt",
				pattern: /^\/speech\/stt\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-B1YbvtEs.js'))
			},
			{
				id: "/speech/tts",
				pattern: /^\/speech\/tts\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-DikioXEk.js'))
			},
			{
				id: "/translate",
				pattern: /^\/translate\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-CUphjZHb.js'))
			},
			{
				id: "/user",
				pattern: /^\/user\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-BJ9h46QD.js'))
			},
			{
				id: "/user/group",
				pattern: /^\/user\/group\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-BrA9W1X-.js'))
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
