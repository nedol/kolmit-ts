import pkg from 'lodash';
import md5 from 'md5';
import postgres from 'postgres';
import { s as sql_st } from './stores-9atq2JWj.js';
import './index-BIAFQWR9.js';
import nodemailer from 'nodemailer';
import { HttpsProxyAgent } from 'https-proxy-agent';
import translatex from 'google-translate-api-x';
import { translate } from 'deeplx';

const langs = [
  "bg",
  "cs",
  "da",
  "de",
  "el",
  "en",
  "es",
  "et",
  "fi",
  "fr",
  "hu",
  "id",
  "it",
  "ja",
  "ko",
  "lt",
  "lv",
  "nb",
  "nl",
  "pl",
  "pt",
  "ro",
  "ru",
  "sk",
  "sl",
  "sv",
  "zh"
];
async function Translate(text, from, to) {
  if (!text) return "";
  text = text.replace(/\r\n/g, " ");
  const sentences = text.split(/(?<=[.!?])\s+/);
  let translatedText = "";
  for (let i = 0; i < sentences.length; i += 5) {
    const chunkGroup = sentences.slice(i, i + 5).join(" ").trim();
    if (!chunkGroup || chunkGroup == '"') continue;
    let chunk = chunkGroup.replaceAll('"', "");
    let res = "";
    const hasQuotes = chunk.includes("<<");
    if (hasQuotes) {
      chunk = chunk.replace(/<</g, " ").replace(/>>/g, " ");
    }
    const resp = await ReadSpeech({ lang: to, key: md5(chunk) });
    if (resp?.translate) {
      try {
        console.log(`Файл уже существует`);
        return resp.translate;
      } catch (error) {
        console.error("Error converting text to speech:", error);
      }
    } else {
      console.log(`Файл  НЕ существует`);
      try {
        if (langs.includes(to)) {
          res = await translate(chunk, to.toUpperCase());
        } else {
          const en = await translate(chunk, "EN");
          res = await translatex(en, {
            from: "en",
            to,
            forceBatch: true,
            requestOptions: {
              agent: new HttpsProxyAgent("https://164.132.175.159:3128")
            }
          });
          res = res.text;
        }
        WriteSpeech({ lang: to, key: md5(text), text, translate: res });
      } catch (error) {
        res = chunk;
      }
    }
    translatedText += `${res} `;
  }
  return translatedText.trim();
}
class Email {
  constructor() {
    this.transporter = nodemailer.createTransport({
      service: "gmail",
      port: 465,
      secure: true,
      // upgrade later with STARTTLS
      auth: {
        user: "kolmit.be@gmail.com",
        pass: "zsfz xbhd iwax jvxj"
      }
      // auth: {
      //   user: 'nedooleg@gmail.com',
      //   pass: 'gytn jkgk ucll koig',
      // },
    });
  }
  SendMail(to, subj, html, cb) {
    let mailOptions = {
      from: "kolmit.be@gmail.com",
      //from, //'youremail@gmail.com',
      to,
      //'myfriend@yahoo.com',
      subject: subj,
      html
    };
    this.transporter.sendMail(mailOptions, function(error, info) {
      if (error) {
        cb({ error });
        console.log(error);
      } else {
        cb("Email sent to: " + to + info.response);
        console.log("Email sent to: " + to + info.response);
      }
    });
  }
}
const { find, remove, findIndex, difference } = pkg;
let sql;
sql_st.subscribe((data) => {
  sql = data;
});
let { PGHOST, PGDATABASE, PGUSER, PGPASSWORD, ENDPOINT_ID } = process.env;
let conStrNeon = {
  connectionString: "postgresql://nedooleg:nHLhfQB0WS5Y@ep-polished-bush-a2n4g5y9-pooler.eu-central-1.aws.neon.tech:5432/neondb?sslmode=require"
};
async function CreatePool_neon() {
  sql_st.set(postgres(conStrNeon.connectionString, {
    host: "ep-polished-bush-a2n4g5y9-pooler.eu-central-1.aws.neon.tech",
    // Postgres ip address[s] or domain name[s]
    port: 5432,
    // Postgres server port[s]
    database: "neondb",
    // Name of database to connect to
    username: "nedooleg",
    // Username of database user
    password: "nHLhfQB0WS5Y"
    // Password of database user
  }));
}
async function SendEmail(q) {
  let operator = new Email();
  const { abonent, send_email: mail, lang, name } = q;
  const helpLink = `https://kolmit.onrender.com/html/howto.${lang}.html`;
  const link = `https://kolmit.onrender.com/?abonent=${abonent}&user=${mail}`;
  const subject = await Translate("Приглашение присоединиться к приложению Kolmit", "ru", lang);
  const html = `
  <div style="font-family: Arial, sans-serif; color: #333; line-height: 1.6; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
    <h2 style="color: #007BFF;">${await Translate("Здравствуйте", "ru", lang)} ${name}!</h2>
    ${await Translate(
    `<p>Спасибо, что выбрали <strong>Kolmit</strong> для изучения иностранных языков! Мы рады приветствовать вас в нашем сообществе.</p>
    <p>Для входа в приложение используйте следующую ссылку:</p>`,
    "ru",
    lang
  )}
    <p style="text-align: center;">
      <a href="${link}" style="background-color: #007BFF; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
        👉 ${await Translate("Войти в Kolmit", "ru", lang)}
      </a>
    </p>
    ${await Translate("<p>Для получения помощи по работе с приложением ознакомьтесь с инструкцией по ссылке ниже:</p>", "ru", lang)}
    <p style="text-align: center;">
      <a href="${helpLink}" style="color: #007BFF; text-decoration: underline;">
        📖 ${await Translate("Инструкция по работе с приложением", "ru", lang)}
      </a>
    </p>
    ${await Translate(`<p>Удачи в изучении языков и увлекательного обучения!</p><p>С уважением,</p>`, "ru", lang)}
   
    <p><strong>${await Translate("Команда Kolmit</strong></p>", "ru", lang)}
    <p style="font-size: 0.9em; color: #666;">kolmit.be@gmail.com</p>
  </div>
`;
  operator.SendMail(
    mail,
    subject,
    html,
    (result) => {
      console.log("Письмо успешно отправлено:", result);
    }
  );
}
async function CreateOperator(par) {
  try {
    let res = await sql` 
		UPDATE operators 
		SET
		name = ${par.name},
    email = ${par.email},
		operator = ${md5(par.email)}, 
		psw = ${md5(par.psw)}, 
		picture = ${par.picture} 
		WHERE email = ${par.email} AND abonent=${par.abonent}
		`;
    return {
      operator: md5(par.email),
      name: par.name,
      email: par.email,
      psw: md5(par.psw),
      lang: par.lang
    };
  } catch (er) {
    console.log(er);
  }
}
async function CreateSession(oper, suid) {
  await sql` 
    SELECT create_session(${oper}, ${suid})
  `;
}
async function GetGroup(par) {
  const group = await sql`
			SELECT "group", abonent, role, operator, picture, lang, name
      	FROM operators
        WHERE operators.abonent=${par.abonent} 
        AND  operators.operator=${par.operator}
        AND operators.group=(
        SELECT "group" FROM operators
        WHERE operators.abonent=${par.abonent} 
        AND operator=${par.operator} AND psw=${par.psw}
      )`;
  if (group) {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    CreateSession(par.operator, md5(par.operator + timestamp));
  }
  const oper = await sql`
			SELECT 
			"group", abonent, role, operator, picture, lang, name
			FROM operators
			WHERE operators.abonent=${par.abonent} AND operator=${par.operator}
      `;
  return { group, oper };
}
async function GetUsers(par) {
  let operators, admin = "";
  try {
    if (par.abonent) {
      operators = await sql`
			SELECT 
			*,
			operator as email
			FROM operators
			WHERE role<>'admin' AND operators.abonent=${par.abonent} AND
      operators.group = (
          SELECT operators.group
          FROM operators
          WHERE operators.operator=${par.operator} AND operators.abonent=${par.abonent} 
      )
      `;
      admin = await sql`
			SELECT 
			*,
			operator as email
			FROM operators
			WHERE role='admin' AND operators.abonent=${par.abonent}
			`;
    }
  } catch (ex) {
    console.log();
  }
  return { operators, admin };
}
async function CheckOperator(q) {
  let result;
  if (q.psw && q.operator) {
    try {
      await sql`
			INSERT INTO operators (psw, operator, abonent,  name) VALUES(${q.psw}, ${q.operator}, 
			, ${q.name})`;
    } catch (ex) {
    }
  }
  if (q.operator) {
    if (q.abonent) {
      result = await sql`
			SELECT * FROM  operators WHERE operator=${q.operator} AND abonent=${q.abonent} AND psw=${q.psw}`;
    } else {
      result = result;
      await sql`
			SELECT * FROM  operators WHERE operator=${q.operator} AND abonent=${q.abonent} AND psw=${q.psw}`;
    }
    result = result;
    if (result[0]) {
      if (q.psw == result[0].psw) {
        return {
          func: q.func,
          check: true
        };
      } else {
        return JSON.stringify({ func: q.func, check: false });
      }
    } else {
      return JSON.stringify({ func: q.func, check: false });
    }
  } else {
    result = await sql`
		SELECT * FROM  operators WHERE operator=${q.operator}`;
    return result;
  }
}
async function GetListen(q) {
  try {
    let res = await sql`SELECT * FROM listen
		WHERE name= ${q.name} AND lang=${q.lang}`;
    return { data: res[0].data, html: res[0].html };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function GetWords(q) {
  try {
    let res = await sql`SELECT data, context, subscribe  FROM word
		WHERE name=${q.name} AND owner=${q.owner} AND level=${q.level}`;
    return res[0];
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function GetBricks(q) {
  try {
    let res = await sql`SELECT * FROM bricks
		WHERE name=${q.name} AND owner=${q.owner} AND level=${q.level}`;
    return res[0];
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function GetDialog(q) {
  try {
    let res = await sql`SELECT dialog, html, subscribe FROM dialogs
		WHERE name=${q.name} AND owner=${q.owner} AND level=${q.level}`;
    return {
      dialog: res[0].dialog,
      html: res[0].html || "",
      subscribe: res[0].subscribe
    };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function GetPrompt(name) {
  let prompt = await sql`SELECT system, user FROM prompts
		WHERE name=${name}`;
  return {
    prompt: prompt[0]
  };
}
async function getLevels(owner) {
  const levels = await sql`SELECT level FROM lessons WHERE owner=${owner}`;
  return levels.map((item) => {
    return item.level;
  });
}
async function GetLesson(q) {
  try {
    let res = "";
    if (q.operator !== q.owner) {
      res = await sql`
      SELECT lessons.data, lessons.level, lessons.lang 
        FROM lessons
        JOIN operators ON (operators.operator = ${q.operator} and operators.abonent=${q.owner})
        JOIN groups ON (groups.name = operators.group and groups.level=lessons.level)
        WHERE  groups.owner=${q.owner} AND lessons.owner=${q.owner}
        ORDER BY level desc`;
    } else if (q.level) {
      res = await sql`SELECT data, level, lang FROM lessons WHERE owner=${q.owner} AND level=${q.level}  ORDER BY level desc`;
    } else {
      res = await sql`SELECT data, level, lang FROM lessons WHERE owner=${q.owner}  ORDER BY level desc`;
    }
    const levels = await getLevels(q.owner);
    const les = find(res, { level: q.level });
    return {
      data: les ? les.data : res[0].data,
      lang: les?.lang ? les.lang : res[0].lang,
      level: les?.level ? les.level : res[0].level,
      levels
    };
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function UpdateQuizUsers(q) {
  let res;
  try {
    if (q.type == "dialog")
      res = await sql`SELECT subscribe FROM dialogs WHERE name = ${q.quiz} AND owner = ${q.abonent}`;
    else if (q.type == "word")
      res = await sql`SELECT subscribe FROM word WHERE name = ${q.quiz} AND owner = ${q.abonent}`;
    let qu = res[0]?.subscribe || [];
    if (q.add) {
      qu.push(q.add);
    } else if (q.rem) {
      let index = qu.indexOf(q.rem);
      if (index > -1) {
        qu.splice(index, 1);
      }
    }
    if (q.type == "dialog")
      res = await sql`UPDATE dialogs 
                    SET subscribe = ${sql.json(
        qu
      )} -- используем JSON для PostgreSQL
                    WHERE name = ${q.quiz} AND owner = ${q.abonent}`;
    else if (q.type == "word")
      res = await sql`UPDATE word 
                    SET subscribe = ${sql.json(
        qu
      )} -- используем JSON для PostgreSQL
                    WHERE name = ${q.quiz} AND owner = ${q.abonent}`;
    return qu;
  } catch (ex) {
    console.log(ex);
    throw ex;
  }
}
async function GetDict(q) {
  try {
    let res = await sql`SELECT words FROM dicts
		WHERE type=${q.type} AND level= ${q.level}  AND owner=${q.owner}`;
    if (res[0]) return res[0].words;
    else return res;
  } catch (ex) {
    return JSON.stringify({ func: q.func, res: ex });
  }
}
async function WriteSpeech(q) {
  try {
    await sql.begin(async (sql2) => {
      await sql2`INSERT INTO speech (lang, key, text, translate)
                VALUES (${q.lang}, ${q.key}, ${q.text}, ${q.translate})
                ON CONFLICT (key, lang) 
                DO UPDATE SET 
                  lang=EXCLUDED.lang,
                  translate = EXCLUDED.translate`;
    });
    return { success: true, message: "Data written successfully." };
  } catch (ex) {
    console.error("Error writing speech:", ex);
    return { success: false, message: "Failed to write data.", error: ex };
  }
}
async function ReadSpeech(q) {
  try {
    let res = await sql`SELECT translate FROM speech
                        WHERE key = ${q.key} AND lang = ${q.lang}`;
    if (res[0]) {
      return res[0];
    } else {
      return null;
    }
  } catch (ex) {
    console.error("Database query failed:", ex);
    return { error: "Database query failed" };
  }
}

export { CreatePool_neon as C, GetGroup as G, SendEmail as S, Translate as T, UpdateQuizUsers as U, CheckOperator as a, CreateOperator as b, GetUsers as c, GetDict as d, GetWords as e, GetBricks as f, getLevels as g, GetDialog as h, GetLesson as i, GetListen as j, GetPrompt as k };
//# sourceMappingURL=db-LknqzByu.js.map
