import { b as CreateAdmin } from './db.admin-BSGKTkbW.js';
import 'md5';
import './db-LknqzByu.js';
import 'lodash';
import 'postgres';
import './stores-9atq2JWj.js';
import './index2-Iz8xeDhy.js';
import './utils-DaVwj2Zu.js';
import './index-BIAFQWR9.js';
import 'nodemailer';
import 'https-proxy-agent';
import 'google-translate-api-x';
import 'deeplx';

async function POST({ request, url, fetch, cookies }) {
  const { par } = await request.json();
  const resp = await CreateAdmin(par);
  if (resp) {
    cookies.set(
      `kolmit.admin.${resp.operator}`,
      JSON.stringify({
        name: resp.name,
        operator: resp.operator,
        abonent: resp.operator,
        psw: resp.psw,
        lang: "en"
      }),
      {
        path: "/",
        maxAge: 60 * 60 * 24 * 400
      }
    );
  }
  let response = new Response(JSON.stringify({ resp }));
  response.headers.append("Access-Control-Allow-Origin", `*`);
  return response;
}

export { POST };
//# sourceMappingURL=_server-BfYtzkJY.js.map
